"""API/grammar research only: not a platform reader, service, validator or test suite."""
from pathlib import Path
from io import BytesIO
import hashlib,json,re,sys,xml.etree.ElementTree as ET
from rdkit import Chem,rdBase,RDConfig
from rdkit.Chem import rdDepictor,rdMolDescriptors,Lipinski,Crippen
from rdkit.Chem.Draw import rdMolDraw2D
ROOT=Path(__file__).resolve().parent
RAW=ROOT.parents[1]/'academic_rehearsal_20261019/examples/caffeine-demo/inputs/ligands'
def sha(b):return hashlib.sha256(b).hexdigest()
def smiles_probe(data):
    text=data.decode('ascii')
    if text.endswith('\r\n'):text=text[:-2]
    elif text.endswith('\n'):text=text[:-1]
    if not text or any(c.isspace() or ord(c)<33 or ord(c)==127 for c in text):raise ValueError('single token required')
    p=Chem.SmilesParserParams();p.sanitize=True;p.removeHs=False;p.parseName=False;p.allowCXSMILES=False
    with rdBase.BlockLogs():m=Chem.MolFromSmiles(text,p)
    if m is None:raise ValueError('invalid SMILES')
    return m
def sdf_probe(data):
    data.decode('utf-8',errors='strict')
    if data.startswith(b'\xef\xbb\xbf') or b'\x00' in data:raise ValueError('BOM or NUL')
    lines=data.splitlines(keepends=True)
    delimiters=[i for i,x in enumerate(lines) if x.rstrip(b'\r\n')==b'$$$$']
    if len(delimiters)!=1:raise ValueError('exactly one physical record required')
    tail=b''.join(lines[delimiters[0]+1:])
    if tail:raise ValueError('extra content after final delimiter line')
    with rdBase.BlockLogs():mols=list(Chem.ForwardSDMolSupplier(BytesIO(data),sanitize=True,removeHs=False,strictParsing=True))
    if len(mols)!=1 or mols[0] is None:raise ValueError('one valid record required')
    return mols[0]
font=Path(RDConfig.RDDataDir)/'Fonts'/'Telex-Regular.ttf'
def draw(m):
    original=Chem.MolToMolBlock(m)
    cp=Chem.Mol(m)
    # Omit untrusted presentation annotations only, never structural atom fields.
    for x in [cp,*cp.GetAtoms(),*cp.GetBonds()]:
        for key in ['atomLabel','_displayLabel','_displayLabelW','molFileAlias','atomNote','bondNote','_MolFileRLabel']:
            if x.HasProp(key):x.ClearProp(key)
    rdDepictor.Compute2DCoords(cp,canonOrient=True,clearConfs=True,nFlipsPerSample=0,nSample=0,sampleSeed=0,permuteDeg4Nodes=False,forceRDKit=True,useRingTemplates=False)
    semantic_before=Chem.MolToSmiles(cp,canonical=True,isomericSmiles=True)
    atoms_before=[(a.GetAtomicNum(),a.GetIsotope(),a.GetFormalCharge()) for a in cp.GetAtoms()]
    cp=rdMolDraw2D.PrepareMolForDrawing(cp,kekulize=False,addChiralHs=False,wedgeBonds=True,forceCoords=False,wavyBonds=False)
    assert Chem.MolToSmiles(cp,canonical=True,isomericSmiles=True)==semantic_before,(semantic_before,Chem.MolToSmiles(cp,canonical=True,isomericSmiles=True))
    assert [(a.GetAtomicNum(),a.GetIsotope(),a.GetFormalCharge()) for a in cp.GetAtoms()]==atoms_before
    d=rdMolDraw2D.MolDraw2DSVG(600,400)
    opt=d.drawOptions();opt.prepareMolsBeforeDrawing=False;opt.fontFile=str(font);opt.includeMetadata=False;opt.includeAtomTags=False
    opt.addAtomIndices=False;opt.addBondIndices=False
    d.DrawMolecule(cp,legend='');d.FinishDrawing();svg=d.GetDrawingText()
    assert Chem.MolToMolBlock(m)==original
    root=ET.fromstring(svg)
    return svg,sorted({n.tag for n in root.iter()}),sorted({k for n in root.iter() for k in n.attrib})
rows=[]
for p in sorted(RAW.glob('*/*.sdf')):
    b=p.read_bytes();m=sdf_probe(b);svg,tags,attrs=draw(m)
    name=p.parent.name+'.svg';(ROOT/name).write_text(svg,encoding='utf-8')
    rows.append({'input':p.parent.name,'input_sha256':sha(b),'bytes':len(b),'atoms':m.GetNumAtoms(),'bonds':m.GetNumBonds(),'svg_sha256':sha(svg.encode()),'svg_bytes':len(svg.encode()),'svg_tags':tags,'svg_attributes':attrs,'input_unchanged':p.read_bytes()==b,'svg_repeat_equal':draw(m)[0]==svg})
cases=[]
for text,valid in [(b'CCO',True),(b'CCO\n',True),(b'CCO\r\n',True),(b'CCO ethanol',False),(b' CCO',False),(b'CCO ',False),(b'CCO\n\n',False),(b'CCO\r',False),(b'CCO\nN',False),(b'\xef\xbb\xbfCCO',False),(b'CCO\x00',False),(b'CCO |atomProp:0.foo.bar|',False),(b'C[13CH3]',True),(b'[2H]OC',True),(b'N[C@@H](C)C(=O)O',True),(b'[NH4+]',True),(b'CC(=O)[O-]',True)]:
    try:m=smiles_probe(text);ok=True;extra={'canonical':Chem.MolToSmiles(m,isomericSmiles=True),'formula':rdMolDescriptors.CalcMolFormula(m,separateIsotopes=True,abbreviateHIsotopes=False)}
    except (ValueError,UnicodeError) as e:ok=False;extra={'error':type(e).__name__}
    assert ok==valid
    cases.append({'bytes_repr':repr(text),'expected_accept':valid,'observed_accept':ok,**extra})
base=Chem.MolToMolBlock(Chem.MolFromSmiles('CO')).encode()+b'\n$$$$\n'
sdfcases=[]
for label,data,valid in [('one-v2000',base,True),('one-v3000',Chem.MolToMolBlock(Chem.MolFromSmiles('CO'),forceV3000=True).encode()+b'\n$$$$\n',True),('two-records',base+base,False),('valid-plus-invalid',base+b'invalid\n$$$$\n',False),('invalid-plus-valid',b'invalid\n$$$$\n'+base,False),('tail-garbage',base+b'secret',False),('tail-whitespace',base+b' \r\n\t',False),('missing-terminator',base.replace(b'$$$$\n',b''),False)]:
    try:sdf_probe(data);ok=True
    except ValueError:ok=False
    assert ok==valid,(label,ok,valid);sdfcases.append({'case':label,'expected_accept':valid,'observed_accept':ok})
probes=[]
for s in ['CN','N','NCCN']:
    m=smiles_probe(s.encode());probes.append({'smiles':s,'CalcNumHBD':rdMolDescriptors.CalcNumHBD(m),'NumHDonors':Lipinski.NumHDonors(m),'NHOHCount':Lipinski.NHOHCount(m)})
labelm=smiles_probe(b'CO');labelm.GetAtomWithIdx(0).SetProp('atomLabel','<script>UNTRUSTED_020A</script>');labelm.GetAtomWithIdx(0).SetProp('atomNote','UNTRUSTED_020A');labelm.SetProp('_Name','UNTRUSTED_020A')
labelsvg=draw(labelm)[0];assert 'UNTRUSTED_020A' not in labelsvg
additional=[]
for s in ['[2H]OC','C[13CH3]','[NH4+]','CC(=O)[O-]','N[C@@H](C)C(=O)O','F/C=C/F','[CH3]','[Na+]','c1ccncc1']:
    svg,tags,attrs=draw(smiles_probe(s.encode()))
    additional.append({'smiles':s,'tags':tags,'attributes':attrs,'svg_sha256':sha(svg.encode())})
out={'python':sys.version,'platform':sys.platform,'rdkit_version':rdBase.rdkitVersion,'scope':'Isolated grammar/API research. No production implementation, Windows filesystem validation or pytest execution.','raw_examples':rows,'smiles_cases':cases,'sdf_cases':sdfcases,'hbd_discriminating_cases':probes,'additional_drawing_cases':additional,'constructor_docstring':Chem.ForwardSDMolSupplier.__init__.__doc__,'Crippen_has_CalcCrippenDescriptors':hasattr(Crippen,'CalcCrippenDescriptors'),'rdMolDescriptors_has_CalcCrippenDescriptors':hasattr(rdMolDescriptors,'CalcCrippenDescriptors'),'font_filename':font.name,'font_sha256':sha(font.read_bytes()),'hostile_display_labels_absent':True,'drawing_preparation':{'kekulize':False,'addChiralHs':False,'wedgeBonds':True,'forceCoords':False,'wavyBonds':False,'prepareMolsBeforeDrawing':False},'drawing_graph_signature_checks_passed':True}
(ROOT/'profile-probe-results.json').write_text(json.dumps(out,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
print(json.dumps({'raw_examples':len(rows),'smiles_cases':len(cases),'sdf_cases':len(sdfcases),'rdkit_version':rdBase.rdkitVersion,'tags':sorted({x for r in rows for x in r['svg_tags']}),'attributes':sorted({x for r in rows for x in r['svg_attributes']}),'largest_input':max(r['bytes'] for r in rows),'largest_svg':max(r['svg_bytes'] for r in rows),'font_sha256':out['font_sha256'],'hbd':probes},indent=2))
