import inspect,json,platform,hashlib
from pathlib import Path
from rdkit import Chem,rdBase
from rdkit.Chem import Lipinski,rdMolDescriptors,Crippen
source=inspect.getsource(Lipinski)
rows=[]
for s in ['CN','N','NCCN','CO','CC(=O)N','c1ccncc1']:
 m=Chem.MolFromSmiles(s)
 r={'smiles':s,'CalcNumHBD':rdMolDescriptors.CalcNumHBD(m),'NumHDonors':Lipinski.NumHDonors(m),'CalcNumHBA':rdMolDescriptors.CalcNumHBA(m),'NumHAcceptors':Lipinski.NumHAcceptors(m),'NHOHCount':Lipinski.NHOHCount(m),'NOCount':Lipinski.NOCount(m)}
 assert r['CalcNumHBD']==r['NumHDonors']
 assert r['CalcNumHBA']==r['NumHAcceptors']
 rows.append(r)
out={'python':platform.python_version(),'platform':platform.platform(),'rdkit_version':rdBase.rdkitVersion,'lipinski_source_sha256':hashlib.sha256(source.encode()).hexdigest(),'wrapper_source_lines':[l for l in source.splitlines() if l.startswith(('NumHDonors =','NumHAcceptors =','NOCount =','NHOHCount ='))],'cases':rows,'ForwardSDMolSupplier_constructor_doc':Chem.ForwardSDMolSupplier.__init__.__doc__,'Crippen_has_CalcCrippenDescriptors':hasattr(Crippen,'CalcCrippenDescriptors'),'rdMolDescriptors_has_CalcCrippenDescriptors':hasattr(rdMolDescriptors,'CalcCrippenDescriptors'),'TPSA_signature':rdMolDescriptors.CalcTPSA.__doc__,'rotatable_signature':rdMolDescriptors.CalcNumRotatableBonds.__doc__}
Path(__file__).with_name('review-claims-evidence.json').write_text(json.dumps(out,indent=2))
print(json.dumps({k:v for k,v in out.items() if k not in ['ForwardSDMolSupplier_constructor_doc','TPSA_signature','rotatable_signature']},indent=2))
print(out['ForwardSDMolSupplier_constructor_doc'][:750])
