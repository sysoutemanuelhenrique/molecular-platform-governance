"""Isolated API evidence for an architectural proposal; no platform implementation."""
import io,json,math,hashlib,sys,pathlib
from rdkit import Chem,rdBase
from rdkit.Chem import Descriptors,rdMolDescriptors,rdDepictor
from rdkit.Chem.Draw import rdMolDraw2D
root=pathlib.Path(__file__).resolve().parent
raw_root=root.parent/'academic_rehearsal_20261019/examples/caffeine-demo/inputs/ligands'
evidence=root/'evidence';evidence.mkdir(exist_ok=True)
def describe(m):
    return {'formula':rdMolDescriptors.CalcMolFormula(m,separateIsotopes=True,abbreviateHIsotopes=False),
      'molar_mass_g_mol':Descriptors.MolWt(m),
      'exact_mass_da':rdMolDescriptors.CalcExactMolWt(m,onlyHeavy=False),
      'formal_charge_e':Chem.GetFormalCharge(m),
      'heavy_atom_count':m.GetNumHeavyAtoms(),
      'hbd_count':rdMolDescriptors.CalcNumHBD(m),
      'hba_count':rdMolDescriptors.CalcNumHBA(m),
      'rotatable_bond_count':rdMolDescriptors.CalcNumRotatableBonds(m,rdMolDescriptors.NumRotatableBondsOptions.Strict),
      'tpsa_a2':rdMolDescriptors.CalcTPSA(m,force=True,includeSandP=False),
      'clogp_wildman_crippen':rdMolDescriptors.CalcCrippenDescriptors(m,includeHs=True,force=True)[0]}
def drawing(m):
    copy=Chem.Mol(m)
    rdDepictor.Compute2DCoords(copy,canonOrient=True,clearConfs=True,nFlipsPerSample=0,nSample=0,sampleSeed=0,permuteDeg4Nodes=False,forceRDKit=True,useRingTemplates=False)
    draw=rdMolDraw2D.MolDraw2DSVG(600,400)
    draw.DrawMolecule(copy);draw.FinishDrawing()
    return draw.GetDrawingText()
rows=[]
for path in sorted(raw_root.glob('*/*.sdf')):
    b=path.read_bytes();ms=list(Chem.ForwardSDMolSupplier(io.BytesIO(b),sanitize=True,removeHs=False,strictParsing=True))
    assert len(ms)==1 and ms[0] is not None
    m=ms[0];assert len(Chem.GetMolFrags(m))==1
    before=Chem.MolToMolBlock(m);n=m.GetNumAtoms();iso=tuple(a.GetIsotope() for a in m.GetAtoms());confs=m.GetNumConformers()
    values=describe(m);assert all(not isinstance(v,float) or math.isfinite(v) for v in values.values())
    svg=drawing(m);svg2=drawing(m)
    assert '<svg' in svg and '</svg>' in svg
    assert Chem.MolToMolBlock(m)==before and m.GetNumAtoms()==n and tuple(a.GetIsotope() for a in m.GetAtoms())==iso and m.GetNumConformers()==confs
    assert path.read_bytes()==b
    normalized=Chem.MolToSmiles(m,canonical=True,isomericSmiles=True)
    params=Chem.SmilesParserParams();params.sanitize=True;params.removeHs=False;params.parseName=False;params.allowCXSMILES=False
    roundtrip=Chem.MolFromSmiles(normalized,params)
    val2=describe(roundtrip)
    same=all(abs(v-val2[k])<1e-9 if isinstance(v,float) else v==val2[k] for k,v in values.items())
    (evidence/(path.parent.name+'.svg')).write_text(svg)
    rows.append({'input':path.parent.name,'sha256':hashlib.sha256(b).hexdigest(),'size':len(b),'values':values,'svg_sha256':hashlib.sha256(svg.encode()).hexdigest(),'svg_repeat_equal':svg==svg2,'molecule_and_raw_unchanged':True,'same_values_after_smiles_roundtrip':same})
additional=[]
for s in ['[2H]OC','C[13CH3]','[NH4+]','CC(=O)[O-]','N[C@@H](C)C(=O)O','CC(=O)O.[Na+]','CS(=O)(=O)O','CP(=O)(O)O']:
    p=Chem.SmilesParserParams();p.removeHs=False;p.parseName=False;p.allowCXSMILES=False
    m=Chem.MolFromSmiles(s,p)
    additional.append({'smiles':s,'fragments':len(Chem.GetMolFrags(m)),'values':describe(m),'tpsa_including_s_and_p':rdMolDescriptors.CalcTPSA(m,force=True,includeSandP=True),'svg_generated':bool(drawing(m))})
out={'python':sys.version,'engine':rdBase.rdkitVersion,'scope':'Library API spike only; no Application Service or CLI characterization exists','raw_cases':rows,'additional_cases':additional}
(evidence/'rdkit-spike-results.json').write_text(json.dumps(out,indent=2,allow_nan=False))
print(json.dumps(out,indent=2))
