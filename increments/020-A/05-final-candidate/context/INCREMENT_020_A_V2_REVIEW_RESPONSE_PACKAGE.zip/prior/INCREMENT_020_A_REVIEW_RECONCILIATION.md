# Incremento 020-A — Reconciliação das revisões preliminares

Autor: Codex, no papel de arquiteto. Data de referência: 19/10/2026, America/Sao_Paulo; evidências técnicas coletadas em 20/10/2026 UTC.

**Estado:** reconciliação arquitetural preliminar. Não é nova revisão adversarial independente, especificação final ou autorização de implementação. Nenhum parecer recebido foi modificado. A proposta original permanece preservada; este documento registra a disposição dos achados e as correções que deverão orientar sua próxima versão.

## 1. Materiais lidos integralmente

| Identificador nesta reconciliação | Arquivo recebido | Linhas | Bytes | SHA-256 |
|---|---|---:|---:|---|
| R1 | Markdown colado(5).md | 161 | 11.390 | 6c42572d8ca926c93c9db75d8b683e01827842b24e975cb91544572c0fb98514 |
| R2 | Texto colado (2)(1).txt | 115 | 21.666 | 94f9cd0ce26d1cb2fe303ff34d79b0e3ebb3eacf2514eab97ac52042f54b4419 |

R1 apresenta APPROVE WITH CHANGES somente para evolução da proposta, com 1 blocker de gate, 4 majors e 3 minors. R2 apresenta APPROVE WITH NON-BLOCKING NOTES, com 0 blockers, 0 majors, 4 minors e 4 notes. Ambos dizem expressamente que a implementação não está liberada e reconhecem que não verificaram o código do commit independentemente.

Os achados não são somados ou diluídos por votação. Os dois documentos avaliam uma proposta preliminar por critérios e bases documentais distintos. Os gates técnicos e documentais ainda abertos continuam abertos mesmo quando um parecer usa o termo non-blocking para seus novos achados.

## 2. Snapshot e verificações adicionais do arquiteto

- main remota reconfirmada por git ls-remote: `08b797e0985e123ffd4d7ca7e5a5e8f040e63851`.
- Clone de leitura no mesmo HEAD; git status --porcelain vazio.
- Símbolos `_AUTHORIZED_ROOT_TEMPLATE`, `create_verified_raw_snapshot` e `resolve_rdkit_engine` existem no código desse snapshot, conforme a proposta havia informado.
- `atomic.py` documenta Route B do Incremento 018 e contém a raiz `inputs/ligands/{input_id}`.
- `rdkit_tautomer.py` documenta separadamente Route B do Incremento 016, para construir o enumerador via CleanupParameters.
- `execution.py` restringe operation_type a state-transformation e requested a TautomerEnumerationPolicy.
- `atomic_write_text` contém except BaseException exclusivamente para limpeza seguido de raise. A compatibilidade da política de interrupção com esse padrão é fato de código verificado.
- Governance remoto reconfirmado: a API contents respondeu `This repository is empty`. Os anexos recebidos são pareceres, não os documentos normativos integrais solicitados.

O ambiente virtual usado no spike anterior não estava disponível nesta retomada. Foi criado outro venv isolado neste workspace, com Python 3.12.14 e instalação explícita de rdkit==2026.3.6. O motor retornou 2026.03.6. Nenhuma dependência global nem arquivo do repositório foi alterado.

Foi executado `check_review_claims.py`, somente como sonda independente de biblioteca. O arquivo JSON acompanhante registra os resultados e trechos da fonte Python instalada. Não foi executada suíte pytest nem implementação de caracterização.

## 3. Reconciliação do primeiro parecer

| Achado R1 | Disposição | Fundamentação e condição de fechamento |
|---|---|---|
| B1 — governance original não verificado | ACEITO, ABERTO | A API remota segue sem documentos e os anexos não substituem os originais. Gate normativo permanece fechado. |
| M1 — política de leitura segura indefinida | ACEITO, ABERTO | Checksum dos bytes calculados e confinamento do acesso são garantias diferentes. Não reaproveitar a função de RAW com um ID falso. É necessária decisão específica para representação científica. |
| M2 — ausência de histórico durável | ACEITO COMO DECISÃO A RATIFICAR | A preferência por cálculo sob demanda é provisória. Proveniência retornada possibilita reprodução, mas não equivale a execução preservada pelo sistema. Confrontar a ausência de persistência com governance antes de fechar o recorte. |
| M3 — gramática de parsing incompleta | ACEITO, ABERTO | A futura versão deve fixar codificação, linhas, newline terminal, nomes/CXSMILES, conteúdo extra, delimitação SDF e contagem de registros inválidos. O spike anterior não validou uma implementação completa desse contrato. |
| M4 — perfil SVG incompleto | ACEITO, ABERTO | Definir a superfície de saída estática e testes para não importar markup/propriedades arbitrárias, além de H, isotopia e estereoquímica na cópia de desenho. Não ampliar isso para um sistema genérico de sanitização de SVG recebido de terceiros. |
| N1 — massa exata | ACEITO, REFINAMENTO TEXTUAL | Manter unidade Da, tratamento isotópico e de carga explícitos, sem chamar o número de m/z experimental ou de massa de um aduto. |
| N2 — TPSA S/P | ACEITO, REFINAMENTO TEXTUAL | Registrar includeSandP=False como escolha explícita que coincide com o default; não sugerir que é uma modificação do default. Manter casos discriminantes S/P. |
| N3 — esforço baixo | ACEITO, ESTIMATIVA CONDICIONAL | APIs são simples, mas a integração depende principalmente de leitura segura e da decisão de persistência. A classificação de esforço será reavaliada após esses pontos. |

Não declaro esses majors resolvidos apenas por mencioná-los. Nesta etapa ficaram reconciliados como ações arquiteturais aceitas e pendentes; a especificação implementável dependerá das decisões concretas e da revisão subsequente.

## 4. Reconciliação do segundo parecer

| Achado R2 | Disposição | Fundamentação |
|---|---|---|
| MINOR-1 — numeração 020-A | PARCIALMENTE ACEITO | O risco documental é legítimo. O usuário escolheu a sequência A/B/C explicitamente. Não foi apresentada norma vigente que torne sufixos tematicamente proibidos; um roadmap histórico não basta para invalidar o planejamento atual. Manter 020-A/B/C como nomes provisórios até conferir e registrar a convenção, sem renumerar unilateralmente o 021. |
| MINOR-2 — defaults TPSA/Strict | ACEITO COMO CLAREZA, COM RESSALVA | Distinguir explicitamente coincidência com default e desvio. Contudo, fixar um parâmetro igual ao default continua sendo decisão do perfil e é útil para reprodução. A proposta não precisava divergir da biblioteca para justificar parâmetros explícitos. |
| MINOR-3 — suposta contagem HBD/HBA por ligação | PREMISSA REJEITADA POR EVIDÊNCIA | No pin instalado, NumHDonors e NumHAcceptors são wrappers das próprias CalcNumHBD e CalcNumHBA. A distinção afirmada no parecer não existe entre essas funções. Manter nomes/métodos explícitos e acrescentar fixtures discriminantes, sem adotar a semântica errada. |
| MINOR-4 — limpeza sob BaseException | ACEITO | Esclarecer que é legítimo usar finally ou captura para limpeza com reraise, sem converter nem suprimir KeyboardInterrupt/SystemExit. Isso é coerente com atomic.py. |
| NOTE-1 — sais desconectados | ACEITO COM RESTRIÇÃO CIENTÍFICA | Explicar que formas multicomponente podem ficar fora do perfil. A mensagem não deve recomendar trocar automaticamente sal por ácido/base livre como se fossem a mesma entrada científica. Outra representação exige escolha explícita do cientista e proveniência. |
| NOTE-2 — dois usos de Route B | PARCIALMENTE ACEITO | A ambiguidade de leitura é real, mas ambos os nomes já existem em código de incrementos distintos. Usar qualificadores “Route B de snapshot RAW, Inc. 018” e “Rota B do enumerador, Inc. 016”. Não renomear contratos históricos por esta revisão. |
| NOTE-3 — versão | ACEITO | 2026.3.6 e 2026.03.6 são formas normalizadas equivalentes da versão; registrar o pin e a string observada do motor sem chamar isso de deriva. |
| NOTE-4 — leitura segura como gate | ACEITO, MAS NÃO EXCLUSIVO | A leitura segura está aberta. A ausência dos originais normativos e a decisão de persistência também impedem a liberação neste processo; o próprio bloco final de R2 reconhece governance pendente. |

## 5. Correções factuais adicionais em R2

### 5.1 HBD/HBA: código e execução no pin

A fonte Python instalada no RDKit 2026.03.6 define:

```python
NumHDonors = lambda x: rdMolDescriptors.CalcNumHBD(x)
NumHAcceptors = lambda x: rdMolDescriptors.CalcNumHBA(x)
```

Assim, a recomendação de tratar CalcNumHBD como uma contagem de ligações diferente de NumHDonors está incorreta. A afirmação correspondente sobre aceptores também não é sustentada.

Resultados observados:

| Entrada SMILES | CalcNumHBD | NumHDonors | CalcNumHBA | NumHAcceptors | NHOHCount |
|---|---:|---:|---:|---:|---:|
| CN, metilamina | 1 | 1 | 1 | 1 | 2 |
| N, amônia | 1 | 1 | 1 | 1 | 3 |
| NCCN, etilenodiamina | 2 | 2 | 2 | 2 | 4 |
| CO, metanol | 1 | 1 | 1 | 1 | 1 |
| CC(=O)N, acetamida | 1 | 1 | 1 | 1 | 2 |
| c1ccncc1, piridina | 0 | 0 | 1 | 1 | 0 |

O RDKit expõe também NHOHCount/NOCount por outros wrappers. No pin, NHOHCount chama CalcNumLipinskiHBD e NOCount chama CalcNumLipinskiHBA. Esses nomes devem ser distinguidos dos métodos selecionados. Essa distinção não autoriza rebatizar CalcNumHBD como contagem de N–H/O–H individuais.

A fonte oficial pública consultada confirma a delegação de NumHDonors/NumHAcceptors; a execução e a leitura da fonte instalada confirmaram o fato especificamente no pin. Documentar métodos é necessário, mas não devemos introduzir uma diferença de algoritmo inexistente.

### 5.2 Default do supplier

R2 afirma que ForwardSDMolSupplier tem strictParsing=False como default. A assinatura instalada em 2026.03.6 e a documentação oficial consultada mostram strictParsing=True. Os defaults observados são sanitize=True, removeHs=True, strictParsing=True.

Portanto, no perfil proposto: sanitize=True e strictParsing=True explicitam defaults; removeHs=False é um desvio deliberado do default. Esse esclarecimento deve acompanhar a tabela de parâmetros, sem alterar a escolha anterior ou o parsing de produção.

### 5.3 Namespace de Crippen

R2 escreve Crippen.CalcCrippenDescriptors ao confirmar o método. No pin instalado, esse atributo não existe no módulo Crippen. O método usado pelo spike da proposta é rdMolDescriptors.CalcCrippenDescriptors. Crippen.MolLogP é outro ponto de entrada disponível, mas não deve ser confundido com o nome usado no spike.

Não é necessário mudar a proposta para o namespace incorreto para “atender à revisão”. Trata-se de corrigir a atribuição do parecer na reconciliação.

## 6. Texto arquitetural adotado para esclarecer interrupções

> KeyboardInterrupt e SystemExit não serão convertidos em falhas de negócio nem suprimidos. Recursos de propriedade exclusiva da chamada devem ser liberados também sob interrupção, preferencialmente por context managers/finally. Uma captura de BaseException restrita à limpeza é admissível quando seguida de propagação da exceção original, sem abranger lógica científica ou produzir falso sucesso.

Isso esclarece a frase ambígua da proposta. Não determina a criação de um handler novo nem a mudança de atomic.py, que já contém o padrão de limpeza apropriado ao seu contrato.

## 7. Direção arquitetural mantida

- Operar sobre MolecularState registrado, atendendo SDF e SMILES conforme gramática a definir.
- Manter os dez valores tipados, métodos explícitos e SVG opcional sobre cópia molecular.
- Não modificar ScientificEntity/MolecularState/Conformer ou criar transformação para um cálculo de descritores.
- Não encaixar a operação artificialmente no ExecutionAttempt atual, que tem política e tipo de operação específicos.
- Preservar RAW e representação científica; coordenadas de desenho são derivadas.
- Manter preferência provisória por cálculo sob demanda. Ela não é ratificada enquanto faltar confronto normativo sobre persistência.
- Manter entrada interativa e apresentação do experimento completo para a proposta C; a operação A pode ter uma CLI técnica fina.

## 8. Gates ainda abertos e próximo passo

1. Receber e ler os documentos normativos originais atuais. Os dois pareceres anexados não encerram essa pendência.
2. Decidir se caracterização sem registry interno é permitida e suficiente para o recorte.
3. Definir o contrato específico de leitura de representação, incluindo confinamento e comportamento sob substituição concorrente.
4. Fixar gramáticas de SDF/SMILES e os limites da política de parsing.
5. Definir perfil SVG estático, H/isotopia/estereoquímica e comportamento em falha de desenho.
6. Registrar a convenção de identificação do incremento e elaborar a matriz de testes após as decisões.

A ação necessária do usuário é fornecer os arquivos do governance local, de preferência em ZIP. O arquiteto fará a leitura, reconciliação e revisão da proposta. Não é necessário gastar uma sessão do Claude implementador com outro estudo de repositório.

Nenhum teste Windows novo é solicitado agora. Se a solução de leitura segura depender de um fato do Windows/NTFS não verificável aqui, o arquiteto deverá formular um spike local específico, com pergunta e critérios, e só então solicitar sua execução.

## 9. Evidências e limitações

Documentação primária consultada:

- https://github.com/rdkit/rdkit/blob/master/rdkit/Chem/Lipinski.py
- https://www.rdkit.org/docs/source/rdkit.Chem.rdmolfiles.html
- https://www.rdkit.org/docs/source/rdkit.Chem.rdMolDescriptors.html

As páginas públicas podem representar versão posterior ao pin. Por isso, as correções factuais principais foram confirmadas adicionalmente no RDKit 2026.03.6 instalado em ambiente isolado. Fonte Python de Lipinski observada: SHA-256 `6f7b5b8c86d05d29e48eaafdb8ebd85d4acf5c81c2df0d7aef8987467c9923fd`.

Evidência acompanhante: `check_review_claims.py` e `review-claims-evidence.json`. Esses arquivos são sondas de biblioteca, não código de produção ou testes já integrados à plataforma. Seis casos discriminantes foram executados; nenhuma suíte pytest foi executada. A conferência de trechos do código no SHA informado não equivale à revisão integral de todos os incrementos nem à leitura dos contratos normativos ausentes.

REVIEW RECONCILIATION COMPLETE: YES
ORIGINAL REVIEWS MODIFIED: NO
ORIGINAL PROPOSAL MODIFIED: NO
HEAD CHECKED: 08b797e0985e123ffd4d7ca7e5a5e8f040e63851
RDKit CLAIMS VERIFIED IN PIN: YES
GOVERNANCE ORIGINALS VERIFIED: NO
ALL MAJORS RESOLVED: NO
READY FOR NORMATIVE DRAFT: NO
READY FOR IMPLEMENTATION: NO
FINAL SPECIFICATION FROZEN: NO
CODE REPOSITORY MODIFIED: NO
