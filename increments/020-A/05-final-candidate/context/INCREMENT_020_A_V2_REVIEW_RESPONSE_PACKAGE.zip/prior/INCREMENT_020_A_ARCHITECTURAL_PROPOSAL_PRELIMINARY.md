# Incremento 020-A — Proposta arquitetural preliminar

## Caracterização molecular e representação 2D

Autor: Codex, no papel de arquiteto. Data: 19/10/2026.

**Natureza:** proposta para confronto com revisor independente. Não é especificação final, não congela contratos e não autoriza implementação.

## 1. Decisão recomendada

Introduzir uma operação de caracterização de um **MolecularState já registrado**, capaz de retornar uma ficha de dez valores e, quando solicitada, uma representação SVG 2D. Calcular sob demanda, sem alterar o estado ou o RAW e sem persistir um registry novo nesta primeira etapa.

O resultado é informação derivada da representação de entrada. A operação não produz ScientificEntity, MolecularState, Conformer ou StateTransformationRecord. Não determina protonação, tautômero predominante, atividade biológica ou adequação para docking.

A recomendação é provisória e deve ser confrontada com os documentos originais de governance e com o revisor antes do rascunho normativo.

## 2. Papéis e sequência de trabalho

| Papel | Responsabilidade |
|---|---|
| Arquiteto, nesta conversa | Pesquisa, inspeção do repositório, proposta de modelo, justificativas e reconciliação das revisões |
| Revisor independente | Confrontar fatos, semântica científica, arquitetura, alternativas e riscos |
| Claude implementador | Implementar especificação aprovada, executar testes e produzir evidência local necessária |
| Responsável pelo projeto | Decidir escopo e passagem dos gates |

Investigações que podem ser feitas por leitura do GitHub ou por spike isolado neste ambiente pertencem ao trabalho do arquiteto. Só serão solicitadas ao implementador evidências dependentes do Windows local ou capacidades ausentes aqui, com perguntas e critérios concretos.

Sequência acordada: 020-A, esforço baixo; 020-B, análise e comparação de esforço médio; 020-C, comandos guiados e apresentação acadêmica. Essa nomenclatura precisa ser registrada no governance; não implica reabrir o contrato do Incremento 020 já integrado.

## 3. Snapshot e limite documental

### Evidência observada

- Repositório: `sysoutemanuelhenrique/molecular-platform`.
- main remota reconfirmada: `08b797e0985e123ffd4d7ca7e5a5e8f040e63851`.
- Clone novo usado somente para leitura de produção e execução isolada: mesmo SHA.
- Working tree do clone: limpo; `git diff --check`: exit code 0.
- Dependência declarada: `rdkit==2026.3.6`; versão retornada pelo motor instalado: `2026.03.6`.
- Python do spike: 3.12.14, Linux. Isso não valida o serviço futuro em Windows.
- Governança remota: a API de `sysoutemanuelhenrique/molecular-platform-governance/contents` respondeu `This repository is empty`; `git ls-remote` não retornou refs.

### Evidência documental secundária

Foram lidas as transcrições disponíveis intituladas `Texto colado(20261006-155705).txt` e `Texto colado(20261008-013700).txt`. A primeira registra criação de documentos de governance, mas contém trechos truncados. A segunda registra o congelamento do Incremento 020 e informa 1.975 linhas, 210.880 bytes e SHA-256 `cf6cb534f9267d51e718052c7b36a2293c522bc566c99cf3bb2ef5909385a0a6`.

Essas transcrições NÃO são os originais e não permitem validar sua identidade nem substituir sua leitura integral. O caminho Windows `C:\Users\Pichau\Documents\MolecularGovernance` não é acessível deste ambiente. Não foi encontrado um original integral por título nas buscas realizadas; isso não prova sua inexistência em outros locais.

**Pendência documental:** receber os documentos centrais de governance e as especificações finais pertinentes, incluindo o encerramento do 020. Essa pendência impede declarar conformidade normativa completa ou avançar diretamente para implementação. Não impede submeter esta proposta explicitamente preliminar a debate arquitetural.

## 4. Fatos verificados no código e nos testes

Todas as referências abaixo são relativas ao SHA da Seção 3.

| Fato observado | Evidência de produção e testes |
|---|---|
| Entidade e estado são modelos pequenos, frozen e extra=forbid | `scientific.py`, ScientificEntity/MolecularState; `test_scientific.py`, testes de imutabilidade e rejeição de extras |
| Representação tem path, format e checksum; format não é uma lista química fechada | `scientific.py`, MolecularRepresentationRef; registry aceita formato não vazio |
| Registrar um estado não prova sua elegibilidade química | `scientific_registry.py`, register_state copia/verifica bytes; elegibilidade é responsabilidade de operações específicas |
| Enumeração atual exige SDF na entrada, mas publica candidatos em SMILES | `application.py`, enumerate_state_tautomers, resolução e escrita de arquivos .smi com format="smiles" |
| Attempts atuais não são um mecanismo universal de cálculo | `execution.py`: operation_type Literal["state-transformation"], requested TautomerEnumerationPolicy, operation_ids referem transformações |
| RAW seguro da promoção possui raiz e vínculo específicos de LigandInput | `atomic.py`, _AUTHORIZED_ROOT_TEMPLATE, create_verified_raw_snapshot; não é um leitor genérico de representação de estado |
| Somente rdkit_tautomer.py importa RDKit diretamente em produção | Docstring do adaptador e inspeção dos imports atuais; testes de fronteira de dados neutros e CLI |
| O resolver de experimento usa identidade lógica | `context.py`, resolve_experiment compara config.experiment_id; `test_context.py` distingue nome do diretório e ID |
| Escrita atômica atual não significa create-once | `atomic.py`, atomic_write_text usa os.replace; não deve ser reutilizado sob uma promessa inexistente de nunca sobrescrever |

**Correção factual para a UX futura:** o argumento de experimento é o ID lógico declarado no YAML, resolvido entre subdiretórios do diretório-base. Ele não é um caminho relativo ou absoluto de propósito geral. Um nome simples funciona no ensaio porque coincidiu com experiment_id. Esse contrato deve orientar o estudo do 020-C.

**Implicações:** caracterização somente em SDF excluiria os estados de tautômeros que o projeto já publica. Embutir descritores em MolecularState ampliaria um modelo deliberadamente mínimo. Reutilizar ExecutionAttempt sem mudança normativa exigiria declarar falsamente uma transformação de estado e usar uma política de enumeração inadequada.

## 5. Escopo proposto

Incluído:

- Caracterizar um estado individual por chamada.
- Ler a representação registrada de formato `sdf` ou `smiles`.
- Exigir exatamente uma molécula válida e um fragmento conectado para o perfil inicial.
- Calcular os dez valores da Seção 6.
- Produzir SVG 2D por solicitação explícita, sobre cópia de trabalho.
- Retornar dados tipados, proveniência e avisos compreensíveis.
- Disponibilizar comando técnico mínimo, mantendo a experiência interativa para 020-C.

O formato aceito deve vir de representation.format, não de adivinhação pela extensão ou conteúdo. A lista de formatos da operação é própria e não altera os modelos existentes.

Fora do escopo: pKa, protonação por pH, neutralização, fragment parent, dessalinização, geração 3D, MMFF/UFF, cargas parciais, docking, preparação de receptor, fingerprints, classificação de grupos funcionais, filtros automáticos de drug-likeness, GUI e aliases novos tbmp.

## 6. Ficha molecular: perfil candidato de dez valores

Nome de trabalho do perfil: `molecular-characterization-v1`. É uma proposta, não um identificador normativo congelado.

| Campo candidato | Método RDKit observado no spike | Unidade ou interpretação |
|---|---|---|
| formula | CalcMolFormula(separateIsotopes=True, abbreviateHIsotopes=False) | Texto, com distinção isotópica |
| molar_mass_g_mol | Descriptors.MolWt | Massa molar calculada, g/mol |
| exact_mass_da | CalcExactMolWt(onlyHeavy=False) | Massa exata calculada, Da, segundo isótopos/carga tratados pelo RDKit |
| formal_charge_e | Chem.GetFormalCharge | Carga formal líquida em unidades da carga elementar |
| heavy_atom_count | Mol.GetNumHeavyAtoms | Número de átomos não hidrogênio |
| hbd_count | CalcNumHBD | Doadores segundo a definição RDKit |
| hba_count | CalcNumHBA | Aceptores segundo a definição RDKit |
| rotatable_bond_count | CalcNumRotatableBonds(NumRotatableBondsOptions.Strict) | Contagem sob a opção Strict |
| tpsa_a2 | CalcTPSA(force=True, includeSandP=False) | Å², perfil explicitamente sem a contribuição adicional S/P |
| clogp_wildman_crippen | CalcCrippenDescriptors(includeHs=True, force=True)[0] | Estimativa Wildman–Crippen, adimensional |

Não usar um dicionário irrestrito de quaisquer descritores para substituir esse conjunto tipado. Manter valores de máquina sem arredondamento prévio; arredondar apenas a apresentação, com precisão explicitada. Rejeitar NaN e infinito. Contagens devem ser inteiras e coerentes; cLogP pode ser negativo.

As escolhas Strict, includeSandP=False e tratamento isotópico são decisões científicas candidatas, não fatos impostos pela biblioteca. O revisor deve confrontá-las. O spike mostra que incluir S/P muda TPSA em moléculas adequadas: metanossulfônico passou de 54,37 a 62,75 Å²; metilfosfônico de 57,53 a 67,34 Å². Não esconder essa opção sob o rótulo genérico TPSA.

Massa média não equivale a massa exata. Para moléculas marcadas isotopicamente, interpretar MolWt segundo o algoritmo da versão usada. Para espécies carregadas, não confundir massa exata com m/z de um aduto experimental. Carga formal não representa cargas parciais.

Os descritores pertencem à estrutura específica analisada: podem mudar com tautomerismo ou protonação. HBA/HBD dependem de definições e percepção química. cLogP não é logD em determinado pH, solubilidade ou uma medição experimental. Nenhum valor autoriza classificar automaticamente uma molécula como segura, ativa ou biodisponível.

## 7. Fronteira de dados e modelo candidato

Propor três estruturas tipadas e imutáveis, com nomes sujeitos a revisão:

1. `MolecularCharacterizationValues`: os dez campos da Seção 6.
2. `MolecularCharacterizationProvenance`: state_id, entity_id, referência relativa da representação, formato declarado, checksum esperado, checksum dos bytes efetivamente analisados, tamanho dos bytes, engine_name, engine_version e identificação do perfil com suas opções explícitas.
3. `MolecularCharacterizationResult`: versão própria do resultado, valores, proveniência, avisos e SVG opcional com identificação do perfil de desenho.

Não duplicar CID ou dados do PubChem como atributos químicos do estado. A origem pode ser consultada pelos registros existentes quando existir lineage; não inferir origem de nome de arquivo ou do nome textual da entidade.

Não criar um ID persistente nem um cache nesse recorte. Data de cálculo, se incluída, será metadado da observação e não parte da identidade química. A igualdade de resultados não será baseada apenas no state_id: entrada, checksum, motor e perfil precisam ser os mesmos.

O Application Service recebe project_dir e input_state_id; ele resolve o estado e lê sua representação. O adaptador recebe bytes verificados e formato explícito, retornando somente dados neutros. Nenhum Mol RDKit deve cruzar para domínio, serviço ou CLI.

A API pública atual de resolve_rdkit_engine contém parâmetros de enumeração. Não reutilizar esses parâmetros como se descrevessem cálculo de descritores. Um resolvedor dedicado à caracterização pode observar a versão no mesmo módulo adaptador, sem instanciar o enumerador.

## 8. Leitura, parsing e segurança

Fluxo candidato:

1. Validar o ID antes de I/O e resolver o registro do estado.
2. Validar formato e referência de representação, incluindo checksum SHA-256 com forma válida para esta operação.
3. Aplicar uma política explícita de acesso ao artefato científico, com confinamento ao experimento e rejeição de redirecionamento por links/reparse points segundo o contrato que vier a ser aprovado.
4. Ler uma única sequência de bytes e calcular SHA-256 sobre ela.
5. Comparar com a referência capturada do estado. Em divergência, recusar antes do cálculo.
6. Passar exatamente os bytes verificados ao adaptador, sem reabrir o arquivo pelo caminho.
7. Fazer parsing e cálculos; retornar o resultado completo somente ao concluir o formato solicitado.

O spike confirmou `ForwardSDMolSupplier(BytesIO(...), sanitize=True, removeHs=False, strictParsing=True)` na versão instalada. Para SMILES, o estudo propõe uma única linha molecular não vazia, permitindo o newline terminal dos arquivos publicados pelo projeto. ParseName=False, removeHs=False e política explícita de CXSMILES evitam interpretar campos extras silenciosamente. Os detalhes de linhas em branco, codificação e conteúdo extra ainda precisam entrar no rascunho normativo e seus testes.

SDF multimolécula deve ser rejeitado pela contagem de registros; não filtrar os inválidos e aceitar um remanescente. Estruturas desconectadas devem ser rejeitadas neste perfil, sem escolher silenciosamente um componente. A checagem cabe à operação mesmo quando o estado já existe, porque o registro genérico não faz validação química.

Sanitização e interpretação RDKit acontecem em memória sob opções registradas. Não executar Cleanup, Uncharger, Reionizer, normalização de tautômeros ou remoção de H como pré-processamento oculto. Não editar o artefato científico nem o RAW.

**Questão arquitetural ainda bloqueadora do rascunho:** não há leitor genérico atual que ofereça automaticamente a garantia de Route B para artefatos de estado. A função existente é vinculada a `inputs/ligands/<input_id>` e seu snapshot persiste arquivos próprios. Não usá-la com um ID falso nem enfraquecê-la. O nível de garantia exigido e a menor extensão específica para representação de estado precisam ser decididos após ler o governance original. `resolve()+read_bytes()` sozinho não deve ser descrito como garantia completa contra corrida de substituição.

Ler bytes uma vez e validá-los garante correspondência entre checksum e cálculo daquela observação. Isso não prova, isoladamente, ausência de redirecionamento no acesso ao arquivo nem imutabilidade permanente do disco. A proposta faz essa distinção explicitamente.

## 9. Desenho 2D

Recomendar SVG como único formato inicial. O spike gerou SVG com a dependência existente, sem adicionar uma dependência gráfica externa. Não prometer PNG/Cairo sem avaliar distribuição e disponibilidade na plataforma suportada.

Gerar coordenadas apenas em `Chem.Mol(mol)` de trabalho. Perfil candidato: orientação canônica, clearConfs=True somente nessa cópia, amostragem desligada, sampleSeed=0, forceRDKit=True e useRingTemplates=False. O perfil evita depender silenciosamente de uma preferência global por CoordGen. Dimensão do spike: 600 × 400.

No perfil inicial, não remover H da molécula original nem introduzir uma limpeza oculta na cópia. Uma futura simplificação gráfica de H explícitos exige política de exibição registrada, distinguindo isótopos e estereoquímica. A estética dessa simplificação não deve forçar mudança da representação científica.

O desenho é uma representação gerada e não um Conformer ou geometria experimental. A presença de um objeto de coordenadas 2D interno ao RDKit não altera essa interpretação de domínio. Nenhum arquivo SDF deve ser regravado com coordenadas 2D em cima do original.

Não inserir nomes, títulos ou propriedades arbitrárias do SDF como markup no SVG. O arquivo deve ser uma imagem estática derivada da estrutura. Validar a saída SVG e conferir visualmente exemplos reais; nenhuma garantia de identidade byte a byte entre sistemas operacionais deve ser deduzida de duas execuções locais iguais.

## 10. Alternativas arquiteturais confrontadas

| Alternativa | Vantagem | Custo ou risco | Recomendação |
|---|---|---|---|
| A. Cálculo sob demanda com resultado tipado | Menor integração, sem publicação interna nem rollback de registros | Recalcula; não fica automaticamente no histórico do experimento | Preferida para 020-A |
| B. Registry persistente de caracterização e artefatos | Histórico interno e reutilização explícita | Novo schema, identidade, create-once, concorrência, invalidação e publicação composta | Avaliar se o revisor demonstrar necessidade imediata |
| C. Cálculo sob demanda mais registry/cache | Consulta e histórico | Acumula os custos de A/B e exige regras claras de cache | Adiar |
| D. Usar ExecutionAttempt atual sem alterá-lo | Reaproveitamento aparente | Semântica incorreta: política de tautômero e operation_type fixo de transformação | Rejeitar |

A prefere uma consulta derivada auditável pelo conteúdo retornado. Não oferece histórico automático de execuções fracassadas nem registro durável da ficha dentro do experimento. Essa é uma limitação deliberada proposta para revisão, não algo já autorizado por norma. Caso o governance exija persistir toda observação científica, a recomendação precisa ser revista e o esforço deixa de ser presumidamente baixo.

Exportar uma resposta por redirecionamento do terminal é captura externa do usuário, não registro científico da plataforma. Não chamar isso de registry, execução persistida ou idempotência transacional.

## 11. Atomicidade, concorrência e falhas

Na alternativa A, não há publicação de estados ou registros que exija compensação científica. Duas consultas simultâneas não disputam um ID de saída. Cada resultado corresponde ao snapshot de bytes e metadados que observou; alterações externas precisam ser recusadas ou identificadas conforme a política de leitura aprovada.

Se arquivos temporários forem necessários para o leitor seguro, eles devem pertencer exclusivamente à chamada; só esses arquivos podem ser limpos. Ausência de escrita no domínio não equivale a ausência garantida de todo I/O temporário, nem dispensa o desenho de leitura segura da Seção 8.

Preparar a saída solicitada antes de imprimir sucesso. No modo JSON, emitir um documento completo sem banners misturados ao stdout. Erros devem usar canal apropriado e código de saída 1; sucesso 0. Mensagens públicas não devem conter traceback ou caminhos absolutos. A forma final de banners deve seguir os contratos existentes, após conferência normativa.

Não capturar BaseException genericamente; KeyboardInterrupt e SystemExit devem manter sua natureza. O novo caminho não precisa persistir uma falha em um attempt de tautomerização. Também não deve tentar compensar entidades, estados ou promoções existentes.

Distinguir sucesso dos cálculos de sucesso do desenho. Proposta: no modo sem figura, calcular só valores; quando figura for solicitada e falhar, a chamada falha explicitamente, sem apresentar uma ficha com imagem prometida como concluída. Não converter exceções em zero, string vazia ou descritor falso. A possibilidade de resultado parcial precisa ser uma decisão explícita caso o revisor a prefira.

## 12. CLI técnica mínima e relação com 020-C

Sintaxe candidata, sujeita a revisão:

```text
molecular state characterize <experiment_id> --input-state <state_id> --format text
molecular state characterize <experiment_id> --input-state <state_id> --format json
molecular state characterize <experiment_id> --input-state <state_id> --format svg
```

`text` apresenta a ficha; `json` apresenta valores e proveniência; `svg` solicita o desenho. Uma opção para incluir SVG no JSON pode ser discutida, sem criar exportador multifile no primeiro recorte. Text e JSON não devem exigir desenho para um cálculo independente funcionar. O resultado do serviço deve permitir que o futuro cliente 020-C peça a ficha e a figura em uma chamada coordenada.

O comando técnico é uma exposição fina do serviço para teste e uso avançado. `tbmp init/create/open/show`, perguntas interativas, seleção guiada de operações e apresentação amigável de todo o experimento permanecem no 020-C. Não precisa existir uma GUI ou novo alias para o cálculo ser validado no 020-A.

Abrir automaticamente browser ou escolher caminhos de exportação não está nesta proposta. O 020-C poderá consumir SVG/dados e gerenciar a interação com o usuário, conforme seu próprio contrato.

## 13. Spike independente executado

Foi criado e executado um script isolado fora do repositório de código. Ele usa RDKit 2026.03.6 de um venv novo já preparado nesta sessão, sem mocks, sem novos pacotes e sem alterar a plataforma.

Entradas: os cinco SDFs 2D baixados anteriormente pela CLI real. A origem e os hashes estão no JSON de evidência. O spike não promoveu estados em Linux nem contornou a restrição Windows/NTFS.

Para cada um dos cinco RAWs: leitura em BytesIO, exatamente um registro e fragmento, dez valores finitos, desenho SVG, segunda execução do desenho, comparação do Mol original antes/depois e do arquivo RAW antes/depois, e round-trip de SMILES com os mesmos valores dentro de tolerância 1e-9 para floats.

| Entrada | Fórmula | Massa molar g/mol | TPSA Å² | cLogP | Resultado |
|---|---|---:|---:|---:|---|
| Cafeína | C8H10N4O2 | 194,194 | 61,82 | -1,0293 | Dez valores e SVG |
| Ácido rosmarínico | C18H16O8 | 360,318 | 144,52 | 1,7613 | Dez valores e SVG |
| Imidacloprido | C9H10ClN5O2 | 255,665 | 83,66 | 0,6879 | Dez valores e SVG |
| Diclofenaco | C14H11Cl2NO2 | 296,153 | 49,33 | 4,3641 | Dez valores e SVG |
| Atrazina | C8H14ClN5 | 215,688 | 62,73 | 1,7771 | Dez valores e SVG |

Esses são cálculos observados nas entradas especificadas, não dados experimentais ou valores copiados do PubChem. O resultado completo sem arredondamento de apresentação está no JSON. As cinco repetições locais de SVG foram byte-idênticas; isso não é contrato de igualdade entre builds ou sistemas.

Os cinco SVGs passaram por parsing XML e foram renderizados para inspeção visual local. A política conservadora mostra os H explícitos recebidos e deixa o desenho mais carregado. Isso torna concreta a decisão de exibição da Seção 9: simplificar a figura pode ser útil, mas requer uma política declarada sobre a cópia gráfica, sem modificar o estado científico. A inspeção não foi feita no navegador Windows.

Oito sondas adicionais: H isotópico, carbono-13, amônio, acetato, estereocentro definido, estrutura desconectada, enxofre e fósforo. As sondas observaram APIs e efeitos de parâmetros. Em especial, a sonda desconectada produziu descritores no RDKit: demonstra que a biblioteca sozinha não impõe a política proposta de rejeição; essa política deverá ser validada pela plataforma.

Limites: não foi executada uma implementação futura de caracterização porque ela não existe; não foram validados parser completo de SMILES, casos de erro em produção, acesso seguro no Windows, CLI nova, aparência em browser Windows ou suíte pytest nesta etapa. O round-trip de SMILES de um spike não prova o comportamento de um parser de produção ainda não especificado.

## 14. Regressões e testes propostos

Não fixar uma contagem artificial de testes antes da especificação. A matriz deve cobrir comportamentos independentes:

- Módulos e --help continuam funcionando sem o extra rdkit.
- Nenhuma importação direta RDKit fora do adaptador; nenhum Mol atravessa sua fronteira.
- Não alterar parâmetros ou resultados da enumeração existente; não reusar o resolvedor de enumeração para descrever outra operação.
- Estado SDF promovido e estado SMILES publicado pela enumeração são entradas reais.
- Falhas para formato incompatível, checksum inválido/divergente, arquivo ausente, registro inválido, SDF multimolécula, molécula desconectada e SMILES extra/múltiplo.
- Validação do acesso ao artefato segundo a decisão de leitura segura, incluindo redirecionamento e substituição onde o contrato exigir.
- Átomos/H isotópicos, cargas e estereoquímica tratados sem alteração silenciosa.
- Massa média versus exata, opção Strict e TPSA S/P comprovadas por casos discriminantes.
- Resultados finitos, unidades explícitas e arredondamento só na apresentação.
- SVG válido, cópia de trabalho, RAW e representação intactos; conferência visual em exemplos representativos.
- Erro de figura distingue-se de cálculo; ausência de sucesso parcial no modo que exige figura.
- Não surgem entidades, estados, transformações, attempts de tautomerização ou registries novos em consultas.
- Interrupções preservadas; logs RDKit restaurados quando houver supressão localizada.
- Saída JSON parseável, text legível e SVG isolado, com códigos de saída coerentes e erros sem caminhos sensíveis.

A prova de correção não pode consistir só em chamar duas vezes a mesma função e comparar resultados. Repetição observa determinismo local; valores científicos e políticas precisam de fixtures discriminantes e expectativas justificadas. Testes reais do adapter devem ser acompanhados de testes do serviço e CLI; mocks servem para falhas de I/O e fronteiras específicas.

## 15. Tamanho e checkpoints candidatos

Esforço baixo é relativo ao aproveitamento de APIs prontas. O desenho de entrada segura e a decisão sobre persistência podem aumentar esse esforço.

Sequência sugerida, ainda não autorizada:

1. Resultado tipado e perfil científico; parsing/cálculos/desenho no adaptador existente.
2. Serviço de caracterização e leitura verificada da representação.
3. CLI técnica mínima e regressões cumulativas.
4. Ensaio no Windows das perguntas não resolvidas aqui, mais revisão independente.

Arquivos candidatos, sem allowlist congelada: novos modelos de caracterização e serviço com seus testes, ampliação aditiva de `rdkit_tautomer.py`, `cli.py` e testes correspondentes. `atomic.py` só entraria se a solução aprovada de leitura realmente precisar de uma extensão específica. Não renomear o adaptador nem reorganizar a arquitetura apenas por estética.

## 16. Questões que o revisor deve confrontar

| Questão | Posição inicial do arquiteto | O que falta decidir |
|---|---|---|
| Persistir ficha dentro do experimento? | Não no primeiro recorte | Confrontar com governance e necessidade de histórico |
| ExecutionAttempt existente serve? | Não com sua semântica atual | Confirmar que consulta derivada pode existir sem esse mecanismo |
| Formatos | SDF e SMILES | Gramática exata e comportamento para entradas legadas |
| Segurança de leitura de representação | Bytes únicos verificados; sem reutilizar raiz RAW falsa | Contrato completo e menor extensão necessária no Windows |
| TPSA | includeSandP=False explícito | Confirmar escolha ou nomear perfil alternativo |
| Figura | SVG solicitado, cópia em memória, sem PNG inicial | Política de H na exibição e falhas do desenho |
| Comando mínimo no 020-A | Expor operação técnica para validação | Confirmar divisão com UX interativa do 020-C |
| IDempotência | Nenhum registro de saída; consulta recalculada | Não chamar repetição de consulta de reutilização persistente |

O revisor deve classificar violações ou omissões significativas separadamente de preferências de nomes e organização. Não comparar o futuro 020-A com uma arquitetura universal de análises que este recorte não pretende implementar.

## 17. Materiais necessários para fechar a base normativa

Receber cópia integral e atual dos documentos centrais de governance e das especificações finais que regem modelo científico, fronteira RDKit, promoção e Incremento 020, incluindo o encerramento/revisão cumulativa do 020. Um ZIP de documentos é suficiente para transferência; não é necessário solicitar ao implementador um estudo novo.

Após leitura, o arquiteto deve reconciliar o que esta proposta sugere com as normas efetivas, atualizar as pendências e então submetê-la a revisão adversarial completa. Qualquer spike Windows solicitado deverá responder somente uma questão técnica específica ainda aberta.

## 18. Fontes e evidências

### Código primário fixado

- [Dependências](https://github.com/sysoutemanuelhenrique/molecular-platform/blob/08b797e0985e123ffd4d7ca7e5a5e8f040e63851/pyproject.toml)
- [Modelo científico](https://github.com/sysoutemanuelhenrique/molecular-platform/blob/08b797e0985e123ffd4d7ca7e5a5e8f040e63851/src/molecular/scientific.py)
- [Registro científico](https://github.com/sysoutemanuelhenrique/molecular-platform/blob/08b797e0985e123ffd4d7ca7e5a5e8f040e63851/src/molecular/scientific_registry.py)
- [Application Service](https://github.com/sysoutemanuelhenrique/molecular-platform/blob/08b797e0985e123ffd4d7ca7e5a5e8f040e63851/src/molecular/application.py)
- [ExecutionAttempt](https://github.com/sysoutemanuelhenrique/molecular-platform/blob/08b797e0985e123ffd4d7ca7e5a5e8f040e63851/src/molecular/execution.py)
- [Atomic e Route B](https://github.com/sysoutemanuelhenrique/molecular-platform/blob/08b797e0985e123ffd4d7ca7e5a5e8f040e63851/src/molecular/atomic.py)
- [Adaptador RDKit](https://github.com/sysoutemanuelhenrique/molecular-platform/blob/08b797e0985e123ffd4d7ca7e5a5e8f040e63851/src/molecular/rdkit_tautomer.py)
- [Resolver de experimento](https://github.com/sysoutemanuelhenrique/molecular-platform/blob/08b797e0985e123ffd4d7ca7e5a5e8f040e63851/src/molecular/context.py)

Os testes citados na Seção 4 foram lidos nos arquivos correspondentes do mesmo commit. Não foram reexecutados para esta proposta.

### Documentação primária RDKit

- https://www.rdkit.org/docs/source/rdkit.Chem.rdMolDescriptors.html
- https://www.rdkit.org/docs/source/rdkit.Chem.Crippen.html
- https://www.rdkit.org/docs/source/rdkit.Chem.rdDepictor.html
- https://www.rdkit.org/docs/source/rdkit.Chem.Draw.rdMolDraw2D.html

Consultadas em 19/10/2026. O site público serve documentação identificada como 2026.09.1 nesta consulta; portanto sua leitura não foi tratada como prova da API exata do pin. Os métodos e argumentos efetivamente usados foram confirmados por execução e docstrings no RDKit 2026.03.6 instalado. Não foi validada uma cópia arquivada integral da documentação do pin.

### Evidência reproduzível no pacote acompanhante

- `spike.py`: script isolado, não implementação da plataforma.
- `rdkit-spike-results.json`: versões, valores sem arredondamento de apresentação, hashes e sondas.
- Cinco SVGs gerados a partir dos RAWs identificados no JSON.
- Manifesto de identidades dos arquivos do pacote.

Os SVGs serão apenas evidência derivada da biblioteca, sem status de artefato científico registrado. O pacote não inclui o repositório, venv, credenciais ou arquivos privados do usuário.

## 19. Estado final da proposta

ARCHITECTURAL PROPOSAL COMPLETE: YES
PROPOSAL STATUS: PRELIMINARY
HEAD STUDIED: 08b797e0985e123ffd4d7ca7e5a5e8f040e63851
RDKit SPIKE EXECUTED: YES
SPIKE PLATFORM: LINUX
GOVERNANCE ORIGINALS VERIFIED: NO
READY FOR PRELIMINARY ARCHITECTURAL REVIEW: YES
READY FOR NORMATIVE DRAFT: NO
READY FOR IMPLEMENTATION: NO
FINAL SPECIFICATION FROZEN: NO
CODE REPOSITORY MODIFIED: NO
