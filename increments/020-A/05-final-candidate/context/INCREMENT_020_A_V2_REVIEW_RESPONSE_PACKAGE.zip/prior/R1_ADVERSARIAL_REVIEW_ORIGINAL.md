# Revisão adversarial independente — Turing-Bohr Molecular Platform

APPROVE WITH CHANGES — apenas para evolução da proposta

Documento: `INCREMENT_020_A_ARCHITECTURAL_PROPOSAL_PRELIMINARY.md` Incremento: 020-A — Caracterização molecular e representação 2D Tipo de revisão: arquitetural, científica e documental Escopo: somente leitura, sem implementação.

## 1. Parecer executivo

A proposta está bem alinhada à arquitetura científica da Turing-Bohr. Concordo especialmente com três decisões:

- Preservar `MolecularState` como representação mínima e imutável.
- Manter RDKit atrás de um adaptador, sem permitir que objetos `Mol` atravessem as fronteiras de domínio.
- Tratar descritores e desenhos 2D como resultados derivados, sem criar novas entidades moleculares ou alterar os arquivos científicos.

O recorte também é apropriado para um incremento pequeno: uma caracterização de estado individual, com dez descritores bem definidos e SVG opcional.

Entretanto, não autorizaria a implementação ainda. Existem decisões que precisam ser resolvidas antes do congelamento normativo.

## 2. Achados adversariais

| ID | Severidade      | Achado                                                                                                         | Recomendação                                                                                                                            |
| -- | --------------- | -------------------------------------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------- |
| B1 | BLOCKER de gate | Os documentos originais de governance não foram verificados.                                                   | Recuperar e confrontar os contratos vigentes antes da especificação normativa.                                                          |
| M1 | MAJOR           | A política de leitura segura de representações científicas permanece indefinida.                               | Formalizar confinamento, tratamento de links/reparse points e proteção contra substituição durante a leitura.                           |
| M2 | MAJOR           | Caracterização sob demanda não produz histórico durável de investigação.                                       | Decidir explicitamente se isso é compatível com o contrato científico existente e como uma futura persistência consumirá os resultados. |
| M3 | MAJOR           | A gramática de entrada SMILES e SDF ainda não está inteiramente especificada.                                  | Fixar tratamento de linhas, codificação, campos extras, registros inválidos e estruturas desconectadas.                                 |
| M4 | MAJOR           | O perfil de representação SVG ainda possui decisões não congeladas de segurança, hidrogênios e estereoquímica. | Definir e testar a política de desenho antes da implementação.                                                                          |
| N1 | MINOR           | A terminologia de massa exata pode gerar interpretação analítica indevida.                                     | Explicitar fórmula isotópica, cargas e diferença em relação a valores experimentais de m/z.                                             |
| N2 | MINOR           | O perfil TPSA exclui contribuições adicionais de S/P.                                                          | Manter essa escolha expressa na identificação do perfil e nos testes discriminantes.                                                    |
| N3 | MINOR           | O esforço foi classificado como baixo antes da solução de leitura segura.                                      | Reavaliar esforço após resolver M1.                                                                                                     |

### B1 — Ausência dos originais de governance

O documento reconhece que os arquivos originais não foram recuperados e que as transcrições anteriores não substituem evidência documental integral.

Essa transparência é correta, mas impede concluir que o cálculo sob demanda sem registro persistente obedece aos contratos atuais.

Decisão: manter o gate normativo fechado.

### M1 — Segurança e identidade dos arquivos

A sequência de leitura proposta verifica o checksum dos bytes utilizados, o que é positivo.

Porém, verificar o checksum não demonstra, isoladamente, que o acesso ao arquivo ocorreu dentro da fronteira autorizada.

O contrato precisa responder como serão tratados redirecionamentos por links, substituição concorrente de arquivos e peculiaridades de Windows/NTFS, sem reutilizar indevidamente a política de RAW vinculada a `LigandInput`.

Este ponto deve ser resolvido antes da implementação do serviço.&#x20;

INCREMENT_020_A_ARCHITECTURAL_PROPOSAL_PRELIMINARY.md



### M2 — Persistência e reprodutibilidade

Este é o ponto que mais merece atenção considerando a evolução científica da Turing-Bohr.

Concordo que não é necessário criar um registry de caracterização no 020-A se os contratos existentes permitirem consultas derivadas sem persistência.

Mas precisamos distinguir:

- Reprodutibilidade potencial: o resultado contém dados suficientes para reconstruir a execução.
- Reprodutibilidade registrada: a plataforma preserva duravelmente a execução, os parâmetros, as entradas e os resultados.

A alternativa A oferece a primeira possibilidade, não a segunda.

Minha recomendação é aceitar provisoriamente o cálculo sob demanda, desde que o resultado contenha proveniência suficientemente completa e que essa limitação seja registrada como decisão arquitetural explícita, sem chamar a operação de workflow persistido.&#x20;

INCREMENT_020_A_ARCHITECTURAL_PROPOSAL_PRELIMINARY.md



### M3 — Contrato de parsing

É correta a decisão de aceitar SDF e SMILES, especialmente porque a enumeração de tautômeros já publica estados em SMILES.

A operação deve garantir que entradas com múltiplos registros, conteúdo suplementar ou estruturas desconectadas não sejam interpretadas silenciosamente.

Também considero importante testar estruturas com cargas, estereoquímica e marcação isotópica, verificando a preservação do significado químico.

### M4 — Representação 2D

A proposta acerta ao declarar que coordenadas 2D geradas para visualização não são conformações experimentais nem novas entidades de domínio.

Entretanto, o SVG deve ser tratado como saída derivada potencialmente não confiável: é necessário controlar a presença de conteúdo externo, scripts, elementos inesperados e metadados importados de arquivos de origem.

Além disso, a simplificação visual de hidrogênios não pode alterar a interpretação de isótopos ou estereoquímica.&#x20;

INCREMENT_020_A_ARCHITECTURAL_PROPOSAL_PRELIMINARY.md



## 3. Avaliação científica dos dez descritores

O conjunto proposto é apropriado para uma primeira ficha de caracterização molecular, incluindo fórmula, massas, carga formal, átomos pesados, HBD, HBA, ligações rotacionáveis, TPSA e cLogP.

Eu manteria os dez campos inicialmente propostos. Não acrescentaria propriedades como pKa, solubilidade, permeabilidade ou classificações farmacológicas neste incremento.

Há um benefício científico em limitar a operação a valores cujo método computacional possa ser identificado precisamente. Isso diminui o risco de apresentar previsões dependentes de modelos como propriedades experimentais estabelecidas.

O documento já reconhece corretamente que cLogP não representa logD, que carga formal não equivale a carga parcial e que descritores dependem do estado molecular analisado.&#x20;

INCREMENT_020_A_ARCHITECTURAL_PROPOSAL_PRELIMINARY.md



## 4. Decisões que recomendo manter

Aprovadas conceitualmente:

- Operação de caracterização de um `MolecularState` já registrado.
- Nenhuma mutação de `ScientificEntity`, `MolecularState` ou `Conformer`.
- Nenhum novo `StateTransformationRecord`.
- Nenhuma utilização artificial de `ExecutionAttempt` como se caracterização fosse enumeração de tautômeros.
- Descritores tipados e imutáveis.
- SVG opcional gerado a partir de cópia molecular.
- Aceitação dos formatos SDF e SMILES.
- Comando técnico mínimo, preservando a experiência guiada para 020-C.

A distinção entre consulta científica e transformação de estado está particularmente bem resolvida no desenho proposto.

## 5. Gates recomendados antes do rascunho normativo

Recuperar governance original e encerramento do Incremento 020

Definir contrato de leitura segura de representações

Decidir formalmente a ausência de persistência em 020-A

Congelar política de parsing SDF/SMILES

Congelar perfil SVG e sua validação de segurança

Preparar matriz de testes com fixtures discriminantes

0 de 6 gates marcados. Controle de acompanhamento, sem efeito sobre o repositório.

## 6. Veredito formal

| Critério                             | Resultado                                                    |
| ------------------------------------ | ------------------------------------------------------------ |
| Coerência arquitetural preliminar    | Favorável                                                    |
| Semântica científica dos descritores | Favorável, com refinamentos                                  |
| Preservação do domínio existente     | Favorável                                                    |
| Política de segurança de leitura     | Pendente                                                     |
| Persistência / governance            | Pendente                                                     |
| Evidência do spike RDKit             | Documentada, não reproduzida independentemente nesta revisão |
| Pronto para especificação normativa  | NÃO                                                          |
| Pronto para implementação            | NÃO                                                          |

Observação sobre a independência: conferi o documento integral enviado, mas não executei a suíte nem verifiquei diretamente o commit remoto ou os documentos originais de governance. Portanto, aceito os fatos relatados pelo arquiteto como evidências apresentadas, não como resultados independentemente reproduzidos.

### Minha decisão

APROVAR COM ALTERAÇÕES a direção arquitetural preliminar do Incremento 020-A.

Não considero necessário redesenhar a proposta. Os problemas identificados são principalmente de fechamento de contratos e garantias operacionais.

Há ainda uma razão estratégica para preservar esse desenho: a caracterização molecular será uma capacidade útil para o projeto de prospecção de bioativos que estamos desenvolvendo para o mestrado. Porém, não devemos incorporar agora toda a visão de workflows científicos, banco de dados colaborativo e triagem molecular ao escopo do 020-A. Isso comprometeria o controle incremental da Turing-Bohr.

O próximo passo recomendado ao arquiteto é recuperar a documentação normativa, resolver B1 e M1–M4 e apresentar uma proposta revisada. Somente então deveremos avaliar o congelamento de uma especificação implementável.