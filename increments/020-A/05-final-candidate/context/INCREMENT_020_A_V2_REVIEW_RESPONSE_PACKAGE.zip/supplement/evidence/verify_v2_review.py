"""Read-only API and parser research, not product implementation.
Requires an existing RDKit 2026.03.6 environment and a read-only project clone.
No dependency installation, network access or code-repository writes.
"""
import argparse,hashlib,importlib.util,json,stat,subprocess,sys,xml.parsers.expat as expat
from pathlib import Path
sys.dont_write_bytecode=True
from rdkit import Chem,RDConfig,rdBase
from rdkit.Chem import rdDepictor
from rdkit.Chem.Draw import rdMolDraw2D
ap=argparse.ArgumentParser();ap.add_argument('--repository',type=Path,required=True);ap.add_argument('--output',type=Path,required=True);a=ap.parse_args()
assert rdBase.rdkitVersion=='2026.03.6'
repo=a.repository.resolve()
if a.output.resolve().is_relative_to(repo):raise SystemExit('Output must be outside the read-only code repository.')
target='08b797e0985e123ffd4d7ca7e5a5e8f040e63851'
head=subprocess.run(['git','-C',str(repo),'rev-parse','HEAD'],check=True,capture_output=True,text=True).stdout.strip();assert head==target
source=repo/'src/molecular/inputs.py'
spec=importlib.util.spec_from_file_location('_tbmp_inputs_readonly_probe',source);mod=importlib.util.module_from_spec(spec);sys.modules[spec.name]=mod;spec.loader.exec_module(mod)
ids=[]
for value,expected in [('a',True),('A1_state-2',True),('0',True),('',False),('.',False),('..',False),('.staging',False),('x/y',False),('x\\y',False),('x y',False),('x\n',False),('C:state',False),('state.id',False),('á',False),('_state',False),('-state',False),(None,False),(1,False),('CON',True),('NUL',True),('LPT1',True)]:
    try:result=mod.validate_input_id(value);accepted=True;assert result==value
    except ValueError:accepted=False
    assert accepted==expected,(value,accepted)
    ids.append({'input':value,'format_accepted':accepted,'expected':expected})
m=Chem.MolFromSmiles('CCO')
args={'canonOrient':True,'clearConfs':True,'nFlipsPerSample':0,'nSample':0,'sampleSeed':0,'permuteDeg4Nodes':False,'forceRDKit':True,'useRingTemplates':False}
conf_id=rdDepictor.Compute2DCoords(m,**args);assert conf_id==0 and m.GetNumConformers()==1
font=Path(RDConfig.RDDataDir)/'Fonts'/'Telex-Regular.ttf';font_data=font.read_bytes()
assert stat.S_ISREG(font.lstat().st_mode) and len(font_data)==38940
assert hashlib.sha256(font_data).hexdigest()=='eeaa2d17d105b6b46e5368ecd990f5b19c50131ff922dbf79bfb9bb45c249871'
drawer=rdMolDraw2D.MolDraw2DSVG(600,400);drawer.drawOptions().fontFile=str(font);drawer.DrawMolecule(m);drawer.FinishDrawing();svg=drawer.GetDrawingText();assert '<svg' in svg
class ForbiddenXML(ValueError):pass
def guarded_xml_probe(data):
    # Tests parser-level policy only, NOT SVG elements/styles validation.
    if len(data)>1024*1024:raise ValueError('Research fixture limit')
    p=expat.ParserCreate(namespace_separator='|');events=[];external_calls=[]
    def reject_doctype(*args):events.append('doctype-rejected');raise ForbiddenXML('DOCTYPE forbidden')
    def reject_entity(*args):events.append('entity-rejected');raise ForbiddenXML('Entity declaration forbidden')
    def reject_external(*args):external_calls.append(True);raise ForbiddenXML('External entity forbidden')
    assert p.SetParamEntityParsing(expat.XML_PARAM_ENTITY_PARSING_NEVER)
    p.UseForeignDTD(False)
    p.StartDoctypeDeclHandler=reject_doctype;p.EntityDeclHandler=reject_entity;p.ExternalEntityRefHandler=reject_external
    try:p.Parse(data,True);accepted=True;error=None
    except (ForbiddenXML,expat.ExpatError) as e:accepted=False;error=type(e).__name__
    return {'accepted':accepted,'events':events,'external_handler_calls':len(external_calls),'error':error}
xmls=[]
fixtures=[('generated-svg',svg.encode(),True),('predefined-xml-entity',b'<svg xmlns="http://www.w3.org/2000/svg">a &amp; b</svg>',True),('internal-entity',b'<!DOCTYPE svg [<!ENTITY t "abc">]><svg>&t;</svg>',False),('external-dtd',b'<!DOCTYPE svg SYSTEM "urn:tbmp:never-fetch"><svg/>',False),('external-entity',b'<!DOCTYPE svg [<!ENTITY t SYSTEM "urn:tbmp:never-fetch">]><svg>&t;</svg>',False),('doctype-utf16','<!DOCTYPE svg [<!ENTITY t "abc">]><svg>&t;</svg>'.encode('utf-16'),False),('undefined-entity',b'<svg>&unknown;</svg>',False)]
for label,data,expected in fixtures:
    r=guarded_xml_probe(data);assert r['accepted']==expected,(label,r);assert r['external_handler_calls']==0
    xmls.append({'case':label,'expected_accept':expected,**r})
params=Chem.SmilesParserParams()
status=subprocess.run(['git','-C',str(repo),'status','--porcelain=v1'],check=True,capture_output=True,text=True).stdout
check=subprocess.run(['git','-C',str(repo),'diff','--check'],check=False,capture_output=True,text=True)
out={'scope':'Read-only research: no product readers, full SVG validator, Windows validation or pytest executed.','python':sys.version,'rdkit_version':rdBase.rdkitVersion,'expat_version':expat.EXPAT_VERSION,'repository_head':head,'input_validator_source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'input_id_pattern':mod._INPUT_ID_PATTERN.pattern,'id_cases':ids,'nSample':{'exact_kwargs_executed':args,'returned_conformer_id':conf_id,'docstring':rdDepictor.Compute2DCoords.__doc__},'font':{'location_relative_to_rdkit_package':'rdkit/Data/Fonts/Telex-Regular.ttf','is_real_file':True,'bytes':len(font_data),'header_hex':font_data[:4].hex(),'sha256':hashlib.sha256(font_data).hexdigest(),'fontFile_assignment_read_back_equal':drawer.drawOptions().fontFile==str(font),'svg_draw_completed':True},'smiles_parser_defaults':{name:getattr(params,name) for name in ['sanitize','removeHs','parseName','allowCXSMILES']},'xml_parser_policy_cases':xmls,'git_status_porcelain':status,'git_diff_check_exit_code':check.returncode}
assert not status and check.returncode==0
a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:out[k] for k in ['rdkit_version','expat_version','repository_head','input_id_pattern','font','smiles_parser_defaults','xml_parser_policy_cases','git_status_porcelain','git_diff_check_exit_code']},ensure_ascii=False,indent=2))
