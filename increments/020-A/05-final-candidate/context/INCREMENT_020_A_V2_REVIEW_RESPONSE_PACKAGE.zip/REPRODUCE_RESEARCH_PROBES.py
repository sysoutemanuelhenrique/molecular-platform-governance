"""Optional reproduction of research only. Read before running.
Requires an existing Python environment with rdkit==2026.3.6.
No installation, network, platform CLI, Windows reader or repository changes.
Writes only within a new TemporaryDirectory, removed on exit.
"""
from pathlib import Path
import hashlib,json,math,shutil,subprocess,sys,tempfile
from rdkit import rdBase
PACKAGE=Path(__file__).resolve().parent
if rdBase.rdkitVersion!='2026.03.6':
    raise SystemExit('Use an already prepared environment with RDKit 2026.03.6; no dependency was installed.')
manifest=json.loads((PACKAGE/'MANIFEST.json').read_text(encoding='utf-8'))
for row in manifest['files']:
    member=Path(row['path'])
    if member.is_absolute() or '..' in member.parts:raise SystemExit('Invalid manifest path')
    data=(PACKAGE/member).read_bytes()
    if hashlib.sha256(data).hexdigest()!=row['sha256']:raise SystemExit('Package identity mismatch: '+member.as_posix())
def copy(src,dst):
    dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dst)
with tempfile.TemporaryDirectory(prefix='tbmp-020a-research-') as name:
    work=Path(name)
    for p in sorted((PACKAGE/'evidence/raw').glob('*/*.sdf')):
        copy(p,work/'academic_rehearsal_20261019/examples/caffeine-demo/inputs/ligands'/p.parent.name/p.name)
    jobs=[
      ('evidence/preliminary/spike.py','020a_architecture_20261019/spike.py','020a_architecture_20261019/evidence/rdkit-spike-results.json'),
      ('evidence/check_review_claims.py','020a_reconciliation_20261020/check_review_claims.py','020a_reconciliation_20261020/review-claims-evidence.json'),
      ('evidence/profile/profile_probe.py','020a_governance_20261020/evidence/profile_probe.py','020a_governance_20261020/evidence/profile-probe-results.json')]
    results=[]
    for src,script,result in jobs:
        copy(PACKAGE/src,work/script)
        run=subprocess.run([sys.executable,str(work/script)],cwd=work,text=True,capture_output=True,check=False)
        if run.returncode:
            print(run.stdout);print(run.stderr,file=sys.stderr);raise SystemExit(run.returncode)
        value=json.loads((work/result).read_text(encoding='utf-8'))
        results.append(value)
    expected=json.loads((PACKAGE/'evidence/preliminary/rdkit-spike-results.json').read_text(encoding='utf-8'))
    assert len(results[0]['raw_cases'])==len(expected['raw_cases'])==5
    for a,b in zip(results[0]['raw_cases'],expected['raw_cases']):
        assert a['input']==b['input'] and a['sha256']==b['sha256']
        for k,v in a['values'].items():
            ref=b['values'][k]
            assert math.isclose(v,ref,rel_tol=0,abs_tol=1e-9) if isinstance(v,float) else v==ref
    profile=results[2]
    summary={'scope':'Research reproduction only; no production service, verified Windows reader, SVG validator or pytest was run.',
      'rdkit_version':rdBase.rdkitVersion,'preliminary_raw_cases':len(results[0]['raw_cases']),
      'review_claim_cases':len(results[1]['cases']),'profile_raw_cases':len(profile['raw_examples']),
      'smiles_cases':len(profile['smiles_cases']),'synthetic_sdf_cases':len(profile['sdf_cases']),
      'additional_drawing_cases':len(profile['additional_drawing_cases']),
      'descriptor_reference_comparison':'PASS within 1e-9 for floats',
      'svg_byte_equality_cross_platform_required':False,
      'temporary_files_removed_after_exit':True}
print(json.dumps(summary,ensure_ascii=False,indent=2))
