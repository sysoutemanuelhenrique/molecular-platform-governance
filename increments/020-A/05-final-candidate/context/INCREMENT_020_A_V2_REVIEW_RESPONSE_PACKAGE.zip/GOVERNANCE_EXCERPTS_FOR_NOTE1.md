# Cláusulas originais para verificação de NOTE-1

Extratos para facilitar leitura. Os documentos integrais estão nos caminhos abaixo, byte-idênticos aos originais do pacote anterior. O hash é do documento integral, não do extrato. O arquiteto não atribui aprovação independente à sua própria extração.


## Fonte

`normative/strategy/LIGAND_CONFORMER_GENERATION_AND_GEOMETRY_OPTIMIZATION_SCOPE_DECISION.md`

SHA-256 integral: `50d443ac30e3cdfe0964dc0db5ea51f595a32690173f656bed4d27dad11a619e`


### Trecho extraído

## 11. Roadmap revisado

- Incremento 018 — RAW/PubChem → Scientific Model;
- Incremento 019 — `ExperimentalConditions` declaradas pelo cientista;
- Incremento 020 — protonação e microestados;
- Incremento 021 — Conformer Generation Foundation;
- Incremento 022 — Geometry Optimization;
- Incremento 023 — aquisição de receptor/RCSB;
- Incremento 024 — preparação de receptor;
- Incremento 025 — binding site/grid;
- Incremento 026 — `DockingRunSpec`;
- Incremento 027 — primeiro motor de docking;
- Incremento 028 — `Pose`;
- Incremento 029 — RMSD/redocking/validação;
- Incremento 030+ — workflow integrado, GUI e expansões posteriores.

Essa numeração é roadmap provisório, não contrato congelado.




## Fonte

`normative/increments/020/13-final-specification/INCREMENT_020_FINAL_SPECIFICATION.md`

SHA-256 integral: `cf6cb534f9267d51e718052c7b36a2293c522bc566c99cf3bb2ef5909385a0a6`


### Trecho extraído

## 7. Fora de Escopo

Herdado e reafirmado do Draft original e do Revised Discovery, sem alteração — nenhuma correção desta revisão amplia o escopo em direção a química ou materialização:

### Transformação estrutural — fora do 020 (fica para o 021)
Materializar assembly; extrair cadeias; resolver/remover altlocs fisicamente; remover água/ligante/cofator/metal fisicamente; reconstruir componente; gerar novo mmCIF/PDB; produzir `PreparedReceptorArtifact`.

### Preparação química — fora do 020 (fica para 022–024 ou posterior)
Adicionar hidrogênios; atribuir protonação; calcular pKa; corrigir orientação de His/Asn/Gln; construir átomos ou resíduos; reparar loops; atribuir cargas; minimizar geometria; solvatar; adicionar membrana.

### Itens já fora de escopo, reafirmados sem alteração
Docking; search space; scoring; `Pose`; ranking; execução Vina; PDBQT como modelo central; redocking; RMSD de validação; conformer generation; ETKDG; otimização de geometria; campos de força; MOPAC; HF; DFT; STO/GTO; enumeração de microestados; seleção automática da melhor estrutura; GUI; banco de dados; scheduler; execução em nuvem; IA para decisões científicas; recomendações automáticas; simulação de membrana; dinâmica molecular; cascatas intracelulares.

### Explicitamente não resolvido por esta especificação, por decisão (não por omissão)
- Determinação automática de função biológica de qualquer componente não-polimérico além de água/íon metálico (Seção 17).
- Resolução de membership de cadeia dentro de um assembly declarado (assemblies são apenas listados, nunca resolvidos).
- Qualquer mecanismo de revisão/supersedes para `ReceptorSelectionPolicy` ou `ResolvedReceptorSelection`.
- Qualquer identidade secundária derivada de conteúdo (`semantic_key`-like) para `ResolvedReceptorSelection` — distinta e não confundida com o `inspection_id` determinístico introduzido por esta revisão para `ReceptorInspectionReport` (Seção 23.1 explica a distinção).
- Re-resolução de uma política contra uma inspeção diferente da que foi originalmente referenciada — eliminada como possibilidade por construção (Seção 24), não apenas proibida por regra.
- Materialização física de qualquer registro legado de conectividade PDB (`SSBOND`/`LINK`/`CONECT`) — apenas inventariados (Seção 18.4).

---




## Fonte

`normative/increments/020/13-final-specification/INCREMENT_020_FINAL_SPECIFICATION.md`

SHA-256 integral: `cf6cb534f9267d51e718052c7b36a2293c522bc566c99cf3bb2ef5909385a0a6`


### Trecho extraído

## 34. Integração com o Incremento 021

### 34.1 Contrato de leitura — atualizado

```python
load_protein(project_dir, protein_input_id) -> ProteinInput                              # já existente
load_resolved_receptor_selection(project_dir, selection_id) -> ResolvedReceptorSelection   # Seção 25
load_receptor_inspection(project_dir, inspection_id) -> ReceptorInspectionReport           # NOVO, Seção 25
```

O 021 carrega `ResolvedReceptorSelection` por `selection_id` para obter a seleção confirmada (`resolved_model`/`resolved_assembly`/`resolved_chains`/`resolved_component_dispositions`), e, quando precisar do inventário completo (por exemplo, para decidir como materializar componentes não cobertos pela seleção explícita), carrega o `ReceptorInspectionReport` completo por `inspection_id` — nunca a partir de uma cópia embutida, porque essa cópia não existe mais (Seção 22.2). Isso é uma melhoria direta sobre o contrato do Draft original: o 021 agora tem acesso ao inventário completo por referência estável, sem a penalidade de armazenamento que a duplicação impunha.

### 34.2 O que o 021 poderá fazer — inalterado, fora de escopo deste documento

Materializar o assembly declarado; extrair fisicamente as cadeias selecionadas; resolver fisicamente altloc; aplicar fisicamente as disposições de água/metal/componente; produzir o primeiro `PreparedReceptorArtifact`; decidir se estende `StateTransformationRecord.operation` ou introduz vocabulário próprio.

### 34.3 Compatibilidade de schema

`schema_version="1.0"` em todos os quatro modelos (agora incluindo `ReceptorInspectionReport` como objeto persistido de primeira classe) permanece um compromisso: o 021 pode depender da forma exata descrita neste documento enquanto ela permanecer `"1.0"`. `INSPECTION_PROFILE_VERSION` (Seção 15.1) é um versionamento **adicional e independente**, específico às regras de classificação da inspeção — uma mudança nele nunca invalida `schema_version="1.0"`, e vice-versa.

---


