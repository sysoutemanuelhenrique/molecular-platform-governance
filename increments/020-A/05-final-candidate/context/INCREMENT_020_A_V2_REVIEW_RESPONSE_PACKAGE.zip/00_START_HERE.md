# Pacote único para revisão independente — Incremento 020-A

## O que fazer com este ZIP

Envie **este mesmo ZIP, sem editar seu conteúdo, a cada um dos dois revisores**. Não envie ao Claude implementador como ordem de implementação.

Leia primeiro `INCREMENT_020_A_ARCHITECTURAL_PROPOSAL_REVISED.md`, depois a rastreabilidade. Consulte os originais em `normative/` e a evolução documental em `prior/`. Os scripts/JSON/SVG em `evidence/` são pesquisa isolada; não são a implementação futura.

## Pedido ao revisor

> Atue como revisor adversarial independente e read-only da proposta revisada do Incremento 020-A. Leia a proposta e a rastreabilidade deste pacote, confronte as decisões A-01–A-14 com os contratos originais pertinentes e com o código real do SHA 08b797e0985e123ffd4d7ca7e5a5e8f040e63851. Reavalie os itens B1/M1–M4 de R1 e os itens de R2 conforme a matriz da §14, verificando as correções factuais RDKit por fonte primária ou pelo pin 2026.03.6. Diferencie fatos, evidência fornecida, observação própria, inferência e preferência. Se não puder acessar o código ou executar ensaios, declare o limite sem presumir seu conteúdo. Classifique BLOCKERS/MAJORS/MINORS/NOTES e dê veredito sobre prontidão **para rascunho de especificação**, não implementação. Não modifique o projeto, não congele contrato, não amplie o escopo para sanitização universal, persistência universal ou funcionalidades futuras e não desloque o 021 por preferência de numeração. Identifique qualquer norma adicional realmente decisiva por documento/cláusula. Entregue seu parecer integral em Markdown e mantenha READY FOR IMPLEMENTATION: NO e FINAL SPECIFICATION FROZEN: NO.

Depois, devolva os dois pareceres ao arquiteto nesta conversa. O próximo passo será reconciliá-los; somente com o gate aprovado será produzido o rascunho. O próprio arquiteto não se declara revisor independente de sua proposta.

## Conteúdo e integridade

- Proposta revisada e `GOVERNANCE_TRACEABILITY_AND_EVIDENCE.md`.
- `SOURCE_IDENTITIES.json`: origens e identidades dos materiais recebidos/anteriores.
- `MANIFEST.json`: identidade de cada membro do pacote, exceto o próprio manifesto.
- `CODE_REFERENCE_HASHES.json`: links no SHA estudado e hashes dos arquivos consultados; sem segunda cópia do repositório.
- `normative/`: finais 016–020, CP4 e parecer cumulativo020; políticas de pesquisa e decisão de escopo de conformeros.
- `prior/`: proposta preliminar, dois pareceres originais e reconciliação já emitida, byte-idênticos.
- `evidence/`: scripts, JSONs, cinco RAWs e figuras de estudo.
- `REPRODUCE_RESEARCH_PROBES.py`: reprodução opcional com ambiente já preparado, sem instalação/rede/alteração de repositório. Leia antes de executar.

O ZIP é um pacote de transferência/revisão. Nenhum membro adquire condição normativa apenas por estar aqui. A especificação final020 permanece congelada na versão original, e as decisões 020-A continuam propostas.
