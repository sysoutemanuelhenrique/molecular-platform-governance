# Incremento 020-A — Resposta delimitada ao parecer arquitetural V2

Autor: Codex, arquiteto. Data: 20/10/2026. Natureza: reconciliação de evidências e complemento de decisões propostas. Não é novo parecer independente, especificação final ou autorização para implementar.

## 1. Parecer recebido e efeito sobre o gate

O arquivo original recebido `Texto colado(20261020-150137).txt` registra, nesta linha de revisão do Claude: **0 BLOCKERS, 0 MAJORS, 3 MINORS, 5 NOTES**, veredito **APPROVE WITH NON-BLOCKING NOTES**, prontidão para rascunho condicional. Esses números e condições são os do revisor, preservados; não são a contagem consolidada dos dois revisores nem aprovação de produção.

Esta resposta trata somente dos três MINOR, das cinco NOTES e da sequência de gates. A proposta revisada V2 e seus documentos acompanhantes permanecem byte-idênticos. Os esclarecimentos candidatos abaixo complementam A-07/A-09/A-11; serão incorporados no eventual rascunho depois do fechamento independente. Não se pede repetição integral da revisão A-01–A-14.

## 2. MINOR-1 — nSample: confirmado como já escrito

**EXPERIMENTALLY_VERIFIED; confiança alta no pin observado.** Foi executada novamente, em RDKit **2026.03.6**, a chamada Python:

```text
Compute2DCoords(mol, canonOrient=True, clearConfs=True,
  nFlipsPerSample=0, nSample=0, sampleSeed=0,
  permuteDeg4Nodes=False, forceRDKit=True, useRingTemplates=False)
```

Retorno observado: conformer interno de desenho com ID0, uma geometria na cópia. A docstring instalada expõe **nSample**, singular. O campo `nSamples` de um struct C++ não determina o nome do keyword da função Python.

**Disposição:** nenhuma correção da chamada da proposta é necessária. Encaminhar ao revisor a assinatura e execução registradas no JSON para encerrar a dúvida factual. Não trocar por nSamples. O objeto de coordenadas em memória não é Conformer publicado pela plataforma.

## 3. MINOR-2 — Telex: arquivo real, não hash de cabeçalho C++

**OBSERVED; confiança alta neste wheel instalado.** Existe o arquivo regular endereçável pelo caminho `Path(RDConfig.RDDataDir) / "Fonts" / "Telex-Regular.ttf"`. Os dados lidos nesta verificação são:

| Medida | Observação |
|---|---|
| Local relativo ao pacote | rdkit/Data/Fonts/Telex-Regular.ttf |
| Tamanho | 38.940 bytes |
| Primeiros quatro bytes | 00 01 00 00 |
| SHA-256 | eeaa2d17d105b6b46e5368ecd990f5b19c50131ff922dbf79bfb9bb45c249871 |

**EXPERIMENTALLY_VERIFIED; confiança alta no caso.** O caminho foi atribuído a `drawOptions().fontFile`, lido de volta sem alteração, e a geração SVG terminou com sucesso.

O hash vem dos bytes desse TTF, não de `telex_regular.h`, de extensão compilada ou de glifos reconstruídos. Uma fonte também poder estar embutida no C++ não exclui sua distribuição como arquivo no pacote observado.

**Disposição:** manter o mecanismo proposto. Ele não promete que todo wheel de todo sistema tenha a mesma distribuição. Na implementação Windows, verificar presença da fonte, registrar seu hash observado e comprovar a configuração; a ausência deverá falhar conforme o perfil, sem fallback. Não substituir agora por hash da extensão compilada e não adicionar pacote de fontes.

## 4. MINOR-3 — state_id: precisão aceita, reutilizando a autoridade atual

**SOURCE_VERIFIED; confiança alta.** No SHA `08b797e0985e123ffd4d7ca7e5a5e8f040e63851`, `src/molecular/inputs.py::validate_input_id` é a autoridade já utilizada pelos modelos/registries para identificadores análogos. O padrão é:

```text
^[A-Za-z0-9][A-Za-z0-9_-]*$
```

A implementação usa `fullmatch`, exige str e devolve o mesmo valor. Não normaliza, sanitiza, aplica strip, troca case ou aceita separadores. **EXPERIMENTALLY_VERIFIED:** a função real desse arquivo foi importada em modo sem bytecode e exercitada em 21 entradas; a matriz completa está no JSON. Não foi recriada uma regex paralela para provar seu comportamento.

**Complemento proposto C-01 para o passo1 de A-07:**

> Antes de construir paths ou fazer I/O do experimento, aplicar `molecular.inputs.validate_input_id(input_state_id)`, com a regra ASCII acima, por fullmatch, sem normalização. Erro de formato é INPUT ERROR no comando novo, com mensagem controlada que não reproduz o valor potencialmente sensível. Usar o valor validado na construção do path fixo. Ao validar o registro carregado, exigir igualdade exata entre seu id e o solicitado. Não alterar o validador compartilhado nem os modelos existentes.

A regex **não** rejeita todos os nomes de dispositivo Windows: CON/NUL/LPT1 foram aceitos como formato. Isso não autoriza abri-los. A-07 já prevê um controle adicional de nomes reservados/inválidos no leitor específico; ele deverá valer tanto para o filename do YAML como para o artefato. A construção de `CON.yaml`, por exemplo, não pode escapar desse controle. O rascunho deverá distinguir validade lexical do ID de elegibilidade do nome para armazenamento Windows, sem apresentar a primeira como prova da segunda.

**Disposição:** incorporar esse esclarecimento no rascunho e submetê-lo ao fechamento curto do revisor. Não é uma mudança global de identidade do projeto.

## 5. NOTES — disposição por item

| Item do parecer V2 | Disposição do arquiteto |
|---|---|
| NOTE-1 — governança não disponível ao revisor | Facilitar acesso: os originais integrais já estavam no ZIP revisado, em normative/, e continuam neste pacote. Acrescentado extrato legível das cláusulas exatas, com hashes e identificação das fontes. A confirmação independente cabe ao revisor que as ler. |
| NOTE-2 — defaults SMILES | Aceita como esclarecimento editorial: sanitize=True coincide com o default observado; removeHs=False, parseName=False e allowCXSMILES=False divergem dos defaults True. Os quatro defaults foram novamente observados no binding instalado. Não mudar valores do perfil. |
| NOTE-3 — implementação privada compartilhada | Aceita no escopo das duas funções novas; complemento C-02 abaixo. Não justifica refatorar leitores legados, criar resolvedor público genérico ou alterar o snapshot RAW do018. |
| NOTE-4 — parser XML | Aceita a necessidade de recusa no próprio parser; proposta concreta C-03 abaixo, sem nova dependência e sem depender exclusivamente de busca textual de DOCTYPE/ENTITY. |
| NOTE-5 — confirmações positivas | Registrar como confirmação do revisor quanto aos precedentes citados. Não extrapolar para auditoria universal de todos os caminhos históricos da CLI ou de erros de uso do próprio framework. O contrato proposto continua 0/sucesso e 1/falha de negócio. |

### C-02 — algoritmo privado comum das duas novas leituras

**DECISÃO PROPOSTA:** as duas entradas de A-07 devem compartilhar o algoritmo privado de verificação de componentes, identidade pré/pós-abertura e leitura pelo mesmo handle. Os wrappers determinam as raízes fixas, limites e exigência de checksum esperado. Não duplicar o protocolo sensível em duas cópias independentes. O helper é privado; o chamador externo não recebe poder para fornecer outra raiz. A forma exata das funções privadas fica para o rascunho/implementação, mantendo os contratos dos leitores atuais intactos.

### C-03 — parser XML com recusa de DTD/entidades

**DECISÃO PROPOSTA:** validar o SVG gerado com um parser configurado para impedir DTD e entidades declaradas, mantendo o perfil estático de elementos/atributos/style de A-11. Uma opção concreta sem dependência nova é `xml.parsers.expat`: recusar StartDoctypeDeclHandler e EntityDeclHandler, instalar ExternalEntityRefHandler que falha sem abrir recursos, usar SetParamEntityParsing(XML_PARAM_ENTITY_PARSING_NEVER) e não habilitar DTD estrangeira. Não criar child parser para resolver entidade externa. Essas recusas são do parser, não apenas de um teste de substring anterior.

A validação do vocabulário SVG deve ocorrer no mesmo fluxo configurado; não fazer depois uma segunda leitura XML com um parser permissivo. Preservar limite de bytes e proteções nativas do parser, incluindo reparse deferral quando disponível. Registrar/testar a versão do Expat no ambiente suportado. Se o ambiente não oferecer as garantias necessárias, falhar de modo explícito; não cair silenciosamente em parser inseguro. Isso não cria um sanitizador universal nem promete imunidade a todo consumo adversarial de CPU/memória.

**EXPERIMENTALLY_VERIFIED; confiança alta para os sete casos:** o ensaio de configuração do parser, em Python3.12.14/Expat2.8.3, aceitou o SVG gerado e uma entidade XML predefinida; recusou DTD interna/externa, entidade declarada externa, DOCTYPE em UTF-16 e entidade indefinida. Nos casos com DTD, a recusa ocorreu no callback de declaração; nenhum handler externo foi chamado. A sonda UTF-16 testa a recusa pelo parser, não acrescenta UTF-16 ao perfil SVG do produto.

Esse ensaio **não** implementa o validador completo SVG de produção e não comprova o comportamento do ambiente Windows futuro. A biblioteca XML padrão não deve ser descrita como segura por default; a configuração e os limites têm de ser explícitos e testados. Referência primária: [Python, xml.parsers.expat](https://docs.python.org/3.12/library/pyexpat.html), métodos de parâmetros/DTD e handlers; [XML vulnerabilities](https://docs.python.org/3.12/library/xml.html#xml-vulnerabilities). O ensaio registra a versão efetivamente executada; documentação web pode corresponder a patch posterior.

## 6. NOTE-1 — como obter a verificação independente solicitada

O revisor declarou não ter acesso ao ZIP original de governance. O ZIP revisado já fornecia as cópias pertinentes integralmente; não é necessário abrir o ZIP original para ler as seguintes fontes no pacote atual:

- `normative/strategy/LIGAND_CONFORMER_GENERATION_AND_GEOMETRY_OPTIMIZATION_SCOPE_DECISION.md`, §11: numeração do roadmap explicitamente provisória.
- `normative/increments/020/13-final-specification/INCREMENT_020_FINAL_SPECIFICATION.md`, §§7/34: materialização de receptor reservada ao021 e interfaces previstas.

`GOVERNANCE_EXCERPTS_FOR_NOTE1.md` contém essas seções extraídas sem reescrita e suas identidades. A confirmação mecânica pelo arquiteto não é contada como aprovação independente. Não se pede ao revisor aceitar a numeração apenas por autoridade do arquiteto: ele pode ler diretamente o texto original agora fornecido.

O outro revisor pode corroborar esses trechos e a convenção proposta de nomes pós-020. Não há autorização para renumerar021 ou modificar contratos congelados a partir desta resposta.

## 7. Gate Windows — ajuste de sequência solicitado

O parecer condiciona a prontidão para rascunho à validação Windows/NTFS dos **dois leitores novos**. Eles ainda são uma proposta; não há implementação autorizada a executar. Exigir sua implementação para poder escrever a especificação que a autorizará criaria uma dependência circular.

**Disposição do arquiteto: aceitar a exigência de evidência Windows, ajustando sua posição no fluxo.**

| Gate | Evidência necessária |
|---|---|
| Prontidão para rascunho | Modelo de acesso, ameaças/limites, perfil de plataforma, fontes/primitivos existentes e plano de testes suficientes para redigir o contrato |
| Rascunho e candidata final | Gramáticas, identidades, controle de fluxo, falhas e critérios Windows escritos de modo verificável; revisão independente antes de congelar |
| Implementação autorizada | Somente após a especificação aprovada, executar os cenários dos novos leitores no Windows/NTFS suportado |
| Aprovação do checkpoint de leitores/serviço | Exigir resultados reais Windows, além de testes controlados das falhas e regressões; sem esses resultados não aprovar esse checkpoint |

Se a revisão descobrir uma dúvida de viabilidade que impeça definir o contrato, poderá ser proposto **um spike Windows separado e delimitado**, sem implementar antecipadamente o leitor de produção. Neste parecer não foi demonstrada impossibilidade concreta do desenho; foi registrada ausência da validação de código ainda não escrito. Não solicito estudo genérico nem implementação ao Claude nesta etapa.

O texto original do parecer não foi alterado: pede-se ao próprio revisor confirmar esse ajuste de sequência. Não se transforma sua prontidão condicional em aprovação incondicional por decisão unilateral do arquiteto.

## 8. Evidência, reprodução e limites

Arquivos novos: `supplement/evidence/verify_v2_review.py` e `v2-review-verification.json`. O script requer ambiente existente RDKit2026.03.6, clone fixado e output fora do clone; não instala dependências nem usa rede. Executa APIs públicas, o validador real de IDs e uma sonda de configuração XML. Não é código de produto nem teste pytest. O arquivo de fonte do validador é identificado por hash no JSON, com referência ao SHA da plataforma.

Neste ambiente, o atalho Python do venv anterior não estava funcional; o teste usou Python3.12.14 disponível e o diretório site-packages existente do ambiente RDKit isolado, por configuração restrita ao processo. Não houve instalação, correção do venv, alteração global ou escrita no repositório. Esse detalhe não altera o motor observado e fica declarado para reprodução.

Resultados: chamada nSample bem-sucedida; TTF confirmado com hash esperado; 21 casos do validador real; quatro defaults SMILES observados; sete casos de política XML. `git status --porcelain=v1` vazio; `git diff --check` exit0, no clone fixado. Não foi feita execução pytest nem validação Windows.

## 9. Pedido de fechamento curto

Ao revisor Claude: conferir apenas (1) a evidência dos MINOR-1/2, (2) C-01 sobre ID, (3) as cláusulas originais para NOTE-1, (4) os complementos C-02/C-03 e (5) o posicionamento do gate Windows. Se suficientes, emitir adendo de fechamento e declarar a prontidão para rascunho, mantendo implementação não autorizada. Não repetir uma revisão universal de A-01–A-14 sem novo achado concreto.

Ao outro revisor: este complemento acompanha o mesmo conjunto V2 e não substitui o seu parecer independente sobre os itens relevantes da rodada anterior.

REVIEW V2 RESPONSE COMPLETE: YES
HEAD REFERENCED: 08b797e0985e123ffd4d7ca7e5a5e8f040e63851
MINOR 1 PYTHON API CONFIRMED: YES
MINOR 2 REAL TTF CONFIRMED: YES
MINOR 3 EXPLICIT RULE PROPOSED: YES
NOTES DISPOSITIONS RECORDED: YES
INDEPENDENT CLOSURE OF THIS RESPONSE OBTAINED: NO
WINDOWS PRODUCTION READERS VALIDATED: NO
READY FOR DRAFT SPECIFICATION: NO — pending independent closure of this round
READY FOR IMPLEMENTATION: NO
FINAL SPECIFICATION FROZEN: NO
EXISTING PROPOSAL AND REVIEWS MODIFIED: NO
CODE REPOSITORY MODIFIED: NO
