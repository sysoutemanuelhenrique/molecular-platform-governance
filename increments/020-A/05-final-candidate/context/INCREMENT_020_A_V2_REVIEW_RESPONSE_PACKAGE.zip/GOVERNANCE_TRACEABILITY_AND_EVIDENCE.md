# Rastreabilidade — revisão arquitetural 020-A

Data: 20/10/2026 UTC. Documento acompanhante, não contrato normativo e não parecer independente. Os originais da proposta e dos dois pareceres permanecem intactos.

## 1. Como usar as evidências

As classes abaixo seguem o `EVIDENCE_MODEL.md` recebido. Cada item factual tem uma classe; confiança é indicada separadamente. Uma decisão proposta não é um fato medido. Relatórios anteriores são evidência documental fornecida, não execução independente nesta revisão.

A política está em `competitive-technical-research/` e tem escopo próprio. Esta entrega é proposta de incremento, com separação explícita entre fonte, ensaio e desenho. Adotam-se seus princípios de evidência e fronteira, sem alegar que o registry formal de investigações/ferramentas do ZIP foi atualizado ou que uma aprovação retrospectiva foi obtida. Nenhum documento existente foi alterado.

## 2. Materiais originais e identidade

O `MANIFEST.json` do pacote enumera o caminho, bytes, linhas e SHA-256 de cada membro. A identidade do arquivo ZIP recebido está em `SOURCE_IDENTITIES.json`. A contagem de linhas usa `bytes.splitlines()`, sem converter newline. Essa escolha é registrada porque o arquivo R2 usa CRLF.

Identidades normativas especialmente confrontadas com registros anteriores:

| Documento | Linhas | Bytes | SHA-256 |
|---|---:|---:|---|
| Final 017 | 776 | 94552 | 273cdb79bb7e75ac866c977fd1f6e749b43ff5d3a0d4430894717d348036b46c |
| Final 018 | 1809 | 134709 | 347632175991b1d72b9f193312b9629ce71697fb0c3d0de2285e52b7299d8023 |
| Final 020 | 1975 | 210880 | cf6cb534f9267d51e718052c7b36a2293c522bc566c99cf3bb2ef5909385a0a6 |
| Validação CP4 | 365 | 25318 | 69ece589ca25ddaa1e3286b33dd1a0e76e5245043cf8f633559383389e918785 |

Classe da verificação mecânica: **OBSERVED**; confiança alta. Para 016 e 019, os hashes calculados são preservados no manifesto e encontrados em documentos posteriores do mesmo arquivo de governance; isso é corroboração interna, não assinatura independente. Nenhum hash, por si, prova autoria ou correção do conteúdo.

## 3. Mapa da leitura normativa

“Integral” aqui qualifica o documento efetivamente lido, não apenas sua disponibilidade no pacote. As cinco especificações são disponibilizadas integralmente ao revisor; a leitura do arquiteto nelas foi dirigida ao que pode afetar 020-A, sem alegar auditoria linha a linha das partes não pertinentes.

| Material | Leitura realizada | Questão respondida |
|---|---|---|
| competitive-technical-research/README.md | Integral | Escopo dessa área, separação de pesquisa e produto |
| GOVERNANCE.md, ENGINE_RESEARCH_POLICY.md, EVIDENCE_MODEL.md | Integrais | Papéis, registro de motor, classificação e confiança |
| RESEARCH_WORKFLOW.md, LEGAL_AND_ETHICAL_BOUNDARIES.md | Integrais | Processo e limites de fontes/ensaios |
| TOOLING_POLICY.md, CLEAN_ROOM_POLICY.md | Integrais | Ferramenta não é aprovação; separar evidência, desenho e implementação |
| strategy/LIGAND_CONFORMER_GENERATION_AND_GEOMETRY_OPTIMIZATION_SCOPE_DECISION.md | Integral | Estado versus conformero, parâmetros explícitos, numeração provisória |
| Final016 | Leitura dirigida: §§2/6/7, trechos de §§10–11/15–17 e critérios relacionados | Adaptador único, dependência opcional, attempt específico, SMILES dos filhos |
| Final017 | Leitura dirigida: §§8/11/12 e enquadramento dos handlers | Interrupções, logger global, logging não duplicado |
| Final018 | Leitura dirigida: §§7/8/12/13 | Parser de promoção e protocolo de RAW, snapshot, raiz fixa, garantia residual e plataforma |
| Final019 | Leitura dirigida: §§6–8/21 | Condições declaradas separadas da execução; não consumo explícito |
| Final020 | Leitura dirigida: §§6–9/11/24–28/31–34 | Objetos persistidos, lineage, ausência de attempts, segurança específica, contrato futuro021 |
| CP4 e parecer cumulativo020 | Integrais | Evidência fornecida do fechamento, sem reexecução cumulativa |
| Proposta020A preliminar, R1, R2 e reconciliação | Integrais | Achados, divergências e evolução da recomendação |

Classe de afirmações sobre o conteúdo das normas: **DOCUMENTED**, confiança alta quanto ao texto recebido. Aplicabilidade à nova consulta é **INFERRED** nos itens correspondentes; não transformar conclusão do arquiteto em cláusula já aprovada.

Documentos históricos de estratégia mais ampla foram apenas consultados como contexto. Não são usados para dizer que capacidades futuras já existem ou que uma decisão do contrato final020 foi revogada. O arquivo recebido não inclui todos os contratos centrais anteriores ao016; esse limite permanece declarado.

## 4. Registro de evidência técnica e decisão derivada

| ID | Afirmação delimitada | Classe | Confiança | Fonte e consequência |
|---|---|---|---|---|
| E-01 | HEAD do clone e main remota são 08b797e0985e123ffd4d7ca7e5a5e8f040e63851; status/diff-check limpos nesta leitura | OBSERVED | Alta | git ls-remote, rev-parse, status --porcelain=v1, diff --check |
| E-02 | O ZIP contém os originais com identidades calculadas no manifesto | OBSERVED | Alta | Extração/inventário; ZIP original preservado |
| E-03 | MolecularState/MolecularRepresentationRef não têm campos de descritores; são modelos mínimos imutáveis | SOURCE_VERIFIED | Alta | scientific.py; testes de imutabilidade/extras |
| E-04 | register_state copia e hasheia o artefato; format não é enum químico fechado | SOURCE_VERIFIED | Alta | scientific_registry.py::register_state; test_register_state_persists_metadata_and_artifact e testes adjacentes |
| E-05 | A enumeração publica SMILES com newline final e entity_id do pai | SOURCE_VERIFIED | Alta | application.py::enumerate_state_tautomers; testes de herança e publicação |
| E-06 | Attempts atuais têm requested TautomerEnumerationPolicy e operation_type state-transformation | SOURCE_VERIFIED | Alta | execution.py |
| E-07 | O leitor RAW existente tem raiz inputs/ligands/<input_id>, controles de identidade e recusa de plataforma não validada | SOURCE_VERIFIED | Alta | atomic.py::_AUTHORIZED_ROOT_TEMPLATE, _capture_identity, _require_validated_platform, create_verified_raw_snapshot |
| E-08 | O registro de inspeção020 é pinado por seleção/resolução, sem máquina de attempts | DOCUMENTED | Alta | Final020 §§24–27; não universalizar essa persistência |
| E-09 | A ausência de cláusula universal encontrada torna defensável, mas não previamente autorizada, uma consulta sem histórico | INFERRED | Média-alta | E-03/E-06/E-08 e leitura normativa; decisão nova A-01/A-12 |
| E-10 | Lipinski.NumHDonors/Acceptors delegam aos métodos CalcNumHBD/HBA no pacote instalado | SOURCE_VERIFIED | Alta | Linhas do source/hash em evidence/review-claims-evidence.json |
| E-11 | Casos discriminantes refutam HBD como número de ligações N–H/O–H nessas APIs | EXPERIMENTALLY_VERIFIED | Alta nos casos | evidence/check_review_claims.py e seu JSON; não confundir com NHOHCount |
| E-12 | O supplier do pin expõe strictParsing=True; CalcCrippenDescriptors existe em rdMolDescriptors e não Crippen | EXPERIMENTALLY_VERIFIED | Alta | Introspecção e execução nos JSONs de evidência |
| E-13 | Cinco entradas produziram os dez valores e desenhos na pesquisa anterior | EXPERIMENTALLY_VERIFIED | Alta nos casos | evidence/preliminary/rdkit-spike-results.json, spike.py e cinco RAWs |
| E-14 | Perfil de entrada novo produziu os resultados esperados para cinco RAWs, 17 SMILES e oito SDFs sintéticos | EXPERIMENTALLY_VERIFIED | Alta nos casos | evidence/profile/profile_probe.py, profile-probe-results.json |
| E-15 | Novo perfil de desenho preservou assinaturas examinadas e omitiu as etiquetas de apresentação hostis usadas | EXPERIMENTALLY_VERIFIED | Alta nos casos | Mesmo ensaio, cinco SVGs e nove sondas adicionais; não é prova do validador futuro |
| E-16 | Appearance local mostra H explícitos e ligações aromáticas no perfil sem kekulização nova | OBSERVED | Média | Render local dos cinco SVGs; legibilidade não foi medida com usuários |
| E-17 | Leitor de estado novo resiste aos cenários Windows exigidos | UNKNOWN | Não determinado | Precisa implementação/testes Windows; nenhum resultado é inventado |
| E-18 | O pacote propõe parâmetros e perfis, mas não contém implementação de produto | OBSERVED | Alta | Artefatos fora do clone; scripts identificados como pesquisa; status do clone limpo |

## 5. Código fixado e testes consultados

Base de todos os links:
`https://github.com/sysoutemanuelhenrique/molecular-platform/blob/08b797e0985e123ffd4d7ca7e5a5e8f040e63851/`

Produção: `pyproject.toml`, `src/molecular/scientific.py`, `scientific_registry.py`, `execution.py`, `application.py`, `atomic.py`, `rdkit_tautomer.py`, `context.py`, `cli.py` e interfaces de proveniência/promoção pertinentes. Hashes de arquivos de referência estão em `CODE_REFERENCE_HASHES.json`; não se inclui uma segunda cópia do repositório no pacote.

Testes consultados como fonte: `tests/test_scientific.py`, `test_scientific_registry.py`, `test_application.py`, `test_rdkit_tautomer.py`, `test_context.py`, `test_cli.py`, nos comportamentos citados. A existência de uma função de teste não foi tratada como prova de execução nesta revisão. Não se repete a contagem1476 do implementador como resultado nosso.

O revisor pode ler o código real pelo SHA ou por clone read-only. Se não conseguir, deve dizer que os fatos de código são evidências fornecidas, sem inventar inspeção independente.

## 6. Registro do motor estudado

| Campo | Registro | Classe |
|---|---|---|
| Nome e projeto | RDKit, projeto RDKit | DOCUMENTED |
| Versão estudada | binding rdBase.rdkitVersion=2026.03.6; dependência do projeto rdkit==2026.3.6 | OBSERVED |
| Tipo escolhido para esta investigação | OPEN_SOURCE_ENGINE | DOCUMENTED |
| Licença do núcleo | O arquivo rdkit/license.txt distribuído declara BSD de três cláusulas | DOCUMENTED |
| Empacotamento | O LICENSE.md do wheel observado declara MIT para empacotamento; não substitui a licença do núcleo | DOCUMENTED |
| Fonte gráfica escolhida | Telex-Regular.ttf do pacote, licença fornecida SIL OFL1.1 | DOCUMENTED |
| Entradas observadas | SDF por stream e SMILES por parser explícito | EXPERIMENTALLY_VERIFIED |
| Saídas observadas | Valores neutros e SVG; nenhum objeto de domínio publicado pelo spike | EXPERIMENTALLY_VERIFIED |
| Parâmetros | As opções efetivamente usadas constam dos scripts preservados | SOURCE_VERIFIED |
| Operações | Descritores/fórmula, parsing/percepção, coordenadas/desenho2D | EXPERIMENTALLY_VERIFIED |
| Dependências observadas no ambiente | numpy2.5.4, Pillow13.0.0; o spike não usou serviço remoto para o cálculo | OBSERVED |
| Limitações | Só casos selecionados; não avalia precisão contra laboratório, leitor Windows, CLI futura ou segurança universal de SVG | UNKNOWN quanto às garantias não ensaiadas |

Confiança global: alta para existência das APIs e saídas dos casos; insuficiente para alegar cobertura química ampla ou validação de produção. Consultar APIs públicas/source aberto não autoriza copiar implementação de terceiro para produção. O pacote não redistribui RDKit, fontes tipográficas, venv ou código C++ da biblioteca.

## 7. Ferramentas, método e não retroatividade

Método: leitura prioritária do source aberto pertinente e de contratos; execução de chamadas públicas para resolver dúvidas de defaults, contagem e desenho; classificação separada da decisão. Não foram usados debugger de binário, decompilador ou captura de rede. Não há estudo de software concorrente/proprietário.

Ferramentas efetivamente usadas: Git/read-only; Python isolado com RDKit2026.03.6; utilitários de leitura/hash; parser XML da stdlib; render local via Sharp já disponível. São evidências do ambiente de estudo, não novas dependências da plataforma. O registro formal em `competitive-technical-research/tooling/README.md` não foi modificado e não se declara aprovação geral de ferramenta por inferência. A autorização do responsável para o estudo arquitetural não é reescrita como aprovação histórica naquele registry.

Separação preservada: inputs/evidência → proposta candidata → revisão independente → eventual rascunho → eventual implementação autorizada. Nenhum desses últimos gates é substituído pela execução bem-sucedida de um script de pesquisa.

## 8. Reprodução opcional e limites

O pacote contém `REPRODUCE_RESEARCH_PROBES.py` e os cinco RAWs identificados por hash, sem rede obrigatória. O script usa um diretório temporário novo, copia scripts/entradas para o layout esperado e executa os três ensaios com o Python que o chamou. Não instala nada, não mexe no repositório, não executa CLI do projeto e recusa RDKit de outra versão. O revisor deve ler o script antes de decidir executá-lo.

Resultados numéricos podem ser confrontados por perfil/tolerância; strings de docstrings e bytes do SVG não são contrato entre builds/SOs. A reprodução do spike não prova o futuro leitor verificado ou o validador SVG. Os checks de aceitação de gramática no script são protótipos de pesquisa fora da produção, não uma implementação aprovada para copiar automaticamente.

Não se pede ao Claude implementador uma nova pesquisa genérica. A única investigação local posterior justificável é uma pergunta dependente do Windows que não possa ser decidida aqui; ela deverá ter entrada, critérios e saída observável delimitados.
