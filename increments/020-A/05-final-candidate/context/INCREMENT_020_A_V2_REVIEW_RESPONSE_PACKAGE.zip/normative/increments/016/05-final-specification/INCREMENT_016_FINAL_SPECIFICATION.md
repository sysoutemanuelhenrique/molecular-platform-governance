# FINAL SPECIFICATION — INCREMENTO 016

## Enumeração real de tautômeros via RDKit, com proveniência e execução auditável

**Projeto:** Turing Bohr Molecular Platform
**Data de produção do rascunho:** 2026-09-23
**Data do congelamento formal:** 2026-09-23
**Natureza deste documento:** especificação final formalmente congelada do Incremento 016. É **autossuficiente**: não exige a leitura de nenhum rascunho anterior para ser implementada, testada ou revisada. **Está congelada** a partir desta versão, após a revisão adversarial final ter concluído `APPROVE WITH NON-BLOCKING NOTES` / `READY TO FREEZE: YES`, e após a incorporação de seus quatro `MINOR`, da `NOTE-1` e do esclarecimento da `NOTE-2` (registro completo na Seção 0.4). Autoriza a implementação de código de produção, estritamente dentro do allowlist da Seção 4 e do plano de etapas da Seção 22.

---

## 0. Proveniência documental e preflight obrigatório

### 0.1 Documentos-fonte utilizados

| Documento-fonte | Papel | Caminho | Tamanho | Linhas | SHA-256 |
|---|---|---|---|---:|---|
| Documento pré-spike | Pesquisa de motores, rascunho arquitetural, dez decisões bloqueadoras resolvidas em rascunho | `C:\Users\Pichau\Downloads\INCREMENT_016_ENGINE_RESEARCH_AND_DRAFT_SPEC_PRE_SPIKE.md` | 64.188 bytes | 1.085 | `51d5c388b40648e09463fde34b8da14645a552a576d7bd583a3f339d1d86410c` |
| Relatório do spike técnico (versão corrigida) | Evidência experimental real da API do `rdkit==2026.3.6`, com a contagem do substrato enol-OD já corrigida (Seção 7.4) | `C:\Users\Pichau\Documents\MolecularGovernance\increments\016\04-spike\INCREMENT_016_RDKIT_SPIKE_REPORT_CORRECTED.md` | 45.796 bytes | 410 | `ae02e22e0d1de6342585c4f7973c5b1dabf4b04ccb7841dbf5d706a17b4ec986` |
| Revisão adversarial independente do spike ("Revisão adversarial independente — Spike técnico RDKit, Incremento 016") | Fonte da correção numérica (MINOR-1), da nota sobre o script auxiliar (MINOR-2) e da recomendação de teste negativo de contrato para a Rota A | `C:\Users\Pichau\Downloads\INCREMENT_016_RDKIT_SPIKE_ADVERSARIAL_REVIEW.md` | 15.411 bytes | 85 | `824f7409b0619a32c38967697835d78eddb8d29660f56b6adce82b8a922da571` |
| Revisão adversarial final desta especificação ("Revisão adversarial final — FINAL SPECIFICATION, Incremento 016") | Fonte dos quatro `MINOR`, da `NOTE-1` e da `NOTE-2` incorporados nesta versão congelada (Seção 0.4); veredito `APPROVE WITH NON-BLOCKING NOTES`, `READY TO FREEZE: YES` | `C:\Users\Pichau\Documents\MolecularGovernance\increments\016\03-reviews\INCREMENT_016_FINAL_SPECIFICATION_ADVERSARIAL_REVIEW.md` | 29.054 bytes | 170 | `d0fc4df9d0c278c429177d906e447ee101d48d0c1402db839d63d7d108cfe25d` |
| Código e testes atuais do repositório | Leitura e confronto factual apenas — nenhuma escrita | `C:\Users\Pichau\molecular-platform` (branch `main`) | — | — | — (ver Seção 0.2) |

Existe um segundo arquivo, `INCREMENT_016_RDKIT_SPIKE_ADVERSARIAL_REVIEW2.md`, em `Downloads`, confirmado nesta e em reconciliação anterior como **idêntico byte a byte** ao arquivo citado acima (revisão adversarial do *spike*, não desta especificação). Não é uma fonte adicional independente.

### 0.3 Reconciliação de identidade documental e preflight do congelamento

Antes de produzir esta versão congelada, foi solicitada uma reconciliação de identidade documental, motivada por uma discrepância encontrada em um preflight anterior: as métricas então informadas para a revisão adversarial final (44.735 bytes, SHA-256 `a329dfc6a20c93752045a764a68d4c3fb768ff766276bb8bab57e24364e3cd85`) não correspondiam ao arquivo real em `C:\Users\Pichau\Documents\MolecularGovernance\increments\016\03-reviews\INCREMENT_016_FINAL_SPECIFICATION_ADVERSARIAL_REVIEW.md` (170 linhas em ambos os casos, mas 29.054 bytes medidos, não 44.735). Diante disso, a produção da especificação congelada foi **interrompida**, e uma busca exaustiva foi conduzida antes de prosseguir.

**Busca realizada** em todo o perfil do usuário acessível a esta sessão, por: (a) o título interno "Revisão adversarial final — FINAL SPECIFICATION, Incremento 016"; (b) os nomes de arquivo literais `Markdown(20260923-202614).md colado` e `Markdown (2)(2).md colado`; (c) qualquer arquivo de exatamente 44.735 bytes. **Resultado:** nenhum arquivo com esses nomes literais foi encontrado em nenhum diretório acessível, e nenhum arquivo de 44.735 bytes existe no sistema. A única cópia real do documento com esse título existe em exatamente dois locais — `Downloads\INCREMENT_016_FINAL_SPECIFICATION_ADVERSARIAL_REVIEW.md` e a cópia canônica de Governança citada na Seção 0.1 — e as duas são **idênticas byte a byte** (mesmas 170 linhas, mesmos 29.054 bytes, mesmo SHA-256 `d0fc4df9d0c278c429177d906e447ee101d48d0c1402db839d63d7d108cfe25d`), confirmado por comparação binária direta, sem necessidade de nenhuma normalização de BOM/EOL/newline final para chegar a essa conclusão.

**DOCUMENT IDENTITY: CONFIRMED** entre as duas cópias localizadas. Nenhuma cópia divergente foi encontrada para comparar. **Causa mais provável da métrica originalmente informada** (44.735 bytes / `a329dfc6...`): não corresponde a nenhum arquivo localizável nesta sessão em nenhum diretório pesquisado; tratada como um valor informado incorretamente na solicitação anterior, não como evidência de uma segunda versão real do documento. O arquivo de Governança é tratado, a partir daqui, como a cópia canônica, com suas métricas reais registradas na Seção 0.1: **170 linhas, 29.054 bytes, SHA-256 `d0fc4df9d0c278c429177d906e447ee101d48d0c1402db839d63d7d108cfe25d`**.

Verificação estrutural do conteúdo canônico, item a item: `BLOCKERS: Nenhum` (Seção 2 do documento de revisão); `MAJOR: Nenhum` (Seção 3); exatamente quatro `MINOR` (Seção 4: MINOR-1 a MINOR-4); `NOTE-1` e `NOTE-2` presentes (Seção 5); parecer final `APPROVE WITH NON-BLOCKING NOTES` (Seção 9); `READY TO FREEZE: YES`, `READY FOR IMPLEMENTATION: NO`, `REPOSITORY MODIFIED: NO` (Seção 10) — todos **confirmados**.

Reconfirmado neste passo: `git rev-parse HEAD` em `C:\Users\Pichau\molecular-platform` → `fc362f086584dd832173f8a5019b0da9ca9325f3`; `git status` → único item não rastreado `increment-009-review.txt`, sem modificações pendentes — idêntico ao preflight original da Seção 0.2. Métricas do próprio rascunho (`INCREMENT_016_FINAL_SPECIFICATION_DRAFT.md`) reconfirmadas: 1.395 linhas, 104.446 bytes, SHA-256 `04e4e25bd7b70dd1907c4d44d09d0e6fa89441832c449fbad0825a97b15402f2` — as mesmas três métricas que a própria revisão adversarial final confirma de forma independente em sua Seção 1.1.

### 0.4 Achados da revisão adversarial final incorporados nesta versão congelada

| Achado | Seção(ões) desta especificação onde foi incorporado | Status |
|---|---|---|
| MINOR-1 — rollback assimétrico (estado publicado, transformação ainda não) não generalizado em prosa | Seção 17.3 (reescrita, cobrindo explicitamente o candidato em publicação no momento da falha) | **Incorporado** |
| MINOR-2 — herança de `entity_id` pelos estados filhos nunca declarada como regra normativa explícita | Nova Seção 15.4; passo 20 da Seção 15; novo item de teste na Seção 20.4; novo critério 26 na Seção 21 | **Incorporado** |
| MINOR-3 — citação de "Regra 17" no relatório do spike sem rastreamento aos quatro documentos-fonte | Nova Seção 24.1 (nota de proveniência) | **Incorporado** |
| MINOR-4 — cinco limitações remanescentes do spike não retomadas na tabela de riscos | Seção 23 (cinco novas linhas, como riscos aceitos e explicitamente mitigados) | **Incorporado** |
| NOTE-1 — `_validate_counts` poderia exigir `enumerated_unique_count - new_unique_count ∈ {0, 1}` | Seção 7.3 (validador estendido); Seção 20.2 (testes para diferença 0, 1, negativa e >1) | **Incorporado** |
| NOTE-2 — redundância editorial na Seção 12 sobre `operation_ids=None` | Seção 12 (parágrafo de esclarecimento editorial adicionado; matriz e comportamento inalterados) | **Esclarecida** |

Nenhum outro conteúdo desta especificação foi alterado por esta reconciliação e congelamento: nenhuma decisão científica, arquitetural ou de escopo foi modificada; nenhum novo tipo, campo, API ou arquivo foi introduzido; todos os testes, matrizes, critérios e proibições já aprovados no rascunho permanecem exatamente como estavam, exceto pelas adições pontuais listadas acima.

### 0.2 Preflight obrigatório executado antes da produção deste rascunho

Todas as verificações abaixo foram executadas **antes** da escrita deste documento, sem nenhuma escrita no repositório:

| Verificação exigida | Resultado observado |
|---|---|
| `git rev-parse HEAD` em `C:\Users\Pichau\molecular-platform` | `fc362f086584dd832173f8a5019b0da9ca9325f3` — **confirmado**, idêntico à baseline registrada no spike e no documento pré-spike |
| `git status` | `On branch main. Your branch is up to date with 'origin/main'.` Único item não rastreado: `increment-009-review.txt`. **Confirmado, nenhum outro item não rastreado, nenhuma modificação pendente.** |
| Nenhum checkout, branch, commit, push ou merge executado | **Confirmado** — apenas `git rev-parse HEAD` e `git status` (comandos de leitura) foram executados |
| Linhas, tamanho e SHA-256 de todos os documentos-fonte | Calculados e reportados na tabela da Seção 0.1 |
| Relatório corrigido do spike — Seção 7.4: 13 candidatos enol-OD, 5 sanitizam, 8 falham | **Confirmado** por leitura do arquivo corrigido |
| Relatório corrigido do spike — os 5 candidatos sanitizáveis preservam o isótopo | **Confirmado** (Seção 7.4 do relatório corrigido: "todos com fórmula `C5H8O2`... e todos retendo o átomo `[2H]` (100% de preservação isotópica entre os sanitizáveis)") |
| Relatório corrigido do spike — anotação do `TypeError` do script auxiliar | **Confirmado** (Seção 9.1 do relatório corrigido, nova nota) |
| Relatório corrigido do spike — `SPIKE VALIDATION: PASS` | **Confirmado** (Seção 16) |
| Relatório corrigido do spike — `READY FOR FINAL SPECIFICATION: YES` | **Confirmado** (Seção 16) |
| Relatório corrigido do spike — `READY FOR IMPLEMENTATION: NO` | **Confirmado** (Seção 16) |

Todos os itens conferiram. A produção deste rascunho prossegue. Nenhum item exigiu interrupção.

O código e os testes atuais do repositório (`src/molecular/execution.py`, `execution_registry.py`, `scientific.py`, `scientific_registry.py`, `transformation.py`, `transformation_registry.py`, `application.py`, `atomic.py`, `inputs.py`, `pyproject.toml`, e os arquivos `tests/test_*.py` correspondentes) foram lidos integralmente, **somente para leitura**, como confronto factual dos contratos abaixo com o estado real do código pós-Incremento 015. Nenhum arquivo do repositório foi criado, modificado ou removido na produção deste documento.

---

## 1. Como ler este documento

Este documento é a especificação normativa completa e autossuficiente do Incremento 016. Toda decisão aqui é **vigente** a menos que explicitamente marcada como superada na Seção 26. Nenhuma seção depende de memória de rascunhos anteriores: onde este documento cita um fato do spike, o fato é reproduzido, não apenas referenciado.

Convenções de leitura normativa usadas neste documento:

- **DEVE / NÃO DEVE** — obrigação testável, critério de aceite.
- **Decisão vigente** — resolve definitivamente uma questão que o rascunho pré-spike ou o spike deixaram condicional.
- Todo contrato Python abaixo é a assinatura pública final proposta para revisão adversarial; nenhum é apresentado como "proposta ainda não decidida" — decisões pendentes no rascunho pré-spike foram todas resolvidas nesta versão (Seção 26 registra o que mudou).
- Este documento não contém `TODO`, `TBD`, questão aberta, alternativa sem decisão, ou estimativa de testes apresentada como contagem final. Toda lista de testes na Seção 20 é normativa (obrigatória), não uma estimativa.

---

## 2. Escopo científico e exclusões explícitas

### 2.1 O que é tautomerismo neste incremento

Uma transformação tautomérica, para os fins deste incremento, é uma redistribuição formal de hidrogênio e ordens de ligação dentro da mesma espécie molecular, preservando:

- a composição elementar (contagem de cada elemento);
- a composição isotópica (contagem e identidade de cada isótopo marcado);
- a carga formal total.

O motor opera sobre representação molecular 2D/topológica. Ele não cria um `Conformer`, não otimiza geometria 3D e não decide qual forma predomina em um ambiente experimental, cristalográfico ou fisiológico.

### 2.2 Capacidade entregue

1. Receber um `MolecularState` já registrado, cuja representação seja um arquivo SDF de molécula única.
2. Enumerar formas tautoméricas segundo as regras versionadas do RDKit (`rdkit==2026.3.6`, Rota B — Seção 8).
3. Sanitizar e validar cada candidato individualmente; descartar silenciosamente os que violarem qualquer invariante químico (Seção 15.3).
4. Deduplicar e ordenar deterministicamente os candidatos válidos, dentro da mesma versão do motor.
5. Excluir a representação equivalente à entrada.
6. Aplicar o teto de publicação `TautomerEnumerationPolicy.max_states`, se declarado.
7. Persistir novos `MolecularState`s e suas arestas `StateTransformationRecord(operation="tautomerization")`.
8. Encerrar o `ExecutionAttempt` com os ids das transformações publicadas (`operation_ids`), possivelmente vazio.

### 2.3 Exclusões explícitas (fora do allowlist e fora do diff deste incremento)

Este incremento **NÃO DEVE**, sob nenhuma circunstância, introduzir:

- predição de pKa;
- população tautomérica dependente de pH;
- protonação, desprotonação ou qualquer estado de microespécie ácido-base;
- preparo de receptor ou de proteína;
- dados ou metadados cristalográficos;
- docking ou redocking;
- geração ou otimização de geometria 3D (`Conformer`);
- uma nova interface de CLI (a camada CLI existente permanece inalterada e sem qualquer import de RDKit; um comando fino é explicitamente adiado para o Incremento 017);
- GUI;
- scheduler, fila, execução distribuída ou orquestração externa;
- banco de dados externo (a persistência continua sendo o filesystem YAML já usado pelo projeto);
- um segundo motor de enumeração de tautômeros, seleção automática entre motores, ou qualquer abstração `Engine`/`Protocol`/`EngineRegistry` genérica.

Qualquer PR que introduza um desses itens está fora do allowlist deste incremento, independentemente de conveniência de implementação.

---

## 3. Baseline oficial

- **Commit de baseline:** `fc362f086584dd832173f8a5019b0da9ca9325f3` (branch `main`), confirmado no preflight da Seção 0.2.
- **Suíte de testes de baseline:** deve permanecer 100% verde antes de qualquer commit deste incremento (critério de aceite, Seção 21).
- **Próximo ato autorizado após este documento:** a revisão adversarial final já ocorreu e aprovou esta especificação (Seção 0.3/0.4). O próximo ato é a criação de uma feature branch a partir do HEAD oficial de `main` (revalidado no momento da criação da branch) e a implementação por allowlist (Seção 4), seguindo o plano de etapas da Seção 22. Este documento, por si só, não implementa nenhum código.

---

## 4. Allowlist provisório de arquivos

### 4.1 Arquivos que o Incremento 016 DEVE modificar ou criar

| Arquivo | Natureza da mudança |
|---|---|
| `pyproject.toml` | Adicionar `[project.optional-dependencies] rdkit = ["rdkit==2026.3.6"]`, preservando o extra `dev` existente inalterado |
| `src/molecular/execution.py` | `ExecutionAttempt.schema_version` passa a `Literal["1.0", "1.1"]`; novo campo `input_state_id`; `ExecutionAttemptError` ganha `residual_state_ids`/`residual_operation_ids`; `_validate_status_invariants` estendido (Seção 10, 12, 13) |
| `src/molecular/execution_registry.py` | `begin_execution_attempt` passa a exigir `input_state_id`; os quatro `mark_*` propagam `input_state_id` sem alteração (Seção 10.6) |
| `src/molecular/rdkit_tautomer.py` (novo arquivo) | Único módulo de produção que importa RDKit; adapter completo (Seção 7) |
| `src/molecular/transformation_registry.py` | Adicionar `_remove_state_transformation_best_effort` (compensação; Seção 17.4) — nenhuma função pública existente é alterada |
| `src/molecular/application.py` | Adicionar `enumerate_state_tautomers` e seu tipo de detalhes de atividade (Seção 16) — nenhuma função existente é alterada |
| `tests/test_execution.py` | Novos casos para `schema_version="1.1"`, `input_state_id`, resíduos |
| `tests/test_execution_registry.py` | Novos casos para `begin_execution_attempt(..., input_state_id=...)` e propagação nas transições |
| `tests/test_rdkit_tautomer.py` (novo arquivo) | Testes do adapter (Seção 20.2) |
| `tests/test_application.py` | Novos casos para `enumerate_state_tautomers` (Seção 20.4) |
| `tests/test_transformation_registry.py` | Novo caso para `_remove_state_transformation_best_effort` |

Nenhum outro arquivo rastreado do repositório é tocado por este incremento.

### 4.2 Arquivos explicitamente fora do allowlist (proibidos)

- `src/molecular/cli.py` — nenhuma mudança; nenhum import de RDKit; nenhum comando novo.
- `src/molecular/scientific.py`, `src/molecular/scientific_registry.py` — usados apenas por chamada (`register_state`, `load_state`), sem alteração de contrato.
- `src/molecular/transformation.py` — `StateTransformationRecord`/`TransformationParameter`/`TransformationProducer` usados como já existem, sem alteração de contrato.
- `src/molecular/models.py`, `src/molecular/pubchem.py`, `src/molecular/registry.py`, `src/molecular/activity.py`, `src/molecular/context.py`, `src/molecular/config.py`, `src/molecular/atomic.py` — nenhuma mudança.
- Qualquer arquivo relacionado a docking, receptor, proteína, cristalografia, evidência experimental, presets ou GUI — não existem no repositório e não devem ser criados por este incremento.
- Qualquer novo arquivo de CLI, scheduler, ou cliente HTTP.

---

## 5. Decisões herdadas do spike, formalizadas nesta especificação

As oito decisões abaixo foram produzidas pelo spike técnico (relatório corrigido, Seção 14) e são incorporadas aqui como contrato normativo, não como recomendação:

| Decisão | Conteúdo normativo nesta especificação |
|---|---|
| **D-016-SPIKE-01** | Rota B é a única forma de configurar `remove_isotopic_hs`. Nenhuma menção condicional a um setter do `TautomerEnumerator` aparece em nenhuma seção operacional deste documento. Ver Seção 8. |
| **D-016-SPIKE-02** | `engine_version` DEVE ser obtido de `rdkit.rdBase.rdkitVersion` (formato real observado: `"2026.03.6"`, com zero à esquerda no mês), nunca do metadado `pip show` (`"2026.3.6"`). Ver Seção 7.3. |
| **D-016-SPIKE-03** | Leitura de SDF DEVE usar `Chem.SDMolSupplier`, nunca `Chem.ForwardSDMolSupplier`. `OSError` na construção é o sinal normativo de SDF vazio/inválido. `len(supplier) == 1` é a checagem normativa de "exatamente uma molécula". Ver Seção 9. |
| **D-016-SPIKE-04** | Sanitização pós-motor é obrigatória e testável, não uma menção em prosa. O spike (corrigido) demonstrou até 62% de candidatos inválidos por saturação de valência isotópica em um substrato real. Ver Seção 15.3. |
| **D-016-SPIKE-05** | Exclusão da representação equivalente à entrada é obrigatória, não cosmética — `TautomerEnumeratorResult` inclui a entrada entre os resultados por comportamento nativo confirmado do RDKit. Ver Seção 15, passo 11. |
| **D-016-SPIKE-06** | Os seis parâmetros científicos são fixados explicitamente no adapter com os valores confirmados no spike: `maxTautomers=1000`, `maxTransforms=1000`, `tautomerReassignStereo=True`, `tautomerRemoveBondStereo=True`, `tautomerRemoveSp3Stereo=True`, `tautomerRemoveIsotopicHs=False`. Ver Seção 7.2. |
| **D-016-SPIKE-07** | `TautomerEnumeratorStatus` tem exatamente quatro valores reais, confirmados por execução: `Completed=0`, `MaxTautomersReached=1`, `MaxTransformsReached=2`, `Canceled=3`. Ver Seção 7.5 e Seção 25. |
| **D-016-SPIKE-08** | Rota B é declarada única rota de produção. Um teste negativo de contrato DEVE confirmar a ausência de `SetRemoveIsotopicHs`/`GetRemoveIsotopicHs`; se uma versão futura do RDKit passar a expor esses métodos, esse teste DEVE falhar explicitamente, exigindo nova revisão adversarial antes de qualquer mudança de rota. Ver Seção 8.3 e Seção 20.2. |

---

## 6. Dependência opcional, pin exato e import tardio

### 6.1 `pyproject.toml`

```toml
[project.optional-dependencies]
dev = [
    "pytest>=8",
]
rdkit = [
    "rdkit==2026.3.6",
]
```

O nome do extra é `rdkit`. O pin é exato: `2026.3.6`. Instalação verificada com sucesso no Windows 11 / Python 3.11.9 pelo spike (Seção 2 do relatório corrigido — `EXIT CODE: 0`, sem necessidade de relaxar o pin). Nenhuma dependência transitiva (`numpy==2.4.6`, `pillow==12.3.0`) é pinada explicitamente pelo projeto — são resolvidas pelo próprio wheel do RDKit.

### 6.2 Import tardio

Nenhum módulo fora de `src/molecular/rdkit_tautomer.py` DEVE importar `rdkit` em qualquer forma (`import rdkit`, `from rdkit import ...`, ou qualquer submódulo). O import de RDKit dentro de `rdkit_tautomer.py` ocorre no nível do módulo (não dentro de cada função) — se RDKit não estiver instalado, o `ImportError` ocorre na importação do módulo `rdkit_tautomer`, não em uma chamada de função posterior; `resolve_rdkit_engine()` (Seção 7.1) DEVE capturar esse `ImportError` na sua própria fronteira e traduzi-lo em `RDKitUnavailableError`, para que o import ausente nunca se propague como um `ImportError` bruto até o Application Service ou a CLI.

DEVE existir um teste de empacotamento que confirma: instalar o projeto **sem** o extra `rdkit` continua permitindo importar `molecular.execution`, `molecular.execution_registry`, `molecular.application`, `molecular.cli` e toda a superfície pré-existente sem erro, e chamando `enumerate_state_tautomers` produz `resolution_failed` com uma mensagem acionável — nunca um `ImportError` não tratado.

---

## 7. Contrato do adapter RDKit — `src/molecular/rdkit_tautomer.py`

Este é o único módulo de produção que importa `rdkit`. Nenhum modelo de domínio, registry, `application.py` ou `cli.py` importa `Mol`, `rdMolStandardize`, ou qualquer exceção do RDKit.

### 7.1 Resolução do motor — `resolve_rdkit_engine`

```python
"""RDKit adapter: the only production module permitted to import rdkit.

Route B (rdMolStandardize.CleanupParameters passed to the
TautomerEnumerator constructor) is the only production route for
remove_isotopic_hs in rdkit==2026.3.6, confirmed by the Increment 016
technical spike (dual introspection via dir() and help() of the real,
installed API - see INCREMENT_016_RDKIT_SPIKE_REPORT_CORRECTED.md,
Sections 4 and 6). Route A (a setter/getter on TautomerEnumerator itself)
does not exist in this version and MUST NOT be attempted, imitated, or
simulated. See test_route_a_absence in tests/test_rdkit_tautomer.py for
the negative contract test guarding this fact against a silent future
change.
"""

from pathlib import Path
from typing import Literal, Mapping

from pydantic import BaseModel, ConfigDict, Field, model_validator

EngineName = Literal["rdkit"]
InputFormat = Literal["sdf"]
EnumerationStatus = Literal[
    "completed", "max-tautomers-reached", "max-transforms-reached", "canceled"
]

_ENGINE_NAME: EngineName = "rdkit"
_ALGORITHM = "rdkit.MolStandardize.TautomerEnumerator"
_INPUT_FORMAT: InputFormat = "sdf"
_OUTPUT_FORMAT = "smiles"
_MAX_TAUTOMERS = 1000
_MAX_TRANSFORMS = 1000
_REASSIGN_STEREO = True
_REMOVE_BOND_STEREO = True
_REMOVE_SP3_STEREO = True
_REMOVE_ISOTOPIC_HS = False
_DEDUPLICATION = "canonical-isomeric-smiles"
_ORDERING = "canonical-isomeric-smiles-lexicographic"
_SELECTION = "complete-then-policy-limit"


class RDKitUnavailableError(RuntimeError):
    """Raised when rdkit cannot be imported, or its version cannot be
    read programmatically. Always a resolution-phase error."""


class InvalidSDFError(ValueError):
    """Raised when the SDF source file is empty, missing, or otherwise
    fails to parse into at least one record. Wraps the OSError
    Chem.SDMolSupplier raises at construction time for an empty/invalid
    file (D-016-SPIKE-03). Always an execution-phase error."""


class MultipleMoleculesError(ValueError):
    """Raised when the SDF source file contains a record count other
    than exactly 1. RDKit does not reject multi-molecule SDF natively;
    this is the platform's own business rule (D-016-SPIKE-03), enforced
    here by checking len(supplier). Always an execution-phase error."""

    def __init__(self, record_count: int) -> None:
        super().__init__(
            f"expected exactly 1 molecule in the SDF source, found {record_count}"
        )
        self.record_count = record_count


class IncompleteEnumerationError(RuntimeError):
    """Raised when TautomerEnumeratorResult.status is not Completed.
    Carries the real status name and the (possibly truncated) tautomer
    count RDKit returned before stopping (D-016-SPIKE-07). Always an
    execution-phase error; the caller MUST NOT publish any candidate
    from an incomplete enumeration (D-016-SPIKE-04's sibling rule)."""

    def __init__(self, status: EnumerationStatus, tautomer_count: int) -> None:
        super().__init__(
            f"tautomer enumeration did not complete: status={status!r}, "
            f"tautomer_count={tautomer_count}"
        )
        self.status = status
        self.tautomer_count = tautomer_count


class RDKitEngineResolution(BaseModel):
    """The fixed, explicit engine configuration this adapter will use,
    resolved BEFORE any molecule is loaded - so an Application Service
    can persist it into ResolvedExecutionSnapshot ahead of invoking
    enumerate_tautomers_rdkit. Every value is fixed by this module's own
    module-level constants (D-016-SPIKE-06); none is read from the
    caller or from any per-molecule state."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    engine_name: EngineName
    engine_version: str = Field(min_length=1)
    parameters: Mapping[str, str | int | float | bool]


def resolve_rdkit_engine() -> RDKitEngineResolution:
    """Import rdkit lazily relative to this module's own import (rdkit
    is already imported at module scope above this function - see
    Section 6.2 of the specification for why the ImportError boundary
    still lives here, at the first point a caller can reach), read its
    real version via rdkit.rdBase.rdkitVersion (D-016-SPIKE-02 - never
    pip metadata), and return the fixed, explicit parameter set this
    adapter will use for every enumeration call.

    Raises RDKitUnavailableError if rdkit is not installed, or if
    rdBase.rdkitVersion is missing or unreadable. Never raises anything
    else. Never touches a molecule, a file, or a TautomerEnumerator
    instance - this function is safe to call during an
    ExecutionAttempt's resolution phase, before any execution-phase
    error becomes possible.
    """
```

`resolve_rdkit_engine()` DEVE retornar exatamente estes doze pares em `parameters`, todos com os tipos e valores fixados por D-016-SPIKE-06/D-016-SPIKE-02:

| Chave | Tipo | Valor fixado |
|---|---|---|
| `algorithm` | `str` | `"rdkit.MolStandardize.TautomerEnumerator"` |
| `input_format` | `str` | `"sdf"` |
| `output_format` | `str` | `"smiles"` |
| `max_tautomers` | `int` | `1000` |
| `max_transforms` | `int` | `1000` |
| `remove_bond_stereo` | `bool` | `True` |
| `remove_sp3_stereo` | `bool` | `True` |
| `reassign_stereo` | `bool` | `True` |
| `remove_isotopic_hs` | `bool` | `False` |
| `deduplication` | `str` | `"canonical-isomeric-smiles"` |
| `ordering` | `str` | `"canonical-isomeric-smiles-lexicographic"` |
| `selection` | `str` | `"complete-then-policy-limit"` |

`engine_version` NÃO é fixado por constante — é lido em tempo real de `rdBase.rdkitVersion` a cada chamada, e DEVE ter o formato observado no spike (`"2026.03.6"`, com zero à esquerda no mês; ver Seção 3 do relatório corrigido do spike).

### 7.2 Configuração Rota B — construção do `TautomerEnumerator`

Internamente, `enumerate_tautomers_rdkit` (Seção 7.3) DEVE construir o enumerador exatamente assim, sem nenhum caminho condicional para uma Rota A:

```python
from rdkit.Chem.MolStandardize import rdMolStandardize

def _build_enumerator() -> "rdMolStandardize.TautomerEnumerator":
    params = rdMolStandardize.CleanupParameters()
    params.maxTautomers = _MAX_TAUTOMERS
    params.maxTransforms = _MAX_TRANSFORMS
    params.tautomerReassignStereo = _REASSIGN_STEREO
    params.tautomerRemoveBondStereo = _REMOVE_BOND_STEREO
    params.tautomerRemoveSp3Stereo = _REMOVE_SP3_STEREO
    params.tautomerRemoveIsotopicHs = _REMOVE_ISOTOPIC_HS
    enumerator = rdMolStandardize.TautomerEnumerator(params)
    # Auditoria: os seis valores efetivos são lidos do MESMO objeto
    # `params` usado na construção, nunca de um getter do enumerador -
    # nenhum getter existe para tautomerRemoveIsotopicHs (Seção 8.1) e,
    # por consistência de uma única fonte da verdade (D-016-SPIKE-06),
    # os outros cinco também são lidos daqui, nunca de
    # enumerator.GetMaxTautomers() e equivalentes.
    assert params.tautomerRemoveIsotopicHs is False
    return enumerator
```

Todo objeto `Mol` do RDKit permanece estritamente dentro deste módulo. Nenhuma função pública deste adapter retorna um `Mol`, uma exceção do RDKit, ou qualquer outro tipo importado de `rdkit.*`.

### 7.3 Enumeração — `enumerate_tautomers_rdkit`

```python
class RDKitTautomerCandidate(BaseModel):
    """One tautomer candidate that survived sanitization and every
    chemical invariant check (Section 15.3), expressed as neutral data -
    never an rdkit Mol object."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    canonical_isomeric_smiles: str = Field(min_length=1)


class RDKitTautomerEnumerationResult(BaseModel):
    """The adapter's neutral output: already sanitized, invariant-
    checked, deduplicated, entry-excluded, and lexicographically sorted.
    Never carries an rdkit object. `candidates` is only ever the SET OF
    VALID NEW candidates - status is not part of this shape at all: a
    non-Completed status is raised as IncompleteEnumerationError before
    any RDKitTautomerEnumerationResult is ever constructed (Section
    15, step 5), so every instance of this model that exists implicitly
    corresponds to status=Completed. This supersedes the tentative,
    not-yet-frozen shape proposed in the pre-spike draft (Section 5.2 of
    that document), which speculatively included a `status` field on
    the result itself - see Section 26 of this specification."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    enumerated_unique_count: int = Field(ge=0)
    new_unique_count: int = Field(ge=0)
    candidates: tuple[RDKitTautomerCandidate, ...]

    @model_validator(mode="after")
    def _validate_counts(self) -> "RDKitTautomerEnumerationResult":
        if len(self.candidates) != self.new_unique_count:
            raise ValueError(
                "len(candidates) must equal new_unique_count "
                f"(got {len(self.candidates)} candidates, "
                f"new_unique_count={self.new_unique_count})"
            )
        if self.new_unique_count > self.enumerated_unique_count:
            raise ValueError(
                "new_unique_count must not exceed enumerated_unique_count "
                f"(got new_unique_count={self.new_unique_count}, "
                f"enumerated_unique_count={self.enumerated_unique_count})"
            )
        if self.enumerated_unique_count - self.new_unique_count not in (0, 1):
            raise ValueError(
                "enumerated_unique_count - new_unique_count must be 0 or 1 - "
                "the only physically possible divergence between the two "
                "counts is excluding the input-equivalent candidate zero or "
                "one time (Section 15, step 15); deduplication (step 14) "
                "already guarantees at most one occurrence of the input's "
                "own canonical isomeric SMILES among the unique candidates "
                f"(got enumerated_unique_count={self.enumerated_unique_count}, "
                f"new_unique_count={self.new_unique_count})"
            )
        return self


def enumerate_tautomers_rdkit(
    *, source_path: Path, source_format: InputFormat
) -> RDKitTautomerEnumerationResult:
    """Enumerate tautomers of the single molecule in the SDF file at
    source_path, using Route B exclusively (Section 7.2), and return
    only the sanitized, invariant-checked, deduplicated, entry-excluded,
    lexicographically-sorted set of new candidates.

    source_format is currently only ever "sdf" - the parameter exists so
    a future format addition is a signature-compatible extension, not a
    breaking change; this function raises ValueError immediately for any
    other value, without touching the filesystem.

    Raises (all execution-phase; see Section 18):
    - InvalidSDFError if the file is empty, missing, or otherwise fails
      to construct an Chem.SDMolSupplier (D-016-SPIKE-03).
    - MultipleMoleculesError if the SDF does not contain exactly one
      record.
    - IncompleteEnumerationError if TautomerEnumeratorResult.status is
      not Completed.

    Never raises RDKitUnavailableError - that is resolve_rdkit_engine's
    exclusive responsibility, and MUST already have succeeded before
    this function is ever called (Section 15, resolution phase).

    Performs, in this exact order (Section 15, execution-phase steps):
    load the SDF via Chem.SDMolSupplier; require exactly one record;
    build the Route B enumerator (Section 7.2); call Enumerate(mol);
    require status Completed; sanitize every candidate independently via
    Chem.SanitizeMol, discarding (never raising for) any that fails;
    verify element counts, isotope counts, and formal charge against the
    input molecule for every candidate that did sanitize, discarding any
    that diverges; serialize the surviving candidates to canonical
    isomeric SMILES; deduplicate by that string; exclude the string
    equal to the input molecule's own canonical isomeric SMILES;
    sort the remainder lexicographically.
    """
```

A única divergência fisicamente possível entre `enumerated_unique_count` e `new_unique_count` é a exclusão, zero ou uma vez, do candidato equivalente à representação da entrada (Seção 15, passo 15) — nunca mais que uma vez, pois a deduplicação (passo 14) já garante no máximo uma ocorrência do SMILES canônico isomérico da entrada entre os candidatos únicos. `_validate_counts` torna essa invariante autoexecutável no próprio modelo, não apenas coberta por casos de teste específicos (ver Seção 20.2 para os quatro testes obrigatórios desta invariante: diferença 0, diferença 1, diferença negativa, e diferença maior que 1).

### 7.4 Regras de leitura e proveniência

- O valor efetivo de `tautomerRemoveIsotopicHs` (e dos outros cinco parâmetros científicos) para fins de auditoria/`ResolvedExecutionSnapshot` DEVE ser lido do **mesmo objeto `CleanupParameters`** usado na construção do enumerador (Seção 7.2), nunca de um getter do `TautomerEnumerator` — nenhum getter existe para `remove_isotopic_hs` (Seção 8.1).
- `resolve_rdkit_engine()` retorna os valores fixados por constante (Seção 7.1); `enumerate_tautomers_rdkit` DEVE construir o `CleanupParameters` com esses mesmos valores (nunca outros) — as duas funções compartilham as mesmas constantes de módulo, nunca duplicam os literais.

---

## 8. Rota B como única rota de produção; ausência da Rota A

### 8.1 Fato confirmado pelo spike (reproduzido, não apenas referenciado)

Por introspecção dupla e independente (`dir()` e `help()`) de uma instância real de `rdMolStandardize.TautomerEnumerator` em `rdkit==2026.3.6`, nenhum método `SetRemoveIsotopicHs` ou `GetRemoveIsotopicHs` existe. A lista completa de métodos públicos confirmada é:

```text
['Canonicalize', 'Enumerate', 'GetCallback', 'GetMaxTautomers', 'GetMaxTransforms',
 'GetReassignStereo', 'GetRemoveBondStereo', 'GetRemoveSp3Stereo', 'PickCanonical',
 'ScoreTautomer', 'SetCallback', 'SetMaxTautomers', 'SetMaxTransforms',
 'SetReassignStereo', 'SetRemoveBondStereo', 'SetRemoveSp3Stereo', 'tautomerScoreVersion']
```

Em contraste, `rdMolStandardize.CleanupParameters().tautomerRemoveIsotopicHs` é uma propriedade Python legível e gravável, confirmada por `help()` com docstring nativa `"remove isotopic Hs from centers involved in tautomerism (defaults to True)"`.

### 8.2 Decisão normativa

**Rota B é a única rota de produção para `rdkit==2026.3.6`.** Nenhum código de produção deste incremento DEVE conter um caminho condicional, um `hasattr` de fallback, ou qualquer menção operacional a uma Rota A. A Rota A não existe nesta versão e não é implementada, imitada, nem simulada.

### 8.3 Teste negativo de contrato (D-016-SPIKE-08)

DEVE existir, em `tests/test_rdkit_tautomer.py`, um teste que:

1. constrói uma instância real de `rdMolStandardize.TautomerEnumerator()`;
2. afirma que `hasattr(instance, "SetRemoveIsotopicHs")` é `False`;
3. afirma que `hasattr(instance, "GetRemoveIsotopicHs")` é `False`.

Este teste **passa hoje** precisamente porque esses métodos estão ausentes. Se uma versão futura do RDKit passar a expô-los, este teste **DEVE falhar explicitamente** no momento em que a versão pinada em `pyproject.toml` for alterada — a suíte vermelha é o sinal exigido, e nenhuma mudança de rota, uso condicional dos novos métodos, ou relaxamento deste teste é permitido sem uma nova revisão adversarial explícita que reavalie a escolha de rota. Nenhum upgrade de `rdkit` neste projeto pode mudar silenciosamente de Rota B para Rota A.

---

## 9. Entrada SDF — regras e tratamento de erro

### 9.1 Regras normativas (D-016-SPIKE-03)

- A entrada DEVE ser lida com `Chem.SDMolSupplier`, nunca `Chem.ForwardSDMolSupplier`.
- Um arquivo vazio ou inválido faz `Chem.SDMolSupplier(path)` lançar `OSError` (`"File error: Invalid input file <path>"`) na própria construção, antes de qualquer iteração — confirmado por execução real no spike. `enumerate_tautomers_rdkit` DEVE capturar esse `OSError` e traduzi-lo em `InvalidSDFError`.
- `Chem.ForwardSDMolSupplier` sobre o mesmo arquivo vazio **não lança exceção** — retorna vazio ao ser iterado. Por isso `ForwardSDMolSupplier` é explicitamente proibido como mecanismo de leitura neste adapter: não produz o sinal de erro que a plataforma exige.
- RDKit **não rejeita** SDF multimolécula nativamente. `len(supplier) == 1` é a checagem normativa e obrigatória, implementada explicitamente pelo adapter — não uma garantia do RDKit. Qualquer outra contagem DEVE lançar `MultipleMoleculesError(record_count)`.
- Somente `representation.format == "sdf"` (após normalização de caixa: `format.strip().lower() == "sdf"`) é aceito pelo Application Service antes mesmo de chamar o adapter (fase de resolução — Seção 15, passo 1). `MolecularRepresentationRef.format` é uma string livre no domínio (Seção 11); nenhuma parte deste incremento presume que o tipo de domínio já validou o vocabulário.

### 9.2 O que este incremento explicitamente não faz silenciosamente

Nenhuma das ações abaixo é executada pelo adapter, pelo Application Service, ou implicitamente pelo RDKit sob este contrato:

- remoção de sais/fragmentos;
- neutralização de carga;
- reionização;
- seleção do maior fragmento;
- geração de coordenadas;
- otimização de geometria;
- escolha de estado por pH;
- aplicação da pipeline completa `Cleanup`/MolVS.

---

## 10. Evolução do schema de persistência — `ExecutionAttempt` 1.0 → 1.1

### 10.1 Decisão normativa de versionamento (D-016-DRAFT-01)

**Somente `ExecutionAttempt.schema_version` passa a aceitar `Literal["1.0", "1.1"]`.** `TautomerEnumerationPolicy.schema_version` e `ResolvedExecutionSnapshot.schema_version` permanecem `Literal["1.0"]`, sem qualquer alteração de forma. Não existe versionamento conjunto desses três modelos.

Todo novo `ExecutionAttempt` criado por este incremento é exclusivamente `schema_version="1.1"`. O registry nunca cria novos attempts `"1.0"`. Documentos `"1.0"` pré-existentes (criados no Incremento 015, sem `input_state_id`) continuam legíveis sem migração e sem reescrita do arquivo em disco no momento da leitura.

### 10.2 Campo novo: `input_state_id`

`ExecutionAttempt` ganha o campo `input_state_id: Optional[str] = None`. Ele declara, desde o momento da criação do attempt (status `started`), sobre qual `MolecularState` a operação incide — antes mesmo de qualquer resolução de motor. Um attempt que termina em `resolution_failed` sem nunca invocar o motor ainda assim carrega um sujeito auditável.

`input_state_id`, quando presente, é validado por `validate_input_id` (o mesmo validador de formato usado por todo outro id de armazenamento do projeto) e é **imutável desde `started`**: nenhuma das quatro transições (`mark_resolved`, `mark_resolution_failed`, `mark_execution_failed`, `mark_succeeded`) DEVE alterá-lo — cada uma delas DEVE copiar `current.input_state_id` verbatim para o novo snapshot construído (ver Seção 10.6).

### 10.3 Matriz normativa completa `schema_version × status × input_state_id`

| `schema_version` | `status` | Regra para `input_state_id` |
|---|---|---|
| `1.0` | `started` | DEVE ser `None` (documentos legados não têm este campo; ausência no YAML desserializa como `None`) |
| `1.0` | `resolution_failed` | DEVE ser `None` |
| `1.0` | `resolved` | DEVE ser `None` |
| `1.0` | `execution_failed` | DEVE ser `None` |
| `1.0` | `succeeded` | DEVE ser `None` |
| `1.1` | `started` | DEVE ser não-`None`, validado por `validate_input_id` |
| `1.1` | `resolution_failed` | DEVE ser não-`None`, idêntico ao valor em `started` |
| `1.1` | `resolved` | DEVE ser não-`None`, idêntico ao valor em `started` |
| `1.1` | `execution_failed` | DEVE ser não-`None`, idêntico ao valor em `started` |
| `1.1` | `succeeded` | DEVE ser não-`None`, idêntico ao valor em `started` |

Regras adicionais que se aplicam a todas as dez células:

- Nenhuma transição pode alterar `schema_version` ou `input_state_id` de um attempt já criado.
- `load_execution_attempt` aceita documentos `1.0` sem migrar ou sobrescrever o arquivo.
- O Application Service (`enumerate_state_tautomers`, Seção 16) rejeita um attempt `1.0` como entrada de qualquer operação futura, porque ele não possui sujeito auditável — mas nada neste incremento lê um attempt `1.0` para retomá-lo; a rejeição é uma garantia de projeto (nenhuma função pública deste incremento aceita um attempt `1.0` como parâmetro), não uma checagem de runtime nova.

### 10.4 Campo novo: resíduos em `ExecutionAttemptError`

`ExecutionAttemptError` ganha dois campos novos:

```python
residual_state_ids: tuple[str, ...] = ()
residual_operation_ids: tuple[str, ...] = ()
```

Semântica:

- Contêm apenas ids que a compensação (Seção 17.3) tentou remover mas não conseguiu confirmar como removidos.
- Permitidos **somente** quando `phase == "execution"`.
- Todos os ids são validados (`validate_input_id`) e deduplicados dentro de cada tupla — duplicatas são rejeitadas, nunca silenciosamente removidas.
- Uma falha sem resíduos mantém ambas as tuplas vazias (o valor default).
- A ordem não é reordenada pelo modelo: o Application Service fornece a ordem determinística original de publicação (Seção 17).
- A mensagem humana (`message`) nunca é usada como armazenamento de ids.

### 10.5 Matriz normativa completa `phase × resíduos`

| `phase` | Resíduos | Resultado |
|---|---|---|
| `resolution` | ambas as tuplas vazias | válido |
| `resolution` | qualquer tupla não vazia | **inválido** — rejeitado por `ExecutionAttemptError.model_validator` |
| `execution` | ambas as tuplas vazias | válido |
| `execution` | uma ou ambas não vazias, ids válidos e únicos | válido |
| `execution` | id inválido ou duplicado dentro de uma tupla | **inválido** — rejeitado por `ExecutionAttemptError.model_validator` |

### 10.6 Propagação de `input_state_id` nas transições — contrato de `execution_registry.py`

Cada uma das quatro funções de transição DEVE copiar `current.input_state_id` (e `current.schema_version`) inalterado para o novo snapshot que constrói, exatamente como já copia `current.requested`. Nenhuma delas aceita `input_state_id` como argumento — ele só é fornecido em `begin_execution_attempt` (Seção 10.7) e nunca mais depois disso.

### 10.7 `begin_execution_attempt` — assinatura atualizada

```python
def begin_execution_attempt(
    project_dir: Path,
    *,
    operation_type: str,
    requested: TautomerEnumerationPolicy,
    input_state_id: str,
) -> ExecutionAttempt:
    """Begin a new ExecutionAttempt in status 'started', schema_version
    "1.1", declaring input_state_id as the MolecularState this attempt
    operates on. input_state_id is validated via validate_input_id
    before any I/O - including before attempt_id generation - exactly
    like operation_type is validated today. This function never checks
    that input_state_id resolves to an actually-registered
    MolecularState: that check belongs to the Application Service's
    resolution phase (Section 15, step 2), which runs strictly after
    this function returns. Does not accept operation_ids, for the same
    D-015-11/D-015-12 timing reason already documented in this module:
    which StateTransformationRecords (if any) this attempt produces is
    only known once execution succeeds.

    This supersedes the Increment 015 signature, which accepted no
    input_state_id at all and always produced schema_version="1.0".
    Every new attempt created by this function is schema_version="1.1";
    this function never constructs a "1.0" attempt.
    """
```

---

## 11. Contratos Python completos

Esta seção reproduz a forma final e completa de todos os modelos afetados ou introduzidos por este incremento. Modelos não listados aqui (`ScientificEntity`, `MolecularState`, `MolecularRepresentationRef`, `Conformer`, `TransformationProducer`, `TransformationParameter`, `StateTransformationRecord`, `LigandInput`, `ProteinInput`) permanecem exatamente como já existem no repositório na baseline da Seção 3, sem nenhuma alteração de campo, tipo, default, `Literal` ou validação.

### 11.1 `molecular.execution` — forma completa pós-016

```python
from collections.abc import Mapping
from datetime import datetime
from types import MappingProxyType
from typing import Literal, Optional

from pydantic import BaseModel, ConfigDict, Field, field_serializer, field_validator, model_validator

from molecular.inputs import validate_input_id

ExecutionStatus = Literal[
    "started",
    "resolution_failed",
    "resolved",
    "execution_failed",
    "succeeded",
]

ExecutionAttemptSchemaVersion = Literal["1.0", "1.1"]


class TautomerEnumerationPolicy(BaseModel):
    """Unchanged from Increment 015. schema_version remains Literal["1.0"]
    - this model is NOT versioned by this increment (Section 10.1)."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    schema_version: Literal["1.0"]
    max_states: Optional[int] = None
    source: Literal["scientist"]

    @field_validator("max_states")
    @classmethod
    def _validate_max_states_positive(cls, value: Optional[int]) -> Optional[int]:
        if value is not None and value < 1:
            raise ValueError(f"max_states must be >= 1 when provided (got {value})")
        return value


class ResolvedExecutionSnapshot(BaseModel):
    """Unchanged shape from Increment 015. schema_version remains
    Literal["1.0"] - this model is NOT versioned by this increment
    (Section 10.1). For the tautomer-enumeration operation, `parameters`
    MUST contain exactly the twelve keys fixed in Section 7.1 of the
    specification (algorithm, input_format, output_format, max_tautomers,
    max_transforms, remove_bond_stereo, remove_sp3_stereo,
    reassign_stereo, remove_isotopic_hs, deduplication, ordering,
    selection) - this is an Increment 016 usage contract on an unchanged
    model, not a schema change."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    schema_version: Literal["1.0"]
    engine_name: str = Field(min_length=1)
    engine_version: str = Field(min_length=1)
    parameters: Mapping[str, str | int | float | bool] = Field(
        default_factory=dict, validate_default=True
    )

    @field_validator("engine_name", "engine_version")
    @classmethod
    def _validate_not_blank(cls, value: str) -> str:
        if not value.strip():
            raise ValueError("must not be blank")
        return value

    @field_validator("parameters", mode="after")
    @classmethod
    def _freeze_parameters(
        cls, value: Mapping[str, str | int | float | bool]
    ) -> Mapping[str, str | int | float | bool]:
        return MappingProxyType(dict(value))

    @field_serializer("parameters")
    def _serialize_parameters(
        self, value: Mapping[str, str | int | float | bool]
    ) -> dict[str, str | int | float | bool]:
        return dict(value)


class ExecutionAttemptError(BaseModel):
    """Extended in Increment 016 with residual_state_ids and
    residual_operation_ids (Section 10.4). `phase` and `message` are
    unchanged from Increment 015."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    phase: Literal["resolution", "execution"]
    message: str = Field(min_length=1)
    residual_state_ids: tuple[str, ...] = ()
    residual_operation_ids: tuple[str, ...] = ()

    @field_validator("message")
    @classmethod
    def _validate_message_not_blank(cls, value: str) -> str:
        if not value.strip():
            raise ValueError("message must not be blank")
        return value

    @model_validator(mode="after")
    def _validate_residuals(self) -> "ExecutionAttemptError":
        for id_value in (*self.residual_state_ids, *self.residual_operation_ids):
            validate_input_id(id_value)

        if len(set(self.residual_state_ids)) != len(self.residual_state_ids):
            raise ValueError("residual_state_ids must not contain duplicate entries")
        if len(set(self.residual_operation_ids)) != len(self.residual_operation_ids):
            raise ValueError("residual_operation_ids must not contain duplicate entries")

        if self.phase == "resolution":
            if self.residual_state_ids or self.residual_operation_ids:
                raise ValueError(
                    "a 'resolution'-phase error must not carry any residual ids "
                    "(nothing can have been published before resolution)"
                )

        return self


class ExecutionAttempt(BaseModel):
    """Extended in Increment 016 with schema_version accepting "1.1" and
    the new input_state_id field (Section 10.2). Every other field is
    unchanged from Increment 015. _validate_status_invariants is
    extended with the schema_version x status x input_state_id cross-
    check (Section 10.3) and the schema_version x residuals cross-check
    (Section 12)."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    schema_version: ExecutionAttemptSchemaVersion
    id: str = Field(min_length=1)
    operation_type: Literal["state-transformation"]
    input_state_id: Optional[str] = None
    operation_ids: Optional[tuple[str, ...]] = None
    status: ExecutionStatus
    requested: TautomerEnumerationPolicy
    resolved: Optional[ResolvedExecutionSnapshot] = None
    error: Optional[ExecutionAttemptError] = None
    created_at: datetime
    resolved_at: Optional[datetime] = None
    finished_at: Optional[datetime] = None

    @field_validator("id")
    @classmethod
    def _validate_id_format(cls, value: str) -> str:
        return validate_input_id(value)

    @field_validator("input_state_id")
    @classmethod
    def _validate_input_state_id_format(cls, value: Optional[str]) -> Optional[str]:
        if value is None:
            return None
        return validate_input_id(value)

    @field_validator("operation_ids")
    @classmethod
    def _validate_operation_ids(
        cls, value: Optional[tuple[str, ...]]
    ) -> Optional[tuple[str, ...]]:
        if value is None:
            return None
        for candidate in value:
            validate_input_id(candidate)
        if len(set(value)) != len(value):
            raise ValueError("operation_ids must not contain duplicate entries")
        return value

    @model_validator(mode="after")
    def _validate_status_invariants(self) -> "ExecutionAttempt":
        # --- schema_version x input_state_id (Section 10.3) ---
        if self.schema_version == "1.0":
            if self.input_state_id is not None:
                raise ValueError(
                    "a schema_version '1.0' attempt must not carry input_state_id "
                    "(it predates this field)"
                )
        else:  # "1.1"
            if self.input_state_id is None:
                raise ValueError(
                    "a schema_version '1.1' attempt must carry a non-null "
                    "input_state_id in every status"
                )

        # --- schema_version x residuals (Section 12) ---
        if self.schema_version == "1.0" and self.error is not None:
            if self.error.residual_state_ids or self.error.residual_operation_ids:
                raise ValueError(
                    "a schema_version '1.0' attempt's error must not carry "
                    "residual ids (residuals did not exist in this schema)"
                )

        # --- per-status invariants (unchanged from Increment 015, plus
        #     the residual-carrying allowance on execution_failed) ---
        if self.status == "started":
            if self.resolved is not None:
                raise ValueError("a 'started' attempt must not have a resolved snapshot")
            if self.error is not None:
                raise ValueError("a 'started' attempt must not have an error")
            if self.resolved_at is not None:
                raise ValueError("a 'started' attempt must not have resolved_at set")
            if self.finished_at is not None:
                raise ValueError("a 'started' attempt must not have finished_at set")
            if self.operation_ids is not None:
                raise ValueError("a 'started' attempt must not have operation_ids set")

        elif self.status == "resolution_failed":
            if self.resolved is not None:
                raise ValueError(
                    "a 'resolution_failed' attempt must not have a resolved snapshot"
                )
            if self.error is None:
                raise ValueError("a 'resolution_failed' attempt must carry an error")
            if self.error.phase != "resolution":
                raise ValueError(
                    "a 'resolution_failed' attempt's error phase must be 'resolution' "
                    f"(got {self.error.phase!r})"
                )
            if self.resolved_at is not None:
                raise ValueError("a 'resolution_failed' attempt must not have resolved_at set")
            if self.finished_at is None:
                raise ValueError("a 'resolution_failed' attempt must have finished_at set")
            if self.operation_ids is not None:
                raise ValueError("a 'resolution_failed' attempt must not have operation_ids set")

        elif self.status == "resolved":
            if self.resolved is None:
                raise ValueError("a 'resolved' attempt must carry a resolved snapshot")
            if self.error is not None:
                raise ValueError("a 'resolved' attempt must not have an error")
            if self.resolved_at is None:
                raise ValueError("a 'resolved' attempt must have resolved_at set")
            if self.finished_at is not None:
                raise ValueError("a 'resolved' attempt must not have finished_at set")
            if self.operation_ids is not None:
                raise ValueError("a 'resolved' attempt must not have operation_ids set")

        elif self.status == "execution_failed":
            if self.resolved is None:
                raise ValueError("an 'execution_failed' attempt must carry a resolved snapshot")
            if self.error is None:
                raise ValueError("an 'execution_failed' attempt must carry an error")
            if self.error.phase != "execution":
                raise ValueError(
                    "an 'execution_failed' attempt's error phase must be 'execution' "
                    f"(got {self.error.phase!r})"
                )
            if self.resolved_at is None:
                raise ValueError("an 'execution_failed' attempt must have resolved_at set")
            if self.finished_at is None:
                raise ValueError("an 'execution_failed' attempt must have finished_at set")
            if self.operation_ids is not None:
                raise ValueError("an 'execution_failed' attempt must not have operation_ids set")

        elif self.status == "succeeded":
            if self.resolved is None:
                raise ValueError("a 'succeeded' attempt must carry a resolved snapshot")
            if self.error is not None:
                raise ValueError("a 'succeeded' attempt must not have an error")
            if self.resolved_at is None:
                raise ValueError("a 'succeeded' attempt must have resolved_at set")
            if self.finished_at is None:
                raise ValueError("a 'succeeded' attempt must have finished_at set")
            if self.operation_ids is None:
                raise ValueError("a 'succeeded' attempt must have operation_ids set")

        return self
```

### 11.2 `molecular.rdkit_tautomer` — forma completa

Reproduzida integralmente na Seção 7 (7.1 a 7.3). Não repetida aqui para evitar duas fontes divergentes do mesmo contrato.

### 11.3 Tipo de correlação de atividade — `molecular.application`

```python
@dataclass(frozen=True)
class TautomerEnumerationActivityDetails:
    """Typed activity-log context for enumerate_state_tautomers. Mirrors
    DerivedStateActivityDetails exactly in spirit: every field is a
    specific, known correlation id, never arbitrary metadata. attempt_id
    is opaque and operational only, exactly as in
    DerivedStateActivityDetails."""

    attempt_id: str
    input_state_id: str
    published_state_ids: tuple[str, ...]
    published_transformation_ids: tuple[str, ...]
```

---

## 12. Matriz normativa completa `schema_version × resíduos`

| `schema_version` | `status` | Regra para `residual_state_ids` / `residual_operation_ids` |
|---|---|---|
| `1.0` | `started` | ambas obrigatoriamente `()` |
| `1.0` | `resolution_failed` | ambas obrigatoriamente `()` |
| `1.0` | `resolved` | ambas obrigatoriamente `()` |
| `1.0` | `execution_failed` | ambas obrigatoriamente `()` |
| `1.0` | `succeeded` | ambas obrigatoriamente `()` |
| `1.1` | `started` | ambas `()`, porque `error` é `None` |
| `1.1` | `resolution_failed` | ambas obrigatoriamente `()`, porque `error.phase="resolution"` não admite resíduos |
| `1.1` | `resolved` | ambas `()`, porque `error` é `None` |
| `1.1` | `execution_failed` | `()` ou não vazias; não vazias somente se `error.phase="execution"`, `resolved` presente e `operation_ids=None` |
| `1.1` | `succeeded` | ambas `()`, porque `error` é `None` |

**Resumo normativo:** `ExecutionAttempt` schema `1.0` exige `residual_state_ids=()` e `residual_operation_ids=()` em todos os status, sem exceção. `ExecutionAttempt` schema `1.1` permite resíduos não vazios somente quando, simultaneamente, `status="execution_failed"`, `error.phase="execution"`, `resolved` está presente e `operation_ids is None`; em qualquer outra combinação de `schema_version` e `status`, ambas as tuplas permanecem vazias.

**Esclarecimento editorial (não normativo; não altera a matriz nem o comportamento):** a condição `operation_ids is None`, citada acima entre as condições simultâneas necessárias para resíduos não vazios, **não é exclusiva nem distintiva** do caso com resíduos — `operation_ids=None` é uma invariante incondicional de **todo** `ExecutionAttempt` com `status="execution_failed"`, com ou sem resíduos, já herdada do Incremento 015 e reafirmada em `_validate_status_invariants` (Seção 11.1). Ela é citada aqui apenas porque é uma das condições que, juntas, tornam resíduos não vazios válidos — não porque a presença de resíduos é o que a torna verdadeira.

### Matriz normativa `status × error × resolved × operation_ids × resíduos`

| `ExecutionAttempt.status` | `error` / fase | `resolved` | `operation_ids` | Resíduos |
|---|---|---|---|---|
| `started` | `None` | `None` | `None` | impossíveis, porque `error=None` |
| `resolution_failed` | obrigatório, `phase="resolution"` | `None` | `None` | obrigatoriamente vazios |
| `resolved` | `None` | obrigatório | `None` | impossíveis, porque `error=None` |
| `execution_failed` | obrigatório, `phase="execution"` | obrigatório | `None` | vazios ou não vazios conforme rollback |
| `succeeded` | `None` | obrigatório | tupla, inclusive vazia | impossíveis, porque `error=None` |

---

## 13. Responsabilidades de validação separadas

Duas fronteiras de validação distintas e não sobrepostas:

1. **`ExecutionAttemptError.model_validator` (mode="after")** — Seção 11.1 — valida exclusivamente o conteúdo interno de um `ExecutionAttemptError` isolado: formato de cada id residual, ausência de duplicatas dentro de cada tupla, e a proibição de qualquer resíduo quando `phase == "resolution"`. Este validador **não tem acesso** a `schema_version` — `ExecutionAttemptError` não possui esse campo.
2. **`ExecutionAttempt._validate_status_invariants` (mode="after")** — Seção 11.1 — executa toda checagem cruzada que depende de mais de um campo do attempt: `schema_version` × `status` × `input_state_id`; `schema_version` × resíduos de `error`; e as invariantes por status já existentes desde o Incremento 015 (`resolved`, `error`, `operation_ids`, timestamps).

Nenhuma checagem cruzada que envolva `schema_version` DEVE ser duplicada dentro de `ExecutionAttemptError` — `ExecutionAttemptError` não sabe, e nunca deve saber, em qual versão de `ExecutionAttempt` está inserido.

---

## 14. `max_states` — docstring normativo completo

O docstring de `TautomerEnumerationPolicy.max_states` em `execution.py` DEVE conter, sem abreviação, o seguinte texto (ou um texto que preserve integralmente esta semântica):

> `max_states` é o teto opcional de novos `MolecularState`s publicados **após** a enumeração ter concluído (`status=Completed`), a sanitização e a verificação de invariantes químicos de cada candidato, a deduplicação por SMILES canônico isomérico, a exclusão do estado equivalente à entrada, e a ordenação determinística. Ele não limita a busca interna do motor e não é mapeado para `maxTautomers` ou `maxTransforms` do RDKit. `None` significa que o cientista não declarou teto algum — não que algum default numérico da plataforma se aplica; este módulo não carrega nenhum default científico para quantos tautômeros enumerar, e nenhum é inventado aqui.

---

## 15. Fluxo algorítmico normativo completo

A tabela abaixo é a ordem exigida, célula a célula, do fluxo completo — desde a validação inicial até a conclusão do attempt. Nenhuma etapa pode ser reordenada, pulada ou combinada de forma que oculte uma das falhas correspondentes.

| # | Etapa normativa | Módulo/função responsável | Fase | Falha correspondente |
|---:|---|---|---|---|
| 1 | Validar `input_state_id` e a `TautomerEnumerationPolicy` (formato de id; a política já chega validada por construção Pydantic) | `enumerate_state_tautomers` (Seção 16) | pré-attempt | `ValueError` imediato, nenhum attempt criado |
| 2 | `begin_execution_attempt(..., input_state_id=...)` — cria o attempt, status `started`, schema `1.1` | `execution_registry.begin_execution_attempt` | — | — |
| 3 | Carregar o `MolecularState` de `input_state_id`; validar `representation.format` normalizado `== "sdf"`; validar que o arquivo referenciado existe e seu SHA-256 corresponde a `representation.checksum` | `enumerate_state_tautomers` | **resolução** | `resolution_failed` (arquivo ausente/checksum divergente, ou formato não suportado) |
| 4 | `resolve_rdkit_engine()` — resolver motor e configuração fixa (Seção 7.1) | `rdkit_tautomer.resolve_rdkit_engine` | **resolução** | `resolution_failed` (`RDKitUnavailableError`) |
| 5 | Construir `ResolvedExecutionSnapshot` com os doze parâmetros fixos (Seção 7.1) e `mark_resolved` | `enumerate_state_tautomers` / `execution_registry.mark_resolved` | — | — |
| 6 | **Carregar entrada**: `Chem.SDMolSupplier(path)` | `rdkit_tautomer.enumerate_tautomers_rdkit` | **execução** | `execution_failed` (`InvalidSDFError`) |
| 7 | **Validar molécula única**: `len(supplier) == 1` | `rdkit_tautomer.enumerate_tautomers_rdkit` | **execução** | `execution_failed` (`MultipleMoleculesError`) |
| 8 | **Enumerar**: construir o enumerador Rota B (Seção 7.2) e chamar `Enumerate(mol)` | `rdkit_tautomer.enumerate_tautomers_rdkit` | **execução** | — |
| 9 | **Exigir status `Completed`** | `rdkit_tautomer.enumerate_tautomers_rdkit` | **execução** | `execution_failed` (`IncompleteEnumerationError`; nenhuma publicação — Seção 15.2) |
| 10 | **Sanitizar candidatos**: `Chem.SanitizeMol` em cada candidato retornado, individualmente | `rdkit_tautomer.enumerate_tautomers_rdkit` | **execução** | nenhuma — candidato reprovado é descartado, não propaga erro (D-016-SPIKE-04; Seção 15.3) |
| 11 | **Aplicar a decisão D-016-SPIKE-04**: qualquer candidato reprovado em (10) é definitivamente excluído do conjunto de saída, sem exceção e sem publicação | `rdkit_tautomer.enumerate_tautomers_rdkit` | **execução** | — |
| 12 | **Verificar elemento, composição isotópica e carga** de cada candidato sanitizado contra a molécula de entrada; descartar qualquer divergência | `rdkit_tautomer.enumerate_tautomers_rdkit` | **execução** | nenhuma — descarte silencioso, mesmo tratamento do passo 10/11 |
| 13 | **Produzir SMILES canônico isomérico** de cada candidato sobrevivente | `rdkit_tautomer.enumerate_tautomers_rdkit` | **execução** | — |
| 14 | **Deduplicar** por essa string | `rdkit_tautomer.enumerate_tautomers_rdkit` | **execução** | — |
| 15 | **Excluir equivalência da entrada** (SMILES canônico isomérico da própria molécula de entrada) | `rdkit_tautomer.enumerate_tautomers_rdkit` | **execução** | — |
| 16 | **Ordenar** lexicograficamente | `rdkit_tautomer.enumerate_tautomers_rdkit` | **execução** | — |
| 17 | Retornar `RDKitTautomerEnumerationResult(enumerated_unique_count, new_unique_count, candidates)` ao Application Service | `rdkit_tautomer.enumerate_tautomers_rdkit` → `enumerate_state_tautomers` | — | — |
| 18 | **Aplicar `max_states`**: `published = candidates[:policy.max_states]` se `policy.max_states is not None`, senão `published = candidates` | `enumerate_state_tautomers` | **execução** | — |
| 19 | Se `len(published) == 0`: pular direto para o passo 23 (Seção 15.1) | `enumerate_state_tautomers` | **execução** | — (sucesso válido, não falha) |
| 20 | **Preparar publicação**: gerar todos os `state_id`/`transformation_id` (uuid4 hex) antes de qualquer escrita; escrever cada SMILES em um arquivo temporário próprio, com newline final; todo `MolecularState` filho recebe exatamente o `entity_id` do `MolecularState` de `input_state_id` (Seção 15.4) | `enumerate_state_tautomers` | **execução** | — |
| 21 | Preflight de conflito de identidade para todos os destinos gerados no passo 20, contra `scientific/states` e `scientific/transformations` | `enumerate_state_tautomers` (via `_check_state_identity_conflict`/`_check_transformation_identity_conflict`) | **execução** | `execution_failed` sem nenhuma escrita, se qualquer conflito for detectado |
| 22 | **Persistir estados e transformações** em ordem: para cada candidato publicado, `register_state` seguido de `register_state_transformation` | `enumerate_state_tautomers` (via `scientific_registry.register_state`, `transformation_registry.register_state_transformation`) | **execução** | `execution_failed` com compensação reversa (Seção 17.3) em caso de exceção a partir daqui |
| 23 | **Concluir o attempt**: `mark_succeeded(attempt_id, operation_ids=<tupla de transformation_ids na ordem de publicação>)` — `operation_ids=()` se o passo 19 foi tomado | `execution_registry.mark_succeeded` | — | — |

### 15.1 Zero novos estados é sucesso válido

Se, após os passos 14–16 (dedup, exclusão da entrada, ordenação) e a truncagem por `max_states` no passo 18, não sobrar nenhum candidato:

- a execução é bem-sucedida;
- nenhum `MolecularState` ou `StateTransformationRecord` é criado;
- `mark_succeeded(..., operation_ids=())` é chamado diretamente, sem nenhuma etapa de staging/preflight/publicação;
- a ausência de derivados **não** é tratada como erro químico, nem como `execution_failed`.

Este é o mesmo comportamento, e o mesmo caminho de código, seja a causa "o motor não encontrou nenhum tautômero novo" ou "todos os candidatos retornados falharam em sanitizar/nas invariantes químicas" (Seção 15.3) ou "a política truncou tudo para zero" — as três causas são operacionalmente indistinguíveis no resultado final e DEVEM produzir exatamente o mesmo sucesso com `operation_ids=()`.

### 15.2 Status de limite/cancelamento proíbem publicação parcial

`MaxTautomersReached`, `MaxTransformsReached` e `Canceled` (Seção 5, D-016-SPIKE-07) produzem `execution_failed` (via `IncompleteEnumerationError`, passo 9) **antes** de qualquer sanitização, verificação de invariantes, ou publicação. Não existe "publicação parcial dos candidatos obtidos até o momento em que o motor parou" — o lote inteiro é descartado, e o attempt termina em `execution_failed` com `error.phase="execution"` e a mensagem carregando o `status` real e a contagem de tautômeros que o RDKit havia produzido até parar (via `IncompleteEnumerationError.status`/`.tautomer_count`).

### 15.3 Comportamento inequívoco para conjuntos mistos de candidatos válidos/inválidos

Esta regra resolve explicitamente o que o rascunho pré-spike deixava implícito:

- Um candidato que falha em `Chem.SanitizeMol`, ou que sanitiza mas diverge da entrada em contagem de elemento, composição isotópica, ou carga formal, é **descartado silenciosamente** do conjunto de saída. Isso **nunca** levanta uma exceção, **nunca** interrompe o processamento dos demais candidatos do mesmo lote, e **nunca**, por si só, torna o attempt `execution_failed`.
- O spike (relatório corrigido, Seção 7.4) demonstrou, com evidência real, um substrato em que 8 de 13 candidatos (≈62%) falham por esse motivo, com `status=Completed` — esse é o comportamento esperado e contratual do motor, não uma anomalia a ser tratada como erro.
- Um conjunto **misto** (alguns válidos, alguns inválidos) resulta em publicação apenas dos válidos — o descarte dos inválidos não é registrado como campo formal em `StateTransformationRecord`, `ResolvedExecutionSnapshot`, nem em qualquer outro modelo persistido; não existe, e este incremento não cria, um campo para "quantos candidatos brutos foram descartados por sanitização". Essa contagem é comportamento interno do adapter, coberto por teste (Seção 20.2), não um dado de proveniência contratual.
- Um conjunto em que **nenhum** candidato sanitiza ou passa as invariantes resulta em `new_unique_count == 0` e no mesmo caminho de sucesso da Seção 15.1 — nunca em `execution_failed`. A ausência de candidatos quimicamente válidos não é, por si só, uma falha de execução; apenas um status de motor diferente de `Completed` (Seção 15.2) o é.

### 15.4 Herança obrigatória de `entity_id`

Todo `MolecularState` filho publicado por `enumerate_state_tautomers` DEVE receber exatamente o `entity_id` do `MolecularState` referenciado por `input_state_id` (carregado no passo 3) — nunca um `entity_id` gerado, substituído, ou escolhido por qualquer outro critério. Isso espelha exatamente o comportamento já existente de `register_derived_state` (`application.py` atual, confirmado por leitura direta do código: o `entity_id` do filho é fixado a partir do pai carregado, por construção, não por checagem posterior).

Um tautômero é, pela própria definição desta especificação (Seção 2.1), a mesma espécie molecular sob redistribuição formal de hidrogênio e ordens de ligação — logo, o mesmo `ScientificEntity` ao qual o `MolecularState` de entrada pertence continua sendo o `ScientificEntity` de todo estado tautomérico derivado dele. Nenhum código de produção deste incremento DEVE gerar, aceitar como parâmetro, ou derivar de qualquer outra fonte um `entity_id` diferente para os estados publicados por esta operação. Esta regra é coberta por teste explícito obrigatório (Seção 20.4) e é critério de aceite objetivo (Seção 21, critério 26).

---

## 16. Contrato da Application API — `enumerate_state_tautomers`

```python
def enumerate_state_tautomers(
    project_dir: Path,
    *,
    input_state_id: str,
    policy: TautomerEnumerationPolicy,
    _resolve_engine: Callable[[], RDKitEngineResolution] = resolve_rdkit_engine,
    _enumerate: Callable[..., RDKitTautomerEnumerationResult] = enumerate_tautomers_rdkit,
) -> ExecutionAttempt:
    """Orchestrate one full tautomer-enumeration ExecutionAttempt end to
    end: resolve the input state and the RDKit engine, enumerate, apply
    policy, publish results, and conclude the attempt - exactly the
    sequence normatively defined in Section 15 of the specification.

    _resolve_engine and _enumerate are private, keyword-only injection
    seams for tests only (Section 20.4) - never part of the public
    contract, never given a Protocol/ABC type of their own (per
    D-016-DRAFT-07/the pre-spike's explicit prohibition on inventing an
    Engine abstraction in this increment), and never documented to
    callers outside this module's own test suite. Every real caller
    (the future Increment 017 CLI, or any test exercising the real
    RDKit path) uses the defaults.

    This is not a database transaction. What exists is the ordering in
    Section 15, plus best-effort compensation on failure (Section 17.3).
    input_state_id and every id inside `policy` are validated (Section
    15, step 1) before any I/O - including before begin_execution_attempt
    - so a malformed id fails immediately, without creating an attempt
    at all.

    Every domain/persistence exception raised by the modules this calls
    propagates unchanged to a corresponding mark_resolution_failed or
    mark_execution_failed call, mirroring register_derived_state's own
    error-handling convention in this module: this function never lets
    an exception escape without first recording it against the attempt
    it belongs to, except for the pre-attempt validation in step 1,
    which by construction has no attempt yet to record against.
    """
```

### 16.1 Sequência de logging de atividade

Mirroring `register_derived_state`, `enumerate_state_tautomers` DEVE registrar, de forma best-effort (nunca afetando o resultado da operação):

1. `outcome="started"`, com `TautomerEnumerationActivityDetails(attempt_id=..., input_state_id=..., published_state_ids=(), published_transformation_ids=())`, antes de qualquer escrita que possa criar estados/transformações;
2. `outcome="success"` ou `outcome="error"` ao final, com `published_state_ids`/`published_transformation_ids` preenchidos com o que foi efetivamente publicado (possivelmente vazio).

A fronteira de captura para compensação e log de erro é `except BaseException`, não `except Exception`, espelhando exatamente a justificativa já documentada em `register_derived_state`: uma vez que qualquer escrita tenha ocorrido, um `KeyboardInterrupt`/`SystemExit` deve acionar a mesma compensação e o mesmo log best-effort de erro que qualquer outra exceção.

---

## 17. Persistência, preflight, compensação e resíduos

### 17.1 Garantia oferecida

Com o layout atual de múltiplos diretórios/arquivos, não existe um único rename capaz de publicar simultaneamente N estados, N transformações e o attempt. Este incremento oferece:

- validação completa (Seção 15, passos 1–17) antes de qualquer escrita de estado/transformação;
- geração de todos os ids antes de qualquer escrita (passo 20);
- preflight de colisão de identidade para todos os destinos antes da primeira escrita (passo 21);
- publicação sequencial (passo 22);
- compensação best-effort dentro do mesmo processo (Seção 17.3);
- nenhum resultado deliberadamente visível quando uma exceção controlada ocorre antes do `mark_succeeded`.

Isso é **all-or-nothing compensado no processo**, não uma transação durável.

### 17.2 Garantias que este incremento explicitamente não oferece

- atomicidade contra encerramento abrupto do processo;
- rollback garantido após queda de energia;
- isolamento entre dois processos concorrentes (a mesma janela TOCTOU já documentada em `atomic.check_storage_identity_conflict` se aplica aqui sem mudança);
- invisibilidade de resultados durante a janela de publicação;
- recuperação automática de órfãos após um crash — um `started` sem `success`/`error` correspondente no log de atividade é apenas candidato a investigação manual, nunca prova de órfão por si só.

### 17.3 Compensação reversa

Se qualquer exceção ocorrer a partir do início do passo 22 (inclusive durante o próprio passo), a compensação DEVE cobrir dois casos distintos, ambos restritos a esta mesma chamada — nunca um registro preexistente de uma chamada anterior:

1. **Pares completos já publicados por esta chamada** (candidatos anteriores ao que estava em publicação no momento da falha): para cada um, em ordem estritamente reversa,
   a. remover a transformação recém-criada (`transformation_registry._remove_state_transformation_best_effort`, Seção 17.4);
   b. remover o estado recém-criado e sua representação (`scientific_registry._remove_state_best_effort`, já existente desde o Incremento 015);
   c. repetir para o par anterior, até o primeiro par publicado nesta chamada.

2. **O candidato em publicação no momento exato da falha (par assimétrico).** Se `register_state` do candidato corrente já teve sucesso, mas o `register_state_transformation` correspondente falhou (ou qualquer exceção ocorreu entre as duas chamadas para esse mesmo candidato), o estado já criado para esse candidato específico DEVE ser removido também — não apenas os pares completos anteriores. `enumerate_state_tautomers` DEVE rastrear esse caso com uma flag booleana por candidato, equivalente em espírito e comportamento à flag `child_created` já usada por `register_derived_state` (`application.py` atual, confirmado por leitura direta do código): a flag (por exemplo, `state_created`) é marcada `True` imediatamente após o `register_state` do candidato corrente ter sucesso, e a compensação, ao alcançar esse candidato, remove seu estado sempre que a flag estiver `True`, independentemente de a transformação correspondente ter sido publicada ou não.

A ordem de remoção permanece estritamente reversa entre os dois casos: o candidato em publicação no momento da falha (caso 2) é removido antes de qualquer par completo anterior (caso 1), por ser o escrito mais recentemente nesta chamada.

Nenhuma remoção jamais alcança um id publicado por uma chamada anterior — a compensação só itera sobre os ids gerados no passo 20 desta invocação específica, e só remove um estado do candidato em publicação quando sua própria flag de criação, gerada nesta mesma chamada, estiver `True` (item 28 do pedido: registros preexistentes são preservados por construção, não por uma checagem adicional).

Se a compensação de um par específico não puder confirmar a remoção (por exemplo, `OSError` durante o `unlink`/`rmtree` best-effort), o `state_id`/`transformation_id` correspondente é acrescentado a `residual_state_ids`/`residual_operation_ids` do `ExecutionAttemptError` usado no `mark_execution_failed` final (Seção 10.4), na mesma ordem determinística de publicação — nunca reordenado. Se a compensação falhar por completo, o attempt ainda assim termina em `execution_failed`; os resíduos tipados, mais o log de atividade `outcome="error"`, são o sinal de que uma intervenção manual pode ser necessária. `operation_ids` permanece `None` neste caminho, preservando sua semântica de sucesso exclusivo.

### 17.4 Novo helper de compensação — `transformation_registry._remove_state_transformation_best_effort`

```python
def _remove_state_transformation_best_effort(project_dir: Path, transformation_id: str) -> None:
    """Best-effort compensating removal of a StateTransformationRecord's
    metadata file - mirrors _remove_state_best_effort in
    molecular.scientific_registry exactly, including its scoping
    contract: this is not a public delete function, and must only ever
    be called by an orchestrating Application Service to roll back a
    transformation it just registered within the same call, when a
    later step of that same operation subsequently fails. A
    StateTransformationRecord has no artifact of its own (see this
    module's own docstring), so there is no artifact directory to clean
    up alongside the metadata file - unlike
    _remove_state_best_effort, which also removes a representation
    directory.

    Never raises: failures are logged as warnings and swallowed, never
    masking whatever error is already propagating from the caller.
    """
```

---

## 18. Taxonomia de erros

| Condição | Fase do `ExecutionAttempt` | Exceção típica capturada | Resultado |
|---|---|---|---|
| Formato de `input_state_id`/`policy` inválido | pré-attempt | `ValueError`/`pydantic.ValidationError` | propaga sem criar attempt |
| `input_state_id` não resolve a um `MolecularState` registrado | resolução | `FileNotFoundError` | `resolution_failed` |
| `representation.format` normalizado ≠ `"sdf"` | resolução | `ValueError` interno do Application Service | `resolution_failed` |
| Arquivo da representação ausente, ou checksum divergente | resolução | `FileNotFoundError`/`ValueError` interno | `resolution_failed` |
| RDKit ausente ou versão ilegível | resolução | `RDKitUnavailableError` | `resolution_failed` |
| SDF vazio/inválido | execução | `InvalidSDFError` | `execution_failed` |
| SDF com contagem de moléculas ≠ 1 | execução | `MultipleMoleculesError` | `execution_failed` |
| Status do motor ≠ `Completed` | execução | `IncompleteEnumerationError` | `execution_failed`; nenhuma publicação (Seção 15.2) |
| Candidato individual falha em sanitizar/invariantes | execução | nenhuma — descarte silencioso | não é falha do attempt (Seção 15.3) |
| Conflito de identidade detectado no preflight (passo 21) | execução | `StateIdentityConflictError`/`TransformationIdentityConflictError` | `execution_failed`, nenhuma escrita ocorreu |
| Falha durante `register_state`/`register_state_transformation` (passo 22) | execução | qualquer `OSError`/exceção de registry | `execution_failed`, compensação reversa acionada |
| Compensação conclui com sucesso | execução | — | `execution_failed`, resíduos vazios |
| Compensação falha parcial ou totalmente | execução | — | `execution_failed`, resíduos não vazios, intervenção manual recomendada |

Mensagens persistidas em `ExecutionAttemptError.message` NÃO DEVEM incluir stack trace, caminhos absolutos sensíveis, ou stdout arbitrário do RDKit. O traceback completo permanece apenas no log de desenvolvimento (`logging`); o erro de domínio persistido é conciso e acionável.

---

## 19. Identidade, determinismo e formato de saída

- Cada candidato publicado é persistido como um arquivo de texto contendo exatamente um **SMILES canônico isomérico**, seguido de exatamente um caractere de newline final, com `MolecularRepresentationRef.format = "smiles"`.
- Nenhuma geometria 3D é implicada ou gerada — o novo `MolecularState` é topológico, exatamente como a entrada; nenhuma coordenada herdada do SDF de entrada é copiada ou reaproveitada.
- `state_id` e `transformation_id` são gerados como `uuid4().hex`, no mesmo padrão já usado pelo projeto (`attempt_id`, ids de staging) — nunca derivados de conteúdo químico.
- A ordem de publicação é a ordem lexicográfica do `canonical_isomeric_smiles` de cada candidato, decidida inteiramente pela plataforma (passo 16) — a plataforma nunca confia na ordem de iteração interna do RDKit.
- `candidate_rank` (Seção 19.1) é **0-indexado**, correspondendo à posição do candidato na tupla `candidates` já ordenada e truncada por `max_states` — nunca 1-indexado, decisão explícita desta especificação para eliminar qualquer ambiguidade de convenção.
- Determinismo é garantido dentro da mesma versão pinada do RDKit (`2026.3.6`), para a mesma entrada e os mesmos parâmetros. Não é garantido entre versões diferentes do RDKit — mudanças de canonicalização entre versões são um risco documentado (Seção 23), não uma regressão.

### 19.1 `StateTransformationRecord.parameters` — conteúdo obrigatório

Cada `StateTransformationRecord` publicada por este incremento DEVE registrar, como `TransformationParameter`s, no mínimo:

| Nome do parâmetro | Tipo | Conteúdo |
|---|---|---|
| `engine_name` | `str` | `"rdkit"` |
| `engine_version` | `str` | valor real de `rdBase.rdkitVersion` no momento da execução |
| `candidate_rank` | `int` | posição 0-indexada na ordenação final, após `max_states` |
| `enumerated_unique_count` | `int` | de `RDKitTautomerEnumerationResult.enumerated_unique_count` |
| `new_unique_count` | `int` | de `RDKitTautomerEnumerationResult.new_unique_count` |
| `published_count` | `int` | `len(published)` — quantos candidatos foram efetivamente publicados nesta execução |
| `truncated_by_policy` | `bool` | `published_count < new_unique_count` |
| `attempt_id` | `str` | o `id` do `ExecutionAttempt` que produziu esta transformação |

**`canonical_isomeric_smiles` NÃO DEVE ser incluído em `TransformationParameters`** (item 25 do pedido). O conteúdo autoritativo do candidato vive exclusivamente em `child_state_id → MolecularState → representation.path`, protegido pelo checksum de `MolecularRepresentationRef`. A transformação registra metadados do processo; a representação química pertence exclusivamente ao estado filho.

`StateTransformationRecord.operation` é sempre `"tautomerization"`. `producer` é `TransformationProducer(name="rdkit", version=<engine_version real>)`. `method_description` permanece `None` quando `producer` está presente (o modelo já exige pelo menos um dos dois — Seção 11, `StateTransformationRecord` inalterado).

### 19.2 Ligação `attempt → input_state_id` e `transformação → attempt_id`

- `ExecutionAttempt.input_state_id` é a ligação direta e obrigatória do attempt ao estado sobre o qual opera, presente desde `started` (Seção 10.2).
- `StateTransformationRecord.parameters["attempt_id"]` (Seção 19.1) é a ligação inversa: cada transformação publicada sabe qual attempt a produziu. `StateTransformationRecord` não ganha um campo tipado dedicado para isso neste incremento — `TransformationParameter` é aceitável no primeiro corte (decisão preservada do rascunho pré-spike, D-016-DRAFT-09); um campo tipado é matéria para reavaliação em um incremento futuro, apenas quando outro tipo de execução também precisar dessa ligação inversa.

---

## 20. Estratégia de testes obrigatória

Toda lista abaixo é normativa — cada item **DEVE** existir como teste automatizado antes que este incremento seja considerado implementado (Seção 21). Nenhuma lista aqui é uma estimativa de contagem.

### 20.1 Testes de domínio — `tests/test_execution.py`

- as dez células da matriz `schema_version × status × input_state_id` (Seção 10.3): um `ExecutionAttempt` válido para cada célula marcada "válido" constrói sem erro; a violação de cada regra levanta `pydantic.ValidationError`;
- carregar (construir a partir de um `dict` equivalente ao YAML) um attempt `1.0` real sem `input_state_id`, em cada um dos cinco status, sem erro;
- rejeitar um attempt `schema_version="1.0"` que carregue `input_state_id` não-`None`, em cada status;
- construir um attempt `schema_version="1.1"` com `input_state_id` obrigatório e preservá-lo idêntico em cada status;
- rejeitar um attempt `schema_version="1.1"` com `input_state_id=None`, em cada status;
- rejeitar um `input_state_id` malformado (viola `validate_input_id`);
- as dez células da matriz `schema_version × resíduos` (Seção 12): cada combinação produz exatamente o resultado normativo, incluindo a rejeição de resíduos não vazios em `1.0/execution_failed` e a aceitação condicional em `1.1/execution_failed`;
- `ExecutionAttemptError` com `phase="resolution"` e ambas as tuplas residuais vazias é válido;
- `ExecutionAttemptError` com `phase="resolution"` e qualquer resíduo não vazio é rejeitado;
- `ExecutionAttemptError` com `phase="execution"` aceita resíduos vazios;
- `ExecutionAttemptError` com `phase="execution"` aceita resíduos não vazios com ids válidos e únicos;
- ids residuais malformados são rejeitados por `validate_input_id`;
- ids residuais duplicados (dentro da mesma tupla) são rejeitados, não deduplicados silenciosamente;
- `resolution_failed` exige erro de resolução, `resolved=None`, `operation_ids=None` e resíduos vazios;
- `execution_failed` aceita erro de execução com resíduos, exige `resolved` presente e `operation_ids=None`;
- `started`, `resolved` e `succeeded` rejeitam qualquer `error`, inclusive um erro que carregue resíduos;
- `succeeded` continua aceitando `operation_ids=()` e nunca carrega resíduos;
- carregar um erro legado (dict sem os dois campos novos) produz tuplas vazias, sem exigir reescrita;
- round-trip (`model_dump` → `model_validate`) preserva `schema_version`, `input_state_id` e os resíduos, inclusive sua ordem quando presentes;
- `TautomerEnumerationPolicy` e `ResolvedExecutionSnapshot` continuam aceitando exclusivamente `schema_version="1.0"` — um teste que tenta `schema_version="1.1"` em qualquer um dos dois é rejeitado (guarda de regressão para a decisão da Seção 10.1).

### 20.2 Testes do adapter — `tests/test_rdkit_tautomer.py`

Todo o arquivo é protegido por `pytest.importorskip("rdkit")` no topo, refletindo a natureza opcional da dependência (Seção 6). Casos obrigatórios:

- **Teste negativo de contrato da Rota A (D-016-SPIKE-08, Seção 8.3):** instância real de `TautomerEnumerator` não expõe `SetRemoveIsotopicHs` nem `GetRemoveIsotopicHs`, verificado via `hasattr`;
- **Teste da Rota B e leitura dos parâmetros:** construir `CleanupParameters`, setar `tautomerRemoveIsotopicHs=False`, construir o enumerador, e ler de volta `params.tautomerRemoveIsotopicHs is False`, tanto antes quanto depois da construção do enumerador;
- `resolve_rdkit_engine()` retorna `engine_name="rdkit"`, `engine_version` correspondendo ao valor real de `rdBase.rdkitVersion` (formato `"20XX.0X.X"` observado), e os doze pares de `parameters` fixados na Seção 7.1, byte a byte;
- import ausente de `rdkit` (simulado por um `monkeypatch` no import) produz `RDKitUnavailableError`, nunca um `ImportError` bruto propagado;
- **Teste da acetilacetona monodeuterada:** entrada `CC(=O)C([2H])C(=O)C`; com Rota B `remove_isotopic_hs=False`, resultado tem exatamente 5 candidatos, todos retendo o átomo `[2H]` (`GetIsotope() != 0`), todos sanitizáveis, todos com fórmula `C5H8O2` idêntica à entrada;
- **Teste dos 5 candidatos sanitizáveis e 8 inválidos do caso enol-OD:** entrada `[2H]OC(C)=CC(C)=O`; a enumeração bruta produz 13 candidatos; exatamente 5 sobrevivem à sanitização e às invariantes (fórmula `C5H8O2`, isótopo preservado); exatamente 8 são descartados (fórmula excedente `C5H9O2`, falha de valência) — este teste reproduz literalmente a contagem corrigida da Seção 7.4 do relatório do spike, nunca a contagem original incorreta;
- `enumerated_unique_count` e `new_unique_count` refletem corretamente a contagem acima (`enumerated_unique_count` inclui a entrada se ela sobreviver à sanitização e estiver entre os únicos válidos; `new_unique_count` é `enumerated_unique_count` menos a entrada, se presente);
- `RDKitTautomerEnumerationResult._validate_counts` aceita `enumerated_unique_count - new_unique_count == 0` (entrada ausente do conjunto único, ou já excluída antes da contagem) e `== 1` (entrada presente e excluída uma vez); rejeita com `pydantic.ValidationError` uma diferença negativa (`new_unique_count > enumerated_unique_count`) e rejeita, também com `pydantic.ValidationError`, uma diferença maior que 1 — quatro casos de teste obrigatórios (diferença 0, diferença 1, diferença negativa, diferença > 1);
- **Status `Completed`:** guanina (`Nc1nc2[nH]cnc2c(=O)[nH]1`) com limites default → `status=Completed`, resultado retornado normalmente, sem exceção;
- **Status `MaxTautomersReached`:** guanina com `maxTautomers=2` → `IncompleteEnumerationError` com `.status == "max-tautomers-reached"` e `.tautomer_count == 2`;
- **Status `MaxTransformsReached`:** guanina com `maxTransforms=1` → `IncompleteEnumerationError` com `.status == "max-transforms-reached"`;
- **Status `Canceled`:** callback real derivado de `TautomerEnumeratorCallback` que retorna `False` após 2 invocações → `IncompleteEnumerationError` com `.status == "canceled"` e `.tautomer_count == 2`;
- SDF de uma única molécula é aceito e produz um resultado válido;
- SDF vazio (0 bytes) produz `InvalidSDFError`, nunca um `OSError` bruto propagado;
- SDF com 3 moléculas produz `MultipleMoleculesError(record_count=3)`;
- entrada com cátion amidínio carregado (`[NH2+]=CN`) preserva carga `+1` em 100% dos candidatos publicados;
- entrada com estereocentro espectador (`C[C@H](F)CC(=O)CC(C)=O`) preserva o descritor `[C@H]` em 100% dos candidatos publicados;
- a entrada não isotópica de acetilacetona (`CC(=O)CC(C)=O`) tem sua própria representação canônica excluída do resultado — o resultado nunca inclui um candidato cujo `canonical_isomeric_smiles` seja idêntico ao SMILES canônico da entrada;
- candidatos retornados são ordenados lexicograficamente por `canonical_isomeric_smiles`;
- nenhum objeto RDKit (`Mol`, exceção nativa, etc.) escapa do retorno de nenhuma função pública deste módulo — verificado por `isinstance` negativo contra os tipos do RDKit em cada campo do resultado.

### 20.3 Testes de registry — `tests/test_execution_registry.py`, `tests/test_transformation_registry.py`

- `begin_execution_attempt(..., input_state_id=...)` sempre produz `schema_version="1.1"`, nunca `"1.0"`;
- `begin_execution_attempt` rejeita `input_state_id` malformado antes de qualquer I/O (nenhum arquivo é criado);
- os quatro `mark_*` preservam `input_state_id` e `schema_version` idênticos ao attempt carregado, em cada transição válida;
- `load_execution_attempt` carrega um documento `1.0` real (sem `input_state_id` no YAML) sem erro e sem reescrever o arquivo;
- `_remove_state_transformation_best_effort` remove o arquivo de metadado de uma transformação recém-criada e nunca levanta, mesmo quando o arquivo já não existe (idempotência best-effort, mesma convenção de `_remove_state_best_effort`).

### 20.4 Testes de aplicação — `tests/test_application.py`

Usando os seams de injeção `_resolve_engine`/`_enumerate` (Seção 16) com implementações falsas (fakes), nunca RDKit real:

- ciclo completo `started → resolved → succeeded`, com N candidatos falsos publicados e `operation_ids` na ordem determinística correta;
- todo `MolecularState` publicado tem `entity_id` idêntico ao `entity_id` do `MolecularState` referenciado por `input_state_id` (Seção 15.4) — verificado explicitamente para os N estados publicados em pelo menos um caso com N > 1;
- falha de resolução antes do motor (fake `_resolve_engine` levanta `RDKitUnavailableError`) → `resolution_failed`, `error.phase="resolution"`;
- `input_state_id` inexistente → `resolution_failed` antes de qualquer chamada ao motor;
- `representation.format` diferente de `"sdf"` → `resolution_failed`;
- checksum divergente do arquivo referenciado → `resolution_failed`;
- falha do motor após resolução (fake `_enumerate` levanta `InvalidSDFError`/`MultipleMoleculesError`/`IncompleteEnumerationError`) → `execution_failed`, `error.phase="execution"`, nenhum estado/transformação criado;
- zero novos estados (fake `_enumerate` retorna `new_unique_count=0`, `candidates=()`) → sucesso, `operation_ids=()`, nenhum arquivo de estado/transformação criado;
- `max_states=None`, `max_states=1`, e `max_states=N` (menor que o total de candidatos retornados) produzem a contagem de publicação correta e `truncated_by_policy` correto em cada `StateTransformationRecord`;
- `operation_ids` é retornado na mesma ordem determinística da publicação;
- falha simulada no K-ésimo `register_state` (K entre 1 e N) aciona rollback reverso de exatamente os `K-1` pares já publicados nesta chamada, preservando qualquer registro preexistente de uma chamada anterior;
- falha simulada na K-ésima `register_state_transformation` aciona o mesmo rollback, incluindo a remoção do estado correspondente que já havia sido criado nesse mesmo par;
- falha simulada em `mark_succeeded` (após toda publicação ter ocorrido) aciona rollback de todos os N pares publicados;
- falha simulada durante o próprio rollback (um `state_id`/`transformation_id` específico não pode ser removido) resulta em `execution_failed` com esse id presente em `residual_state_ids`/`residual_operation_ids`, na ordem determinística, sem mascarar a exceção original que motivou o rollback;
- repetir a mesma chamada (mesmo `input_state_id`, mesma política) após um sucesso anterior cria um novo `ExecutionAttempt` independente, nunca sobrescreve o anterior;
- `enumerate_state_tautomers` chamado sem o extra `rdkit` instalado (sem monkeypatch, com os defaults reais) produz `resolution_failed` com uma mensagem acionável, nunca um `ImportError` não tratado — teste de empacotamento (Seção 6.2).

### 20.5 Testes de empacotamento e dependência

- instalação base (sem o extra `rdkit`) continua permitindo importar `molecular.execution`, `molecular.execution_registry`, `molecular.application`, `molecular.cli` e toda a superfície pré-existente, sem erro;
- instalação com `.[rdkit]` resolve exatamente `rdkit==2026.3.6`;
- a versão reportada pelo ambiente (`rdBase.rdkitVersion`) coincide com o `engine_version` persistido em um `ResolvedExecutionSnapshot` real de teste de integração;
- nenhum import de `rdkit` ocorre ao iniciar qualquer comando não químico da CLI pré-existente (verificado por inspeção de `sys.modules` antes/depois de invocar um comando CLI que não usa RDKit).

### 20.6 Testes químicos de referência (subconjunto obrigatório dentro de 20.2/20.4)

Já cobertos explicitamente nas listas acima: acetilacetona monodeuterada (keto-enol simples com isótopo), enol-OD (13 candidatos, 5/8), guanina (heterocíclico, três status), cátion amidínio (carga), e a molécula com estereocentro espectador. Nenhum caso adicional é exigido por esta especificação; qualquer caso adicional que a suíte científica queira incluir no futuro é uma extensão, não um requisito deste incremento.

---

## 21. Critérios de aceite objetivos

O Incremento 016 só pode ser considerado implementado se, cumulativamente:

1. a suíte de testes da baseline (Seção 3) permanecer 100% verde;
2. a entrada do attempt (`input_state_id`) for persistida e auditável desde `started`;
3. attempts `schema_version="1.0"` continuarem legíveis, sem migração ou reescrita durante a leitura;
4. RDKit estiver isolado inteiramente em `src/molecular/rdkit_tautomer.py` — nenhum outro módulo de produção importa `rdkit`;
5. a ausência do extra `rdkit` produzir `resolution_failed` em `enumerate_state_tautomers`, nunca um `ImportError` não tratado;
6. versão e os doze parâmetros efetivos forem registrados em todo `ResolvedExecutionSnapshot` desta operação, incluindo `remove_isotopic_hs=false`;
7. somente enumerações com `status=Completed` (internamente) puderem resultar em qualquer publicação;
8. resultados forem deduplicados por SMILES canônico isomérico e ordenados lexicograficamente pela plataforma, nunca pela ordem interna do RDKit;
9. `max_states` for aplicado somente depois da enumeração completa, sanitização, verificação de invariantes, deduplicação, exclusão da entrada e ordenação (Seção 14);
10. zero novos estados válidos for tratado uniformemente como sucesso válido (Seção 15.1), qualquer que seja a causa;
11. cada novo `MolecularState` publicado possuir exatamente uma `StateTransformationRecord(operation="tautomerization")` correspondente;
12. cada `StateTransformationRecord` publicada identificar o `attempt_id` que a produziu (Seção 19.1);
13. falhas controladas a partir da publicação acionarem compensação reversa, e resíduos não confirmados como removidos forem persistidos nos campos tipados (Seção 10.4/17.3);
14. a documentação de código não prometer atomicidade contra crash de processo (Seção 17.2);
15. nenhuma funcionalidade de pH/pKa/protonação/receptor/proteína/cristalografia/docking/redocking/CLI nova/GUI/scheduler/banco de dados/segundo motor entrar no diff (Seção 2.3/4.2);
16. o teste negativo de contrato da Rota A (Seção 8.3, D-016-SPIKE-08) existir e passar;
17. todos os testes obrigatórios listados na Seção 20 existirem e passarem, incluindo o caso enol-OD com a contagem corrigida 5/8 (nunca a contagem original incorreta 7/6);
18. a matriz `schema_version × status × input_state_id` (Seção 10.3) estiver coberta célula a célula por teste;
19. a matriz `phase × resíduos` (Seção 10.5) estiver coberta célula a célula por teste;
20. a matriz `schema_version × resíduos` (Seção 12) estiver coberta célula a célula por teste;
21. a matriz `status × error × resolved × operation_ids × resíduos` (Seção 12) estiver coberta linha a linha por teste;
22. o docstring de `max_states` refletir integralmente a semântica da Seção 14;
23. somente `ExecutionAttempt.schema_version` aceitar `"1.1"`; `TautomerEnumerationPolicy` e `ResolvedExecutionSnapshot` permanecerem exclusivamente `"1.0"`, com teste de regressão guardando essa restrição;
24. `git diff --check` estiver limpo (sem espaços em branco à direita, sem conflitos de merge residuais);
25. revisão adversarial independente aprovar esta especificação final antes de qualquer codificação começar;
26. cada `MolecularState` filho publicado possuir `entity_id` idêntico ao `entity_id` do `MolecularState` referenciado por `input_state_id` (Seção 15.4), verificado por teste explícito (Seção 20.4).

---

## 22. Plano de implementação por etapas

A etapa 1 abaixo está **concluída**: a revisão adversarial final aprovou esta especificação (`APPROVE WITH NON-BLOCKING NOTES`, `READY TO FREEZE: YES`), seus quatro `MINOR`, a `NOTE-1` e o esclarecimento da `NOTE-2` foram incorporados (Seção 0.4), e o documento foi formalmente congelado (Seção 28). As etapas 2 em diante são as únicas ainda não executadas — nenhuma delas foi realizada pela produção deste congelamento, e nenhuma está autorizada a pular a ordem abaixo.

1. ~~Revisão adversarial final desta especificação~~ — **concluída**: `APPROVE WITH NON-BLOCKING NOTES`, `READY TO FREEZE: YES` (Seção 0.1/0.3/0.4). Os quatro `MINOR`, a `NOTE-1` e o esclarecimento da `NOTE-2` foram incorporados nesta versão congelada.
2. Criar a feature branch a partir do HEAD oficial de `main` (`fc362f086584dd832173f8a5019b0da9ca9325f3` no momento deste congelamento; deve ser revalidado no momento real da criação da branch).
3. Implementar, nesta ordem, dentro do allowlist da Seção 4.1:
   a. `pyproject.toml` — extra `rdkit`;
   b. `src/molecular/execution.py` — schema `1.1`, `input_state_id`, resíduos, validadores estendidos; `tests/test_execution.py` correspondentes (Seção 20.1);
   c. `src/molecular/execution_registry.py` — `begin_execution_attempt` atualizado; `tests/test_execution_registry.py` correspondentes;
   d. `src/molecular/rdkit_tautomer.py` (novo) — adapter completo; `tests/test_rdkit_tautomer.py` (novo, Seção 20.2);
   e. `src/molecular/transformation_registry.py` — `_remove_state_transformation_best_effort`; `tests/test_transformation_registry.py` correspondente;
   f. `src/molecular/application.py` — `enumerate_state_tautomers`; `tests/test_application.py` correspondentes (Seção 20.4);
   g. testes de empacotamento (Seção 20.5).
4. Confirmar todos os 26 critérios de aceite da Seção 21.
5. Revisão adversarial da implementação (revisão de código, não desta especificação).
6. Merge, somente após aprovação.

Nenhuma etapa de implementação real é executada por este documento ou por sua produção.

---

## 23. Riscos e mitigações

| Risco | Severidade | Mitigação nesta especificação |
|---|---:|---|
| Chamar conjunto parcial de completo | Alta | `IncompleteEnumerationError` obrigatório antes de qualquer sanitização/publicação (Seção 15.2) |
| Confundir canônico com predominante | Alta | escopo explícito na Seção 2; nenhuma linguagem de "estabilidade" ou "predominância" é usada para o resultado |
| Mudar resultados após upgrade de RDKit | Alta | pin exato `2026.3.6`; `engine_version` persistido; teste negativo de contrato da Rota A (Seção 8.3) força revisão explícita antes de qualquer mudança de comportamento |
| Órfãos por falha parcial | Alta | staging + preflight + rollback reverso (Seção 17); resíduos tipados quando a compensação falha |
| Perder proveniência da entrada | Alta | `input_state_id` persistido desde `started` (Seção 10.2) |
| Remover marcação de hidrogênio isotópico | Alta | `remove_isotopic_hs=False` fixado por constante; teste da acetilacetona monodeuterada e do caso enol-OD (Seção 20.2/20.6) |
| Invariantes divergirem entre schemas/status | Alta | quatro matrizes cartesianas normativas, cada uma coberta célula a célula por teste (Seção 21, critérios 18–21) |
| Misturar protonação com tautomeria | Alta | exclusão explícita na Seção 2.3 |
| Estereoquímica invalidada silenciosamente | Média/alta | parâmetros efetivos persistidos; teste do estereocentro espectador (Seção 20.2) |
| Import de RDKit quebrar a CLI base | Média | extra opcional; import isolado em um único módulo; teste de empacotamento (Seção 20.5) |
| Ordem interna do RDKit não determinística | Média | ordenação explícita por SMILES, decidida pela plataforma (Seção 19) |
| Rollback falhar e ocultar resíduos | Média/alta | ids residuais tipados, com matriz normativa explícita (Seção 12) |
| Confundir descarte de candidato inválido com falha de execução | Média | Seção 15.3 torna o comportamento inequívoco: descarte nunca é `execution_failed` |
| Formatos de entrada variados criarem química implícita | Média | SDF de molécula única como única entrada aceita (Seção 9) |
| Validação em CI/Linux ainda não executada; ausência atual de pipeline de CI no repositório | Baixa (prática) / Média (formal) | **Risco aceito e mitigado explicitamente:** a decisão de rota (Rota B, Seção 8) é uma propriedade da API Python do RDKit e não deve variar por sistema operacional; a validação em Linux/CI fica pendente como verificação a executar quando este projeto adotar um pipeline de CI — hoje não existe nenhuma pasta `.github` no repositório, portanto não há gate de CI real para esta especificação silenciar. Introduzir CI **não pertence ao escopo do 016** (Seção 2.3/4.2); matéria de um incremento de infraestrutura futuro, se e quando decidido |
| Nenhum contraste comportamental observado entre `remove_isotopic_hs=True` e `=False` nos substratos testados pelo spike | Média | **Risco aceito e mitigado explicitamente:** `remove_isotopic_hs=False` é fixado por constante (D-016-SPIKE-06) independentemente de o spike não ter isolado, no tempo disponível, um substrato em que o efeito visível de `True` vs. `False` diverge — a decisão é motivada pela composição isotópica ser invariante obrigatória (Seção 2.1), não por um contraste observado. Investigação adicional para encontrar (ou descartar formalmente) tal substrato é matéria de suíte científica futura, **fora do escopo de implementação do 016** |
| Cobertura isotópica experimental restrita a ²H, sem testes de ¹³C, ¹⁵N ou ³H | Média | **Risco aceito e mitigado explicitamente:** os testes obrigatórios (Seção 20.2/20.6) cobrem deutério (²H), suficiente para validar o contrato de preservação isotópica desta especificação (Seção 15.3/19). Extensão de cobertura a outros isótopos é matéria de suíte científica futura, **não um requisito de aceite deste incremento** (Seção 21) |
| Ausência de prova de re-sincronização (ou não re-sincronização) do `CleanupParameters` após construir o enumerador | Baixa | **Risco aceito e mitigado explicitamente:** o adapter (Seção 7.2/7.4) sempre lê os valores efetivos do mesmo objeto `CleanupParameters` usado na construção, antes de qualquer mutação futura — o contrato desta especificação nunca depende de o `TautomerEnumerator` refletir mudanças posteriores no objeto original, e um novo `CleanupParameters` é construído a cada chamada de `enumerate_tautomers_rdkit` (Seção 7.2), nunca reutilizado entre chamadas. Confirmar essa hipótese por teste dedicado é matéria futura, apenas se o adapter algum dia passar a reutilizar objetos `CleanupParameters` entre chamadas |
| Disponibilidade futura do wheel exato `rdkit==2026.3.6` não garantida | Baixa/Média | **Risco aceito e mitigado explicitamente:** o pin exato (Seção 6.1) é uma decisão deliberada de reprodutibilidade (D-016-DRAFT-06), não uma garantia de disponibilidade eterna do wheel no índice do PyPI. Se o wheel deixar de estar disponível, a instalação falha de forma visível e acionável (gate de instalabilidade, Seção 6.1) — falha de infraestrutura de dependência a ser tratada operacionalmente (nova versão pinada, nova revisão adversarial), nunca uma falha silenciosa de contrato. Mirror/cache de wheels está **fora do escopo deste incremento** |

---

## 24. Distinção entre fatos observados no spike e contratos normativos deste documento

Esta distinção é preservada explicitamente, sem confundir as duas categorias em nenhuma seção anterior:

- **Fatos observados** (reproduzidos ao longo deste documento, com atribuição às Seções do relatório corrigido do spike): a ausência real de `SetRemoveIsotopicHs`/`GetRemoveIsotopicHs`; a disponibilidade e leitura confiável da Rota B; os quatro valores reais de `TautomerEnumeratorStatus`; o comportamento de `SDMolSupplier`/`ForwardSDMolSupplier` para SDF vazio; a contagem corrigida 5/8 do substrato enol-OD; a preservação isotópica em 100% dos candidatos que sanitizam, em todos os substratos testados. Nenhum desses fatos foi re-obtido por um novo experimento nesta especificação — todos vêm do relatório corrigido do spike, citado com precisão.
- **Contratos normativos** (as decisões desta especificação que vão além do que o spike observou diretamente): a exata forma dos modelos Pydantic da Seção 11; a divisão exata entre fase de resolução e fase de execução (Seção 15); o comportamento para conjuntos mistos de candidatos (Seção 15.3) — uma decisão de design desta especificação, não uma medição do spike; a estrutura das quatro matrizes (Seções 10.3, 10.5, 12); os nomes de funções, classes e exceções do adapter (Seção 7); a decisão de não persistir a contagem de candidatos descartados (Seção 15.3). Essas decisões são vinculantes para a implementação a partir da aprovação desta especificação, mas não são, em si, fatos medidos por nenhum experimento — são escolhas de arquitetura tomadas para tornar os fatos observados operacionalmente completos e testáveis.

Nenhuma inferência não verificada do spike (por exemplo, a hipótese sobre hidrogênio implícito vs. átomo isotópico explícito, ou a hipótese sobre não re-sincronização de `CleanupParameters` pós-construção — ambas registradas como tais no relatório corrigido, Seção 12) foi usada como base para qualquer decisão normativa desta especificação. Toda decisão de rota (Seção 8) se apoia exclusivamente em fatos observados por introspecção direta e execução real.

### 24.1 Nota de proveniência — "Regra 17"

O relatório corrigido do spike (Seção 6, texto herdado sem alteração da versão original desse relatório) justifica seu veredito `PASS` citando "a Regra 17 do pedido original". Essa expressão não aparece em nenhum dos quatro documentos-fonte listados na Seção 0.1 desta especificação. Ela se origina do prompt operacional original que encomendou o spike, enviado diretamente pelo usuário a uma sessão anterior desta colaboração, e que não foi preservado como um documento-fonte autônomo e citável nesta cadeia de proveniência.

Esta especificação registra essa lacuna de rastreabilidade explicitamente, sem modificar retroativamente o relatório do spike — a correção do relatório do spike é matéria fora do escopo de alteração deste documento, e nenhuma reconciliação documental deste incremento reabre esse arquivo. **Nenhuma decisão normativa desta especificação depende dessa referência**: as oito decisões `D-016-SPIKE-01` a `-08` (Seção 5) se apoiam exclusivamente em evidência bruta reproduzível — introspecção direta da API instalada, execução real dos testes químicos, e leitura linha a linha dos arquivos de evidência preservados — confirmada de forma independente tanto pela revisão adversarial do spike quanto pela revisão adversarial final desta especificação (Seção 0.1), nunca na citação de "Regra 17" como autoridade.

---

## 25. Nota sobre a limitação do script auxiliar (`status_enum_output.txt`)

A evidência bruta `status_enum_output.txt`, gerada por um script auxiliar de investigação durante o spike, termina em um `TypeError: int() argument must be a string, a bytes-like object or a real number, not 'method_descriptor'`. Esta exceção ocorre **depois** de o mesmo script já ter impresso corretamente, com sucesso, os quatro valores reais do enum `TautomerEnumeratorStatus` — `Completed=0`, `MaxTautomersReached=1`, `MaxTransformsReached=2`, `Canceled=3` — ao tentar, numa etapa de introspecção adicional e não essencial, aplicar `int()` sobre um objeto `method_descriptor` (não sobre um valor do enum).

Esta especificação registra explicitamente: essa exceção é uma **limitação do script auxiliar de investigação**, não um achado sobre a API do RDKit, e **não invalida** nenhum dos quatro valores do enum citados na Seção 5 (D-016-SPIKE-07) e usados normativamente na Seção 15.2 e na Seção 18. Os quatro estados foram, adicionalmente, cada um reproduzido de forma independente por um teste comportamental real e bem-sucedido (`limits_test_output.txt` para os dois primeiros, `cancel_test_output.txt` para `Canceled`, e a enumeração padrão bem-sucedida da guanina para `Completed`) — nenhum dos quatro valores depende, para sua validade, de o script de introspecção auxiliar ter concluído sem exceção.

---

## 26. Registro de decisões superadas e decisões vigentes

### 26.1 Decisões vigentes (herdadas sem alteração de conteúdo, apenas formalizadas nesta especificação)

Todas as dez decisões `D-016-DRAFT-01` a `D-016-DRAFT-10` do documento pré-spike (compatibilidade de schema; local de `input_state_id`; formato de entrada; formato de saída; configuração do enumerador; versão RDKit; CLI adiado; atomicidade aceita; ligação inversa ao attempt; resíduos após rollback falho) permanecem vigentes e foram incorporadas nas Seções 2, 6, 9, 10, 17 e 19 deste documento. Todas as oito decisões `D-016-SPIKE-01` a `D-016-SPIKE-08` do relatório corrigido do spike permanecem vigentes e foram formalizadas na Seção 5.

### 26.2 Decisões superadas por esta especificação

| Decisão/texto superado | Substituído por | Motivo |
|---|---|---|
| Menção condicional a uma "Rota A — setter disponível" como possibilidade real de configuração (documento pré-spike, Seção 8) | Rota B como única rota de produção, sem nenhum caminho condicional (Seção 8.2) | O spike confirmou por introspecção dupla que a Rota A não existe em `rdkit==2026.3.6` (D-016-SPIKE-01/08) |
| Contagem "13 candidatos, 7 sanitizam / 6 falham" para o substrato enol-OD (relatório original do spike, antes da reconciliação) | "13 candidatos, 5 sanitizam / 8 falham" (Seção 5, D-016-SPIKE-04; Seção 15.3; Seção 20.2/20.6) | Erro de contagem identificado pela revisão adversarial independente (MINOR-1) e corrigido na reconciliação documental do relatório do spike |
| Forma tentativa de `RDKitTautomerEnumerationResult` com um campo `status` incluindo os quatro valores do enum (documento pré-spike, Seção 5.2, explicitamente marcada como "ainda não congelada") | `RDKitTautomerEnumerationResult` sem campo `status` — todo resultado retornado implicitamente corresponde a `status=Completed`; um status diferente é sinalizado por `IncompleteEnumerationError`, nunca por um valor de campo (Seção 7.3, Seção 15) | Decisão de design desta especificação: elimina um estado inatingível do modelo (nenhuma instância de `RDKitTautomerEnumerationResult` jamais teria um `status` diferente de `"completed"`) |
| `ExecutionAttempt` com `schema_version: Literal["1.0"]` e sem `input_state_id` (Incremento 015) | `schema_version: Literal["1.0", "1.1"]`, `input_state_id: Optional[str] = None`, resíduos tipados (Seção 10, 11.1) | Necessidade de um sujeito auditável declarado desde `started`, identificada já no documento pré-spike (Seção 6.1) e agora formalizada com sua matriz cartesiana completa |
| `begin_execution_attempt` sem parâmetro `input_state_id` (Incremento 015) | `begin_execution_attempt(..., input_state_id: str)`, obrigatório (Seção 10.7) | Mesma razão acima |

Nenhuma decisão anterior foi superada por conveniência de implementação; cada superação nesta tabela tem uma causa registrada e rastreável a um documento-fonte específico.

---

## 27. Confirmação de integridade do repositório

Nenhum arquivo do repositório `molecular-platform` foi criado, modificado ou removido durante a produção deste documento. As únicas ações realizadas sobre o repositório foram leituras: `git rev-parse HEAD`, `git status`, e a leitura de conteúdo de `pyproject.toml` e dos módulos `.py` listados na Seção 0.2, todas com o único propósito de confronto factual dos contratos descritos aqui contra o código real na baseline `fc362f086584dd832173f8a5019b0da9ca9325f3`. Nenhum branch foi criado, nenhum commit foi feito, nenhum push ou merge ocorreu. Nenhuma evidência bruta do spike foi modificada. Nenhum documento anterior (`INCREMENT_016_ENGINE_RESEARCH_AND_DRAFT_SPEC_PRE_SPIKE.md`, `INCREMENT_016_RDKIT_SPIKE_REPORT_CORRECTED.md`, ou a revisão adversarial) foi sobrescrito — este é um novo arquivo, em um novo diretório (`05-final-specification/`), que não existia antes desta tarefa.

---

## 28. Estado final deste documento

- **RESEARCH COMPLETE: YES**
- **ARCHITECTURAL REVIEW COMPLETE: YES**
- **SPIKE VALIDATION: PASS**
- **SPIKE ADVERSARIAL REVIEW: APPROVE WITH NON-BLOCKING NOTES**
- **FINAL ADVERSARIAL REVIEW: APPROVE WITH NON-BLOCKING NOTES**
- **FINAL REVIEW MINORS INCORPORATED: YES**
- **FINAL SPECIFICATION FROZEN: YES**
- **READY FOR IMPLEMENTATION: YES**
- **IMPLEMENTATION STARTED: NO**

O próximo ato autorizado é a implementação de código de produção, estritamente dentro do allowlist da Seção 4.1 e seguindo o plano de implementação por etapas da Seção 22 (etapas 2 em diante), a partir da criação de uma feature branch a partir do HEAD oficial de `main` (revalidado no momento real da criação da branch). Este documento, por si só, não implementa nenhum código, não cria nenhuma branch, e não faz nenhum commit, push ou merge.
