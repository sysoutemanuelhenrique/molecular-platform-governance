# REVISÃO ADVERSARIAL CUMULATIVA — INCREMENTO 020

## Receptor Preparation Foundation — Checkpoints 1 a 4, Revisão Independente e Read-Only

**Natureza:** revisão adversarial independente, estritamente read-only, do Incremento 020 completo (Checkpoints 1–4, incluindo as correções do Checkpoint 1 e do Checkpoint 3), conforme autorizado pelas Seções 37–38 da especificação final congelada. Esta é uma revisão de código e de contratos científicos/arquiteturais — não uma solicitação de implementação, não uma autorização de PR, não uma autorização de Checkpoint futuro. Nenhum arquivo de código, teste, especificação ou documento de governança anterior foi criado, alterado, movido ou removido por este trabalho. Nenhum commit, branch, push, PR, comentário ou merge foi realizado. `main`/`origin/main` não foram tocados. `increment-009-review.txt` e `_figura_curcumina/` não foram lidos, alterados ou movidos.

---

## 1. Preflight — SHAs Remotos e Ausência de Alvo Móvel

| Item | Esperado | Observado nesta sessão | Status |
|---|---|---|---|
| Repositório | `sysoutemanuelhenrique/molecular-platform` | confirmado (remotes do `.git`) | ✅ |
| Branch | `feature/increment-020-receptor-preparation-foundation` | confirmado | ✅ |
| HEAD local da feature | `1e68a1ef9482b5f480b06d286bc4512ef3a438cc` | `1e68a1ef9482b5f480b06d286bc4512ef3a438cc` | ✅ |
| HEAD remoto da feature (`origin/feature/...`) | igual ao local | `1e68a1ef9482b5f480b06d286bc4512ef3a438cc` — **idêntico**, confirmado por leitura direta do ref remoto | ✅ |
| `main`/`origin/main` | `23a3a8e35fe16fceb22cb28ea2a777ab196c4f54` | local = remoto = `23a3a8e35fe16fceb22cb28ea2a777ab196c4f54` (inalterado) | ✅ |
| PR aberto para a branch | ausência a confirmar | **NÃO VERIFICÁVEL** — `gh api repos/sysoutemanuelhenrique/molecular-platform/pulls` retornou 403 ("GitHub access to this repository is not enabled for this session... No linked GitHub account") nesta sessão, mesma limitação já registrada em todas as revisões anteriores desta linhagem | LIMITAÇÃO DE EVIDÊNCIA (ver §10) |

**A branch não avançou em relação ao HEAD esperado — não há alvo móvel.** A revisão prosseguiu sobre `1e68a1ef9482b5f480b06d286bc4512ef3a438cc`.

### 1.1 Cadeia de commits entre `main` e `HEAD` — decodificada mecanicamente

Em vez de confiar em `git log`/`git rev-list` (indisponíveis nesta sessão — sem `device_bash`), cada objeto de commit foi lido e decodificado diretamente dos objetos git (zlib-decompress + auto-verificação SHA-1), byte a byte:

```
23a3a8e3 (main, merge PR #6 increment-019)
  └─ parent de → c160f26e  "feat: add receptor inspection foundation (checkpoint 1)"
       └─ parent de → 02aae09d  "fix: correct receptor water classification and NFC normalization" (correção CP1)
            └─ parent de → 92ff7443  "feat: add receptor selection and resolution foundation (checkpoint 2)"
                 └─ parent de → 31a0485c  "feat: add receptor application service and CLI foundation (checkpoint 3)"
                      └─ parent de → 1e68a1ef  "fix: correct malformed selection_id handling and reload chaining..." (correção CP3) = HEAD
```

**Cadeia linear confirmada, exatamente 5 commits, nenhum merge, nenhum commit extra, nenhum commit fora de ordem.** Cada relação parent→filho acima foi lida diretamente do campo `parent` do objeto de commit correspondente (não inferida), e cada SHA de commit corresponde exatamente ao HEAD já revisado pelo respectivo parecer da linhagem (`14-checkpoint-1-review` → `c160f26e`; `15-checkpoint-1-correction-review` → `02aae09d`; `16-checkpoint-2-review` → `92ff7443`; `17-checkpoint-3-review` → `31a0485c`; `18-checkpoint-3-correction-review`/`19-checkpoint-4-validation` → `1e68a1ef`).

### 1.2 Identidades de Documentos de Governança — Verificadas Byte a Byte

| Documento | Linhas esperadas | Bytes esperados | SHA-256 esperado | Observado |
|---|---|---|---|---|
| `INCREMENT_020_FINAL_SPECIFICATION.md` | 1.975 | 210.880 | `cf6cb534f9267d51e718052c7b36a2293c522bc566c99cf3bb2ef5909385a0a6` | **idêntico** |
| `INCREMENT_020_CHECKPOINT_4_VALIDATION.md` | 365 | 25.318 | `69ece589ca25ddaa1e3286b33dd1a0e76e5245043cf8f633559383389e918785` | **idêntico** |

Ambas as identidades foram recalculadas nesta sessão via `wc -l`/`wc -c`/`sha256sum` sobre os arquivos obtidos diretamente do diretório de governança do usuário, antes de qualquer leitura de conteúdo adicional — **nenhuma divergência encontrada; nenhum bloqueio necessário.**

---

## 2. Materiais Revisados

Lidos integralmente nesta sessão: a especificação final congelada; `INCREMENT_020_CHECKPOINT_1_MICRO_REVIEW.md`; `INCREMENT_020_CHECKPOINT_1_CORRECTION_MICRO_REVIEW.md`; `INCREMENT_020_CHECKPOINT_2_MICRO_REVIEW.md`; `INCREMENT_020_CHECKPOINT_4_VALIDATION.md`. Os pareceres do Checkpoint 3 (`17-checkpoint-3-review`, `18-checkpoint-3-correction-review`) já haviam sido produzidos por mim mesmo, nesta mesma linhagem de sessões, e seu conteúdo é tratado aqui como já verificado, não relido palavra a palavra — mas suas conclusões estruturais foram **reconfirmadas mecanicamente** nesta revisão (§4, §6), não apenas citadas por confiança.

Diff cumulativo `23a3a8e3..1e68a1ef` obtido por decodificação direta e recursiva de árvores git (nunca por `git diff` textual) — metodologia descrita em §3.

---

## 3. Diff Cumulativo vs. Allowlist Normativa (Seção 37) — Verificação Exaustiva

Metodologia: árvore do commit `23a3a8e3` (baseline) e árvore do commit `1e68a1ef` (HEAD) decodificadas e comparadas recursivamente — descendo apenas em subárvores cujo SHA diverge entre as duas (SHA igual ⇒ subárvore byte-idêntica, não descida); SHAs de blob comparados diretamente nas folhas. Esta é uma comparação exaustiva de **todos** os nomes presentes em cada diretório, não uma amostragem.

**Raiz:** `.gitignore` e `exp001/` — SHA idêntico nos dois commits (intocados). `pyproject.toml`, `src/`, `tests/` — SHA diverge, descida necessária.

**`src/molecular/` (24 arquivos na baseline → 30 no HEAD):**

| Arquivo | Status |
|---|---|
| `cli.py` | MODIFICADO |
| `receptor_inspection.py`, `receptor_parsing.py`, `receptor_registry.py`, `receptor_resolution.py`, `receptor_selection.py`, `receptor_service.py` | ADICIONADOS (6) |
| demais 23 arquivos | **idênticos, byte a byte** |

**`tests/` (23 arquivos na baseline → 29 no HEAD):**

| Arquivo | Status |
|---|---|
| `test_cli.py` | MODIFICADO |
| `test_receptor_inspection.py`, `test_receptor_parsing.py`, `test_receptor_registry.py`, `test_receptor_resolution.py`, `test_receptor_selection.py`, `test_receptor_service.py` | ADICIONADOS (6) |
| demais 22 arquivos | **idênticos, byte a byte** |

**`pyproject.toml`:** diff isolado e lido na íntegra — a totalidade da mudança cumulativa é exatamente três linhas, adicionando o extra opcional `structure = ["gemmi==0.7.5"]`; nenhuma outra linha do arquivo foi tocada em todo o incremento.

**Resultado: exatamente 15 arquivos alterados em todo o incremento cumulativo (`pyproject.toml` + `cli.py` + `test_cli.py` + 6 produção + 6 teste) — nenhum arquivo adicional, nenhuma omissão.** Idêntico, arquivo por arquivo, à tabela da Seção 4 do `INCREMENT_020_CHECKPOINT_4_VALIDATION.md` — **confirmado de forma independente e exaustiva**, não apenas aceito por declaração do relatório de validação.

---

## 4. Preservação dos Checkpoints 1 e 2 — Verificação por Identidade de Blob (Não Apenas por Ausência no Diff)

Em vez de apenas confirmar que `receptor_parsing.py`/`receptor_inspection.py`/`receptor_selection.py`/`receptor_resolution.py`/`receptor_registry.py` "não aparecem" em diffs posteriores, esta revisão comparou diretamente os **SHAs de blob exatos** desses cinco arquivos entre o commit em que cada um foi finalizado e o HEAD atual:

| Arquivo | SHA no commit de finalização | SHA no HEAD (`1e68a1ef`) | Idêntico? |
|---|---|---|---|
| `receptor_parsing.py` | `4898e46c...` (em `02aae09d`, correção CP1) | `4898e46c...` | ✅ **byte-idêntico** |
| `receptor_inspection.py` | `347bd917...` (em `02aae09d`, correção CP1) | `347bd917...` | ✅ **byte-idêntico** |
| `receptor_registry.py` | `c7582403...` (em `92ff7443`, CP2) | `c7582403...` | ✅ **byte-idêntico** |
| `receptor_resolution.py` | `53a822a1...` (em `92ff7443`, CP2) | `53a822a1...` | ✅ **byte-idêntico** |
| `receptor_selection.py` | `e9b15d46...` (em `92ff7443`, CP2) | `e9b15d46...` | ✅ **byte-idêntico** |

**Conclusão: os cinco módulos de domínio/parsing/registry dos Checkpoints 1–2 estão byte-idênticos desde suas respectivas correções/conclusões — nenhuma regressão estrutural é possível, porque não há diferença alguma a regredir.** Esta é uma confirmação mais forte do que a leitura de `git diff --name-only` que o próprio `INCREMENT_020_CHECKPOINT_4_VALIDATION.md` (Seção 6.1) usa — aqui a identidade foi comparada diretamente nos objetos, não inferida da ausência de um arquivo em uma lista de nomes.

Também confirmado: `pyproject.toml` tem o mesmo SHA de blob (`b8317bdf...`) em `02aae09d`, `92ff7443` e `1e68a1ef` — o pin do Gemmi não foi tocado por nenhum checkpoint posterior ao Checkpoint 1.

**Comportamental** (herdado das revisões já aprovadas desta linhagem, reconfirmado por grep direto nos blobs do HEAD, §6): classificação de água incondicional, normalização NFC, vetor golden do `inspection_id`, ausência de `setup_entities()`/métodos mutantes do Gemmi — todos presentes e intactos no HEAD atual.

---

## 5. Reconciliação Mecânica da Matriz Normativa T-001–T-137

Extração automatizada de todas as tags `# T-NNN` nos sete arquivos relevantes (os seis arquivos de teste de domínio/registry/service, mais a região de `test_cli.py`), com deduplicação por arquivo:

| Arquivo | T-ids extraídos |
|---|---|
| `tests/test_receptor_parsing.py` | T-001–012, T-095–105 (23) |
| `tests/test_receptor_inspection.py` | T-013–042, T-106–122 (47) |
| `tests/test_receptor_selection.py` | T-043–056, T-123 (15) |
| `tests/test_receptor_resolution.py` | T-057–068, T-124 (13) |
| `tests/test_receptor_registry.py` | T-069–080, T-125–130 (18) |
| `tests/test_receptor_service.py` | T-081–090, T-131–135 (15) |
| `tests/test_cli.py` (região receptor) | T-091–094, T-136–137 (6) |

**União dos sete conjuntos = exatamente `{1, 2, ..., 137}` — nenhum id faltante, nenhuma duplicata, nenhum id fora do intervalo 1–137.** Idêntico à Seção 5 do `INCREMENT_020_CHECKPOINT_4_VALIDATION.md`, confirmado por script determinístico independente, não por inspeção visual.

### 5.1 Achado NOTE — colisão numérica de tags `# T-NNN` entre incrementos dentro de `test_cli.py` (não um defeito)

A extração automatizada inicial, antes de ser restringida à "região receptor" do arquivo, encontrou as tags `# T-070` até `# T-090` **também** em `tests/test_cli.py`, fora da região de recebimento deste incremento — pertencentes a cenários normativos do **Incremento 019** (`INCREMENT_019_FINAL_SPECIFICATION.md`, Seção 25.2, testes de `conditions add`/`conditions revise`/`conditions show`, confirmado pelo comentário de cabeçalho da própria seção do arquivo: *"T-070-T-090"* referenciando o Incremento 019, não o 020). Isto **não é uma duplicata real nem um erro de rotulagem** — a numeração `T-NNN` é local a cada especificação de incremento, não um namespace global único no repositório, e o Incremento 020 reutiliza, de forma válida e já documentada em sua própria Seção 35, os mesmos números `T-069`–`T-090` para cenários completamente diferentes (`receptor_registry.py`/`receptor_service.py`). Confirmado que a região correta do Incremento 020 em `test_cli.py` é exatamente `T-091–094, T-136–137` (6 ids, isolados e sem colisão real de significado com os `T-070–090` do Incremento 019 vizinhos no mesmo arquivo).

**Classificado como NOTE, não MINOR/MAJOR:** nenhum teste está mal rotulado, nenhum cenário foi confundido na prática (os comentários de cabeçalho de cada bloco citam explicitamente a especificação de origem). O ponto de atenção é puramente de ferramental de governança: um script de reconciliação automática que faça `grep "# T-" tests/test_cli.py` sem isolar a região por incremento produzirá uma contagem inflada e aparentemente conflitante — exatamente o que esta revisão encontrou na primeira passada, antes de investigar a causa. Recomenda-se, para incrementos futuros que também toquem `test_cli.py`, delimitar a região de cada incremento com um comentário de fronteira explícito (o arquivo já faz isso parcialmente, e foi o que permitiu esta revisão resolver a aparente divergência em poucos minutos).

---

## 6. Verificações de Contrato — Confirmadas Diretamente no Código do HEAD

Todas as verificações abaixo foram feitas por leitura/grep direto dos blobs do HEAD atual (`1e68a1ef`), não por confiança no relatado pelos pareceres anteriores:

| Verificação | Método | Resultado |
|---|---|---|
| `setup_entities()`/`add_entity_types()`/`assign_subchains()`/`ensure_entities()`/`deduplicate_entities()`/métodos mutantes nunca chamados | grep por `nome(` em `receptor_parsing.py` | **Zero chamadas reais** — as únicas 3 ocorrências estão dentro do docstring que documenta a proibição | ✅ |
| Vetor golden do `inspection_id` (T-122) | grep por `73090f1a141de86e358c79f051b0245df0ca32287425935632e624d15078adf4` | presente em `test_receptor_inspection.py`, exato | ✅ |
| Química proibida (`protonat`/`pKa`/`minimiz`/`solvat`/`membrane`) como ação real | grep nos 6 módulos de produção + `cli.py` | **Zero ocorrências como ação real** — as únicas 3 ocorrências de "protonat" estão em `cli.py`, pertencem ao comando de tautomerismo do Incremento 016/017 (`operation not in ("protonation", "tautomerization")`), não ao receptor | ✅ |
| Materialização estrutural (campos `.pdb`/`.mmcif`/`output_path`/`coordinate_file`) | grep em `receptor_selection.py`/`receptor_resolution.py` | **Zero ocorrências** | ✅ |
| `ReceptorResolutionParserVersionConflictError` eliminada | grep nos 6 módulos de produção + `cli.py` (não apenas os 3 arquivos que o próprio T-089 verifica) | **Zero ocorrências em todo o código de produção relevante** — verificação mais ampla do que a do próprio T-089 | ✅ |
| Contrato de leitura da Seção 34.1 (`load_protein`/`load_resolved_receptor_selection`/`load_receptor_inspection`) | leitura direta de `receptor_service.py:743-761` e dos imports de `cli.py:99-115` | `load_receptor_inspection`/`load_receptor_selection`/`load_resolved_receptor_selection` são wrappers finos sobre o registry, expostos na camada de Service; `cli.py` importa e usa exatamente essas três funções do módulo **`receptor_service`** (não de `receptor_registry` diretamente) nas linhas 1975, 2100, 2163, 2204 | ✅ |

### 6.1 Achado MINOR — contagem de classes de erro no `INCREMENT_020_CHECKPOINT_4_VALIDATION.md` (critério 7 da checklist, Seção 10)

O `INCREMENT_020_CHECKPOINT_4_VALIDATION.md` (Seção 10, critério 7) declara: *"27 classes da Seção 30.1 confirmadas presentes."* Contagem programática e independente, feita nesta revisão, de **ambos** os lados dessa afirmação:

- **Na especificação congelada** (`INCREMENT_020_FINAL_SPECIFICATION.md`, tabela da Seção 30.1, linhas 1299–1326): exatamente **28** classes nomeadas na tabela (confirmado por script que extrai cada nome de classe entre crases de cada linha da tabela, não por contagem visual).
- **No código real** (os seis módulos de produção do incremento): exatamente **28** classes `*Error` definidas (confirmado por grep de `^class .*Error`).
- **Os dois conjuntos de 28 nomes são idênticos, item a item**, quando ordenados alfabeticamente — nenhuma classe da tabela está ausente do código, nenhuma classe do código está ausente da tabela.

**Classificação: MINOR, contra a precisão do documento de validação do Checkpoint 4 — não contra o código.** O código está **exatamente** conforme a especificação (28 de 28, correspondência perfeita); o erro é um desvio de contagem por um (27 em vez de 28) na prosa do próprio `INCREMENT_020_CHECKPOINT_4_VALIDATION.md`, que não afeta nenhuma conclusão substantiva daquele documento (a conclusão "taxonomia completa, `ReceptorResolutionParserVersionConflictError` corretamente ausente" permanece correta), mas é uma imprecisão factual verificável em um documento de governança que esta revisão foi instruída a confrontar contra o código real — exatamente o tipo de achado que essa instrução pede para não deixar passar. Não é uma falha contratual da implementação; é uma falha de precisão de um relatório anterior desta própria linhagem.

---

## 7. Preservação das Três Correções do Checkpoint 3

Já verificadas em detalhe, com reprodução empírica, por esta mesma linha de revisões (`18-checkpoint-3-correction-review`, produzido por mim nesta sessão). Nesta revisão cumulativa, reconfirmo apenas que **nada mudou desde então**, pois o HEAD é idêntico (`1e68a1ef`) e nenhum commit novo existe:

- **CP3-MAJOR-01** (selection_id malformado em `receptor resolve` → INPUT ERROR, sem traceback): a cláusula `except ValueError` permanece, corretamente posicionada após `RawChecksumMismatchError`/as classes de RESOLUTION FAILED — reconfirmado por leitura direta da função `receptor_resolve` completa em `cli.py` nesta sessão. **CONFIRMADO.**
- **CP3-MINOR-01** (colisão + recarga inválida → erro terminal logado, `__cause__` preservado): os dois blocos `try/except *RecordInvalidError: log(error); raise` em `inspect_receptor`/`resolve_receptor_selection` permanecem — reconfirmado por leitura direta de `receptor_service.py` nesta sessão. **CONFIRMADO.**
- **CP3-MINOR-02** (T-136 observa o ponto real de parsing): a instrumentação de `receptor_service_module.parse_receptor_raw` permanece em `test_cli.py`, no namespace correto. **CONFIRMADO.**

Nenhuma NOTA remanescente daquela revisão foi reaberta sem evidência nova: a NOTA-1 (catch-all `except ValueError` que mascararia um `ValidationError` hoje inalcançável de `ResolvedReceptorSelection(...)`) permanece exatamente como estava — nenhuma nova evidência de gatilho concreto foi encontrada nesta revisão cumulativa, portanto **não é reaberta como achado de severidade maior**, por instrução explícita desta tarefa.

---

## 8. Conformidade Cumulativa por Checkpoint

| Checkpoint | Allowlist (arquivos) | Cenários normativos | Verificado nesta revisão | Veredito herdado | Reabertura? |
|---|---|---|---|---|---|
| 1 | `pyproject.toml`, `receptor_parsing.py`, `receptor_inspection.py`, `receptor_registry.py` (parcial), 2 testes | T-001–042, T-095–122 (70) | Identidade de blob confirmada byte-idêntica desde a correção (`02aae09d`); comportamento (água/NFC/golden vector) confirmado por grep direto no HEAD | REQUEST CHANGES → corrigido → APPROVE | **Não reaberto** — nenhuma evidência de regressão |
| 2 | `receptor_selection.py`, `receptor_resolution.py`, `receptor_registry.py` (completo), 3 testes | T-043–080, T-123–130 (46) | Identidade de blob confirmada byte-idêntica desde `92ff7443`; T-061/T-125-130/T-129 (análises adversariais dedicadas do próprio parecer do CP2) não contradizem o código atual (arquivos intactos) | APPROVE WITH NOTES | **Não reaberto** — nenhuma evidência de regressão |
| 3 | `receptor_service.py`, `cli.py`, 2 testes | T-081–094, T-131–137 (21) | T-081-090/131-135 relidos integralmente nesta sessão — todos exercitam produção real (`inspect_receptor`/`declare_receptor_selection`/`resolve_receptor_selection` reais, nunca stand-ins), asserções concretas confirmadas | REQUEST CHANGES (CP3-MAJOR-01, CP3-MINOR-01/02) → corrigido | **Não reaberto além do já corrigido** |
| 3 (correção) | mesmos 4 arquivos | +5 itens pytest | Reconfirmado §7 | APPROVED (CORRECTIONS VERIFIED) | — |
| 4 | nenhum arquivo novo (verificação pura) | nenhum novo | Diff/allowlist/matriz/contrato 34.1 reconfirmados independentemente (§3–§6); um achado MINOR de precisão no próprio documento (§6.1) | APPROVED | **Achado novo registrado (§6.1), não eleva severidade do gate** |

---

## 9. Execução de Testes — O Que Esta Revisão Executou vs. O Que Foi Apenas Recebido

**Execução independente realizada nesta sessão: NENHUMA.** Sem `device_bash` disponível nesta sessão e sem acesso a `pip`/rede para instalar `gemmi`/`typer`/`click`/demais dependências do projeto no ambiente de sandbox desta revisão, não foi possível executar `pytest` de forma independente — a mesma limitação já registrada em toda a cadeia de pareceres desta linhagem produzidos a partir deste ambiente (Checkpoints 1–3 e suas correções, incluindo os dois pareceres que eu mesmo produzi nesta sessão para o Checkpoint 3).

Números citados nos documentos de governança, **recebidos, não reexecutados por mim**:
- `INCREMENT_020_CHECKPOINT_4_VALIDATION.md`: testes direcionados de receptor = 152 passed; cumulativo (receptor + `test_cli.py`) = 564 passed, 2 skipped; suíte completa = 1476 passed, 5 skipped, 0 failed; `git diff --check` limpo.
- Esses números são **internamente consistentes** com a progressão aritmética que esta revisão reconstruiu de forma independente a partir dos próprios diffs (não apenas aceitos por declaração): 1385 (CP1) + 16 (correção CP1, não-normativos) = 1401; + 49 (CP2) = 1450; + 21 (CP3: T-081-094/131-137) + 5 (correção CP3) = 1476. **A aritmética fecha exatamente**, confirmada por reconciliação independente dos diffs de teste, não apenas por repetição do número final.

**Observação estrutural sobre a cadeia de "execução real" desta linhagem:** o `INCREMENT_020_CHECKPOINT_4_VALIDATION.md`, apesar de se autodenominar uma validação com "execução real, nesta sessão" (Seção 8), foi produzido pelo **implementador**, não por um revisor independente — a mesma pessoa/processo que escreve o código também relatou ter executado os testes que o validam. Nenhum dos pareceres desta linhagem produzidos por um revisor genuinamente independente (Checkpoints 1, 2, 3 e suas correções, e esta própria revisão cumulativa) conseguiu, em nenhum momento, executar a suíte de forma independente neste ambiente de sandbox — todos, sem exceção, declararam explicitamente "NÃO EXECUTADO" e citaram os números do implementador como não contraditos, nunca como confirmados por execução própria. **Isto não é uma falha de nenhum parecer individual** (cada um foi honesto sobre a limitação), mas é um ponto estrutural que vale registrar explicitamente nesta revisão cumulativa: a garantia de "0 failed" em toda a linhagem do Incremento 020 repousa inteiramente sobre a honestidade do relato do implementador, nunca sobre uma reexecução verdadeiramente independente. Isto não é, por si só, motivo para REQUEST CHANGES (os números são consistentes, a aritmética fecha, e nenhuma evidência os contradiz), mas é uma lacuna de verificação a registrar como NOTE para quem avaliar o peso desta aprovação.

---

## 10. Regressões e Saída de Escopo

- **Nenhuma regressão encontrada** em nenhum dos cinco módulos preservados (§4), em nenhum banner/exit code/formato de log de atividade, em nenhum contrato científico ou de registro.
- **Nenhuma saída de escopo**: os 15 arquivos do diff cumulativo (§3) correspondem exatamente à união das allowlists dos quatro checkpoints; nenhum arquivo de um incremento futuro, nenhuma funcionalidade não autorizada (preparação química, materialização estrutural, docking) foi introduzida em nenhum ponto da cadeia.
- **Decisões já aprovadas não foram reabertas** sem evidência de violação contratual ou regressão concreta — especificamente, as NOTAS/achados MINOR já fechados ou aceitos como não-bloqueantes nos Checkpoints 1, 2 e 3 (classificação `"explicitly-selected"` não nomeada textualmente pela especificação; T-129 como prova parcial honesta; ausência de teste dedicado para `KeyboardInterrupt`/`SystemExit`; código morto em `_classify_non_polymer`; dupla reabertura Gemmi) foram revisitados apenas para confirmar que nada mudou — nenhum foi elevado de severidade, nenhum foi usado como pretexto para reabrir uma decisão de implementação já aceita.
- O único achado **novo** desta revisão cumulativa é o MINOR de precisão de contagem no próprio `INCREMENT_020_CHECKPOINT_4_VALIDATION.md` (§6.1) e a NOTE sobre colisão numérica de tags entre incrementos em `test_cli.py` (§5.1) — ambos descobertos por verificação mecânica independente, não por preferência de implementação.

---

## 11. Limitações da Evidência

- **PR aberto não verificável**: sem acesso à API do GitHub nesta sessão (`gh api` retorna 403, "GitHub access to this repository is not enabled for this session"). A ausência de PR é inferida pela ausência de qualquer referência a PR no repositório local, mas não confirmada ao vivo contra a API.
- **Execução de testes**: nenhuma execução independente realizada por este revisor (§9) — ambiente sem `device_bash`, sem `pip`/rede para as dependências do projeto. Todos os números de teste citados são recebidos do `INCREMENT_020_CHECKPOINT_4_VALIDATION.md`, não reexecutados.
- **Profundidade de releitura semântica dos Checkpoints 1–2**: esta revisão reconfirmou a **identidade de blob** (preservação estrutural exata) dos cinco módulos de domínio/parsing/registry dos Checkpoints 1–2, mas não refez, linha a linha, a análise semântica completa de todos os 116 cenários T-001–080/095–130 — essa análise já existe, em detalhe adversarial (incluindo três investigações dedicadas: T-061, T-125–130, T-129), nos pareceres já aprovados `14-checkpoint-1-review`, `15-checkpoint-1-correction-review` e `16-checkpoint-2-review`, lidos integralmente nesta sessão. Como os arquivos estão byte-idênticos desde então, não há razão contratual para refazer essa análise do zero; esta revisão a trata como válida e ainda vigente, por ausência de qualquer alteração que a invalidasse.
- **Os 21 cenários do Checkpoint 3 (T-081–094, T-131–137) foram relidos integralmente nesta sessão** (não apenas confiados à revisão anterior), dado que o Checkpoint 3 e sua correção são o objeto mais recente e menos previamente escrutinado desta cadeia.
- **Auditoria dos 14 comandos CLI (traceback/caminho absoluto/saída enganosa) do `INCREMENT_020_CHECKPOINT_4_VALIDATION.md` (Seção 9)**: não reexecutada via `CliRunner` nesta sessão; verificada indiretamente por leitura direta do código de `cli.py` (toda rota de erro usa `_sanitize_cli_error_text`, uma função de redação de caminho já herdada e aprovada do Incremento 018; nenhuma interpolação direta de `project_dir`/`raw_path` em nenhum `typer.echo` foi encontrada por grep) — consistente com, mas não uma repetição independente de, a auditoria de 14 invocações do implementador.

---

## 12. Achados Classificados

| # | Severidade | Resumo | Localização | Status |
|---|---|---|---|---|
| — | **BLOCKER** | Nenhum. | — | — |
| — | **MAJOR** | Nenhum. | — | — |
| CUML-MINOR-01 | **MINOR** | `INCREMENT_020_CHECKPOINT_4_VALIDATION.md` (critério 7, Seção 10) declara "27 classes da Seção 30.1 confirmadas presentes"; a contagem real, tanto na especificação quanto no código, é **28** (conjuntos idênticos item a item). O código está perfeitamente conforme a especificação; o erro é exclusivamente de contagem no texto do relatório de validação. | `INCREMENT_020_CHECKPOINT_4_VALIDATION.md`, Seção 10, linha do critério 7 | Achado novo desta revisão; não bloqueia nenhum gate |
| CUML-NOTE-01 | **NOTE** | Tags `# T-070`–`# T-090` em `tests/test_cli.py` pertencem ao Incremento 019 (não ao 020), coexistindo no mesmo arquivo com os números `T-069`–`090` reais do Incremento 020 (em `receptor_registry.py`/`receptor_service.py`) — namespace de numeração é por incremento, não global; nenhum teste mal rotulado, mas um ponto de fragilidade de tooling de reconciliação automática. | `tests/test_cli.py` (ao redor da linha 6744) | Observado, sem ação corretiva exigida |
| CUML-NOTE-02 (herdado) | **NOTE** | `except ValueError` em `receptor_resolve` é um catch-all pré-existente que mascararia um `ValidationError` hoje inalcançável de `ResolvedReceptorSelection(...)`, não protegida. Fora de escopo desde a correção do Checkpoint 3; sem gatilho concreto conhecido; não reaberto por falta de evidência nova. | `src/molecular/cli.py`, função `receptor_resolve` | ABERTA, herdada, não reaberta em severidade maior |
| CUML-NOTE-03 | **NOTE** | Nenhum parecer desta linhagem, incluindo os produzidos por revisores independentes, conseguiu executar a suíte de testes de forma verdadeiramente independente neste ambiente de sandbox — toda garantia de "suíte verde" repousa sobre o relato do implementador. Números consistentes e sem contradição encontrada, mas a verificação de execução real permanece, estruturalmente, não-independente em toda a linhagem até aqui. | processo de governança, não código | Limitação estrutural a registrar, não um defeito |
| CUML-NOTE-04 | **NOTE** | Ausência de PR aberto para a branch não verificável nesta sessão (sem acesso à API do GitHub). | processo | LIMITAÇÃO DE EVIDÊNCIA |

**Nenhum achado BLOCKER. Nenhum achado MAJOR. Um achado MINOR, contra a precisão de um relatório de governança anterior (não contra o código). Quatro achados NOTE, nenhum deles um defeito funcional ou uma violação de contrato normativo.**

---

## 13. Veredito

**VERDICT: APPROVE WITH NOTES**

Justificativa: o Incremento 020 completo — quatro checkpoints e duas correções (Checkpoint 1 e Checkpoint 3) — foi verificado de forma independente e, na maior parte das dimensões revisadas, **exaustivamente mecânica** (diff de árvore completo, não amostrado; identidade de blob direta, não inferida; reconciliação de matriz normativa via extração automatizada, não leitura visual; ausência de química/materialização proibida e de `setup_entities()` confirmada por grep em todos os arquivos de produção relevantes, não apenas nos arquivos que os próprios testes do incremento verificam). O diff cumulativo contra `main` corresponde exatamente aos 15 arquivos previstos pela allowlist da Seção 37; os cinco módulos de domínio/parsing/registry dos Checkpoints 1–2 estão byte-idênticos desde suas respectivas conclusões, eliminando qualquer possibilidade de regressão estrutural nesses arquivos; a matriz normativa T-001–T-137 reconcilia exatamente, sem lacunas nem duplicatas reais (após resolver uma colisão numérica aparente e inofensiva entre incrementos, §5.1); as três correções do Checkpoint 3 permanecem efetivas e intactas; o contrato de leitura da Seção 34.1 está corretamente implementado na camada de Service, não na de registry, exatamente como o Incremento 021 precisará consumi-lo.

Nenhum achado BLOCKER ou MAJOR foi encontrado nesta revisão cumulativa. Um único achado MINOR novo foi identificado — e é, notavelmente, contra a precisão do próprio relatório de validação do Checkpoint 4 (contagem de 27 em vez de 28 classes de erro), não contra o código, que está perfeitamente conforme a especificação neste ponto. As NOTAS remanescentes (catch-all pré-existente de `except ValueError`; colisão de numeração `T-NNN` entre incrementos; limitação estrutural de execução de testes nunca verdadeiramente independente nesta linhagem; PR não verificável) são todas informativas, nenhuma delas condiciona a aprovação.

---

## 14. Prontidão para o Próximo Gate

**READY FOR NEXT GATE: YES** — entendido aqui como prontidão para que o Incremento 020 seja considerado adversarialmente revisado em sua totalidade cumulativa, habilitando a decisão (fora do escopo desta revisão) sobre abertura de Pull Request. Esta revisão **não** abre, aprova a abertura, ou recomenda unilateralmente um PR — essa decisão pertence ao usuário/processo de governança, não a este parecer.

---

**Relatório produzido por:** revisão adversarial independente, read-only, sem alteração de nenhum arquivo do repositório ou da especificação congelada, sem criação de commit/branch/push/PR/comentário/merge, sem qualquer leitura/alteração/movimentação de `increment-009-review.txt` ou `_figura_curcumina/`.

```
INCREMENT 020 CUMULATIVE ADVERSARIAL REVIEW COMPLETE: YES
HEAD REVIEWED: 1e68a1ef9482b5f480b06d286bc4512ef3a438cc
SPECIFICATION SHA VERIFIED: YES
CHECKPOINT 4 VALIDATION SHA VERIFIED: YES
CUMULATIVE ALLOWLIST VERIFIED: YES
BLOCKERS: 0
MAJORS: 0
MINORS: 1
NOTES: 4
VERDICT: APPROVE WITH NOTES
READY FOR NEXT GATE: YES
PULL REQUEST CREATED: NO
MERGE PERFORMED: NO
MAIN MODIFIED: NO
CODE REPOSITORY MODIFIED: NO
```
