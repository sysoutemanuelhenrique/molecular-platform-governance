# VALIDAÇÃO CUMULATIVA — INCREMENTO 020, CHECKPOINT 4

## Receptor Preparation Foundation — Validação Cumulativa e Handoff para o 021

**Natureza:** execução, pelo implementador, do Checkpoint 4 da especificação final congelada do Incremento 020 (Seção 38). Este documento é uma **validação**, não uma autorização de nova funcionalidade nem de abertura de Pull Request. Nenhum código de produção foi alterado para produzir este documento — Checkpoint 4 não autoriza nenhum arquivo novo, apenas verificação (Seção 38, cláusula do Checkpoint 4, citada integralmente na Seção 2). Nenhum commit, push, PR ou merge foi realizado. `main`/`origin/main` não foram tocados.

---

## 1. Preflight — Identidade

| Item | Esperado | Observado | Status |
|---|---|---|---|
| Repositório | `sysoutemanuelhenrique/molecular-platform` | confirmado (remote `origin`) | ✅ |
| Branch | `feature/increment-020-receptor-preparation-foundation` | confirmado (`git branch --show-current`) | ✅ |
| HEAD local | `1e68a1ef9482b5f480b06d286bc4512ef3a438cc` | `1e68a1ef9482b5f480b06d286bc4512ef3a438cc` | ✅ |
| HEAD remoto | `1e68a1ef9482b5f480b06d286bc4512ef3a438cc` | `1e68a1ef9482b5f480b06d286bc4512ef3a438cc` (via `git fetch` + `git rev-parse origin/feature/...`) | ✅ |
| Parent direto do HEAD | `31a0485c27cba020e941d11077356fa2d1bd093b` | `31a0485c27cba020e941d11077356fa2d1bd093b` | ✅ |
| `main`/`origin/main` | `23a3a8e35fe16fceb22cb28ea2a777ab196c4f54` | `23a3a8e35fe16fceb22cb28ea2a777ab196c4f54` (local == remoto, via `git fetch origin main`) | ✅ |
| `git status --porcelain` | apenas os itens do usuário | `?? _figura_curcumina/` e `?? increment-009-review.txt` — nenhum outro item, nenhuma alteração em arquivo rastreado | ✅ |
| `increment-009-review.txt` | não tocado | 66.761 bytes, mtime `2025-09-19 12:12` (inalterado) | ✅ |
| `_figura_curcumina/` | não tocado | presente, conteúdo inalterado (`gerar_estruturas_curcumina.py`, 17.175 bytes) | ✅ |
| PR aberto para a branch | ausência a confirmar | **NÃO VERIFICÁVEL** — `gh` CLI não está instalado/configurado neste ambiente (nem via Git Bash, nem via PowerShell); nenhum acesso à API do GitHub nesta sessão | ⚠️ limitação de evidência (ver Seção 12) |

Nenhum gate de preflight divergiu. Nenhum item não rastreado do usuário foi lido, movido ou alterado.

### 1.1 Especificação final congelada

| Item | Esperado | Observado |
|---|---|---|
| Linhas | 1.975 | 1.975 |
| Bytes | 210.880 | 210.880 |
| SHA-256 | `cf6cb534f9267d51e718052c7b36a2293c522bc566c99cf3bb2ef5909385a0a6` | `cf6cb534f9267d51e718052c7b36a2293c522bc566c99cf3bb2ef5909385a0a6` |

Identidade confirmada byte a byte via `wc -l`/`wc -c`/`sha256sum`, antes de qualquer outra leitura de conteúdo. **Idêntica à identidade registrada na governança.**

---

## 2. Extração Normativa — Seção 38, Checkpoint 4

Transcrição literal da cláusula que rege este gate:

> ### Checkpoint 4 — Validação cumulativa e handoff para o 021
> - **Arquivos autorizados:** nenhum arquivo novo — apenas verificação.
> - **Contratos:** confirmar que o contrato de leitura da Seção 34.1 é exercitável de ponta a ponta, incluindo `load_receptor_inspection` por `inspection_id`.
> - **Cenários normativos:** nenhum novo — os 137 cenários anteriores são reexecutados integralmente.
> - **Suíte completa:** reexecução integral de toda a baseline do repositório (herdada + os 137 novos), confirmando 0 falhas.
> - **Restore point:** commit final deste incremento, antes de qualquer trabalho do 021.
> - **Microrrevisão obrigatória:** checklist completo da Seção 36 (Critérios de Aceite) reexecutado contra o código real.
> - Nenhuma preparação química ou estrutura derivada é produzida neste checkpoint — este é o último checkpoint do 020.

E o contrato de leitura citado (Seção 34.1):

```python
load_protein(project_dir, protein_input_id) -> ProteinInput                              # já existente
load_resolved_receptor_selection(project_dir, selection_id) -> ResolvedReceptorSelection   # Seção 25
load_receptor_inspection(project_dir, inspection_id) -> ReceptorInspectionReport           # NOVO, Seção 25
```

**Conclusão da extração: nenhuma cláusula normativa exige qualquer alteração de código neste gate.** Checkpoint 4 é, por definição, verificação pura. Nenhum trabalho novo foi inventado ou antecipado; nenhuma allowlist de arquivos é aberta.

---

## 3. Escopo Executado Neste Gate

Apenas verificação, exatamente como a cláusula exige:

1. Confronto do diff acumulado `origin/main..HEAD` contra a allowlist completa do Incremento 020 (Seção 37).
2. Reconciliação mecânica da matriz normativa completa (T-001–T-137).
3. Verificação de preservação estrutural e comportamental dos Checkpoints 1, 2 e 3 (incluindo as correções do Checkpoint 1 e do Checkpoint 3).
4. Prova de ponta a ponta do contrato de leitura da Seção 34.1.
5. Execução real, nesta sessão, de: testes direcionados de receptor, testes cumulativos, suíte completa, `git diff --check`.
6. Verificação dos sete comandos CLI quanto a traceback, caminho absoluto e saída enganosa.
7. Checklist da Seção 36 (Critérios de Aceite) reexecutado contra o código real.

**Nenhum arquivo de código foi criado, alterado ou removido para produzir esta validação.**

---

## 4. Diff Acumulado `origin/main..HEAD` vs. Allowlist Completa (Seção 37)

```
$ git diff --name-status origin/main..HEAD
M   pyproject.toml
M   src/molecular/cli.py
A   src/molecular/receptor_inspection.py
A   src/molecular/receptor_parsing.py
A   src/molecular/receptor_registry.py
A   src/molecular/receptor_resolution.py
A   src/molecular/receptor_selection.py
A   src/molecular/receptor_service.py
M   tests/test_cli.py
A   tests/test_receptor_inspection.py
A   tests/test_receptor_parsing.py
A   tests/test_receptor_registry.py
A   tests/test_receptor_resolution.py
A   tests/test_receptor_selection.py
A   tests/test_receptor_service.py
```

`git diff --stat`: **15 arquivos alterados, 6.943 inserções, 0 remoções** — nenhuma linha removida em todo o incremento, consistente com a disciplina aditiva exigida para `cli.py`/`test_cli.py`/`pyproject.toml`.

**Comparação com a allowlist cumulativa da Seção 37:**

| Categoria (Seção 37) | Arquivos esperados | Presentes no diff | Status |
|---|---|---|---|
| Modificado | `cli.py`, `pyproject.toml` | ambos, exatamente | ✅ |
| Adicionado (produção) | `receptor_inspection.py`, `receptor_parsing.py`, `receptor_registry.py`, `receptor_resolution.py`, `receptor_selection.py`, `receptor_service.py` | todos os seis, exatamente | ✅ |
| Adicionado (testes) | `test_receptor_inspection.py`, `test_receptor_parsing.py`, `test_receptor_registry.py`, `test_receptor_resolution.py`, `test_receptor_selection.py`, `test_receptor_service.py` | todos os seis, exatamente | ✅ |
| Modificado (testes) | `test_cli.py` | presente, exatamente | ✅ |

**Exatamente os 15 arquivos previstos — nenhum arquivo adicional, nenhuma omissão.** `pyproject.toml` contém exclusivamente a adição do extra `structure = ["gemmi==0.7.5"]` (confirmado por `git diff -- pyproject.toml`), sem qualquer outra alteração de dependência.

Nenhum arquivo fora desta allowlist (os demais ~28 módulos de `src/molecular/` e seus ~28 arquivos de teste correspondentes, `.gitignore`, `exp001/`) foi tocado em nenhum commit do incremento.

---

## 5. Reconciliação Mecânica da Matriz Normativa (T-001–T-137)

Contagem direta de tags `# T-NNN` em todos os seis arquivos de teste de receptor e na região nova de `test_cli.py`:

| Arquivo | T-ids únicos |
|---|---|
| `tests/test_receptor_parsing.py` | 23 (T-001–012, T-095–105) |
| `tests/test_receptor_inspection.py` | 47 (T-013–042, T-106–122) |
| `tests/test_receptor_selection.py` | 15 (T-043–056, T-123) |
| `tests/test_receptor_resolution.py` | 13 (T-057–068, T-124) |
| `tests/test_receptor_registry.py` | 18 (T-069–080, T-125–130) |
| `tests/test_receptor_service.py` | 15 (T-081–090, T-131–135) |
| `tests/test_cli.py` (região receptor) | 6 (T-091–094, T-136–137) |
| **Total** | **137** |

Verificação de contiguidade (script determinístico, comparando o conjunto ordenado de ids contra `{1..137}`): **conjunto idêntico, sem lacunas, sem duplicatas** — T-001 até T-137, exatamente.

**Reconciliação por checkpoint (Seção 38, aritmética explícita):**

| Checkpoint | Grupos | Subtotal |
|---|---|---|
| Checkpoint 1 | parsing (23) + inspection (47) | **70** |
| Checkpoint 2 | selection (15) + resolution (13) + registry (18) | **46** |
| Checkpoint 3 | service (15) + cli (6) | **21** |
| Checkpoint 4 | nenhum novo | **0** |
| **Soma** | | **70+46+21+0 = 137** |

**Idêntico à Seção 35.8/38 da especificação congelada.** Nenhuma renumeração, remoção ou consolidação em toda a linhagem.

**Itens pytest além da matriz normativa (testes extras, não numerados, documentados em cada checkpoint):** `test_receptor_registry.py` carrega 3 itens extras (`CP2-REGISTRY-EXTRA-01/02/03`, Checkpoint 2); `test_receptor_service.py` carrega 2 itens extras (correção do Checkpoint 3, colisão-então-recarga-inválida); `test_cli.py` carrega 3 itens extras na região receptor (2 casos parametrizados de id malformado + 1 fluxo válido, correção do Checkpoint 3); `test_receptor_parsing.py`/`test_receptor_inspection.py` carregam, juntos, 16 itens extras herdados do Checkpoint 1 (inclusive os 5 testes `CP1-MAJOR-01` de classificação de água e os testes de normalização NFC). Nenhum desses itens reivindica numeração normativa que não lhe pertence — todos aumentam cobertura sem alterar a contagem de 137 cenários.

---

## 6. Preservação dos Checkpoints 1, 2 e 3

### 6.1 Estrutural

```
$ git diff --name-only 02aae09d..HEAD -- src/molecular/receptor_parsing.py src/molecular/receptor_inspection.py
(vazio)
$ git diff --name-only 92ff7443..HEAD -- src/molecular/receptor_selection.py src/molecular/receptor_resolution.py src/molecular/receptor_registry.py
(vazio)
```

`receptor_parsing.py`/`receptor_inspection.py` estão byte-idênticos desde `02aae09d` (correção do Checkpoint 1, que já havia resolvido CP1-MAJOR-01 e CP1-MAJOR-02). `receptor_selection.py`/`receptor_resolution.py`/`receptor_registry.py` estão byte-idênticos desde `92ff7443` (Checkpoint 2). **Nenhum dos cinco módulos do domínio/registry dos Checkpoints 1–2 foi tocado pelo Checkpoint 3 ou por sua correção.**

### 6.2 Comportamental

| Item | Evidência | Status |
|---|---|---|
| Pin do Gemmi | `pyproject.toml`: `"gemmi==0.7.5"` | ✅ inalterado |
| Vetor golden de `inspection_id` (T-122) | `tests/test_receptor_inspection.py:857`: `assert inspection_id == "73090f1a141de86e358c79f051b0245df0ca32287425935632e624d15078adf4"` — presente e passando | ✅ |
| Classificação de água (CP1-MAJOR-01) | 5 testes dedicados presentes em `test_receptor_inspection.py`; `_classify_non_polymer`/construção de `NonPolymerComponent` em `receptor_inspection.py` dão prioridade incondicional a `HOH`/`DOD` | ✅ |
| Normalização NFC (CP1-MAJOR-02) | `_normalize_structural_strings` presente em `receptor_parsing.py`, chamada antes do retorno de `parse_receptor_raw`; testes de NFC/NFD presentes e passando | ✅ |
| `setup_entities()`/métodos mutantes do Gemmi | nenhuma invocação real em `receptor_parsing.py` (confirmado por busca textual por `.setup_entities(` etc. — zero ocorrências de chamada, apenas a proibição documentada) | ✅ |
| `ReceptorResolutionParserVersionConflictError` (eliminada no Checkpoint 2/3) | zero ocorrências em todo `src/molecular/` | ✅ |
| Correções do Checkpoint 3 (CP3-MAJOR-01, CP3-MINOR-01, CP3-MINOR-02) | presentes em `cli.py`/`receptor_service.py`, confirmadas na revisão independente `18-checkpoint-3-correction-review` (0 BLOCKERS/MAJORS/MINORS) | ✅ |

**Checkpoints 1, 2 e 3 preservados, estrutural e comportamentalmente, sem exceção.**

---

## 7. Contrato de Leitura da Seção 34.1 — Prova de Ponta a Ponta

Executado nesta sessão (não apenas lido): um `ProteinInput` real foi registrado (`register_protein`), inspecionado (`inspect_receptor`), uma seleção foi declarada (`declare_receptor_selection`) e resolvida (`resolve_receptor_selection`) — e então as três funções exatas da Seção 34.1 foram chamadas, nesta ordem, sobre o resultado real:

```
load_protein(project, "demo-protein") -> demo-protein
load_resolved_receptor_selection(project, "sel-021") -> resolved_model=1, chains=['A']
load_receptor_inspection(project, resolved.inspection_id) -> inventário completo, 1 cadeia, selection_capability=full
```

**Confirmado: o 021 pode carregar a seleção confirmada por `selection_id` e, a partir dela, o inventário completo por `inspection_id` — nunca a partir de uma cópia embutida (Seção 22.2) — exatamente como a Seção 34.1 exige.** Nenhuma das três chamadas levantou exceção; todos os valores retornados correspondem exatamente ao que foi declarado/resolvido.

---

## 8. Execução de Testes — Resultados Reais Desta Sessão

Todas as execuções abaixo foram realizadas **nesta sessão**, no checkout atual (`1e68a1ef...`), não assumidas a partir de relatos anteriores.

### 8.1 Testes direcionados de receptor (os seis arquivos de domínio/registry/service)

```
$ .\.venv\Scripts\python.exe -m pytest tests/test_receptor_parsing.py tests/test_receptor_inspection.py \
      tests/test_receptor_selection.py tests/test_receptor_resolution.py \
      tests/test_receptor_registry.py tests/test_receptor_service.py -q
152 passed in 8.60s
```

Reconciliação: 23+47+15+13+21+17 = 131 cenários normativos + 21 itens extras documentados = **152**, exatamente o resultado obtido.

### 8.2 Cumulativo (receptor + `test_cli.py` completo)

```
$ .\.venv\Scripts\python.exe -m pytest tests/test_receptor_parsing.py tests/test_receptor_inspection.py \
      tests/test_receptor_selection.py tests/test_receptor_resolution.py tests/test_receptor_registry.py \
      tests/test_receptor_service.py tests/test_cli.py -q
564 passed, 2 skipped in 42.30s
```

**Idêntico ao valor relatado pelo implementador após a correção do Checkpoint 3** — reproduzido de forma independente nesta sessão, não apenas aceito por declaração.

### 8.3 Suíte completa do repositório

```
$ .\.venv\Scripts\python.exe -m pytest -q
1476 passed, 5 skipped in 77.23s
```

**Idêntico ao valor relatado pelo implementador (1476 passed, 5 skipped, 0 failed).** Nenhuma diferença de coleta, parametrização ou resultado foi encontrada ao reexecutar de forma independente — os números permanecem válidos porque foram **reexecutados agora**, não porque foram aceitos sem verificação.

### 8.4 `git diff --check`

```
$ git diff --check origin/main..HEAD
(sem saída — exit code 0)
```

Limpo sobre todo o diff acumulado do incremento (não apenas sobre o diff do Checkpoint 3 isolado).

---

## 9. Verificação dos Sete Comandos CLI — Traceback, Caminho Absoluto, Saída Enganosa

Catorze invocações reais via `CliRunner`, cobrindo os sete comandos e, para cada um, pelo menos um caminho de erro (incluindo os dois exigidos pela correção do CP3-MAJOR-01: `selection_id` malformado em `receptor select` e em `receptor resolve`):

| Comando exercitado | Cenário | Exit | `Traceback` presente | Caminho absoluto no output |
|---|---|---|---|---|
| `protein inspect` | protein_input_id inexistente | 1 | não | não |
| `receptor inspection show` | id malformado | 1 | não | não |
| `receptor inspection show` | id hex64 válido, inexistente | 1 | não | não |
| `receptor select` | selection_id malformado | 1 | não | não |
| `receptor select` | source inexistente | 1 | não | não |
| `receptor select` | sintaxe de `--chain` inválida | 1 | não | não |
| `receptor select` | sintaxe de `--component` inválida | 1 | não | não |
| `receptor resolve` | selection_id malformado | 1 | não | não |
| `receptor resolve` | selection_id inexistente | 1 | não | não |
| `receptor show-selection` | id malformado | 1 | não | não |
| `receptor show-selection` | id inexistente | 1 | não | não |
| `receptor show-resolution` | id malformado | 1 | não | não |
| `receptor show-resolution` | id inexistente | 1 | não | não |
| `receptor list-selections` | lista vazia | 0 | não | não |

**Resultado: 14/14 limpos** — nenhum traceback, nenhum caminho absoluto do filesystem do usuário em nenhuma mensagem, nenhum banner de sucesso para uma operação que falhou. Os dois casos de `selection_id` malformado em `receptor select`/`receptor resolve` confirmam, de forma independente e nesta sessão, que a correção do CP3-MAJOR-01 está efetiva no binário atual, não apenas nos testes automatizados que a acompanham.

---

## 10. Checklist da Seção 36 (Critérios de Aceite) — Reexecutado Contra o Código Real

| # | Critério (resumo) | Verificação contra o código real nesta sessão | Status |
|---|---|---|---|
| 1 | Nenhuma química proibida introduzida | busca textual por `protonat`/`pKa`/`minimiz`/`solvat`/`membrane`/adição de hidrogênio como ação real nos seis módulos novos — zero ocorrências fora de comentários de proibição/campos de observação (`explicit_hydrogens_present`) | ✅ |
| 2 | Nenhuma materialização estrutural | nenhum campo nomeia `.pdb`/`.mmcif`/`output_path`/`coordinate_file` em `receptor_selection.py`/`receptor_resolution.py`; T-063/T-124 (introspecção de schema) presentes e passando | ✅ |
| 3 | Parser decidido, F-01/F-02 incorporados | `gemmi==0.7.5` fixado; `setup_entities()`/métodos mutantes nunca invocados (zero chamadas reais); fluxo de rejeição de compressão presente e testado (T-096–105) | ✅ |
| 4 | Quatro modelos de domínio completos | `ReceptorInspectionReport`/`ReceptorSelectionPolicy`/`ResolvedReceptorSelection` + submodelos, todos `frozen=True`/`extra="forbid"`, com validadores e serialização testados | ✅ |
| 5 | Persistência completa, três registros create-once | `register_receptor_inspection`/`register_receptor_selection`/`register_resolved_receptor_selection` presentes, todos guardados por `check_storage_identity_conflict` | ✅ |
| 6 | CLI completa, incluindo comando novo | sete comandos confirmados (`protein inspect`, `receptor inspection show` [novo], `receptor select`, `receptor resolve`, `receptor show-selection`, `receptor show-resolution`, `receptor list-selections`) | ✅ |
| 7 | Taxonomia de erros completa | 27 classes da Seção 30.1 confirmadas presentes, cada uma na camada correta; `ReceptorResolutionParserVersionConflictError` confirmada ausente (classe eliminada) | ✅ |
| 8 | Matriz normativa reconciliada mecanicamente | Seção 5 deste documento — 137 ids, contíguos, sem duplicatas | ✅ |
| 9 | Allowlist sem arquivos além dos previstos | Seção 4 deste documento — exatamente 15 arquivos | ✅ |
| 10 | Checkpoints reconciliam contra a matriz | 70+46+21+0 = 137 (Seção 5) | ✅ |
| 11 | 4 MAJORs/6 MINORs/10 NOTES da linhagem pré-implementação RESOLVED/RECONCILED | critério sobre o texto da especificação congelada em si (histórico de governança anterior à implementação), não sobre o código — especificação inalterada desde seu congelamento (hash idêntico, Seção 1.1) | ✅ (herdado, não reaberto) |
| 12 | Nenhum TBD normativo remanescente | especificação inalterada; nenhum TBD introduzido pela implementação | ✅ (herdado) |
| 13 | Sete correções mecânicas da Seção 19 (m-02 etc.) aplicadas | critério sobre o texto da especificação congelada; inalterado | ✅ (herdado) |

**Treze de treze critérios confirmados.** Os critérios 11–13 descrevem o próprio texto da especificação (resolvidos antes da implementação começar); os critérios 1–10 foram reverificados diretamente contra o código real nesta sessão, não apenas contra o texto da especificação.

---

## 11. Nota Não Bloqueante Herdada da Correção do Checkpoint 3

Conforme a `18-checkpoint-3-correction-review` (NOTA-1, §5): a cláusula `except ValueError` adicionada a `receptor_resolve` (correção do CP3-MAJOR-01) é um catch-all que, embora corretamente posicionado e não demasiado amplo para os caminhos hoje exercitados (confirmado também nesta sessão, Seção 9), também mascararia como `INPUT ERROR` um eventual `pydantic.ValidationError` não tratado vindo da construção de `ResolvedReceptorSelection(...)` dentro de `resolve_receptor_selection` — construção que permanece sem bloco `try/except` dedicado, ao contrário do equivalente já protegido em `declare_receptor_selection`.

Esta nota é **pré-existente** ao HEAD revisado neste gate, está **fora do escopo** do que foi pedido para o Checkpoint 4, e **não tem hoje gatilho concreto conhecido** (os dados que alimentam essa construção já passaram por validações anteriores do fluxo). Registrada aqui exatamente como recebida — **não ampliada para um novo requisito**, **não convertida em trabalho deste gate**, e **não bloqueante** para a decisão da Seção 13.

---

## 12. Limitações da Evidência

- **PR aberto não verificável**: `gh` CLI não está instalado neste ambiente (confirmado via Git Bash e via PowerShell); nenhum outro conector de API do GitHub está disponível nesta sessão. A ausência de PR para esta branch é assumida pela ausência de qualquer referência a PR no repositório local, mas não foi confirmada ao vivo contra a API do GitHub.
- **HEAD remoto**: confirmado via `git fetch origin feature/increment-020-receptor-preparation-foundation` seguido de `git rev-parse origin/...` nesta sessão — uma confirmação ao vivo, não apenas uma referência local desatualizada.
- Nenhuma outra limitação de evidência identificada: todos os números de teste citados neste documento foram **executados nesta sessão**, com acesso real a shell e ao `.venv` do projeto — não há, aqui, a limitação de "revisão sem `device_bash`" registrada nos pareceres anteriores desta linhagem.

---

## 13. Achados Classificados

| # | Severidade | Resumo | Status |
|---|---|---|---|
| — | — | Nenhum BLOCKER. | — |
| — | — | Nenhum MAJOR. | — |
| — | — | Nenhum MINOR. | — |
| NOTE-CP4-01 | NOTE | `except ValueError` em `receptor_resolve` é um catch-all pré-existente (herdado da correção do Checkpoint 3, NOTA-1) que mascararia um `ValidationError` hoje inalcançável de `ResolvedReceptorSelection(...)`. Fora do escopo deste gate; sem gatilho concreto conhecido. | ABERTA (não bloqueante) |
| NOTE-CP4-02 | NOTE | Ausência de PR aberto não verificável nesta sessão (sem `gh`/API do GitHub disponível). | LIMITAÇÃO DE EVIDÊNCIA |

---

## 14. Decisão e Próximo Gate

**Todos os critérios da cláusula do Checkpoint 4 (Seção 38) foram satisfeitos:**
- Nenhum arquivo novo foi necessário ou criado (verificação pura).
- O contrato de leitura da Seção 34.1 foi exercitado de ponta a ponta com sucesso.
- Os 137 cenários normativos foram reexecutados integralmente e reconciliados mecanicamente.
- A suíte completa foi reexecutada nesta sessão: **1476 passed, 5 skipped, 0 failed**.
- O checklist da Seção 36 foi reexecutado contra o código real: 13/13 critérios confirmados.

**VALIDATION VERDICT: APPROVED.**

Esta validação **não** é uma aprovação por revisão adversarial independente, e **não** declara o incremento pronto para Pull Request — ambas as decisões são de outro gate. O próximo gate é a **revisão adversarial cumulativa do Incremento 020 completo**, cobrindo os quatro checkpoints e suas correções como um todo, antes de qualquer decisão sobre abertura de PR.

---

## 15. Identidade Deste Relatório

Caminho, linhas, bytes e SHA-256 deste próprio arquivo são reportados na mensagem de encerramento desta validação, fora deste documento — mesma convenção já usada em todas as revisões anteriores desta linhagem (um arquivo não pode citar seu próprio hash sem se alterar). Nenhum documento anterior em `increments/020/` (`01-discovery/` a `18-checkpoint-3-correction-review/`) foi modificado pela produção deste relatório.

---

```
INCREMENT 020 CHECKPOINT 4 VALIDATION COMPLETE: YES
HEAD VALIDATED: 1e68a1ef9482b5f480b06d286bc4512ef3a438cc
PARENT CONFIRMED: YES
MAIN/ORIGIN-MAIN CONFIRMED UNCHANGED: YES
SPECIFICATION SHA VERIFIED: YES
CUMULATIVE ALLOWLIST VERIFIED: YES (15/15 files, exact match)
CHECKPOINT 1 PRESERVED: YES
CHECKPOINT 2 PRESERVED: YES
CHECKPOINT 3 PRESERVED: YES
CHECKPOINT 3 CORRECTIONS PRESERVED: YES
NORMATIVE MATRIX T-001-T-137 RECONCILED: YES (137/137, contiguous, no duplicates)
SECTION 34.1 READ CONTRACT PROVEN END-TO-END: YES
SECTION 36 ACCEPTANCE CRITERIA RE-VERIFIED AGAINST REAL CODE: 13/13
TARGETED RECEPTOR TESTS: 152 passed
CUMULATIVE (RECEPTOR + CLI): 564 passed, 2 skipped
FULL SUITE: 1476 passed, 5 skipped, 0 failed
GIT DIFF --CHECK: CLEAN
CLI TRACEBACK/ABSOLUTE-PATH/MISLEADING-OUTPUT AUDIT: 14/14 CLEAN
BLOCKERS: 0
MAJORS: 0
MINORS: 0
NOTES: 2
VALIDATION VERDICT: APPROVED
READY FOR ADVERSARIAL CUMULATIVE REVIEW: YES
READY FOR PULL REQUEST: NOT DECIDED HERE
PULL REQUEST CREATED: NO
MERGE PERFORMED: NO
MAIN MODIFIED: NO
REPOSITORY MODIFIED (CODE): NO
```
