# FINAL SPECIFICATION — INCREMENTO 019
## Experimental Conditions Foundation

**Natureza: especificação final, autossuficiente e congelada.**

## 1. Identity and Baseline

- **Increment:** 019 — "Experimental Conditions Foundation."
- **Document role:** Final, frozen specification — the fifteenth and terminal governance artifact in the Increment 019 lineage, promoting `13-final-specification-candidate`'s already-approved technical content into frozen, final form. **Frozen**: authorizes implementation; replaces every prior draft/candidate stage as the sole normative reference for this increment going forward.
- **Repository:** `C:\Users\Pichau\molecular-platform` (remote: `sysoutemanuelhenrique/molecular-platform`).
- **Branch:** `main`.
- **Local HEAD / `origin/main` at time of writing:** `6494e85c9cdacd9cca090bb57ce0d5454c52b096`, reconfirmed via `git fetch origin && git switch main && git pull --ff-only` immediately before writing (already up to date, clean fast-forward, zero new commits).
- **Working tree:** clean except the one pre-existing untracked file `increment-009-review.txt`. `git diff --check` clean (exit 0).
- **Baseline test status (inherited, not re-executed):** 1142 passed, 5 skipped, 0 failed. `pytest` was **not** run to produce this document.
- **Mandatory input documents, identity-verified before writing:**
  - `13-final-specification-candidate/INCREMENT_019_FINAL_SPECIFICATION_CANDIDATE.md` — 1,008 lines, 100,964 UTF-8 bytes, SHA-256 `3a246dc8f2546fe47c98135f17d24c5d4a7a0b8d7476bf74195736930dffb056`, 33 sections, 99 normative scenarios (`T-001`–`T-099`). Matched exactly. This is the **sole technical source** of this final specification — every model, field, validator, limit, identity/idempotency/revision rule, persistence design, taxonomy member, Application Service signature, CLI command, banner, exit code, activity-logging rule, future-integration guarantee, Legacy pH reconciliation, acceptance criterion, matrix row, allowlist entry, and checkpoint in this document is carried forward from `13` without alteration.
  - `14-final-review/INCREMENT_019_FINAL_SPECIFICATION_CANDIDATE_SHORT_REVIEW.md` — 250 lines, 20,747 UTF-8 bytes, SHA-256 `d57d2a24332222837dcc5df2872ee55b61429f5eaba2d675cd2440bbd537515b`, verdict `APPROVE WITH CHANGES`, 0 BLOCKERS, 0 MAJORS, 1 MINOR, 0 NOTES, `READY FOR FREEZE: YES`. Matched exactly. This is the **authorizing opinion** under which this freeze is performed; its one MINOR (three self-referential "this corrected draft" occurrences, confined to prose, with zero technical contract impact) is corrected in full within Sections 5, 25, and 30 below, exactly and only as that review authorized — the three substitutions themselves are enumerated in Section 4 of this document.
  - No divergence found in either identity. This document was authorized to proceed.
- **Authorized output of this work:** exclusively `15-final-specification/INCREMENT_019_FINAL_SPECIFICATION.md` (this file). No other file was created or modified; no prior document in the lineage (`01` through `14`) was altered.
- **No new technical contract was introduced.** This document performs the one authorized MINOR correction (three phrase substitutions, enumerated in Section 4 below) plus a documentary promotion — title, document role, nature/status framing, lineage description, and terminal state — exactly as authorized by `14`'s `READY FOR FREEZE: YES`. Every technical section (6 through 31, including the normative test matrix, the allowlist, and the checkpoint plan) is carried forward from `13` byte-for-byte, except for the three authorized phrase substitutions within Sections 5, 25, and 30.
- **No code was written, executed, or modified to produce this document. No test was written or run. No spike was executed. No branch, commit, push, PR, or merge was created.**

## 2. Nature and Status

This is the **final, frozen specification** for Increment 019. It is **based integrally on `13`**, **authorized by `14`**'s `APPROVE WITH CHANGES` verdict and its explicit `READY FOR FREEZE: YES`, and **introduces no new technical contract of any kind**. It is self-sufficient: an implementer should not need to open any prior document to understand the current contract. It is **ready for implementation**. Implementation itself **has not been performed** by this document or by any action taken while producing it — that remains a separate, later, and distinct act (opening an implementation branch and writing code), outside this document's own scope.

**Why this document exists, and what it changes relative to `13`:** `13` promoted `11`'s already-approved technical content into candidate form; `14`'s short, final, decisive review confirmed that promotion technically identical to `11` across Sections 5–31, found zero BLOCKERs and zero MAJORs, and identified exactly one MINOR — three self-referential occurrences of "this corrected draft," confined to prose inherited from Sections 5, 25, and 30, with zero technical contract impact — explicitly authorizing a freeze once that MINOR is corrected. This document performs exactly that correction (Section 4 below enumerates all three) and nothing else of substance: the remaining change is the documentary reframing from "candidate, not frozen" to "final specification, frozen," confined to Sections 1–4 and 32–33 plus the terminal status block. **Sections 5 through 31 — including the full reconciliation history, the scientific/technical contract, the normative test matrix, the allowlist, and the checkpoint plan — are carried forward from `13` unchanged, except for the three authorized phrase substitutions.**

**The findings already resolved across the lineage, carried forward intact (full detail in Section 5 below):** four original MAJORs and six original MINORs from the first draft's review (`06`), reconciled in `13`'s own Section 5.1 (inherited from `11`); one new MAJOR (`nm-1`) and two new MINORs (`nm-2`, `nm-3`) from the revised draft's short decisive review (`08`), reconciled in `13`'s own Section 5.2 (inherited from `11`); the one bookkeeping MINOR (`nm-4`) and one bookkeeping NOTE (`nm-5`) raised by `11`'s own micro-review (`10`), corrected in `11` and independently confirmed by `12`; and the one final-review MINOR (three self-referential "this corrected draft" occurrences) found by `14`, corrected in full by this document. No finding from any stage remains open, partially resolved, or reopened by this final specification.

## 3. Normative Sources

Built directly and exclusively on the full Increment 019 lineage, with `13` as the sole technical base and `14` as the authorizing opinion for this freeze:

1. `01-discovery` → `02-discovery-review` → `03-revised-discovery` → `04-revised-discovery-review`: the Discovery stage, summarized in Section 6.
2. `05-draft-specification` → `06-draft-review`: the first draft and its review (4 MAJOR, 6 MINOR, 4 NOTE), reconciled in `07`.
3. `07-revised-draft-specification` → `08-revised-draft-review`: the revised draft and its short decisive review (1 new MAJOR, 2 new MINORs — `nm-1`, `nm-2`, `nm-3`), reconciled in `09`.
4. `09-corrected-draft-specification` → `10-corrected-draft-review`: the corrected draft and its focused micro-review, which found the corrections technically sound but raised one bookkeeping MINOR (`nm-4`) and one bookkeeping NOTE (`nm-5`).
5. `11-bookkeeping-corrected-draft` → `12-bookkeeping-confirmation`: the bookkeeping-corrected draft, independently confirmed (`APPROVE`) as exact and complete, with the normative matrix unchanged and no regression introduced.
6. `13-final-specification-candidate`: the **sole technical base of this final specification**, promoting `11`'s content into candidate form with no new technical contract.
7. `14-final-review`: the **authorizing opinion** for this freeze — a short, final, decisive review confirming `13` technically identical to `11` across Sections 5–31 (99-row matrix, allowlist, checkpoints, all preserved), finding zero BLOCKERs, zero MAJORs, and exactly one MINOR (three self-referential "this corrected draft" occurrences); verdict `APPROVE WITH CHANGES`, `READY FOR FREEZE: YES`.

No other research, broad or narrow, was performed. No scope beyond what `13` already carries, confirmed correct and ready for freeze by `14`, is introduced here.

## 4. Executive Summary

This final specification carries forward, unchanged in every technical respect, the complete specification for `ScientificConditionsDeclaration` — an independent, immutable, scientist-authored declaration of pH (point or range), identified by a stable scientist-supplied id, with explicit authorship, an explicit simulation-input purpose, and explicit, create-new-record-only revision via `supersedes_id`. Every decision settled across the lineage is present and unaltered: `molecular conditions add` explicitly catches `ConditionsRecordInvalidError` (banner `"RECORD INVALID"`, exit 1), with symmetry across all four CLI commands demonstrated by an explicit four-command × six-error-type coverage table, not merely asserted; `ConditionsPersistenceError` has dedicated Application Service and CLI scenarios; `Field(max_digits=12, decimal_places=6)` is documented across all three of its native Pydantic constraints — `decimal_max_digits`, `decimal_max_places`, and `decimal_whole_digits` (the implied six-integer-digit limit) — each independently, empirically verified against the project's exact installed Pydantic 2.13.5. The normative test matrix stands at **99** scenarios (`T-001`–`T-099`), reconciled exactly as `94 + 6 − 1 = 99` (six additions — `T-019`, `T-020`, `T-065`, `T-078`, `T-079`, `T-084` — and one consolidation, `07`'s `T-093`/`T-094` combined into `T-099` with both original guarantees preserved intact). All four original MAJORs, all six original MINORs, and all four original NOTEs from the first draft's review remain resolved or reconciled; the one new MAJOR and two new MINORs from the revised draft's short decisive review remain resolved; the one bookkeeping MINOR and one bookkeeping NOTE from `11`'s own micro-review remain resolved. Option B, the seven-concept semantic boundary, the nine-field schema 1.0 scope, the acyclicity proof, the closed six-member error taxonomy, the restored future-translation guarantees, the `max_digits=12`/`decimal_places=6` limits, the 64-character CLI pre-check, the Legacy pH reconciliation, the eight-file allowlist, and the four-checkpoint plan are all preserved exactly as `13` (and `11` before it) specified them.

**The one MINOR correction performed by this document, in full, per `14`'s authorization — three self-referential phrase substitutions, no technical or scientific content touched:**

| # | Section | Before | After |
|---|---|---|---|
| 1 | §5 (introduction) | "...with some wording condensed for this self-contained corrected draft; Section 5.2..." | "...with some wording condensed for this self-contained final specification; Section 5.2..." |
| 2 | §25.1 | "...are consolidated into a single normative line in this corrected draft, `T-099`..." | "...are consolidated into a single normative line in this final specification, `T-099`..." |
| 3 | §30 (Out of Scope) | "...beyond this corrected draft specification document." | "...beyond this final specification document." |

Each substitution replaces only the self-referential label; no other word, number, id, class name, field, exception, banner, exit code, file, or checkpoint in any of the three sentences — or anywhere else in Sections 5–31 — was touched. **No new technical contract is introduced by this document.** The specification is **ready for implementation**. Implementation has **not** been performed by or during the production of this document.

## 5. Full Reconciliation of Findings

Two tables, kept distinct, per the governing task's explicit instruction not to erase prior traceability: Section 5.1 restates `07`'s own 14-row reconciliation of the first draft's review (`06`) — preserving the substance, identifiers, disposition, and traceability of all fourteen prior findings, with some wording condensed for this self-contained final specification; Section 5.2 is the new, dedicated 3-row table for this correction's own findings from `08`.

### 5.1 Historical Reconciliation (from `07`, substance and traceability preserved)

| ID | Severity | Affected section(s) (first draft) | Correction incorporated | Section (as of `07`) | Status | Test matrix impact (as of `07`) |
|---|---|---|---|---|---|---|
| MAJOR-1 | MAJOR | §16.3 | Cycle-impossibility proof rewritten as an explicit induction on creation order, grounded in the predecessor-must-exist rule (not immutability alone); branching, multi-level chains, and the "retroactive rewire" attack are each addressed explicitly | §17 "Revision and Acyclicity Proof" | RESOLVED | +5 scenarios (predecessor-existence, rewire-blocked, multi-level-chain, idempotent-revision-retry, branching retained; old weak T-042 retired) |
| MAJOR-2 | MAJOR | §18.1, §20, §21 | Closed, five-member error taxonomy (now six, see §5.2) with an explicit wrapping step in the Application Service sequence and symmetric handling in all four CLI commands; `pydantic.ValidationError` can never reach a user unwrapped | §20 "Error Taxonomy and Boundaries", §19.1, §22 | RESOLVED (one residual gap found by `08`, see §5.2 nm-1) | +12 scenarios |
| MAJOR-3 | MAJOR | §6, §9.3, §19 | Restored, verbatim in substance, every EngineParameters-translation guarantee from the Revised Discovery's own Section 20 | §21 "Future Integration" | RESOLVED | +8 static/documentary scenarios |
| MAJOR-4 | MAJOR | §10.3–10.5, §13.2–13.3, §30.1 | Concrete, justified, empirically-tested limits: `Field(max_digits=12, decimal_places=6)`, plus a 64-character CLI pre-check; redundant bool/NaN/Infinity validators removed | §14 "Decimal and Limits" | RESOLVED (one documentation/coverage gap found by `08`, see §5.2 nm-3) | +9 scenarios |
| MINOR-1 | MINOR | §26, §27 | `T-029`'s successor scenario assigned to the registry layer/Checkpoint 1 consistently across every table | §25, §27, §28 | RESOLVED | 0 net |
| MINOR-2 | MINOR | §13.4 | Citation corrected: inclusive-OR precedent vs. new exclusive-OR rule, explicitly distinguished | §13 | RESOLVED | 0 |
| MINOR-3 | MINOR | §17.4, §20.4 | Explicit empty-directory listing behavior specified | §18 | RESOLVED | +1 scenario |
| MINOR-4 | MINOR | §10.4, §13.2–13.3 | Custom bool/NaN/Infinity validators removed; native Pydantic 2.13.5 behavior confirmed empirically | §13, §14 | RESOLVED | 0 net |
| MINOR-5 | MINOR | §10.5, §24 | `-0` and exponential notation addressed explicitly in prose and scenarios | §14 | RESOLVED | +2 scenarios |
| MINOR-6 | MINOR | §21, §24 | Every error-taxonomy member given at least one scenario | §20, §25 | **Claimed RESOLVED in `07`; `08` found this false for `ConditionsPersistenceError` — now genuinely resolved by this correction, see §5.2 nm-2** | folded into MAJOR-2's count |
| NOTE-1 | NOTE | §10 | `rationale`'s naming closure reaffirmed | §10 | NO CHANGE REQUIRED | 0 |
| NOTE-2 | NOTE | §22 | `ConditionsActivityDetails`'s host module stated explicitly | §23 | NO CHANGE REQUIRED | 0 |
| NOTE-3 | NOTE | §14.1 | Reaffirmed as pre-existing, out-of-scope observation | — | NO CHANGE REQUIRED | 0 |
| NOTE-4 | NOTE | §7.1 | Domain-name/product-title distinction reaffirmed solid | §7 | NO CHANGE REQUIRED | 0 |

**Note on MINOR-6's status, carried forward honestly:** `07`'s reconciliation table asserted MINOR-6 as fully `RESOLVED`. The short decisive review (`08`) found this assertion false for one of the taxonomy's six members (`ConditionsPersistenceError` had no scenario). This correction does not retroactively edit the row above — doing so would itself erase the very traceability the governing task requires preserving — it instead treats MINOR-6 as **genuinely completed only as of this correction**, via nm-2 below.

### 5.2 New Findings from the Short Decisive Review (`08`)

| Achado | Severidade | Correção | Seções | Cenários | Status |
|---|---|---|---|---|---|
| nm-1 — `conditions add` sem `ConditionsRecordInvalidError` | MAJOR | `ConditionsRecordInvalidError` added to `add`'s handled-exception list (banner `"RECORD INVALID"`, exit 1, identical to its use in `show`/`list`/`revise`); §22.2's description of `revise`'s own handling of this error corrected to name both paths that can raise it (predecessor-load, and colliding-record-load — the latter shared with `add`); a new explicit four-command × six-error coverage table added at the top of §22, demonstrating rather than asserting symmetry | §22 (new §22.0 coverage table, §22.1, §22.2) | T-078 (new, `add`'s colliding-record path), T-084 (new, `revise`'s second — colliding-record — path, distinct from the predecessor path already covered by T-083) | RESOLVED |
| nm-2 — ausência de cenário para `ConditionsPersistenceError` | MINOR | One Application Service scenario (forced `OSError` during the write itself → `ConditionsPersistenceError`, `__cause__` preserved, no success activity entry, no partial file) and one CLI scenario (same failure surfacing through `add` as `"STORAGE ERROR"`, exit 1) added; §5.1's MINOR-6 status note above records the correction honestly rather than silently rewriting history | §25 (§25.2 Service and CLI groups) | T-065 (new, Service), T-079 (new, CLI) | RESOLVED |
| nm-3 — `decimal_whole_digits` não documentado/testado | MINOR | §14.3 now names `decimal_whole_digits` as a third, independent native constraint (`integer-part digits ≤ max_digits − decimal_places = 6`), re-verified empirically against the project's exact Pydantic 2.13.5 for every boundary value the governing task named; two new scenarios test the accepted and rejected sides of this specific boundary, distinct from `decimal_max_digits`/`decimal_max_places` | §14.3 | T-019 (new, accepted boundary), T-020 (new, rejected boundary) | RESOLVED |

**Cumulative total across the full lineage: 17 findings (4 original MAJOR + 1 new MAJOR, 6 original MINOR + 2 new MINOR, 4 NOTE), all RESOLVED or NO CHANGE REQUIRED. Zero BLOCKERs at any stage. Zero findings left open.**

## 6. Scientific Problem

Unchanged from the entire lineage: the platform has no way for a scientist to declare, as an independent, immutable fact, the condition (today: pH) a future simulation input is intended to be interpreted under — separately from any specific execution, and separately from a historical, post-fact parameter that might already be attached to an unrelated transformation record (Section 9). This correction does not change the problem statement or the proposed solution's scope; it corrects three precision/completeness defects in how that solution's contract was specified.

## 7. Normative Terminology

### 7.1 Domain name (unchanged, reaffirmed per NOTE-4)

`ScientificConditionsDeclaration` remains the frozen class name. The increment's title, "Experimental Conditions Foundation," remains unchanged — the title names the subject area for governance purposes, while the class name foregrounds "declaration" and "scientific" specifically to avoid the measured-value connotation risk the lineage's review rounds (m-6, then NOTE-4, then `08`'s own independent confirmation) have each found adequately addressed. No further action on naming is needed.

### 7.2 Core terms

- **`ScientificConditionsDeclaration`** — the record type specified here.
- **`PhDeclaration`** — the value object holding either a point or a range pH value, mutually exclusive.
- **`resolved_conditions`** — reserved for a future increment: the immutable snapshot a conditions-consuming execution persists of the declaration it actually used. Not modeled here.
- **`EngineParameters`** — the already-existing concept (`ResolvedExecutionSnapshot.parameters` today) of what is concretely sent to a chemistry engine. Not modified here.
- **`TransformationParameter`** — the already-existing, already-tested mechanism (`transformation.py`) for attaching a named, scalar historical parameter to a `StateTransformationRecord`. Not modified here.
- **`ExecutionResult`** — the already-existing outcome of an execution (`ExecutionAttempt.status`/`resolved`/`error`). Not modified here.
- **`Evidence`** — the already-existing, narrow sense of provenance (`TransformationProducer`, `method_description`). Not modified here.
- **Supersession** — creating a new `ScientificConditionsDeclaration` whose `supersedes_id` names the record it revises.

The binding boundary, unchanged:

```
Evidence ≠ ScientificConditionsDeclaration ≠ resolved_conditions ≠ ScientificPolicy ≠ EngineParameters ≠ TransformationParameter ≠ ExecutionResult
```

## 8. Semantic Boundaries

Unchanged: `ScientificConditionsDeclaration` is not a `MolecularState` (the latter is a chemical realization, the former a stated intent about future conditions); not `TransformationParameter` (Section 9); not `Evidence` (its optional `rationale` is explanatory text only, Section 13.5); not `ScientificPolicy`, `EngineParameters`, or `ExecutionResult`. pKa remains explicitly out of schema 1.0. Four pH absence/presence states remain named explicitly: *not declared*, *declared as unknown* (not representable), *not applicable* (not representable), and *informed* — schema 1.0 only ever represents the last.

## 9. Legacy pH in TransformationParameter

Unchanged in substance, restated in full for self-sufficiency.

### 9.1 Confirmed current behavior (unchanged, not touched by this increment)

`src/molecular/transformation.py` permits a `StateTransformationRecord` (`operation: Literal["protonation", "tautomerization"]`) to carry `TransformationParameter(name, value)` entries where `value: str | int | float | bool`. `tests/test_transformation.py`'s `ibuprofen-deprotonation-001` fixture (`operation="protonation"`) carries both `TransformationParameter(name="ph", value=7.4)` and `TransformationParameter(name="pH", value=7.0)` simultaneously, by design (parameter names are case-sensitive, not storage identities). This behavior, this fixture, and this test remain **completely untouched** by Increment 019.

### 9.2 Four-layer boundary (binding)

1. **`ScientificConditionsDeclaration`** — independent, scientist-authored, pre-execution.
2. **`resolved_conditions`** — future: an immutable snapshot of the declaration actually used.
3. **`EngineParameters`** — already-existing: the concrete, auditable translation handed to a chemistry engine.
4. **`TransformationParameter`** — already-existing: a historical, post-fact, operation-scoped parameter, possibly describing a transformation performed entirely outside the platform.

### 9.3 Binding normative declarations

- `TransformationParameter(name="pH"/"ph", ...)` is not, and does not create, a `ScientificConditionsDeclaration`.
- No historical parameter automatically creates, implies, or stands in for a formal declaration.
- No declaration will be inferred, retroactively or otherwise, from any `StateTransformationRecord`, including `ibuprofen-deprotonation-001`.
- Existing records are not migrated, not deleted, not rewritten.
- `register_derived_state`/"state derive" continue registering transformations **post-fact**, exactly as today, with no requirement that a declaration exist first.
- A pH value in a `TransformationParameter` preserves only the context informed at that record's creation — nothing more.
- Presence of a pH-named parameter does not prove any engine consumed a formal declaration.
- A post-fact transformation may record pH even when no declaration exists anywhere in the project.
- A **future**, platform-mediated, conditions-consuming execution must start from an **explicitly selected** declaration — never inferred, defaulted, or most-recent.
- Selection resolves into an immutable `resolved_conditions` snapshot.
- `EngineParameters` derived from that snapshot must be derived **traceably** (full guarantees in Section 21).
- A future `TransformationParameter` produced by such an execution must be **consistent** with its `resolved_conditions` snapshot, and identifiable as effective or derived/reported.
- Divergence between declaration, snapshot, engine parameters, and published parameter must never be silently hidden.
- No bidirectional synchronization, no retroactive update, in either direction.
- `TransformationParameter` is never authoritative for reconstructing a declaration that does not exist.

### 9.4 Conceptual flow (future, platform-mediated path only — not built by this increment)

```
ScientificConditionsDeclaration
  → explicit selection (never automatic)
  → resolved_conditions (immutable snapshot)
  → EngineParameters (traceable translation)
  → execution
  → ExecutionResult
  → StateTransformationRecord / TransformationParameter, when applicable
```

Compatibility with this historical path never authorizes any new ad hoc pH-recording mechanism.

## 10. Scientific Scope of Schema 1.0

Unchanged:

1. A stable, scientist-supplied identity (`id`).
2. A schema version (`schema_version`).
3. pH, point **or** range, mutually exclusive.
4. Authorship (`declared_by`).
5. The instant of declaration (`declared_at`).
6. An explicit purpose (`purpose: Literal["simulation_input"]`).
7. An optional human-facing label (`label`).
8. An optional scientific justification/source note (`rationale`).
9. An optional reference to a superseded declaration (`supersedes_id`).

No unit is stored for pH; no universal 0–14 range is imposed, structurally or otherwise (Section 14.6); no pH convention or scale is assumed. A declared pH range never defines a step, grid, sampling strategy, discretization scheme, microstate count, or publication limit.

## 11. Deferred and Rejected Fields

Unchanged; remains the sole, correctly cross-referenced home for every deferred/rejected field.

### 11.1 Rejected from the central schema

`Evidence` (generic/structured), arbitrary/generic `metadata`, execution results, automatic recommendations, inferred values, and magic markers such as `"unknown"`, `"default"`, `"neutral"`, or `"not applicable"` are rejected outright.

### 11.2 Deferred until a real consumer exists

Solvent/medium, ionic strength, pressure, concentration, physical state, and computed chemical properties (e.g. pKa) are deferred, not rejected.

### 11.3 Temperature — future compatibility

Temperature is **not** part of schema 1.0, with no exception and no partial representation. Reintroduction is conditioned on a real consumer first defining: whether it is a measurement or simulation temperature; the original unit; the original value, preserved exactly; a normalized Kelvin representation, derived traceably; and the engine-compatibility/operational effect. Temperature must not be added merely because it might be useful. Any future reintroduction requires a separate, explicit scientific decision, producing its own `schema_version` bump (Section 13.1).

### 11.4 Platform-level exclusions

No capability abstraction, no workflow/pipeline, no receptor modeling, no docking modeling, no `Pose` modeling, no scheduler, no database, no GUI, no user/identity system, no ontology, no RDF, no JSON-LD. Full restatement in Section 30.

## 12. Domain Model Overview

Three new Pydantic classes and one schema-version `Literal`, all in a new module `src/molecular/conditions.py`, with zero filesystem, CLI, or engine imports:

```
ScientificConditionsDeclarationSchemaVersion = Literal["1.0"]

PhPoint              — a single finite, bounded-precision Decimal pH value
PhRange              — a {minimum, maximum} bounded-precision Decimal pair, minimum <= maximum
PhDeclaration        — wraps exactly one of PhPoint or PhRange
ScientificConditionsDeclaration — the full record: identity, PhDeclaration,
                                   purpose, authorship, timestamp, optional
                                   label/rationale/supersedes_id
```

No status machine exists on `ScientificConditionsDeclaration`: a declaration is a single, immutable fact, written once or not at all.

## 13. Pydantic Models and Validators

Unchanged from `07` — no finding from `08` touches the model code itself; `decimal_whole_digits` (nm-3) is a behavior *of* the already-specified `Field(max_digits=12, decimal_places=6)` constraint, not a new field or validator.

All classes use `model_config = ConfigDict(frozen=True, extra="forbid")`. All raise standard Pydantic `ValidationError` on any violation; the Application Service layer (Section 19) wraps that `ValidationError` into a typed application exception (Section 20).

### 13.1 `ScientificConditionsDeclarationSchemaVersion`

```python
ScientificConditionsDeclarationSchemaVersion = Literal["1.0"]
```

### 13.2 `PhPoint`

```python
class PhPoint(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    value: Decimal = Field(max_digits=12, decimal_places=6)
```

No custom validator is needed: boolean, `NaN`, and infinite values are rejected natively by Pydantic 2.13.5 (confirmed empirically, Section 14.3); excessive total digits, excessive decimal places, excessive integer-part digits, and pathological exponents are all rejected by this single `Field` constraint, via three distinct native error types (`decimal_max_digits`, `decimal_max_places`, `decimal_whole_digits`), named and distinguished in full in Section 14.

### 13.3 `PhRange`

```python
class PhRange(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    minimum: Decimal = Field(max_digits=12, decimal_places=6)
    maximum: Decimal = Field(max_digits=12, decimal_places=6)

    @model_validator(mode="after")
    def _validate_bounds(self) -> "PhRange":
        if self.minimum > self.maximum:
            raise ValueError(
                f"minimum ({self.minimum}) must be <= maximum ({self.maximum})"
            )
        return self
```

### 13.4 `PhDeclaration`

```python
class PhDeclaration(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    point: Optional[PhPoint] = None
    range: Optional[PhRange] = None

    @model_validator(mode="after")
    def _validate_exactly_one_form(self) -> "PhDeclaration":
        if (self.point is None) == (self.range is None):
            raise ValueError(
                "exactly one of 'point' or 'range' must be provided, never both, never neither"
            )
        return self
```

The codebase already has an established architectural precedent for a presence-based cross-field validator on a Pydantic model (`transformation.py`'s `StateTransformationRecord`, whose "either `producer` or `method_description` required" rule is an **inclusive-OR** — both may be present together). `PhDeclaration` follows that same general *style* of cross-field validation but introduces a **new, stricter, Increment-019-specific rule**: exclusive-OR, since a pH declaration cannot simultaneously be a point and a range. The two validators are not the same rule; only the general technique is shared.

### 13.5 `ScientificConditionsDeclaration`

```python
class ScientificConditionsDeclaration(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    schema_version: ScientificConditionsDeclarationSchemaVersion
    id: str = Field(min_length=1)
    ph: PhDeclaration
    purpose: Literal["simulation_input"]
    declared_by: str = Field(min_length=1, max_length=200)
    label: Optional[str] = Field(default=None, max_length=200)
    rationale: Optional[str] = Field(default=None, max_length=4000)
    supersedes_id: Optional[str] = None
    declared_at: datetime

    @field_validator("id")
    @classmethod
    def _validate_id_format(cls, value: str) -> str:
        return validate_input_id(value)

    @field_validator("supersedes_id")
    @classmethod
    def _validate_supersedes_id_format(cls, value: Optional[str]) -> Optional[str]:
        if value is None:
            return value
        return validate_input_id(value)

    @field_validator("declared_by")
    @classmethod
    def _validate_declared_by_not_blank(cls, value: str) -> str:
        if not value.strip():
            raise ValueError("declared_by must not be blank")
        return value

    @field_validator("label")
    @classmethod
    def _validate_label_not_blank(cls, value: Optional[str]) -> Optional[str]:
        if value is not None and not value.strip():
            raise ValueError("label must not be blank")
        return value

    @field_validator("rationale")
    @classmethod
    def _validate_rationale_not_blank(cls, value: Optional[str]) -> Optional[str]:
        if value is not None and not value.strip():
            raise ValueError("rationale must not be blank")
        return value

    @field_validator("declared_at")
    @classmethod
    def _validate_declared_at_timezone_aware(cls, value: datetime) -> datetime:
        if value.tzinfo is None:
            raise ValueError("declared_at must be timezone-aware")
        return value

    @model_validator(mode="after")
    def _validate_no_self_supersession(self) -> "ScientificConditionsDeclaration":
        if self.supersedes_id is not None and self.supersedes_id == self.id:
            raise ValueError("a declaration must not supersede itself")
        return self
```

Field order (`schema_version`, `id`, `ph`, `purpose`, `declared_by`, `label`, `rationale`, `supersedes_id`, `declared_at`) places the timestamp last, mirroring `ExecutionAttempt`.

### 13.6 Field-by-field obligation summary

| Field | Type | Required | Default | Notes |
|---|---|---|---|---|
| `schema_version` | `Literal["1.0"]` | Yes | none | No default — explicit on every construction. |
| `id` | `str` | Yes | none | `validate_input_id`; casefold-unique at the registry layer (Section 15). |
| `ph` | `PhDeclaration` | Yes | none | Exactly one of point/range; both bounded per Section 14. |
| `purpose` | `Literal["simulation_input"]` | Yes | none at domain layer | CLI may default the flag to `"simulation_input"` (Section 22) — a structural, non-scientific default. |
| `declared_by` | `str` | Yes | none | Non-blank, ≤ 200 chars. |
| `label` | `Optional[str]` | No | `None` | Non-blank when present, ≤ 200 chars. |
| `rationale` | `Optional[str]` | No | `None` | Non-blank when present, ≤ 4000 chars; explanatory text only. |
| `supersedes_id` | `Optional[str]` | No | `None` | `validate_input_id` when present; must not equal `id`. |
| `declared_at` | `datetime` | Yes | none (system-generated, Section 19) | Timezone-aware; persisted in UTC. |

### 13.7 Serialization

Persisted via `yaml.safe_dump(model.model_dump(mode="json"), sort_keys=False)`. `Decimal` fields serialize per Pydantic v2's confirmed default JSON-mode string encoding (Section 14.3); `datetime` fields serialize to ISO-8601 with explicit UTC offset.

## 14. Decimal and Limits

Unchanged in its chosen values (`max_digits=12`, `decimal_places=6`, 64-character CLI pre-check) — this section is extended, not redesigned, to resolve **nm-3**.

### 14.1 The distinction this section draws

1. **Computational/structural limits** (this section): bounds that exist purely to prevent disproportionate storage, memory, or processing cost from a pathological input. They carry **no** scientific meaning.
2. **Scientific validity**: whether a given pH value is meaningful for a given solvent/context. Schema 1.0 makes **no** claim about this.
3. **The usual aqueous pH range (0–14)**: a convention, not a constraint, and **not equivalent to** the structural limits below in any way — a value can violate the structural limit while being well within 0–14 (e.g. `"1.1234567"`, 7 decimal places), and a value can satisfy the structural limit while being far outside 0–14 (e.g. `"-999999"`). The two are orthogonal.

### 14.2 The chosen limits

- **Raw CLI string length** (before any `Decimal` conversion is attempted): **64 characters**, for each of `--ph`, `--ph-min`, `--ph-max` independently.
- **`Decimal` field constraint**: `Field(max_digits=12, decimal_places=6)` on `PhPoint.value` and on both `PhRange.minimum`/`PhRange.maximum`.

### 14.3 Empirical verification, including the third native constraint (`decimal_whole_digits`, resolves nm-3)

Direct testing against the project's installed Pydantic **2.13.5** (re-confirmed for this correction; the short decisive review's own testing used the adjacent patch 2.13.3 for an explicitly-declared, narrow environmental reason, and found identical results) confirms `Field(max_digits=12, decimal_places=6)` enforces **three distinct, independent native constraints**, not one:

1. **`decimal_max_digits`** — the value's total number of significant digits must not exceed 12.
2. **`decimal_max_places`** — the value must not have more than 6 digits after the decimal point.
3. **`decimal_whole_digits`** — the value's integer-part digit count must not exceed `max_digits − decimal_places = 6`. **This constraint applies independently of constraint 1** — a value can satisfy the total-digit-count limit (≤ 12) and still violate this one, if too many of those digits fall before the decimal point.

This third constraint was implicit in the original prose (Section 14.2's own phrasing, "up to six more digits before the decimal point," already described it correctly) but was never named, isolated, or tested as its own distinct boundary. It is named and tested explicitly now.

**Full boundary verification, re-run for this correction directly against 2.13.5:**

| Input | Result | Native error type |
|---|---|---|
| `"1"`, `"1.0"`, `"1.00"` | Accepted, each preserved exactly as typed | — |
| `"-0"` | Accepted; compares equal to `Decimal("0")`; serializes as the literal string `"-0"` | — |
| `"999999"` (6 integer digits, 0 decimal) | **Accepted** — exactly at the integer-digit boundary | — |
| `"999999.999999"` (6 integer + 6 decimal = 12 total) | **Accepted** — exactly at both boundaries simultaneously | — |
| `"1000000"` (7 integer digits) | **Rejected** | `decimal_whole_digits` |
| `"-1000000"` (7 integer digits, negative — sign does not change the digit count) | **Rejected** | `decimal_whole_digits` |
| `"1234567"` (7 integer digits, 0 decimal — only 7 total digits, well within the 12-digit total limit) | **Rejected** — confirms constraint 3 is independent of constraint 1 | `decimal_whole_digits` |
| `"1234567.123456"` (7 integer + 6 decimal = 13 total digits) | **Rejected** — this one also exceeds the *total* digit limit | `decimal_max_digits` |
| `"1.1234567"` (7 decimal places) | **Rejected** | `decimal_max_places` |
| `"1E+6"` (= `1000000`, exponential notation reducing to 7 integer digits) | **Rejected** — confirms an exponent that expands into too many integer-part digits is caught by the same constraint as a plain literal | `decimal_whole_digits` |
| `"9.9E+5"` (= `990000`, 6 integer digits) | **Accepted** | — |
| `"1.23E+2"` (= `123`, 3 digits) | Accepted | — |
| `"1E+50"`, `"1E-50"` | Rejected | `decimal_max_digits` |
| A 200,000-digit pathological string | Rejected | `decimal_max_digits` |
| `NaN`, `Infinity`, `-Infinity` | Rejected natively | `finite_number` |
| `True`, `False` | Rejected natively | `decimal_type` |
| Leading/trailing whitespace (`" 7.4 "`) | Accepted, silently trimmed | — |
| `Decimal("1") == Decimal("1.0") == Decimal("1.00")` | `True` | — |

**This closes the exact task requirement**: `"999999"` and `"999999.999999"` are confirmed-valid boundaries; `"1000000"` and `"-1000000"` are confirmed-rejected via `decimal_whole_digits` specifically (not `decimal_max_digits`); a 13-total-digit value is rejected via `decimal_max_digits`; a 7-decimal-place value is rejected via `decimal_max_places`; an exponent that expands past the integer-digit limit (`"1E+6"`) is rejected via `decimal_whole_digits`. No new diagnostic beyond this single confirmatory pass was needed — every boundary the governing task named is now a directly-observed fact against the project's own exact Pydantic version, not an inference from adjacent test cases.

**Whitespace** (` 7.4 `): accepted, silently trimmed by Pydantic's own native `Decimal` coercion. This remains intentional, unlike `label`/`rationale` (where whitespace-only input is semantically empty and must be rejected) — incidental whitespace around a numeric literal carries no competing semantic meaning.

### 14.4 How the native error is encapsulated and presented

Any of the three native constraint violations above — `decimal_max_digits`, `decimal_max_places`, or `decimal_whole_digits` — surfaces as an ordinary `pydantic.ValidationError` at construction time, which the Application Service wraps uniformly into `ConditionsValidationError` (Section 19.1 step 4), exactly like any other construction-time validation failure (an overlong `label`, a blank `rationale`, an invalid `purpose`). **The CLI never needs to name, distinguish, or expose which of the three specific native error types occurred** — all three present identically to the user as `"INPUT ERROR"`, exit 1 (Section 22.1), since from the caller's perspective they are all simply "the declared pH value's representation is too large for this platform to accept," regardless of which specific digit count was exceeded. The internal Pydantic error-type string (`decimal_whole_digits`, etc.) is diagnostic detail useful to a developer reading a stack trace in a test failure; it is never contractually required to appear in the CLI's user-facing banner text.

### 14.5 Canonical representation is bounded

Unchanged: because every pH-bearing field carries the same three-constraint `max_digits=12, decimal_places=6` limit, the maximum possible length of any valid pH value's canonical serialized string is fixed and small.

### 14.6 No intermediate `float` conversion

Unchanged and reaffirmed: pH values are accepted as `Decimal`, `int`, or `str` and converted directly to `Decimal` at every layer (CLI, domain). No `float(...)` call appears anywhere in the pH-handling path.

### 14.7 No universal 0–14 range; no stored unit

Unchanged: no universal numeric range is imposed, structurally or otherwise; no pH convention or scale is declared or assumed; no unit is stored. These remain scientific-content decisions, entirely independent of the structural limits in Section 14.2–14.3.

## 15. Identity

Unchanged from `07`.

### 15.1 Identity flavor and justification

There is exactly **one** shared identity-conflict primitive in the codebase (`atomic.py::check_storage_identity_conflict`), used identically by `registry.py`, `scientific_registry.py`, `transformation_registry.py`, and `execution_registry.py`, and it is **always** casefold-normalized. `ScientificConditionsDeclaration.id` is scientist-chosen and reuses this primitive directly, with a new `conflict_error` subclass (`ConditionsIdentityConflictError`, Section 20).

### 15.2 Why not a content-derived identity

A `semantic_key` (Increment 018's pattern) is not used here. A `ScientificConditionsDeclaration` is a named authorial act, not a deterministic function of content; different ids with the same pH are always permitted.

### 15.3 Isolation and coexistence

Identity is scoped per `project_dir`. Within one `project_dir`, any number of declarations coexist freely; no uniqueness constraint applies to scientific content, only to `id`.

## 16. Idempotency

Unchanged from `07`.

### 16.1 Retry-equivalence definition

A request to create a declaration under an `id` that already has a persisted record is a **safe, recognized retry** if and only if every one of `ph`, `purpose`, `declared_by`, `label`, `rationale`, `supersedes_id` matches exactly. **`declared_at` never participates.** A match returns the existing record unchanged. A mismatch raises `ConditionsDeclarationConflictError` (Section 20).

### 16.2 Canonicalization

`Decimal` equality already treats `"7.40"` and `"7.4"` as equal by numeric value.

### 16.3 No semantic hash

A direct structural comparison of the freshly-requested fields against the freshly-loaded persisted record is cheap, legible, sufficient, and bounded in cost by Section 14's own limits.

### 16.4 Ordering and concurrency

`declared_at` is generated once, before the identity-conflict check; discarded on a recognized retry. Genuinely concurrent writers receive the same, already-accepted TOCTOU limitation every other registry in this codebase provides.

## 17. Revision and Acyclicity Proof

Unchanged from `07` — `08` confirmed this proof `RESOLVED` with no residual gap of any kind.

### 17.1 Revision

`supersedes_id` on a **new** record names the record it revises. The superseded record is never touched, never deleted, and remains independently loadable forever. A revision's `ph` value may differ arbitrarily from its predecessor's.

### 17.2 The five facts the proof depends on

1. **`supersedes_id` may only name an *already-persisted* record.**
2. **Predecessor validation happens before publication.**
3. **Create-once**: a given `id`, once published, can never be published again.
4. **Immutability of the published record**: once published, nothing can ever change.
5. **Edges point only backward in creation time**, as a direct consequence of fact 1.

### 17.3 The proof, by induction on creation order

- **Base case.** A declaration created with `supersedes_id = None` has out-degree zero.
- **Inductive step.** For any declaration `R` published with `supersedes_id = P`, fact 1 requires `P` to already exist at `R`'s creation, so (by fact 3) `creation_time(P) < creation_time(R)` — **every edge points from a later-created vertex to an earlier-created one.**
- **Conclusion.** A cycle would require a vertex's creation time to be strictly less than itself through a chain of strict inequalities — impossible. **No cycle of any length can exist.**
- **Role of fact 4.** The inductive step rules out constructing a cycle outright; fact 4 (immutability) separately rules out introducing one afterward by mutating an already-published record's `supersedes_id`. Facts 1–3 and fact 4 are jointly necessary and jointly sufficient.
- **`n = 1` (self-reference)** is excluded directly by `_validate_no_self_supersession` (Section 13.5).

This supersedes the first draft's proof, which attributed the result to immutability and non-reuse of ids *alone* — insufficient on its own, as a direct counterexample (forward-reference-then-close) demonstrated.

### 17.4 Branching and multi-level chains remain fully compatible with this proof

Fan-in (branching) does not create a cycle — only a back-edge would, and back-edges are exactly what Section 17.3 excludes. A multi-level chain (`A ← B ← C`) is simply a longer acyclic path.

### 17.5 Predecessor absence and predecessor invalidity, distinguished

- **Predecessor absent**: no file exists at the named `supersedes_id` → `ConditionsPredecessorNotFoundError`.
- **Predecessor invalid/unreadable**: a file exists but fails to parse or validate → `ConditionsRecordInvalidError` — the same type `load_conditions_declaration` (Section 18.4) raises for any corrupted record encountered via any path, including (per Section 22's corrected coverage) the colliding-record path shared by both `add` and `revise`.

### 17.6 Branching, "latest," and no automatic resolution

Branching is permitted by design and never auto-resolved. No declaration is ever "active" by default; listing never implies selection (Section 18.6).

### 17.7 Revision idempotency

A `revise` invocation is exactly a call to `declare_conditions` with `supersedes_id` set — governed by the same retry-equivalence rule as `add`, with `supersedes_id` itself among the compared fields.

## 18. Persistence

Unchanged from `07`.

### 18.1 Directory and file naming (frozen)

```
project_dir/scientific/experimental_conditions/<conditions_id>.yaml
```

### 18.2 Module and registry pattern

A new, dedicated `src/molecular/conditions_registry.py`.

### 18.3 Write path

```python
def _conditions_dir(project_dir: Path) -> Path:
    return project_dir / "scientific" / "experimental_conditions"

def _persist(project_dir: Path, declaration: ScientificConditionsDeclaration) -> None:
    metadata_file = _conditions_dir(project_dir) / f"{declaration.id}.yaml"
    serialized_yaml = yaml.safe_dump(declaration.model_dump(mode="json"), sort_keys=False)
    atomic_write_text(metadata_file, serialized_yaml)
```

`atomic_write_text` creates its target directory on demand. Before this write, `check_storage_identity_conflict(_conditions_dir(project_dir), declaration.id, conflict_error=ConditionsIdentityConflictError)` guards the create path.

### 18.4 Read path — ownership of error translation

```python
def load_conditions_declaration(project_dir: Path, conditions_id: str) -> ScientificConditionsDeclaration:
    validate_input_id(conditions_id)
    metadata_file = _conditions_dir(project_dir) / f"{conditions_id}.yaml"

    if not metadata_file.is_file():
        raise FileNotFoundError(f"no conditions declaration registered under '{conditions_id}'")

    try:
        data = yaml.safe_load(metadata_file.read_text(encoding="utf-8"))
        return ScientificConditionsDeclaration.model_validate(data)
    except (yaml.YAMLError, ValidationError) as error:
        raise ConditionsRecordInvalidError(
            f"conditions declaration '{conditions_id}' exists but is not readable/valid"
        ) from error
```

**Design rule:** the **registry** layer owns translation of raw I/O-level parsing/validation failures encountered while *reading an existing, persisted record* into `ConditionsRecordInvalidError` — with `__cause__` always preserved. This applies uniformly whether the record is loaded directly (`show`), enumerated (`list`), consulted as a revision's predecessor, **or encountered as the colliding record during any identity-conflict resolution (`add` or `revise` alike)** — this last path is the one Section 22's correction now surfaces correctly at the CLI layer. The **Application Service** layer owns translation of validation failures encountered while *constructing a new record from caller-supplied input* (Section 19.1).

### 18.5 List path

```python
def list_conditions_declarations(project_dir: Path) -> Tuple[ScientificConditionsDeclaration, ...]:
    directory = _conditions_dir(project_dir)
    if not directory.is_dir():
        return ()
    declarations = [
        load_conditions_declaration(project_dir, path.stem)
        for path in sorted(directory.glob("*.yaml"))
    ]
    return tuple(sorted(declarations, key=lambda d: (d.declared_at, d.id)))
```

When `experimental_conditions/` does not yet exist, returns an **empty tuple**, never raises.

### 18.6 Why no reservation/claim/owner-token protocol

Unchanged: a `ScientificConditionsDeclaration` is a single, small, purely structural YAML document with no external artifact and no staging step.

## 19. Application Service

New module `src/molecular/conditions_service.py`. The sequence below is unchanged from `07` in substance — `08` confirmed its wrapping steps are correctly specified; the defect `08` found (nm-1) was specifically in Section 22's CLI-level handling, not in this sequence itself, which already correctly documented (in its own step 6) that a colliding corrupted record produces `ConditionsRecordInvalidError`. This section is restated for self-sufficiency, with one clarifying addition at the end of step 6 making explicit that this applies to **every** caller, including a plain `add` with no `supersedes_id`.

### 19.1 `declare_conditions` (the sole creation entry point — also used for revision)

```python
def declare_conditions(
    project_dir: Path,
    *,
    conditions_id: str,
    ph: PhDeclaration,
    purpose: Literal["simulation_input"],
    declared_by: str,
    label: Optional[str] = None,
    rationale: Optional[str] = None,
    supersedes_id: Optional[str] = None,
) -> ScientificConditionsDeclaration:
    ...
```

**Sequence:**

1. Validate `conditions_id` via `validate_input_id`; if `supersedes_id` is given, validate it the same way. Any `ValueError` raised by either check is caught and re-raised as `ConditionsValidationError(...) from error`. No I/O has occurred yet.
2. Best-effort log `outcome="started"`.
3. If `supersedes_id` is given, call `load_conditions_declaration(project_dir, supersedes_id)`. A `FileNotFoundError` is re-raised as `ConditionsPredecessorNotFoundError`; a `ConditionsRecordInvalidError` propagates unchanged. Both followed by a best-effort `outcome="error"` log.
4. Construct the candidate `ScientificConditionsDeclaration(...)` with a freshly-generated `declared_at`. Any `pydantic.ValidationError` raised here — an invalid `ph` beyond Section 14's limits (including any of the three distinct `decimal_*` constraint violations), an overlong `label`, a blank `rationale`, an invalid `purpose` — is caught and re-raised as `ConditionsValidationError(...) from error`, followed by a best-effort `outcome="error"` log.
5. Attempt to persist via the registry's create-once write.
6. On `ConditionsIdentityConflictError`: load the existing colliding record and compare per Section 16.1. **This load is itself subject to Section 18.4's own translation: if the colliding record is corrupted, `ConditionsRecordInvalidError` propagates from here — and this path is reachable from every caller of `declare_conditions`, with or without `supersedes_id`, so it applies identically to a plain `add` and to a `revise`.** Identical content returns the existing record unchanged (discarding the freshly-generated `declared_at`), logging `outcome="success"` with a "reused" annotation; divergent content raises `ConditionsDeclarationConflictError`, logging `outcome="error"`.
7. An unexpected `OSError` during the write itself (not an identity conflict) is re-raised as `ConditionsPersistenceError(...) from error`, logging `outcome="error"`. **No partial file is ever left behind by this step**: `atomic_write_text`'s underlying mechanism either completes the replace or leaves the destination untouched (Section 18.3) — an `OSError` here means the original destination (if any) is unaffected, and no new, half-written file exists at the target path.
8. On a fresh successful write: best-effort log `outcome="success"`; return the resulting record.

There is no separate `revise_conditions` function: a "revision" is exactly a call to `declare_conditions` with `supersedes_id` set.

### 19.2 `load_conditions` and `list_conditions`

```python
def load_conditions(project_dir: Path, conditions_id: str) -> ScientificConditionsDeclaration: ...
def list_conditions(project_dir: Path) -> Tuple[ScientificConditionsDeclaration, ...]: ...
```

Thin wrappers over the registry's own functions; propagate `FileNotFoundError`/`ConditionsRecordInvalidError` unchanged. No activity logging.

### 19.3 Layering discipline

Domain (`conditions.py`) → Registry (`conditions_registry.py`, translates read-time failures into `ConditionsRecordInvalidError`) → Application Service (`conditions_service.py`, translates construction-time failures into `ConditionsValidationError`, orchestrates, logs activity) → CLI (`cli.py`, argument parsing, presentation, the Section 14.2 length pre-check).

## 20. Error Taxonomy and Boundaries

Unchanged in its six members and their meanings — `08` confirmed the taxonomy itself has no overlapping or ambiguous member. One clarifying addition to the `ConditionsRecordInvalidError` row, making explicit (consistent with Section 19.1 step 6 and Section 22's correction) that it can arise via two distinct paths, not one.

| Exception | Raised by | Condition | `__cause__` | CLI banner (Section 22) |
|---|---|---|---|---|
| `ConditionsValidationError(ValueError)` | `conditions_service.py` | Any input-shape problem: an invalid `conditions_id`/`supersedes_id` format, or any `pydantic.ValidationError` raised while constructing the candidate record (invalid `ph` — including any of the three distinct `decimal_*` constraint violations named in Section 14.3 — overlong `label`, blank `rationale`, invalid `purpose`, etc.) | Always preserved | `"INPUT ERROR"`, exit 1 |
| `ConditionsIdentityConflictError(FileExistsError)` | `conditions_registry.py` | `check_storage_identity_conflict` detects an exact or casefold collision on `conditions_id` at create time | N/A (not a wrapper) | Never reaches the CLI directly — caught and resolved internally by `declare_conditions` (step 6) into either success, `ConditionsDeclarationConflictError`, or `ConditionsRecordInvalidError` |
| `ConditionsDeclarationConflictError(RuntimeError)` | `conditions_service.py` | A create/revise request under an existing `id` diverges from the persisted record on any Section 16.1 field | N/A | `"CONFLICT"`, exit 1, names the diverging field(s) |
| `ConditionsPredecessorNotFoundError(RuntimeError)` | `conditions_service.py` | `supersedes_id` names an `id` with no persisted record at all | N/A | `"PREDECESSOR NOT FOUND"`, exit 1 |
| `ConditionsRecordInvalidError(RuntimeError)` | `conditions_registry.py` | A persisted record exists but fails to parse as YAML or fails schema validation. **Two distinct reachable paths, both covered identically by every command that can encounter them (Section 22.0)**: (a) the record is the direct target of a load (`show`, `list`, or a `revise`'s named predecessor); (b) the record is the *colliding* existing file encountered while resolving a `ConditionsIdentityConflictError` inside step 6 above — reachable from **any** call to `declare_conditions`, including a plain `add` with no `supersedes_id` | Always preserved | `"RECORD INVALID"`, exit 1 |
| `ConditionsPersistenceError(OSError)` | `conditions_service.py` | An unexpected filesystem failure during the write itself (step 7), distinct from an identity conflict | Always preserved | `"STORAGE ERROR"`, exit 1 |

`FileNotFoundError` (unwrapped) remains the signal for "no record at this `id` at all" when loading directly via `show`/`list`. No exception type is reused with two different meanings. Any exception not named in this table propagates unchanged.

## 21. Future Integration

Unchanged — `08` confirmed this section `RESOLVED` with no residual gap of any kind.

**`ExecutionAttempt` is not modified by Increment 019, in any way, including merely to reserve a future field.** Nothing in this section is implemented, instantiated, or partially built by this increment.

When a future, platform-mediated, conditions-consuming execution exists, that future increment's own specification must ensure: the selected declaration is **referenced explicitly**, never inferred or defaulted; `resolved_conditions` is an **immutable snapshot**; `EngineParameters` is produced by an **explicit, traceable translation**; **no engine may silently substitute** a different pH value than declared; **no engine may invent a pH value** when none was selected or consumed; a condition **not consumed** must be recorded as explicitly not-consumed; **partial consumption** must be recorded explicitly, never collapsed into a binary; a future transformation record must never **hide a divergence** between declaration, snapshot, engine parameters, and published parameter; any translated value must be **traceable back to its snapshot**; the parameter an engine **actually used** must be preserved distinctly; an execution may proceed **without** any declaration selected, remaining the default, unremarkable, explicitly representable case.

None of these structures exists, is instantiated, or is partially built by Increment 019. The exact mechanism a future consumer uses to extend `ExecutionAttempt` (most likely a `schema_version` bump to `"1.2"`) belongs entirely to that future increment's own specification.

## 22. CLI

New `conditions_app` Typer sub-application in `src/molecular/cli.py`, following exactly the structure already used by `ligand_app`/`protein_app`/`state_app`.

### 22.0 Four-command × error-type coverage (new — directly resolves nm-1 by demonstrating, not asserting, symmetry)

The table below enumerates, for every member of Section 20's taxonomy plus the unwrapped `FileNotFoundError` case, exactly which of the four commands can realistically receive it — derived directly from Section 19.1's own sequence and Section 18.4/18.5's read paths — and is the authoritative basis for each command's own handler list in Sections 22.1–22.4 below. A command's handler list below must match its own column in this table exactly; this is the mechanism by which this correction prevents a recurrence of nm-1 (a command silently omitting a handler for an error it can, in fact, receive).

| Error type | `add` | `revise` | `show` | `list` |
|---|---|---|---|---|
| `ConditionsValidationError` | **Yes** (steps 1, 4) | **Yes** (steps 1, 4) | No | No |
| `ConditionsIdentityConflictError` | Internal only — never escapes `declare_conditions` | Internal only — never escapes | No | No |
| `ConditionsDeclarationConflictError` | **Yes** (step 6, divergent retry) | **Yes** (step 6) | No | No |
| `ConditionsPredecessorNotFoundError` | No — `add` never supplies `supersedes_id` | **Yes** (step 3) | No | No |
| `ConditionsRecordInvalidError` | **Yes** (step 6: the colliding existing record is corrupted) | **Yes** — via **two** paths: step 3 (predecessor corrupted) **and** step 6 (colliding existing record corrupted, same as `add`) | **Yes** (the directly-targeted record is corrupted) | **Yes** (any individually-enumerated record is corrupted) |
| `ConditionsPersistenceError` | **Yes** (step 7) | **Yes** (step 7) | No — a read performs no write | No — a read performs no write |
| `FileNotFoundError` (unwrapped) | No — an `add` under a *new* id that doesn't exist yet is the normal, successful case, not an error | No | **Yes** (the targeted record does not exist) | No — an empty directory yields an empty result (Section 18.5), never an exception |

**This is the complete, demonstrated basis for the claim that no command lets a typed exception, or a raw `pydantic.ValidationError`, escape unhandled (restated and now actually true, closing nm-1).**

### 22.1 `molecular conditions add`

```python
@conditions_app.command("add")
def conditions_add(
    experiment: str,
    conditions_id: str,
    ph: Optional[str] = typer.Option(None, "--ph"),
    ph_min: Optional[str] = typer.Option(None, "--ph-min"),
    ph_max: Optional[str] = typer.Option(None, "--ph-max"),
    declared_by: str = typer.Option(..., "--declared-by"),
    purpose: str = typer.Option("simulation_input", "--purpose"),
    label: Optional[str] = typer.Option(None, "--label"),
    rationale: Optional[str] = typer.Option(None, "--rationale"),
):
```

Handling, in order:

1. **Flag-combination pre-check**: exactly one of `--ph` or the complete pair `--ph-min`/`--ph-max` must be given. Otherwise → `"INPUT ERROR"`, exit 1, nothing persisted.
2. **Length pre-check** (Section 14.2): any given `--ph`/`--ph-min`/`--ph-max` string longer than 64 characters → `"INPUT ERROR"`, exit 1, no `Decimal(...)` conversion attempted.
3. **`Decimal` conversion**: via `Decimal(...)`, never `float`; `decimal.InvalidOperation` → `"INPUT ERROR"`, exit 1.
4. **Application Service call**: `declare_conditions(...)` is invoked. Exceptions handled, matching Section 22.0's `add` column exactly:
   - `ConditionsValidationError` → `"INPUT ERROR"`, exit 1.
   - `ConditionsDeclarationConflictError` → `"CONFLICT"`, exit 1, naming the diverging field(s).
   - `ConditionsPersistenceError` → `"STORAGE ERROR"`, exit 1.
   - **`ConditionsRecordInvalidError` → `"RECORD INVALID"`, exit 1 (new — resolves nm-1).** Reachable specifically when `conditions_id` collides with an existing file that is corrupted or schema-invalid. Banner fields presented: `Conditions ID` (the identifier the caller supplied, safe to echo — it is the caller's own input, not content read from the corrupted file) and nothing else — no field is read from the unreadable file itself, since by definition it could not be parsed. The underlying `yaml.YAMLError`/`pydantic.ValidationError` remains attached as `__cause__` on the raised `ConditionsRecordInvalidError` (Section 18.4), available to a developer inspecting a test failure or a logged exception, but **not** echoed to the terminal banner itself — the banner states only that the existing record is unreadable, never its raw parse-error text, to avoid leaking potentially malformed/binary file content into a terminal. **No fallback to `"CONFLICT"` occurs** — an unreadable record cannot be compared for retry-equivalence at all (Section 16.1's comparison requires a successfully-loaded record), so there is no content to diverge from or agree with; the only honest outcome is to report the record as unreadable, distinctly from a successful comparison that happens to disagree. **No new file is published** — `declare_conditions` returns from this branch via the raised exception, never reaching step 8's success path, so no record is ever written under any circumstance of this branch being taken. **No existing file is overwritten or modified** — the corrupted file is only ever opened for reading (Section 18.4); nothing in this path writes to it. **No success activity entry is logged** — the `outcome="error"` log already fires before this exception propagates (Section 19.1 step 6/19.1's general error-logging pattern), and no `outcome="success"` entry is ever written on this path, so the activity log never misrepresents this outcome as a success.
5. **Success**: echo `"SCIENTIFIC CONDITIONS DECLARED"`, then `Conditions ID`, `pH`, `Purpose`, `Declared by`, `Declared at`, and, when present, `Label`/`Rationale`/`Supersedes`. A recognized idempotent retry adds `Result: existing declaration reused`.

`--declared-by` is required on every invocation, never inherited. `--purpose` defaults to `"simulation_input"` at the CLI layer only.

### 22.2 `molecular conditions revise`

Identical option surface to `add`, plus a required `--supersedes` option (enforced at the Typer argument-parsing level, rejected before any Application Service call if missing):

```python
@conditions_app.command("revise")
def conditions_revise(
    experiment: str,
    conditions_id: str,
    supersedes: str = typer.Option(..., "--supersedes"),
    ph: Optional[str] = typer.Option(None, "--ph"),
    ph_min: Optional[str] = typer.Option(None, "--ph-min"),
    ph_max: Optional[str] = typer.Option(None, "--ph-max"),
    declared_by: str = typer.Option(..., "--declared-by"),
    purpose: str = typer.Option("simulation_input", "--purpose"),
    label: Optional[str] = typer.Option(None, "--label"),
    rationale: Optional[str] = typer.Option(None, "--rationale"),
):
```

Same handling as `add` (steps 1–5 above, identically including the `ConditionsRecordInvalidError` handler), plus `ConditionsPredecessorNotFoundError` → `"PREDECESSOR NOT FOUND"`, exit 1.

**Correction to this command's own description of `ConditionsRecordInvalidError`:** this error is **not** exclusive to "the named predecessor is unreadable." Per Section 22.0's coverage table, `revise` can receive `ConditionsRecordInvalidError` via **two** distinct paths — the named predecessor being unreadable (step 3), and the colliding existing record at `conditions_id` itself being unreadable (step 6, identical to `add`'s own case, since `revise` is `declare_conditions` with `supersedes_id` set and is therefore equally subject to step 6). Both paths produce the identical banner (`"RECORD INVALID"`, exit 1); the command's handling code does not need to, and does not, distinguish which of the two paths produced it, since both represent the same user-facing fact: some record this operation needed to read is not readable.

### 22.3 `molecular conditions show`

```python
@conditions_app.command("show")
def conditions_show(experiment: str, conditions_id: str):
```

- `FileNotFoundError` → `"NOT FOUND"`, exit 1.
- `ConditionsRecordInvalidError` → `"RECORD INVALID"`, exit 1.
- Success: the same field listing as `add`'s success banner.

### 22.4 `molecular conditions list`

```python
@conditions_app.command("list")
def conditions_list(experiment: str):
```

Echoes a deterministic, one-line-per-declaration table in `(declared_at, id)` order. On a fresh experiment with zero declarations, prints an empty table and exits `0`. `ConditionsRecordInvalidError` on any individual record encountered during enumeration → `"RECORD INVALID"`, exit 1, naming the offending `id`.

### 22.5 What the CLI never does

No interactive prompt under any flag combination, on any of the four commands. No `set-default`, `infer`, `recommend`, or `apply-all`. No flag or code path selects a "most recent" declaration automatically. `--declared-by` is never defaulted or inherited. No absolute path is ever echoed or persisted.

### 22.6 Activity logging boundary

Unchanged: `declare_conditions` performs its own best-effort `started`/`success`/`error` activity logging; the CLI layer does not add a second logging call around a successful invocation.

## 23. Activity Logging

Unchanged: `declare_conditions` logs exactly one `started` entry and exactly one terminal (`success`/`error`) entry, via `record_activity(project_dir, command="conditions-declare", outcome=..., details=...)`, with a `ConditionsActivityDetails` dataclass defined in `conditions_service.py` (mirroring where `DerivedStateActivityDetails`/`TautomerEnumerationActivityDetails` live in `application.py`), carrying `conditions_id`, `supersedes_id` (or `None`), and `declared_by`. Logging is always best-effort (`except Exception: pass`). `load_conditions`/`list_conditions` perform no activity logging.

## 24. Security and Integrity

Unchanged: all persisted paths remain relative to `project_dir`. `conditions_id`/`supersedes_id` are validated via `validate_input_id` before any filesystem interaction. No free-text field is ever interpreted or parsed for embedded instructions. No new RDKit, network, or external-process dependency is introduced. Immutability is itself an integrity property — no "edit" verb exists anywhere in the CLI. Section 14's bounded `Decimal` representation (now documented across all three of its native constraints, Section 14.3) remains itself an integrity property, eliminating the disproportionate-artifact-size vector the first draft's review demonstrated empirically.

## 25. Normative Test Matrix (Corrected)

**Ninety-nine (99) normative scenarios, `T-001`–`T-099`, sequential, no gaps, no duplicates — up from 94, via six additions and one consolidation, netting to a delta of +5.** No padding, and no technical scenario, guarantee, or contract element was lost in the process.

### 25.1 Delta explanation

**Accounting:**

```
Prior base:                        94 scenarios
Real additions:                     6
Consolidation:                       2 prior documentary scenarios → 1
Net reduction from consolidation:  -1
Result:                            94 + 6 - 1 = 99
Net delta:                         +5
```

**The six additions:**

- `T-019` — the accepted integer-digit boundary (`"999999"`/`"999999.999999"`), resolving `nm-3`.
- `T-020` — the rejected integer-digit boundary, specifically via `decimal_whole_digits`, resolving `nm-3`.
- `T-065` — `ConditionsPersistenceError` exercised at the Application Service layer (a forced `OSError` during write), resolving `nm-2`.
- `T-078` — `conditions add` under an `id` colliding with a corrupted existing record, resolving `nm-1`.
- `T-079` — `ConditionsPersistenceError` surfacing through the CLI (`add`), resolving `nm-2`.
- `T-084` — the second reachable path of `ConditionsRecordInvalidError` in `conditions revise` (the colliding target `id`, distinct from the predecessor path already covered by `T-083`), resolving `nm-1`.

Three of these six additions are CLI-layer scenarios — `T-078`, `T-079`, and `T-084` — consistent with, and already correctly reflected by, Section 27's allowlist note and Section 28's Checkpoint 3 row, both of which name all three.

**The one consolidation:** `07`'s two separate documentary scenarios, `T-093` ("forbids hiding a divergence between declaration, snapshot, engine parameters, and published parameter") and `T-094` ("confirms nothing in Section 21 is implemented; `ExecutionAttempt` remains unmodified"), are consolidated into a single normative line in this final specification, `T-099` (Section 25.2). Both original guarantees remain fully present — concatenated within that one row's text, not dropped. The consolidation changes the row *count* for that pair from two to one; it does not change, remove, or weaken either guarantee's normative *content*.

**Net result:** six additions, minus one row through consolidation, nets to a delta of +5 (`94 + 6 − 1 = 99`) — this is the accurate composition of the delta. (An earlier wording of this section described the change as "exactly 5 new scenarios, no overlap," which did not account for `T-084` or for the `T-093`/`T-094` consolidation; that wording has been corrected here to state the real composition precisely.)

Every other scenario retained from the 94-row matrix keeps its exact substance, with only its number shifting where a new or consolidated row was positioned before it in sequence (full renumbering was required to keep the sequence gap-free and duplicate-free, per the governing task's explicit instruction). Confirmed against the mechanical extraction in Section 25.3.

### 25.2 The matrix

| # | Scenario | Type | Layer / Checkpoint | Test file |
|---|---|---|---|---|
| T-001 | Create a declaration with a valid point pH. | Unit/Domain | Domain / CP1 | `test_conditions.py` |
| T-002 | Create a declaration with a valid pH range (`minimum < maximum`). | Unit/Domain | Domain / CP1 | `test_conditions.py` |
| T-003 | Both `point` and `range` provided → rejected. | Unit/Domain | Domain / CP1 | `test_conditions.py` |
| T-004 | Neither `point` nor `range` provided → rejected. | Unit/Domain | Domain / CP1 | `test_conditions.py` |
| T-005 | `PhRange` with `minimum > maximum` → rejected. | Unit/Domain | Domain / CP1 | `test_conditions.py` |
| T-006 | `PhRange` with `minimum == maximum` → accepted. | Unit/Domain | Domain / CP1 | `test_conditions.py` |
| T-007 | `Decimal` value constructed from a string preserves exact textual precision. | Unit/Domain | Domain / CP1 | `test_conditions.py` |
| T-008 | `Decimal("1")`, `Decimal("1.0")`, `Decimal("1.00")` textually distinct, pairwise equal. | Unit/Domain | Domain / CP1 | `test_conditions.py` |
| T-009 | Boolean rejected natively for `PhPoint.value`/`PhRange` bounds. | Unit/Domain (parametrized) | Domain / CP1 | `test_conditions.py` |
| T-010 | `NaN` rejected natively (point). | Unit/Domain (parametrized w/ T-011–012) | Domain / CP1 | `test_conditions.py` |
| T-011 | `Infinity`/`-Infinity` rejected natively (point). | Unit/Domain (parametrized) | Domain / CP1 | `test_conditions.py` |
| T-012 | `NaN`/infinity rejected natively (range, independently on each bound). | Unit/Domain (parametrized) | Domain / CP1 | `test_conditions.py` |
| T-013 | Leading/trailing whitespace accepted, silently trimmed. | Unit/Domain | Domain / CP1 | `test_conditions.py` |
| T-014 | `-0` accepted; compares equal to `0`; serializes as literal `"-0"`. | Unit/Domain | Domain / CP1 | `test_conditions.py` |
| T-015 | pH below 0 accepted structurally; no scientific-validity claim. | Unit/Domain | Domain / CP1 | `test_conditions.py` |
| T-016 | pH above 14 accepted structurally; same non-claim. | Unit/Domain | Domain / CP1 | `test_conditions.py` |
| T-017 | A value exceeding 12 total significant digits → rejected (`decimal_max_digits`). | Unit/Domain | Domain / CP1 | `test_conditions.py` |
| T-018 | A value with more than 6 decimal places → rejected (`decimal_max_places`). | Unit/Domain | Domain / CP1 | `test_conditions.py` |
| T-019 | **[NEW, resolves nm-3]** A value with integer-part digits at or within the 6-digit boundary (`"999999"`; `"999999.999999"`, 6 integer + 6 decimal = 12 total) → accepted on both sides of the combined boundary. | Unit/Domain | Domain / CP1 | `test_conditions.py` |
| T-020 | **[NEW, resolves nm-3]** A value whose integer part exceeds 6 digits (`"1000000"`; `"-1000000"`; `"1234567"`, only 7 total digits, well within the 12-digit total limit) → rejected specifically via `decimal_whole_digits`, distinct from, and independent of, `decimal_max_digits` (T-017); includes the exponential-notation case `"1E+6"` expanding to 7 integer digits. | Unit/Domain (parametrized) | Domain / CP1 | `test_conditions.py` |
| T-021 | Exponential notation expanding within bounds (`"1.23E+2"`) → accepted. | Unit/Domain | Domain / CP1 | `test_conditions.py` |
| T-022 | Exponential notation with an extreme exponent exceeding the total-digit limit (`"1E+50"`, `"1E-50"`) → rejected via `decimal_max_digits`. | Unit/Domain | Domain / CP1 | `test_conditions.py` |
| T-023 | `label` whitespace-only → rejected. | Unit/Domain | Domain / CP1 | `test_conditions.py` |
| T-024 | `rationale` whitespace-only → rejected. | Unit/Domain | Domain / CP1 | `test_conditions.py` |
| T-025 | `label` exceeding 200 characters → rejected. | Unit/Domain | Domain / CP1 | `test_conditions.py` |
| T-026 | `rationale` exceeding 4000 characters → rejected. | Unit/Domain | Domain / CP1 | `test_conditions.py` |
| T-027 | A naive (non-tz-aware) `declared_at` → rejected. | Unit/Domain | Domain / CP1 | `test_conditions.py` |
| T-028 | A tz-aware `declared_at` round-trips through YAML persistence as UTC. | Registry | Registry / CP1 | `test_conditions_registry.py` |
| T-029 | Missing `declared_by` → rejected. | Unit/Domain | Domain / CP1 | `test_conditions.py` |
| T-030 | `purpose` other than `"simulation_input"` → rejected. | Unit/Domain | Domain / CP1 | `test_conditions.py` |
| T-031 | `purpose` given as an empty string → rejected. | Unit/Domain | Domain / CP1 | `test_conditions.py` |
| T-032 | Unknown/extra field → rejected (`extra="forbid"`). | Unit/Domain | Domain / CP1 | `test_conditions.py` |
| T-033 | Attempted field reassignment → rejected (`frozen=True`). | Unit/Domain | Domain / CP1 | `test_conditions.py` |
| T-034 | Full YAML round-trip reproduces an equal model. | Registry | Registry / CP1 | `test_conditions_registry.py` |
| T-035 | `id` containing invalid characters → rejected. | Unit/Domain | Domain / CP1 | `test_conditions.py` |
| T-036 | `supersedes_id`, when present, validated identically to `id`. | Unit/Domain | Domain / CP1 | `test_conditions.py` |
| T-037 | `supersedes_id` equal to `id` (self-reference) → rejected at construction. | Unit/Domain | Domain / CP1 | `test_conditions.py` |
| T-038 | The canonical serialized representation of any value that passes validation is bounded in length. | Unit/Domain (static) | Domain / CP1 | `test_conditions.py` |
| T-039 | First creation under a brand-new `id` persists successfully. | Registry | Registry / CP1 | `test_conditions_registry.py` |
| T-040 | A casefold collision between differently-cased `id`s → `ConditionsIdentityConflictError`. | Registry | Registry / CP1 | `test_conditions_registry.py` |
| T-041 | Listing on a `project_dir` with zero declarations → empty tuple/table, never raises. | Registry | Registry / CP1 | `test_conditions_registry.py` |
| T-042 | Listing never marks any record as "current," "active," or "latest." | Registry (static) | Registry / CP1 | `test_conditions_registry.py` |
| T-043 | Loading a `conditions_id` with no persisted file → `FileNotFoundError`. | Registry | Registry / CP1 | `test_conditions_registry.py` |
| T-044 | Loading structurally malformed YAML → `ConditionsRecordInvalidError`, `__cause__` set to the original `yaml.YAMLError`. | Registry | Registry / CP1 | `test_conditions_registry.py` |
| T-045 | Loading well-formed YAML that fails schema validation → `ConditionsRecordInvalidError`, `__cause__` set to the original `pydantic.ValidationError`. | Registry | Registry / CP1 | `test_conditions_registry.py` |
| T-046 | Listing produces a stable, repeatable `(declared_at, id)` ordering. | Registry | Registry / CP1 | `test_conditions_registry.py` |
| T-047 | No persisted record ever contains an absolute filesystem path. | Registry (static) | Registry / CP1 | `test_conditions_registry.py` |
| T-048 | Retry under the same `id`, all compared fields identical → recognized reuse. | Service | Service / CP2 | `test_conditions_service.py` |
| T-049 | Retry with divergent `ph` → `ConditionsDeclarationConflictError`. | Service | Service / CP2 | `test_conditions_service.py` |
| T-050 | Retry with divergent `label`/`rationale`/`declared_by`/`purpose`/`supersedes_id` → `ConditionsDeclarationConflictError`. | Service (parametrized) | Service / CP2 | `test_conditions_service.py` |
| T-051 | Recognized retry never overwrites the original `declared_at`. | Service | Service / CP2 | `test_conditions_service.py` |
| T-052 | Two distinct `id`s, identical `ph`, both persist independently. | Service | Service / CP2 | `test_conditions_service.py` |
| T-053 | Multiple declarations coexist with no implicit ranking. | Service | Service / CP2 | `test_conditions_service.py` |
| T-054 | Same `conditions_id` in two different `project_dir`s → fully independent. | Service | Service / CP2 | `test_conditions_service.py` |
| T-055 | Revision creates a new record; the superseded record's file is byte-identical before/after. | Service | Service / CP2 | `test_conditions_service.py` |
| T-056 | `supersedes_id` naming a non-existent predecessor → `ConditionsPredecessorNotFoundError`. | Service | Service / CP2 | `test_conditions_service.py` |
| T-057 | `supersedes_id` naming a corrupted predecessor → `ConditionsRecordInvalidError`. | Service | Service / CP2 | `test_conditions_service.py` |
| T-058 | A revision's `ph` may differ arbitrarily from its predecessor's. | Service | Service / CP2 | `test_conditions_service.py` |
| T-059 | Two records naming the same `supersedes_id` (branching) both accepted. | Service | Service / CP2 | `test_conditions_service.py` |
| T-060 | A multi-level chain (`A ← B ← C`) persists all three, each independently loadable and immutable. | Service | Service / CP2 | `test_conditions_service.py` |
| T-061 | Attempting to publish a divergent record under an already-existing `id` → rejected by the ordinary create-once check (demonstrates immutability blocks retroactive rewiring, Section 17.3 fact 4). | Service | Service / CP2 | `test_conditions_service.py` |
| T-062 | A retried `revise` (identical `id`, `supersedes_id`, and every other compared field) → recognized as safe reuse. | Service | Service / CP2 | `test_conditions_service.py` |
| T-063 | A raw `ValueError` from `validate_input_id` is wrapped into `ConditionsValidationError`, `__cause__` preserved, before any I/O. | Service | Service / CP2 | `test_conditions_service.py` |
| T-064 | A `pydantic.ValidationError` raised during construction is wrapped into `ConditionsValidationError`, `__cause__` preserved. | Service (parametrized) | Service / CP2 | `test_conditions_service.py` |
| T-065 | **[NEW, resolves nm-2]** A forced `OSError` during the write itself (simulated, e.g., at `atomic_write_text`) → `ConditionsPersistenceError`, with `__cause__` preserved; no `outcome="success"` activity entry is logged; no record is persisted at the target path; no pre-existing file at an unrelated `id` is touched. | Service | Service / CP2 | `test_conditions_service.py` |
| T-066 | `declare_conditions` performs no filesystem write when format validation fails before any I/O. | Service | Service / CP2 | `test_conditions_service.py` |
| T-067 | Exactly one `started` and one `success` entry logged on a fresh creation. | Service | Service / CP2 | `test_conditions_service.py` |
| T-068 | Exactly one `started` and one `error` entry logged when any typed failure occurs after `started` is logged. | Service | Service / CP2 | `test_conditions_service.py` |
| T-069 | A forced activity-log write failure does not change `declare_conditions`'s own outcome or returned value. | Service | Service / CP2 | `test_conditions_service.py` |
| T-070 | `conditions add --ph ...` succeeds, exit `0`, point pH rendered correctly. | CLI/Integration | CLI / CP3 | `test_cli.py` |
| T-071 | `conditions add --ph-min ... --ph-max ...` succeeds, exit `0`, range pH rendered correctly. | CLI/Integration | CLI / CP3 | `test_cli.py` |
| T-072 | `conditions add` with both `--ph` and `--ph-min`/`--ph-max` → `"INPUT ERROR"`, exit `1`. | CLI/Integration | CLI / CP3 | `test_cli.py` |
| T-073 | `conditions add` with neither form complete → `"INPUT ERROR"`, exit `1`. | CLI/Integration | CLI / CP3 | `test_cli.py` |
| T-074 | `conditions add --ph` longer than 64 characters → `"INPUT ERROR"`, exit `1`, no `Decimal` conversion attempted. | CLI/Integration | CLI / CP3 | `test_cli.py` |
| T-075 | `conditions add --ph` violating any of the three `decimal_*` constraints (Section 14.3) → `"INPUT ERROR"`, exit `1`, via `ConditionsValidationError`, not a raw traceback. | CLI/Integration (parametrized across `decimal_max_digits`/`decimal_max_places`/`decimal_whole_digits`) | CLI / CP3 | `test_cli.py` |
| T-076 | `conditions add --label` exceeding 200 characters → `"INPUT ERROR"`, exit `1`. | CLI/Integration | CLI / CP3 | `test_cli.py` |
| T-077 | `conditions add --purpose ""` → `"INPUT ERROR"`, exit `1`. | CLI/Integration | CLI / CP3 | `test_cli.py` |
| T-078 | **[NEW, resolves nm-1]** `conditions add` where `conditions_id` collides with an existing, persisted-but-corrupted record → `"RECORD INVALID"`, exit `1`; the corrupted file is byte-for-byte unchanged after the attempt; no new file is published anywhere; no success banner, no reuse banner, and no `"CONFLICT"` banner is ever produced for this case; the activity log contains no `outcome="success"` entry for this invocation. | CLI/Integration | CLI / CP3 | `test_cli.py` |
| T-079 | **[NEW, resolves nm-2]** `conditions add` where the underlying write raises a forced `OSError` (not an identity conflict) → `"STORAGE ERROR"`, exit `1`; no success banner; nothing persisted at the target path. | CLI/Integration | CLI / CP3 | `test_cli.py` |
| T-080 | `conditions revise` without `--supersedes` → rejected at Typer's argument-parsing level. | CLI/Integration | CLI / CP3 | `test_cli.py` |
| T-081 | `conditions revise --supersedes <existing-id> ...` succeeds, exit `0`. | CLI/Integration | CLI / CP3 | `test_cli.py` |
| T-082 | `conditions revise --supersedes <non-existent-id> ...` → `"PREDECESSOR NOT FOUND"`, exit `1`. | CLI/Integration | CLI / CP3 | `test_cli.py` |
| T-083 | `conditions revise --supersedes <id-with-corrupted-file> ...` → `"RECORD INVALID"`, exit `1` (the predecessor-unreadable path). | CLI/Integration | CLI / CP3 | `test_cli.py` |
| T-084 | `conditions revise` where `conditions_id` itself (not the predecessor) collides with a corrupted existing record → `"RECORD INVALID"`, exit `1` (the colliding-record path, same mechanism as T-078, confirming `revise`'s own two-path coverage per Section 22.2's correction). | CLI/Integration | CLI / CP3 | `test_cli.py` |
| T-085 | `conditions show` on a non-existent `conditions_id` → `"NOT FOUND"`, exit `1`. | CLI/Integration | CLI / CP3 | `test_cli.py` |
| T-086 | `conditions show` on a corrupted/schema-invalid record → `"RECORD INVALID"`, exit `1`. | CLI/Integration | CLI / CP3 | `test_cli.py` |
| T-087 | `conditions list` output order stable across repeated invocations. | CLI/Integration | CLI / CP3 | `test_cli.py` |
| T-088 | No `conditions` subcommand exposes an interactive prompt under any flag combination. | CLI/Static | CLI / CP3 | `test_cli.py` |
| T-089 | No `conditions` subcommand named `set-default`, `infer`, `recommend`, or `apply-all` exists. | CLI/Static | CLI / CP3 | `test_cli.py` |
| T-090 | No unhandled Python exception escapes any of the four commands for any input covered by Section 20's taxonomy — cross-command symmetry check against Section 22.0's coverage table (now demonstrably true, including the `add`/`ConditionsRecordInvalidError` and `add`,`revise`/`ConditionsPersistenceError` cells that were previously gaps). | CLI/Static | CLI / CP3 | `test_cli.py` |
| T-091 | The existing `ibuprofen-deprotonation-001` fixture and its `TransformationParameter("pH"/"ph")` entries remain loadable and byte-for-byte unchanged. | Non-regression | CP4 | existing `tests/test_transformation.py` (read-only reference) |
| T-092 | Adding the new conditions modules does not alter `ExecutionAttempt`'s persisted schema; every existing `tests/test_execution*.py` outcome unchanged. | Non-regression | CP4 | existing `tests/test_execution*.py` (read-only reference) |
| T-093 | The full existing baseline suite (1142 passed / 5 skipped) remains green after the new modules and tests are added, strictly additively. | Non-regression (implementation-time gate) | CP4 | full suite |
| T-094 | [Static/Documentary] A future conditions-consuming execution must reference its selected declaration explicitly. | Documentary | N/A | — (satisfied by this document, §21) |
| T-095 | [Static/Documentary] `resolved_conditions` is an immutable snapshot, not modeled by Increment 019. | Documentary | N/A | — |
| T-096 | [Static/Documentary] `EngineParameters` must be produced by explicit, traceable translation from `resolved_conditions`. | Documentary | N/A | — |
| T-097 | [Static/Documentary] No future engine may silently substitute or invent a pH value. | Documentary | N/A | — |
| T-098 | [Static/Documentary] Non-consumption and partial consumption must be recorded explicitly, never silently. | Documentary | N/A | — |
| T-099 | [Static/Documentary] No future transformation record may hide a divergence between declaration, snapshot, engine parameters, and published parameter; none of these structures is implemented by Increment 019; `ExecutionAttempt` remains completely unmodified. | Documentary | N/A | — |

### 25.3 Mechanical reconciliation

Verified by extracting every `T-NNN` token, sorting, and diffing against an expected `001`–`099` sequence: **99 rows, `T-001` through `T-099`, strictly sequential, zero gaps, zero duplicate numbers.**

### 25.4 Subtotals

| Group | Range | Count |
|---|---|---|
| Domain (unit) | T-001–T-038 | 38 |
| Registry | T-039–T-047 | 9 |
| Service | T-048–T-069 | 22 |
| CLI | T-070–T-090 | 21 |
| Non-regression | T-091–T-093 | 3 |
| Documentary | T-094–T-099 | 6 |
| **Total** | | **99** |

(38+9+22+21+3+6 = 99, cross-checked against Section 25.3's mechanical extraction.)

## 26. Acceptance Criteria

An implementation satisfies this specification's intent when, and only when:

1. All 99 scenarios in Section 25 are realized by passing tests (T-094–T-099 by this document's own text, not by executable tests), each traceable to at least one concrete test or documentary confirmation.
2. The full existing baseline suite (1142 passed / 5 skipped / 0 failed) remains green, unmodified in its own right (T-093).
3. No file outside the allowlist (Section 27) is modified.
4. `ExecutionAttempt`, `TransformationParameter`, and every other existing public contract remain untouched.
5. No field, CLI verb, or exception type beyond Sections 13/22/20 is introduced without a specification amendment.
6. No `pydantic.ValidationError`, and no member of Section 20's taxonomy, is ever observable by a CLI user as a raw, unhandled traceback — demonstrated, not merely asserted, by Section 22.0's coverage table (T-090).
7. Every pH-bearing field enforces `Field(max_digits=12, decimal_places=6)` exactly as specified, including the implied integer-digit limit of 6 (`decimal_whole_digits`, Section 14.3).

## 27. Allowlist

| Path | Status | Justification |
|---|---|---|
| `src/molecular/conditions.py` | New | Domain module — `PhPoint`, `PhRange`, `PhDeclaration`, `ScientificConditionsDeclaration` (Sections 12–14). |
| `src/molecular/conditions_registry.py` | New | Registry module — persistence, create-once guard, load/list, `ConditionsRecordInvalidError` translation on both its read paths (Section 18). |
| `src/molecular/conditions_service.py` | New | Application Service — `declare_conditions`, `load_conditions`, `list_conditions`, the full error taxonomy's service-level members, `ConditionsActivityDetails` (Section 19, 23). |
| `src/molecular/cli.py` | Modified | Add `conditions_app` and its four commands (Section 22), including the corrected, symmetric exception-handling lists; no existing command altered. |
| `tests/test_conditions.py` | New | Domain-layer tests, including `decimal_whole_digits` boundary coverage (T-001–T-038). |
| `tests/test_conditions_registry.py` | New | Registry-layer tests, including corrupted-record and empty-directory handling (T-028, T-034, T-039–T-047). |
| `tests/test_conditions_service.py` | New | Application Service tests, including the new `ConditionsPersistenceError` scenario (T-048–T-069). |
| `tests/test_cli.py` | Modified | CLI tests for all four commands, including the two new corrected-coverage scenarios (T-070–T-090). |

**No other file is authorized.** `src/molecular/application.py`, `execution.py`, `execution_registry.py`, and `transformation.py` remain **not** on this allowlist — no concrete need to modify any of them was found anywhere in this correction. `tests/test_execution.py`, `tests/test_execution_registry.py`, `tests/test_transformation.py`, and `tests/test_application*.py` remain read-only non-regression references (T-091–T-092).

**Explicit association, per the governing task's own request:** the `decimal_whole_digits` boundary test belongs to `tests/test_conditions.py` (T-019/T-020, domain-layer, since the constraint is enforced entirely by the `Field` declaration on the domain model itself — no registry or service involvement is needed to observe it); the persistence-failure scenario belongs to `tests/test_conditions_service.py` (T-065, since `declare_conditions` is the only layer that catches the raw `OSError` and translates it); the CLI handlers for both new cases belong to `tests/test_cli.py` (T-078, T-079, T-084); record corruption and create-once behavior remain split exactly as before — the registry owns detecting and translating corruption (`test_conditions_registry.py`), the service owns reacting to it during identity-conflict resolution (`test_conditions_service.py`), and the CLI owns presenting the result (`test_cli.py`).

## 28. Checkpoints

Unchanged in structure; ranges updated to match the renumbered matrix. Planning only — no checkpoint is executed by this document.

| Checkpoint | Scope | Allowed files | Tests expected | Review gate | Restoration point |
|---|---|---|---|---|---|
| **1 — Domain and raw persistence** | `PhPoint`/`PhRange`/`PhDeclaration`/`ScientificConditionsDeclaration` (including the now-fully-documented three-constraint `Decimal` behavior); create-once registry with `ConditionsRecordInvalidError` translation; no retry/predecessor/Application Service logic yet | `conditions.py`, `conditions_registry.py`, `tests/test_conditions.py`, `tests/test_conditions_registry.py` | T-001–T-047 | All pass; `max_digits`/`decimal_places`/`decimal_whole_digits` boundaries (T-019/T-020) explicitly confirmed, not just `max_digits`/`max_places` | A standalone, usable create-once registry — independently revertible. |
| **2 — Revision, idempotency, Application Service** | `declare_conditions` (retry, conflict, predecessor resolution, `ConditionsValidationError`/`ConditionsPersistenceError` wrapping), `load_conditions`/`list_conditions` | `conditions_service.py`, `tests/test_conditions_service.py` | T-048–T-069 | All pass; the new `ConditionsPersistenceError` scenario (T-065) demonstrably implemented, not merely specified in prose | A fully functional Application Service — independently revertible to Checkpoint 1's state. |
| **3 — CLI and activity logging** | Four `conditions_app` commands, with the corrected, symmetric exception-handling lists per Section 22.0's coverage table | `cli.py` (additive only), `tests/test_cli.py` (additive only) | T-070–T-090 | All pass; T-078/T-079/T-084 (the three new/corrected CLI scenarios) demonstrably implemented; T-090's cross-command symmetry check passes against the full, corrected coverage table | A complete, user-facing feature — independently revertible to Checkpoint 2's state. |
| **4 — Cumulative validation and legacy reconciliation** | No new production code expected; full-suite and non-regression confirmation | None beyond Checkpoints 1–3 | T-091–T-093 (T-094–T-099 confirmed by this document's own text) | Full suite green; diff audit confirms the allowlist was respected exactly | The final, reviewable state of the increment. |

## 29. Risks and Limitations

Unchanged, with one addition: **the `decimal_whole_digits` constraint, while already an intrinsic consequence of `max_digits=12, decimal_places=6` (not a new limit introduced by this correction), was previously undocumented** — any prior reasoning about the schema's acceptance envelope based only on "≤ 12 total digits" would have been incorrect for any value with more than 6 integer-part digits; this correction closes that documentation gap, but it is recorded here as a reminder that a numeric constraint's *full* behavior should always be verified empirically against the exact library in use, not inferred from a constraint's name alone. All other risks (scope creep, silent "most recent" defaulting, the TOCTOU window, the five DeepSeek alerts, branching fan-out, the specification-level nature of the `12`/`6` choice) are unchanged from `07`.

## 30. Out of Scope

Unchanged, exhaustive: pKa calculation; protonation execution; microstate generation; predominant-tautomer selection; any executable chemistry; any change to tautomer enumeration; conformer generation; geometry optimization; force fields; MOPAC; HF; DFT; STO; GTO; receptor preparation; docking; `Pose` modeling; a GUI; an educational mode; automatic recommendation of any kind; a database; a scheduler; AI/ML of any kind; environmental or biological simulation; any modification to `ExecutionAttempt`; migration of historical records (including `ibuprofen-deprotonation-001`); temperature, solvent, medium, ionic strength, pressure, concentration, physical state, or computed chemical properties in the schema 1.0 field list; generic `Evidence`; arbitrary/generic metadata; engine-capability abstraction; workflow/pipeline modeling; a user/identity system; an ontology; RDF; JSON-LD. No code, test, or documentation change of any kind beyond this final specification document.

## 31. Open Questions

Unchanged from `07`, reconfirmed by `08` with no new item raised:

1. `Decimal` width/precision bound — **CLOSED** (Section 14, now additionally complete with all three native constraints named).
2. `conditions list` filter option — **DEFERRED — NON-BLOCKING**.
3. Future `schema_version "1.1"` for `ScientificConditionsDeclaration` itself — **DEFERRED — NON-BLOCKING**.
4. Exact CLI table/banner formatting — **DEFERRED — NON-BLOCKING**, conditioned on banners/fields/ordering/errors already being normative, which they are.

No item requires a mandatory spike.

## 32. Conditions for Freezing — All Met

This specification was frozen because every one of the following was confirmed, by `14`'s short, final, decisive review, before this document was produced:

1. The candidate's (`13`'s) documentary-only promotion from `11` was genuine — no technical, scientific, or normative content had been altered in that process. **Confirmed by `14`.**
2. The normative test matrix (Section 25) was textually identical to `11`'s own matrix — same 99 rows, same `T-001`–`T-099` sequence, same files, same checkpoints, same delta accounting (`94 + 6 − 1 = 99`). **Confirmed by `14`.**
3. The allowlist (Section 27, eight files) and the four-checkpoint plan (Section 28) were unchanged from `11`. **Confirmed by `14`.**
4. Section 31's open questions remained correctly classified — `Decimal` width/precision `CLOSED`; `conditions list` filtering, a future `schema_version "1.1"`, and CLI cosmetic formatting all `DEFERRED — NON-BLOCKING` — none newly treated as a pending decision blocking freezing. **Confirmed by `14`.**
5. No new scope item had been introduced beyond Sections 10–11 without a separate, explicit scientific decision of the same rigor as the one governing this increment. **Confirmed by `14`.**
6. The sole finding `14` raised — one MINOR, three self-referential phrase occurrences — was corrected exactly as authorized, with zero technical contract impact. **Performed by this document (Section 4).**

All six conditions are met. **This specification is frozen.** It authorizes implementation under the allowlist (Section 27) and checkpoint plan (Section 28) exactly as specified, starting from Checkpoint 1.

## 33. Final State

This document freezes the Increment 019 specification for `ScientificConditionsDeclaration`. It promotes `13`'s already-approved, already-reviewed technical content into final form, performing exactly one substantive act — the three-phrase MINOR correction `14` authorized (Section 4) — plus the documentary reframing from "candidate, not frozen" to "final specification, frozen," confined to Sections 1–4 and 32–33 plus this terminal status block. Every other section, from Section 5's full reconciliation history through Section 31's open questions — including the complete scientific/technical contract, the 99-row normative test matrix, the eight-file allowlist, and the four-checkpoint plan — is carried forward from `13` unchanged. All four original MAJORs, all six original MINORs, and all four original NOTEs from the first draft's review are resolved; the one new MAJOR and two new MINORs from the revised draft's short decisive review are resolved; the one bookkeeping MINOR and one bookkeeping NOTE from `11`'s own micro-review are resolved; the one final-review MINOR is resolved by this document. No finding from any of the fourteen prior governance artifacts remains open. **This specification is ready for implementation. Implementation has not been performed by this document or by any action taken while producing it** — opening an implementation branch and writing code against Checkpoint 1 (Section 28) is a separate, later, and distinct act.

---

## Final Verification

```
INCREMENT 019 FINAL SPECIFICATION COMPLETE: YES
CANDIDATE IDENTITY VERIFIED: YES
FINAL REVIEW RECONCILED: YES
REQUIRED MINOR CORRECTED: YES
TECHNICAL CONTRACT CHANGES: 0
SCIENTIST-DECLARED CONDITIONS PRESERVED: YES
LEGACY TRANSFORMATION PH PRESERVED: YES
NORMATIVE TEST MATRIX PRESERVED: YES
NORMATIVE SCENARIOS: 99
ALLOWLIST FROZEN: YES
CHECKPOINT PLAN FROZEN: YES
MANDATORY SPIKES IDENTIFIED: NO
READY FOR IMPLEMENTATION: YES
FINAL SPECIFICATION FROZEN: YES
IMPLEMENTATION PERFORMED: NO
REPOSITORY MODIFIED: NO
```
