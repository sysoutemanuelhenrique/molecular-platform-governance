# FINAL SPECIFICATION — INCREMENTO 018
## Promoção auditável de LigandInput RAW para ScientificEntity e MolecularState

**Projeto:** Turing Bohr Molecular Platform
**Natureza:** especificação final, autossuficiente e congelada. Incorpora integralmente as decisões sustentadas pelos três spikes obrigatórios (RD-018-01, FS-018-01, FS-018-02), por suas revisões adversariais/reconciliações, e pela revisão adversarial final curta e decisiva da candidata (`increments/018/10-final-review/INCREMENT_018_FINAL_SPECIFICATION_CANDIDATE_SHORT_REVIEW.md`, 195 linhas, 21.627 bytes, SHA-256 `6250bd6999d22798868be0710be5d5e8e7197d64745303e8d163dfda34bf52d7`), que concluiu com **0 blockers, 0 majors, 1 minor evidencial (corrigido nesta versão, § 2.3) e `VERDICT: APPROVE`**. **Este documento está congelado** e **autoriza implementação**, a partir do HEAD confirmado (§ 2).
**Data:** 2026-09-29
**Baseline:** `main` em `4aaeed12515ed14580b16240dd4d253a11c4d68e`
**Escopo escolhido:** Opção B com a fundação mínima de lineage da Opção A (inalterado desde o rascunho original)
**Revisão:** 5 (final, congelada, pós-revisão final)

Este documento é **autossuficiente**: um implementador não precisa ler o rascunho pré-spike, a candidata nem os relatórios de spike para entender o contrato. Toda decisão relevante derivada de spike está reproduzida aqui, com a evidência citada por caminho, identidade (linhas/bytes/SHA-256) e número de seção da fonte.

---

## 0. Natureza deste documento e histórico de correções

### 0.1 O que este documento é

Este é a **especificação final e congelada** do Incremento 018. Ele substitui a candidata (revisão 4, `increments/018/09-final-specification/INCREMENT_018_FINAL_SPECIFICATION_CANDIDATE.md`) e o rascunho pré-spike (revisão 3) como **versão documental corrente e autoritativa**, mas não apaga, corrige nem reescreve nenhum documento anterior — todos permanecem intactos em seus próprios diretórios de governança, como registro histórico do processo:

| Documento anterior | Caminho | Papel |
|---|---|---|
| Rascunho original (revisão 1) | `increments/018/03-draft-specification/INCREMENT_018_RAW_TO_SCIENTIFIC_PROMOTION_DRAFT_SPEC.md` | primeira proposta técnica, superada |
| Revisão adversarial do rascunho original | `increments/018/04-draft-review/INCREMENT_018_DRAFT_SPECIFICATION_ADVERSARIAL_REVIEW.md` | fonte de MAJOR-1, MINOR-1 a 4, NOTES 1-3 |
| Rascunho revisado (revisão 2) | `increments/018/05-revised-draft/INCREMENT_018_RAW_TO_SCIENTIFIC_PROMOTION_DRAFT_REVISED.md` | incorporou MAJOR-1/MINOR-1-4/NOTES-1-3 |
| Revisão adversarial curta do rascunho revisado | `increments/018/06-revised-draft-review/INCREMENT_018_REVISED_DRAFT_SHORT_ADVERSARIAL_REVIEW.md` | fonte de MINOR-NOVO-1, NOTE-NOVA-1 a 3 |
| Rascunho pré-spike (revisão 3) | `increments/018/07-pre-spike/INCREMENT_018_RAW_TO_SCIENTIFIC_PROMOTION_DRAFT_PRE_SPIKE.md` | resolveu MINOR-NOVO-1; preparou os três spikes obrigatórios; superado como versão corrente |
| RD-018-01 (relatório, revisão, reconciliação) | `increments/018/08-spikes/RD-018-01/`, `RD-018-01-review/`, `RD-018-01-reconciliation/` | spike de parsing RDKit; fonte das decisões da § 9 |
| FS-018-01 (relatório, revisão) | `increments/018/08-spikes/FS-018-01/`, `FS-018-01-review/` | spike de path/links/snapshot; fonte das decisões da § 8 |
| FS-018-02 (relatório) | `increments/018/08-spikes/FS-018-02/` | spike de reserva cross-process; fonte das decisões da § 11 |
| Candidata à especificação final (revisão 4) | `increments/018/09-final-specification/INCREMENT_018_FINAL_SPECIFICATION_CANDIDATE.md` | consolidou os três spikes; superada como versão corrente por este documento |
| Revisão final curta e decisiva | `increments/018/10-final-review/INCREMENT_018_FINAL_SPECIFICATION_CANDIDATE_SHORT_REVIEW.md` | 0 blockers, 0 majors, 1 minor evidencial, `VERDICT: APPROVE`, `READY FOR FREEZE: YES` |

### 0.2 Baseline (inalterada durante todo o processo)

```text
main / origin/main: 4aaeed12515ed14580b16240dd4d253a11c4d68e
git status --short:  ?? increment-009-review.txt (único untracked)
git diff --check:    limpo
```

Nenhuma mudança de baseline ocorreu durante a execução dos três spikes, durante a produção da candidata, durante a revisão final, nem durante a produção deste documento de congelamento. Cada uma dessas oito etapas (RD-018-01, sua revisão, sua reconciliação, FS-018-01, sua revisão, FS-018-02, a candidata, e a revisão final) reconfirmou independentemente HEAD/`origin/main` idênticos e `git status --short`/`git diff --check` inalterados. Este documento reconfirmou o mesmo estado antes de ser escrito.

### 0.3 Documentos-base confirmados

**Rascunho pré-spike:**

| Item | Valor |
|---|---|
| Caminho | `increments\018\07-pre-spike\INCREMENT_018_RAW_TO_SCIENTIFIC_PROMOTION_DRAFT_PRE_SPIKE.md` |
| Linhas | 1.841 |
| Bytes | 113.404 |
| SHA-256 | `a93356d01de285e41362840e714bec156ac9fa76892c9046dc716fc47e194d3f` |

**Candidata à especificação final:**

| Item | Valor |
|---|---|
| Caminho | `increments\018\09-final-specification\INCREMENT_018_FINAL_SPECIFICATION_CANDIDATE.md` |
| Linhas | 1.779 |
| Bytes | 130.461 |
| SHA-256 | `e0e587ada87f4044646c0423275a448ce50ac07e4149c676689fc89c45339f59` |

**Revisão final curta e decisiva:**

| Item | Valor |
|---|---|
| Caminho | `increments\018\10-final-review\INCREMENT_018_FINAL_SPECIFICATION_CANDIDATE_SHORT_REVIEW.md` |
| Linhas | 195 |
| Bytes | 21.627 |
| SHA-256 | `6250bd6999d22798868be0710be5d5e8e7197d64745303e8d163dfda34bf52d7` |

Todas as três identidades foram confirmadas nesta sessão antes de qualquer edição, e conferem exatamente com o exigido pela tarefa — nenhuma divergência em nenhuma das oito verificações independentes já realizadas ao longo de todo o processo (RD-018-01, sua revisão, FS-018-01, sua revisão, FS-018-02, a candidata, a revisão final, e este documento).

### 0.4 Congelamento

Este documento **congela a especificação final e autoriza implementação** (`FINAL SPECIFICATION FROZEN: YES`, `READY FOR IMPLEMENTATION: YES`). A revisão final curta e decisiva (§ 0.3) já ocorreu e concluiu com **0 blockers, 0 majors, 1 minor evidencial e `VERDICT: APPROVE`**, `READY FOR FREEZE: YES`. A única correção indicada por essa revisão (MINOR-1, qualificação evidencial sobre o primeiro bug do harness de FS-018-02) foi aplicada literalmente em § 2.3, item 4, abaixo — nenhuma outra alteração de conteúdo foi feita em relação à candidata. A implementação pode começar em um branch novo a partir do HEAD confirmado (§ 2), seguindo o plano informativo da § 25, após novo baseline local/`pytest` nesse branch.

---

# 1. Papel e limites

Este documento fixa o contrato final e congelado do Incremento 018. Ele autoriza implementação a partir do congelamento confirmado pela revisão final sem blocker/major (0 blockers, 0 majors, `VERDICT: APPROVE`, § 0.4). Seu objetivo é transformar um `LigandInput` já persistido em um primeiro `MolecularState` auditável, sem misturar aquisição HTTP, protonação, preparo 3D ou docking.

Fluxo pretendido:

```text
LigandInput existente
  → referência RAW validada
  → snapshot privado e verificado (Rota B endurecida, § 8)
  → interpretação SDF explícita (política confirmada por RD-018-01, § 9)
  → ScientificEntity nova ou preexistente
  → MolecularState inicial
  → ScientificInputPromotionRecord (reserva/claims por criação exclusiva, § 11, confirmado por FS-018-02)
  → entrada possível para state enumerate-tautomers
```

Esta versão:

- fixa os defaults científicos (confirmados por RD-018-01);
- fixa o mecanismo de segurança de path/identidade (confirmado por FS-018-01, Rota B endurecida);
- fixa a primitiva de reserva/concorrência (confirmada por FS-018-02, criação exclusiva por `os.mkdir`);
- não altera o repositório;
- não executa `pytest`;
- não é prompt de implementação;
- incorpora integralmente as evidências e decisões dos três spikes obrigatórios e de todas as suas revisões/reconciliações, mais a revisão adversarial final.

---

# 2. Baseline

## 2.1 Snapshot confirmado

```text
4aaeed12515ed14580b16240dd4d253a11c4d68e
Merge pull request #4 from sysoutemanuelhenrique/hotfix/increment-017-path-redaction-connectors
```

Idêntico ao confirmado por todas as etapas anteriores, incluindo os três spikes, a candidata e a revisão final. Nenhuma mudança de baseline ocorreu em nenhum momento do processo.

## 2.2 Entradas documentais e de spike

Rascunho pré-spike (§ 0.3): 1.841 linhas, 113.404 bytes, SHA-256 `a93356d01de285e41362840e714bec156ac9fa76892c9046dc716fc47e194d3f`.

| Spike | Relatório (linhas/bytes/SHA-256) | Revisão adversarial | Reconciliação |
|---|---|---|---|
| RD-018-01 | 358 / 32.880 / `f346af07…d0074` | 299 / 43.553 / `68306521…9b4317c` — `APPROVE WITH NON-BLOCKING NOTES` | `INCREMENT_018_RD_018_01_RECONCILIATION.md` — `RECONCILED PASS WITH LIMITATIONS` |
| FS-018-01 | 312 / 31.212 / `0f3a195c…8cee6` | **197 linhas / 37.923 bytes / SHA-256 `19875b91fef5b8c701a2e1e2a0d5069d2eef18c9b0a271d92ff9fcf7f7e73736`** — `PASS WITH LIMITATIONS` (`RECONCILED FS-018-01 CLASSIFICATION`) | integrada na própria revisão (§ 17-19 daquele documento), sem documento separado |
| FS-018-02 | **92 linhas / 11.661 bytes / SHA-256 `572fdaab25ddf68a3a019d1186c8e161d6304f9a22403fb9993e8db670e36d92`** | sem revisão adversarial separada (spike de escopo estreito, 8 cenários, executado e auto-verificado em duas rodadas — ver § 2.3) | — |

Todas as identidades acima foram recomputadas de forma independente ao longo do processo (candidata e revisão final), nunca copiadas de nenhum texto.

## 2.3 Verificação específica de FS-018-02 antes de uso (exigida pela tarefa que produziu a candidata)

Antes de incorporar qualquer conclusão de FS-018-02 à candidata, foram executadas as seguintes verificações:

1. **Linhas/bytes/SHA-256 do relatório** — recomputados: 92 linhas, 11.661 bytes, SHA-256 `572fdaab25ddf68a3a019d1186c8e161d6304f9a22403fb9993e8db670e36d92`. Idêntico ao valor já registrado em `FS-018-02/MANIFEST_SHA256.txt`.
2. **Recálculo de todos os hashes do manifesto** — os 6 arquivos permanentes de FS-018-02 (`INCREMENT_018_FS_018_02_REPORT.md`, `evidence/results.json`, `evidence/summary.csv`, `evidence/stdout.log`, `evidence/stderr.log`, `scripts/fs_018_02.py`) foram rehashados (SHA-256 completo) e comparados byte a byte contra `MANIFEST_SHA256.txt` — **6/6 idênticos**, incluindo `evidence/stderr.log` (arquivo vazio, hash `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` — o SHA-256 canônico da string vazia, consistente com uma execução sem erro).
3. **Confirmação dos 8 cenários** — `evidence/results.json` contém exatamente 8 entradas (`S01`-`S08`), todas com `"pass": true`, `overall_pass: true`, duração total `2.3251s`. Estrutura, contagem e nomes conferem exatamente com o relatório.
4. **Confirmação de que somente a execução final corrigida sustenta as conclusões** — o script preservado (`scripts/fs_018_02.py`) é a versão **corrigida**: uma primeira execução revelou dois defeitos no próprio protótipo — (a) o self-release do vencedor comparava contra o diretório-base do claim, não contra o diretório do slot com hash, produzindo `NO_METADATA_REFUSE` mesmo em releases bem-sucedidos; (b) três verificações de cenário (S02/S03/S04) dependiam incorretamente de arquivos remanescentes em vez dos resultados registrados por processo. Ambos os defeitos foram corrigidos no próprio script antes da execução final preservada; `evidence/results.json`, `evidence/summary.csv`, `evidence/stdout.log` e o próprio `scripts/fs_018_02.py` preservados **são exclusivamente os da execução final corrigida** — nenhum artefato da execução com bug foi preservado como evidência permanente. **O segundo defeito (verificações de S02/S03/S04 dependendo de arquivos remanescentes) é corroborado por comentários explicativos presentes no próprio `scripts/fs_018_02.py` preservado. O primeiro defeito (self-release comparando o diretório errado) é consistente com o comportamento observado no script preservado, mas não possui corroboração direta em comentário de código nem em artefato da execução anterior — que, por desenho, não foi preservada.**

Nenhum spike foi reexecutado por esta verificação; apenas os artefatos já preservados foram relidos e rehashados. **Correção aplicada:** a última frase do item 4 acima (a partir de "O segundo defeito...") foi acrescentada neste documento em atendimento literal ao MINOR-1 da revisão final (§ 4 daquele documento), qualificando o grau de corroboração dos dois defeitos sem alterar nenhuma conclusão de arquitetura — os 8/8 cenários da execução final preservada permanecem válidos, os hashes batem 6/6 contra o manifesto, e o comportamento atual do código é correto e consistente com a política normativa em qualquer um dos dois casos.

---

# 3. Fontes

## 3.1 Código real

Confrontados no SHA obrigatório (`4aaeed12515ed14580b16240dd4d253a11c4d68e`): `inputs.py`, `registry.py`, `pubchem.py`, `scientific.py`, `scientific_registry.py`, `atomic.py`, `rdkit_tautomer.py`, `application.py`, `cli.py`, registries de execution/transformation, testes correspondentes. Nenhuma mudança de baseline ocorreu desde a última verificação.

## 3.2 Documentação externa e evidência empírica dos spikes

- RDKit 2026.03.6 real (`SDMolSupplier`), exercitado empiricamente em 144 células por RD-018-01;
- Windows 11/NTFS real, exercitado empiricamente em 44 cenários nomeados (50 entradas com sub-janelas) por FS-018-01;
- primitivas de filesystem stdlib (`os.mkdir`, `os.link`, `os.replace`, `ctypes`/`kernel32`), exercitadas empiricamente em 8 cenários com processos reais por FS-018-02.

Nenhuma fonte externa substitui o comportamento observado no código do snapshot nem a evidência empírica dos três spikes.

---

# 4. Escopo escolhido

**Sem alteração desde o rascunho pré-spike.**

## 4.1 Entrega funcional

1. exatamente uma tentativa auditável;
2. exatamente uma `ScientificEntity` nova ou uma associação explícita a entidade preexistente;
3. exatamente um `MolecularState` inicial novo;
4. uma representação SDF composta pelos mesmos bytes do snapshot validado;
5. exatamente um `ScientificInputPromotionRecord` de sucesso por chave semântica;
6. activity best effort para a tentativa;
7. erro estruturado e resíduos quando a operação falhar.

## 4.2 Rejeições de escopo

- a operação não baixa PubChem;
- não aceita `ProteinInput`;
- não aceita formatos além de SDF;
- não escolhe tautômero, protômero ou pH;
- não cria `Conformer`;
- não normaliza, neutraliza, dessaliniza ou reserializa a molécula;
- não usa nome, CID, InChIKey ou propriedade SD como identidade interna automática.

Ver também § 24 para a lista explícita de padrões de proveniência/interoperabilidade que permanecem fora do escopo normativo deste incremento.

## 4.3 Cardinalidade

`1 input RAW → 1 entity associada → 1 state inicial → 1 lineage record` por promoção sem token. SDF com zero, mais de um registro ou qualquer registro ilegível é rejeitado.

---

# 5. Fatos confirmados no código

**Preservada sem alteração de conteúdo** — nenhum spike toca estes 17 fatos; todos permanecem válidos sem reverificação adicional.

1. `LigandInput` contém `AcquisitionRecord` e `RawArtifact(path, format, checksum)`.
2. `RawArtifact.path` exige somente string não vazia; não possui as proteções de `MolecularRepresentationRef.path`.
3. `register_ligand` cria paths relativos e copia bytes com checksum, mas YAML posteriormente alterado pode apontar para outro local.
4. `load_ligand` valida o modelo; não refaz hash do artefato em cada leitura.
5. `ScientificEntity` contém identidade interna mínima; não contém origem RAW.
6. `MolecularState` aponta para entity e representação; não contém `input_id`.
7. Não existe lineage formal `LigandInput → MolecularState`.
8. `register_entity` não possui remoção pública.
9. `_remove_state_best_effort` é privado e só é seguro para state recém-criado pelo mesmo fluxo.
10. `register_state` copia uma fonte para staging, compara checksums, publica o diretório e grava metadata atomicamente.
11. Os registries são atomicamente locais, não transacionais entre si.
12. `check_storage_identity_conflict` reduz colisões exatas/casefold, mas documenta janela TOCTOU.
13. O único módulo de produção que importa RDKit é `rdkit_tautomer.py`.
14. `Chem.SDMolSupplier(str(path))` é usado atualmente com defaults na enumeração — **confirmado por RD-018-01 (§ 9.2) que isso equivale hoje a `sanitize=True, removeHs=True, strictParsing=True` (C8), diferente da política final deste documento**.
15. O RDKit é dependência opcional `rdkit==2026.3.6`.
16. `ExecutionAttempt` vigente só modela `operation_type="state-transformation"`; promoção RAW não deve ser fingida como transformação estado→estado.
17. Activity é best effort e não é source of truth.

---

# 6. Modelos propostos

**Preservada sem alteração de conteúdo desde o rascunho pré-spike** — confirmada, empiricamente, por RD-018-01 (as 8 combinações de `LigandPromotionPolicy` foram construídas e exercitadas sem erro de validação) e indiretamente por FS-018-02 (nenhum modelo de domínio foi tocado pelo spike de reserva). Todos os modelos são Pydantic, `frozen=True`, `extra="forbid"`.

## 6.1 `LigandPromotionPolicy`

```python
class LigandPromotionPolicy(BaseModel):
    schema_version: Literal["1.0"] = "1.0"
    source: Literal["scientist"] = "scientist"
    sanitize: bool = True
    remove_hs: bool = False
    strict_parsing: bool = True
    record_policy: Literal["exactly-one"] = "exactly-one"
    component_policy: Literal["reject-disconnected"] = "reject-disconnected"
    charge_policy: Literal["preserve"] = "preserve"
    stereo_policy: Literal["preserve"] = "preserve"
    representation_policy: Literal["verified-source-bytes"] = "verified-source-bytes"
```

`sanitize`, `remove_hs` e `strict_parsing` são `bool` puro. O espaço representável é as 8 combinações booleanas completas (§ 9.3); a combinação `sanitize=True, remove_hs=False, strict_parsing=True` é a **única combinação usada pelo fluxo de produção** (CLI, § 15.1) — **confirmada por RD-018-01** como a única, entre as 8, que rejeita corretamente uma estrutura com valência inválida sem mascaramento (§ 9.2, § 9.3 abaixo). As 7 combinações não-default são exercitadas apenas por spike/testes, nunca pela CLI.

## 6.2 `PromotionStatus` e `PromotionPhase`

```python
PromotionStatus = Literal[
    "started", "resolved", "resolution_failed", "execution_failed", "succeeded",
]
PromotionPhase = Literal["resolution", "execution"]
```

`resolution_failed`, `execution_failed` e `succeeded` são terminais.

## 6.3 `ResolvedLigandPromotionSnapshot`

```python
class ResolvedLigandPromotionSnapshot(BaseModel):
    schema_version: Literal["1.0"] = "1.0"
    engine_name: Literal["rdkit"]
    engine_version: str
    input_format: Literal["sdf"]
    raw_checksum_persisted: str
    snapshot_checksum: str
    snapshot_size_bytes: int = Field(ge=1)
    sanitize: bool
    remove_hs: bool
    strict_parsing: bool
    record_count: Literal[1]
    fragment_count: Literal[1]
    formal_charge: int
    atom_count: int = Field(ge=1)
    explicit_hydrogen_count: int = Field(ge=0)
    isotopic_hydrogen_count: int = Field(ge=0)
    warnings: tuple[str, ...] = ()
```

Invariantes inalteradas desde o rascunho pré-spike. Ver § 9 para a proveniência exata (solicitado vs. efetivo vs. não introspectável) de `sanitize`/`remove_hs`/`strict_parsing`, fechada por RD-018-01.

## 6.4 `AcquisitionProvenanceSnapshot`

```python
class AcquisitionProvenanceSnapshot(BaseModel):
    schema_version: Literal["1.0"] = "1.0"
    method: Literal["uploaded", "downloaded"]
    source_name: str | None = None
    source_identifier: str | None = None
    source_uri: str | None = None
    acquired_at: datetime
    raw_artifact_path: str
    raw_artifact_format: str
    raw_artifact_checksum: str
    pubchem_cid: int | None = None
    pubchem_record_type: Literal["2d"] | None = None
```

## 6.5 `PromotionResultSnapshot`

```python
class PromotionResultSnapshot(BaseModel):
    schema_version: Literal["1.0"] = "1.0"
    promotion_id: str
    entity_id: str
    state_id: str
    representation: MolecularRepresentationRef
    entity_created: bool
    state_created: bool
    reused_existing_promotion: bool
```

Se `reused_existing_promotion=True`, `entity_created` e `state_created` devem ser `False`.

## 6.6 `LigandPromotionError`

```python
class LigandPromotionError(BaseModel):
    schema_version: Literal["1.0"] = "1.0"
    phase: PromotionPhase
    code: str
    message: str
    residual_entity_ids: tuple[str, ...] = ()
    residual_state_ids: tuple[str, ...] = ()
    residual_reservation_keys: tuple[str, ...] = ()
```

`code` pertence à taxonomia da § 17, incluindo o código adicional confirmado por FS-018-01 (`raw-permission-denied`) e o código confirmado por FS-018-02 (`promotion-primitive-unavailable`).

## 6.7 `LigandPromotionAttempt`

```python
class LigandPromotionAttempt(BaseModel):
    schema_version: Literal["1.0"] = "1.0"
    id: str
    input_id: str
    requested_entity_id: str
    requested_state_id: str
    requested_entity_name: str
    intentional_revision: str | None = None
    requested: LigandPromotionPolicy
    status: PromotionStatus
    semantic_key: str | None = None
    resolved: ResolvedLigandPromotionSnapshot | None = None
    result: PromotionResultSnapshot | None = None
    error: LigandPromotionError | None = None
    created_at: datetime
    resolved_at: datetime | None = None
    finished_at: datetime | None = None
```

## 6.8 `ScientificInputPromotionRecord`

Commit marker e aresta formal de lineage, existente apenas em sucesso:

```python
class ScientificInputPromotionRecord(BaseModel):
    schema_version: Literal["1.0"] = "1.0"
    id: str                  # igual ao semantic_key SHA-256
    semantic_key: str
    input_id: str
    acquisition: AcquisitionProvenanceSnapshot
    policy: LigandPromotionPolicy
    resolved: ResolvedLigandPromotionSnapshot
    entity_id: str
    state_id: str
    representation: MolecularRepresentationRef
    created_by_attempt_id: str
    intentional_revision: str | None = None
    created_at: datetime
```

Invariantes: `id == semantic_key`; checksum da representação igual ao snapshot; entity/state/representation coerentes antes do commit; nunca carrega estado de falha; **nunca pode ser sobrescrito — confirmado empiricamente por FS-018-02 (criação exclusiva via `os.link`, S01/S02/S08)**.

## 6.9 Matriz de `LigandPromotionAttempt`

| status | semantic_key | resolved | result | error | resolved_at | finished_at |
|---|---|---|---|---|---|---|
| `started` | `None` | `None` | `None` | `None` | `None` | `None` |
| `resolved` | presente | presente | `None` | `None` | presente | `None` |
| `resolution_failed` | opcional | opcional | `None` | phase `resolution` | opcional | presente |
| `execution_failed` | presente | presente | `None` | phase `execution` | presente | presente |
| `succeeded` | presente | presente | presente | `None` | presente | presente |

## 6.10 Exemplo YAML (vetor golden preservado)

Ver § 10.3 para o vetor de teste canônico completo, idêntico ao das revisões anteriores e não afetado por nenhum spike.

---

# 7. Política de promoção

## 7.1 Política final

| decisão | valor final | justificativa | estado |
|---|---|---|---|
| formato | SDF | único formato já usado pelo fluxo PubChem/tautômeros | fixado |
| registros | exatamente um | evita ambiguidade 1→N; algoritmo confirmado por RD-018-01 § 13 | fixado |
| sanitização | `True` | exigir estrutura válida; **confirmado por RD-018-01** como a única forma de rejeitar corretamente estrutura de valência inválida | **confirmado** |
| remoção de H | `False` | preservar H explícito/isotópico; **confirmado por RD-018-01** — `removeHs=True` mascara um erro de valência real, transformando-o silenciosamente em outra molécula | **confirmado** |
| parsing estrito | `True` | não aceitar tolerância silenciosa; **RD-018-01 não encontrou efeito comportamental observável** com as 18 fixtures testadas — mantido por completude/proveniência, não por efeito comprovado (regra A/B/C, § 9.4) | **confirmado com limitação registrada** |
| fragmentos | rejeitar `>1` | não dessalinizar implicitamente | fixado |
| carga | preservar | não neutralizar | fixado |
| stereo indefinida | preservar e warning | não inventar configuração | fixado |
| representação | mesmos bytes do snapshot | evita transformação silenciosa/reserialização | fixado |

**Os três parâmetros RDKit devem ser sempre passados explicitamente** pelo código de produção — nunca depender de defaults implícitos da biblioteca. RD-018-01 confirmou empiricamente que os defaults nativos do RDKit 2026.03.6 são `sanitize=True, removeHs=True, strictParsing=True` (a combinação C8), diferente da política final deste documento, e que o código de produção atual (`Chem.SDMolSupplier(str(path))` sem kwargs, Fato 14) está hoje, implicitamente, sob C8.

## 7.2 Propriedades SD

Sem alteração desde o rascunho pré-spike. Propriedades SD produzem apenas warnings controlados; não selecionam entity/state, não mudam IDs e não bloqueiam sozinhas uma estrutura válida.

## 7.3 Saída científica

Sem alteração. O `MolecularState` representa a connection table aceita conforme a política. O SDF publicado permanece byte a byte igual ao snapshot.

---

# 8. Segurança do RAW

**Esta seção incorpora integralmente as decisões de FS-018-01**, substituindo a formulação condicional "Rota A ou Rota B, a decidir por spike" do rascunho pré-spike por um mecanismo único, normativo e comprovado empiricamente.

## 8.1 Path lexical

Sem alteração desde o rascunho pré-spike:

| entrada | resultado |
|---|---|
| absoluto POSIX | rejeitar |
| absoluto Windows com drive | rejeitar |
| UNC | rejeitar |
| drive-relative | rejeitar |
| `.` ou `..` como componente | rejeitar |
| backslash em path canônico POSIX | rejeitar |
| path vazio | rejeitar |
| prefixo diferente de `inputs/ligands/<input_id>/` | rejeitar |

## 8.2 Contenção real — decisão fechada por FS-018-01

Raiz autorizada: `<project_dir>/inputs/ligands/<input_id>/`.

**Decisão normativa, confirmada empiricamente (FS-018-01, § 11 do relatório, achado central):**

> `str(candidate).startswith(str(root))` — nem antes, nem depois de `resolve()` — **nunca** deve ser usado como prova de contenção. FS-018-01 construiu um caso concreto e reproduzível (`allowed_root_EVIL`, um diretório irmão cujo nome começa com o mesmo texto de `allowed_root`) em que `resolve()` seguido de `startswith()` continua retornando `True` incorretamente. A única comparação correta observada empiricamente foi `Path.is_relative_to()` (comparação por componentes de caminho, nunca por substring).

Requisitos normativos:

1. resolver `project_dir` e raiz;
2. verificar cada componente existente com política de links (§ 8.3);
3. rejeitar symlink, junction ou reparse point em **qualquer** componente do caminho, final ou ancestral (§ 8.3);
4. resolver o candidato em modo estrito;
5. exigir **`resolved_candidate.is_relative_to(resolved_root)`** — nunca `startswith()`, em nenhuma forma, mesmo pós-`resolve()`;
6. exigir arquivo regular;
7. nunca mostrar o path absoluto em erro público.

## 8.3 Mecanismo normativo: Rota B endurecida — decisão fechada por FS-018-01

### 8.3.0 Por que apenas uma rota

O rascunho pré-spike definia Rota A (nativa, baseada em descritores relativos ao estilo `openat`/`dir_fd`) e Rota B (fallback baseado em `lstat`/`fstat` por nome), deixando a FS-018-01 decidir qual(is) seria(m) suportada(s) em cada plataforma. **FS-018-01 determinou empiricamente que `os.supports_dir_fd` é `False` no CPython 3.14 sobre Windows** (§ 6 do relatório) — a técnica de encadeamento de descritores que a Rota A propunha avaliar preferencialmente **não está disponível** na superfície `stdlib + ctypes(kernel32)` usada pelo spike. Como consequência, a implementação real da Rota A construída pelo spike **degradou para o mesmo mecanismo de validação de ancestrais por nome que a Rota B usa**, acrescida apenas de uma sondagem nativa adicional do componente final via `CreateFileW(..., FILE_FLAG_OPEN_REPARSE_POINT)` — sem jamais alcançar a garantia estrutural de fechamento de corrida que a técnica `openat` teoricamente oferece.

A revisão adversarial de FS-018-01 reconciliou a classificação: **Rota A: `PASS WITH LIMITATIONS`** (carece de reverificação de existência/identidade do arquivo final **após** a leitura — a única assimetria real encontrada entre as rotas, cenário de remoção-durante-leitura); **Rota B: `PASS`** (fecha essa lacuna via reverificação lexical pós-leitura); **FS-018-01 (classificação reconciliada): `PASS WITH LIMITATIONS`**.

**Decisão normativa para o Incremento 018, schema 1.0:**

> A **Rota B endurecida** é o único mecanismo normativo de abertura sem seguir link para o Windows 11/NTFS local validado por este spike. **A Rota A não será implementada no Incremento 018.** Ela permanece apenas como possibilidade futura, condicionada, cumulativamente, a: (a) verificação pós-leitura equivalente à da Rota B; (b) contrato integral de ancestrais idêntico ao exigido aqui; (c) um novo spike específico que prove a técnica de descritores relativos disponível e suficiente na plataforma-alvo; (d) nenhuma degradação silenciosa para um mecanismo mais fraco quando a técnica nativa não estiver disponível.

Este documento especifica **apenas** a Rota B endurecida como mecanismo de produção. Todo texto anterior que descrevia "Rota A ou Rota B" é substituído por esta única rota.

### 8.3.1 Contrato de identidade da cadeia completa de ancestrais (preservado do rascunho pré-spike, agora exclusivo da Rota B)

1. **Captura da cadeia completa de ancestrais** entre a raiz RAW autorizada e o arquivo final, incluindo todo componente de diretório intermediário;
2. **identidade inicial de cada componente ancestral** capturada via `lstat` antes de qualquer abertura, da raiz até o diretório pai imediato;
3. **tipo de cada componente** determinado sem seguir links (`lstat`, nunca `stat`);
4. **detecção de symlink, junction e reparse point em qualquer nível** da cadeia, não apenas no componente final;
5. **comparação de `st_dev`/`st_ino`** (ou, no Windows, `dwVolumeSerialNumber` + índice de arquivo combinado via `GetFileInformationByHandle` — confirmado funcional por FS-018-01 § 6) para cada ancestral, entre capturas sucessivas;
6. **comparação de atributos de arquivo/reparse point e reparse tag do Windows** (`FILE_ATTRIBUTE_REPARSE_POINT`, `st_reparse_tag` — confirmado corretamente identificável para junctions por FS-018-01 § 6), quando disponível, para cada ancestral;
7. **validação de contenção via `is_relative_to()`** (§ 8.2) de cada nível da cadeia, não apenas do componente final;
8. **reverificação da identidade de todos os ancestrais imediatamente antes da abertura final**;
9. **reverificação da identidade de todos os ancestrais imediatamente após a abertura do descritor**;
10. **reverificação da identidade de todos os ancestrais depois da leitura completa e do cálculo do checksum**;
11. **rejeição** (`raw-identity-unstable`) caso qualquer ancestral tenha sido, entre duas capturas sucessivas: substituído, renomeado, trocado por symlink/junction/reparse point, redirecionado para fora da raiz, ou removido e recriado com o mesmo nome;
12. **falha fechada** (`raw-nofollow-unavailable`) quando a identidade estável de qualquer ancestral não puder ser provada.

### 8.3.2 Rota B endurecida — mecanismo passo a passo

1. `lstat` de cada componente do caminho, incluindo o arquivo final e todos os ancestrais — nunca `stat`; capturar `st_dev`/`st_ino`/atributos/reparse tag (ou equivalente Windows) de cada um;
2. rejeitar symlink, junction ou reparse point sempre que `lstat` indicar um desses tipos, em qualquer componente;
3. validar contenção via `is_relative_to()` (§ 8.2), para cada nível da cadeia;
4. **reverificar os tokens de identidade de todos os ancestrais imediatamente antes de abrir o arquivo final** — divergência aqui é `raw-identity-unstable`;
5. abrir o arquivo pelo path validado;
6. `fstat` do descritor recém-aberto imediatamente após a abertura, **e reverificar os tokens de identidade de todos os ancestrais neste mesmo momento**;
7. comparar a identidade obtida no `fstat` do arquivo final com a identidade observada no `lstat` do passo 1 — divergência é `raw-identity-unstable`;
8. no Windows, comparar também `FILE_ATTRIBUTE_REPARSE_POINT` e o reparse tag de cada ancestral e do arquivo final, entre validação e abertura;
9. ler o arquivo inteiramente **através do mesmo descritor aberto**, calculando SHA-256 e tamanho incrementalmente sobre os bytes efetivamente lidos — nunca por releitura do path (§ 8.3.3);
10. **verificação pós-leitura obrigatória, endurecida a partir do achado de FS-018-01 (§ 8.3.2.1 abaixo)**;
11. **falhar fechado (`raw-nofollow-unavailable`)** quando a plataforma não oferecer informação suficiente para capturar/comparar identidade estável de qualquer ancestral ou do arquivo final.

### 8.3.2.1 Verificação pós-leitura obrigatória (correção normativa a partir de FS-018-01)

FS-018-01 encontrou uma **assimetria real e reprodutível** entre as duas rotas construídas pelo spike (S27, remoção do arquivo final durante a leitura): a implementação da Rota A não repetia uma verificação de existência do caminho final após a leitura (apenas dos ancestrais), e por isso não detectava a remoção (`READ_SAFE_CONTENT`, incorretamente tratado como seguro); a Rota B, por reverificar o arquivo final via `lstat` pós-leitura, detectou corretamente a remoção (`DETECTED`, `FileNotFoundError`). Esta especificação torna esta verificação **normativa e obrigatória** para a Rota B endurecida, fechando essa lacuna definitivamente:

Após a leitura completa dos bytes, e antes de aceitar o snapshot como válido, a implementação deve, nesta ordem:

1. **reverificar a identidade do arquivo final** (novo `lstat`, comparado contra o token capturado antes da abertura);
2. **reverificar a identidade de toda a cadeia de ancestrais** (comparando contra a captura inicial e a captura pré-abertura);
3. **comparar as identidades** obtidas em (1) e (2) contra as capturas anteriores — qualquer divergência é `raw-identity-unstable`;
4. **comparar o tamanho** dos bytes efetivamente lidos contra o `st_size` observado no `lstat` inicial do arquivo final, quando aplicável;
5. **calcular SHA-256 sobre os bytes efetivamente usados** (os mesmos lidos no passo 9 da § 8.3.2, nunca uma releitura);
6. **comparar esse SHA-256 com o `RawArtifact.checksum` persistido** (§ 8.3.4) — divergência é `raw-checksum-mismatch`;
7. **somente então** aceitar o snapshot como válido para prosseguir ao parsing SDF (§ 9).

Qualquer ausência de capacidade para executar um destes passos, qualquer identidade instável, qualquer ancestral trocado, qualquer reparse point detectado, ou qualquer divergência de checksum **falha fechado** — nunca aceita parcialmente, nunca degrada silenciosamente.

### 8.3.3 Cálculo de checksum e tamanho

Sem alteração: SHA-256 e tamanho calculados exclusivamente a partir dos bytes efetivamente lidos do descritor aberto — nunca de uma nova leitura do `path` original, nunca de metadata de filesystem isolada.

### 8.3.4 Relação com a checagem interna de `register_state`

Sem alteração: duas checagens diferentes e complementares — a desta seção (snapshot vs. `RawArtifact.checksum` persistido, responsabilidade do serviço de promoção, executada **antes** de `register_state`) e a interna de `register_state` (cópia publicada vs. `source_file`, sem conhecimento do checksum original). O serviço de promoção executa ambas, em sequência.

## 8.4 Symlink, junction, reparse point — decisões fechadas por FS-018-01

1. **Symlink não foi construível no ambiente de FS-018-01** (`OSError [WinError 1314]`, ausência de `SeCreateSymbolicLinkPrivilege`/Developer Mode) — classificado honestamente como `UNSUPPORTED`, nunca simulado. **Esta especificação não declara comportamento empiricamente comprovado para symlink.** O contrato normativo é: **qualquer reparse point detectável** (symlink, junction, ou qualquer outro tipo) **deve ser rejeitado**, em qualquer nível da cadeia, independentemente de o ambiente de desenvolvimento permitir construí-lo para teste.
2. **Junction é construível sem privilégio** (`mklink /J`) e foi exercitado com sucesso — `os.path.islink()` retorna `False` para uma junction; a checagem separada `os.path.isjunction()`/verificação de `FILE_ATTRIBUTE_REPARSE_POINT` é **obrigatória**, nunca substituível por `islink()` isolado.
3. **Qualquer ancestral que seja junction ou reparse point deve ser rejeitado** — confirmado suficiente em todos os cenários construíveis de FS-018-01 (S08, S09, S20, S21 — todos `PREVENTED`/`DETECTED`).

## 8.5 Hardlink — decisões fechadas por FS-018-01

1. Hardlink **não é tratado como prova de escape de path** — uma entrada de diretório hardlinked é estruturalmente idêntica a qualquer arquivo comum dentro da raiz autorizada; não há sinal de identidade que a distinga de um arquivo criado diretamente ali.
2. Hardlink **não fornece imutabilidade** — um hardlink dentro da raiz autorizada, apontando para bytes originalmente populados por um caminho fora de qualquer raiz autorizada pela plataforma, estende a superfície de risco de "mutação em vaga do mesmo inode" (§ 8.6) para um caminho que a plataforma nunca controla.
3. **Identidade do arquivo nunca substitui identidade dos bytes.**
4. **O checksum do RAW registrado deve sempre ser comparado contra os bytes efetivamente lidos** (§ 8.3.2.1), mesmo quando o arquivo final é um hardlink.
5. **Alteração de conteúdo deve sempre causar falha** de checksum (`raw-checksum-mismatch`) — nunca uma alegação de imutabilidade baseada em identidade de arquivo.
6. **Nenhuma alegação de imutabilidade por hardlink** é feita por esta especificação, em nenhuma circunstância.

## 8.6 Limitações TOCTOU reconhecidas — não corrigidas, documentadas

**Confirmado empiricamente por FS-018-01 (§ 22 do relatório), não uma limitação apenas teórica:**

1. **Mutação de conteúdo em vaga, mesmo inode, mesmo tamanho, durante a leitura, nunca é detectável por identidade** (`st_ino`/`st_dev`/atributos não mudam quando o mesmo objeto de arquivo é reescrito via um handle de escrita compatível). A **única** proteção contra esta classe é a comparação de checksum externa (§ 8.3.2.1, passo 6) contra o `RawArtifact.checksum` persistido — esta especificação **não afirma** que a verificação de identidade, sozinha, cobre esta classe; a checagem de checksum é **essencial**, não redundante.
2. O bloqueio de `rename` pelo sistema operacional enquanto um handle permanece aberto (`PermissionError`/`WinError 5`, observado em 100% de 140 tentativas cobrindo essa classe em FS-018-01) **não é uma garantia do contrato** — é uma observação empírica desta plataforma/configuração específica. A especificação final **não depende dele** como mecanismo de segurança.

## 8.7 Plataformas — decisão fechada por FS-018-01

**Plataforma validada para o Incremento 018:**

- Windows 11 (build 10.0.26200 ou compatível);
- filesystem NTFS local (não montado em rede, não montado em provedor de nuvem);
- Python e capacidades exatamente como registradas por FS-018-01 (`evidence/capabilities.json`): ausência de `os.O_NOFOLLOW`/`os.O_DIRECTORY`/`os.supports_dir_fd`; disponibilidade de `GetFileInformationByHandle`, `CreateFileW` com `FILE_FLAG_OPEN_REPARSE_POINT`, `st_reparse_tag`, `os.path.isjunction`.

**Plataformas explicitamente não validadas para o Incremento 018:**

- POSIX (Linux, macOS) — não avaliado por nenhum spike (FS-018-01 § 7: `POSIX NOT EXECUTED`, ambiente indisponível sem instalação);
- qualquer outro filesystem local além de NTFS;
- network shares (SMB/NFS montados);
- filesystems montados em provedor de nuvem (sincronização, placeholders).

**Nesses ambientes não validados, o Incremento 018 deve falhar fechado com um código de erro tipado (`raw-nofollow-unavailable`) antes de tocar qualquer arquivo RAW — nunca alegar suporte, nunca degradar silenciosamente para uma checagem mais fraca.** A detecção de plataforma não suportada é uma responsabilidade explícita da implementação, não uma suposição implícita.

## 8.8 Fail-closed — decisão consolidada

1. a plataforma/versão testada é classificada, por este documento (§ 8.7), como suportando a Rota B endurecida ou não suportando nenhuma rota;
2. se suportada, a Rota B endurecida é usada;
3. **se não suportada, a promoção falha com `raw-nofollow-unavailable` antes de tocar o arquivo RAW** — nunca degradar silenciosamente;
4. esta classificação é fixada por este documento para cada plataforma validada, não decidida silenciosamente em tempo de execução por tentativa e erro.

---

# 9. Parsing RDKit/SDF

**Esta seção incorpora integralmente as decisões de RD-018-01.**

## 9.1 Fronteira do adapter

Sem alteração: função neutra em `rdkit_tautomer.py`:

```python
def inspect_single_sdf_for_promotion(
    *, source_path: Path, policy: LigandPromotionPolicy
) -> RDKitLigandInspectionResult:
    ...
```

Nenhum `Mol` atravessa o adapter.

## 9.2 Ordem final — confirmada por RD-018-01

1. validar `source_path` já snapshotado (§ 8);
2. construir `Chem.SDMolSupplier(str(path), sanitize=<bool>, removeHs=<bool>, strictParsing=<bool>)` **com os três kwargs sempre explícitos** — **nunca confiar nos defaults da biblioteca**, que RD-018-01 confirmou serem `sanitize=True, removeHs=True, strictParsing=True` (C8), diferentes da política final;
3. se a construção lançar exceção (ex.: arquivo vazio → `OSError`), tratar como zero registros válidos, nunca como um registro `None` pós-construção — **distinção confirmada necessária por RD-018-01 (§ 20, precisão de implementação)**: F10 (0 bytes) falha na própria construção; F11 (whitespace) constrói com sucesso e produz 1 registro `None` — são dois pontos de falha estruturalmente diferentes no código;
4. se construído, **percorrer o supplier inteiramente** (nunca confiar em `len()` isolado, nunca parar no primeiro registro), contando `total`, `valid` (Mol não-nulo) e `none`;
5. exigir `total == 1 and valid == 1` para aceitar; qualquer outro resultado é rejeição com o código apropriado (§ 9.4, § 17);
6. **nunca aceitar isoladamente o único registro válido quando há mais de um registro no arquivo**, mesmo que apenas um seja válido — confirmado necessário mesmo quando o padrão observado varia entre `total=2,valid=1,none=1` e `total=2,valid=2,none=0` conforme a combinação de política (§ 9.3.1);
7. extrair carga, atom count, H explícito/isotópico e stereo indefinida — **sobre o `Mol` original, antes de qualquer sanitização posterior** (RD-018-01 confirmou que todas as medições devem preceder qualquer `SanitizeMol` sobre cópia);
8. quando `sanitize=False` foi solicitado, aplicar `Chem.SanitizeMol` a uma **cópia** (`Chem.Mol(mol)`) do `Mol` retornado, nunca ao objeto original, como verificação adicional de utilizabilidade química;
9. coletar apenas warnings controlados de propriedades SD;
10. retornar resultado neutro; não reserializar.

## 9.3 Matriz de flags — confirmada empiricamente por RD-018-01 (144 células)

| sanitize | removeHs | strictParsing | uso no contrato final | status |
|---:|---:|---:|---|---|
| `True` | `False` | `True` | **único valor usado em produção (CLI, § 15.1)** | **confirmado por RD-018-01 como a única combinação que rejeita corretamente estrutura de valência inválida sem mascaramento** |
| `True` | `False` | `False` | comparação de tolerância com sanitização | testado, sem diferença comportamental observável de `strictParsing` (§ 9.4) |
| `True` | `True` | `True` | comparação de efeito — **nunca usar em produção** | testado; **mascara erro de valência real** (§ 9.3.1) |
| `True` | `True` | `False` | idem, sob parsing tolerante | testado; mesmo mascaramento |
| `False` | `False` | `True` | caracterização de parsing bruto estrito | testado |
| `False` | `False` | `False` | caracterização de parsing bruto tolerante | testado |
| `False` | `True` | `True` | prova de sanitização induzida por remoção de H | testado; nunca chamar de "não sanitizado" |
| `False` | `True` | `False` | mesma prova sob parsing tolerante | testado |

### 9.3.1 Achado crítico confirmado: mascaramento `removeHs=True` × `sanitize=True`

**RD-018-01, § 10 do relatório, reconfirmado célula a célula por sua reconciliação (§ 11-15):** sob `sanitize=True, removeHs=True` (a combinação C8, default nativo da biblioteca), uma estrutura com um átomo de carbono pentavalente (valência inválida) **não é rejeitada**. Os hidrogênios explícitos "em excesso" são removidos, e o carbono restante, agora sem vizinhos explícitos, é reinterpretado com valência implícita padrão, produzindo silenciosamente **metano — uma molécula válida, porém quimicamente diferente da estrutura declarada no arquivo**. Sob `sanitize=True, removeHs=False` (a combinação final `C6`), a mesma estrutura é corretamente rejeitada como `None`.

Este achado **fortalece empiricamente** a escolha de `removeHs=False`, além da justificativa original de "preservar H explícito/isotópico": **`removeHs=True` pode mascarar um erro de valência real que `removeHs=False` detecta corretamente.**

### 9.3.2 Hidrogênio isotópico — confirmado preservado

Confirmado por RD-018-01 (§ 11, fixture de etanol-d1): sob `removeHs=True`, o hidrogênio comum é removido, mas o hidrogênio isotópico (deutério) **permanece explícito** em 100% das combinações testadas — `isotopic_hydrogen_count` e `isotopes_observed` idênticos antes e depois. **O hidrogênio isotópico deve ser preservado** pela política final, independentemente do valor de `remove_hs`.

### 9.3.3 `strictParsing` — regra normativa A/B/C (RD-018-01, reconciliação § 20.1)

RD-018-01 comparou todos os pares `strictParsing=True` vs. `False` (72 pares, mesma fixture/`sanitize`/`removeHs`) contra as 18 fixtures construídas. A revisão adversarial encontrou que a ferramenta de análise original (`analyze.py`) **não implementava** a normalização de timestamp que o relatório afirmava ter aplicado, produzindo, se executada literalmente, 28/72 divergências espúrias (artefatos de texto de timestamp, não de comportamento). A reconciliação de RD-018-01 escreveu uma ferramenta nova e independente que **confirma mecanicamente**, sobre os mesmos dados brutos:

```text
28/72 divergências brutas de stderr (artefatos de timestamp, .strip() apenas)
0/72 divergências após normalização estrita do token [HH:MM:SS]
0 divergências em qualquer campo estrutural, em qualquer um dos 72 pares
```

Regra normativa adotada por este documento, literalmente:

- **A. Resultado do corpus:** nenhuma diferença semântica observada em nenhuma das 72 comparações reconciliadas.
- **B. Limitação:** o corpus de 18 fixtures **não demonstrou** uma fixture capaz de diferenciar `strictParsing` — a fixture desenhada especificamente para isso (F08) falha identicamente sob as duas configurações, por uma violação de limites C++ absorvida antes de chegar à camada Python.
- **C. Contrato futuro:** `strictParsing` continua sendo passado explicitamente pela API e registrado na proveniência e na `semantic_key`, **independentemente** de A e B — sua presença no contrato não depende de um efeito comportamental jamais demonstrado.

**Esta especificação não declara que `strictParsing` nunca produz diferença no RDKit** (A é sobre este corpus específico) **e não declara equivalência universal** entre `True`/`False` (B é uma lacuna de cobertura documentada, não uma prova de equivalência).

## 9.4 Cardinalidade e erros

Sem alteração de conteúdo, com a precisão de RD-018-01 sobre o ponto exato de falha:

| conteúdo | resultado |
|---|---|
| arquivo vazio | `InvalidPromotionSDFError` — **falha na construção do supplier** (`OSError`), não como registro pós-construção |
| bytes não SDF | `InvalidPromotionSDFError` |
| zero registros (supplier construído, nenhum registro) | `PromotionRecordCountError(0)` — caso logicamente necessário, não demonstrado empiricamente por nenhuma fixture de RD-018-01 (limitação registrada, § 9.6) |
| um válido | prosseguir |
| um inválido | `InvalidPromotionSDFError` |
| dois válidos | `PromotionRecordCountError(2)` |
| válido + inválido, em qualquer ordem | `PromotionRecordCountError(2)`; **nunca** aceitar o válido isoladamente — confirmado em ambas as ordens (F13, F14) |
| um registro desconectado | `DisconnectedStructureError` |

## 9.5 Hidrogênio, carga e stereo

Sem alteração — preservação confirmada empiricamente por RD-018-01 (§ 9.3.2 acima).

## 9.6 Camadas de elegibilidade — confirmado por RD-018-01 e sua revisão

**Geração de SMILES não prova elegibilidade para promoção.** `Chem.MolToSmiles` produziu SMILES sintaticamente válido inclusive para um `Mol` obtido sob `sanitize=False` a partir de uma estrutura quimicamente impossível. As seis camadas, sequenciais e não substituíveis, confirmadas por RD-018-01 e reforçadas por sua revisão adversarial:

1. supplier construído sem exceção;
2. registro existe no índice esperado;
3. `Mol` não-nulo;
4. sanitizado — via `sanitize=True` sem produzir `None`, **ou** sanitização posterior bem-sucedida sobre cópia quando `sanitize=False` foi solicitado;
5. livre de erros de valência/estrutura conhecidos;
6. elegível para promoção segundo a política de fragmentos/carga/estereoquímica (§ 9.3-9.5) — não coberto por nenhum spike, apenas pela política declarada.

Nenhuma camada é inferível de outra sem verificação própria.

## 9.7 Proveniência efetiva — regra fechada por RD-018-01

| Campo | Determinável? | Fonte |
|---|---|---|
| `engine_name` | sempre | fixo `"rdkit"` |
| `engine_version` | sempre | `rdBase.rdkitVersion`, confirmado idêntico a `rdkit.__version__` |
| `sanitize` solicitado | sempre | parâmetro passado |
| `sanitize` efetivo | **comprovável** | registro `None` quando falha; sanitização posterior bem-sucedida quando `sanitize=False` |
| `remove_hs` solicitado | sempre | parâmetro passado |
| `remove_hs` efetivo | **comprovável apenas quando `sanitize=True`** (contagem de H muda observavelmente); **não introspectável quando `sanitize=False`** (nenhum efeito observável) | registrar o **solicitado** quando não introspectável |
| `strict_parsing` solicitado | sempre | parâmetro passado |
| `strict_parsing` efetivo | **nunca introspectável neste corpus** (§ 9.3.3) | registrar sempre o **solicitado** |
| contagem de registros/válidos/`None` | sempre, via algoritmo da plataforma | RDKit não expõe isso de forma confiável sem iteração completa (§ 9.2) |

**Regra geral: quando nenhum efeito é observável, a proveniência registra o valor solicitado, nunca um valor "efetivo" inferido de um comportamento não observado.**

## 9.8 Spike `RD-018-01` — encerrado

Executado, revisado adversarialmente e reconciliado. Classificação final: **`RECONCILED PASS WITH LIMITATIONS`**. As limitações registradas (caso "supplier vazio" não demonstrado por nenhuma fixture; preservação RAW comprovada apenas indiretamente quanto às fixtures originais; defaults nativos não reinspecionados pelo revisor por ausência de RDKit em seu ambiente) **não invalidam nenhuma decisão de arquitetura** e são registradas aqui como limitações de evidência, não como blockers.

---

# 10. Identidade e idempotência

**Preservada sem nenhuma alteração de conteúdo** — algoritmo de canonização, payload canônico, vetor golden e decisões de idempotência não são tocados por nenhum spike. O vetor golden foi recomputado de forma independente três vezes ao longo do processo e permanece idêntico byte a byte.

## 10.1 Payload lógico da `semantic_key`

```python
payload = {
    "semantic_key_algorithm_version": "1",
    "input_id": input_id,
    "snapshot_checksum": resolved.snapshot_checksum,
    "engine_name": resolved.engine_name,
    "engine_version": resolved.engine_version,
    "policy": {
        "sanitize": requested.sanitize,
        "remove_hs": requested.remove_hs,
        "strict_parsing": requested.strict_parsing,
        "record_policy": requested.record_policy,
        "component_policy": requested.component_policy,
        "charge_policy": requested.charge_policy,
        "stereo_policy": requested.stereo_policy,
        "representation_policy": requested.representation_policy,
    },
}
```

## 10.2 Algoritmo de canonização

1. Payload é dicionário Python puro contendo exclusivamente `str` e `bool`.
2. Normalização Unicode NFC em toda `str`.
3. `sort_keys=True` recursivo.
4. Ordem de listas preservada (não há listas nesta versão).
5. Nenhum campo resolve para `None`.
6. `allow_nan=False`.
7. Digest sobre bytes UTF-8.
8. `separators=(",", ":")`.
9. Configuração exata:

   ```python
   canonical_json = json.dumps(
       payload, sort_keys=True, separators=(",", ":"),
       ensure_ascii=False, allow_nan=False,
   )
   ```

10. SHA-256: `hashlib.sha256(canonical_json.encode("utf-8")).hexdigest()`.
11. String hexadecimal minúscula de 64 caracteres.
12. `semantic_key_algorithm_version` fixo `"1"`, participa do payload.
13. Erro de programação interno se um valor não puder ser canonizado, nunca conversão silenciosa.
14. Nenhum path absoluto, timestamp, ID aleatório ou warning não determinístico participa do payload.

Floats são **proibidos**.

## 10.3 Vetor de teste canônico

```python
payload = {
    "semantic_key_algorithm_version": "1",
    "input_id": "curcumin-pubchem",
    "snapshot_checksum": "3f786850e387550fdab836ed7e6dc881de23001b0eb99f37a6e6dfb47a54a08",
    "engine_name": "rdkit",
    "engine_version": "2026.03.6",
    "policy": {
        "sanitize": True, "remove_hs": False, "strict_parsing": True,
        "record_policy": "exactly-one", "component_policy": "reject-disconnected",
        "charge_policy": "preserve", "stereo_policy": "preserve",
        "representation_policy": "verified-source-bytes",
    },
}
```

JSON canônico:

```json
{"engine_name":"rdkit","engine_version":"2026.03.6","input_id":"curcumin-pubchem","policy":{"charge_policy":"preserve","component_policy":"reject-disconnected","record_policy":"exactly-one","remove_hs":false,"representation_policy":"verified-source-bytes","sanitize":true,"stereo_policy":"preserve","strict_parsing":true},"semantic_key_algorithm_version":"1","snapshot_checksum":"3f786850e387550fdab836ed7e6dc881de23001b0eb99f37a6e6dfb47a54a08"}
```

Digest esperado:

```text
1bd810f669ad078fa744fc88b6248eeca8a5a2730d56493e518419dc316577f4
```

Segundo vetor (`input_id="curcumin-pubchem-2"`):

```text
e3dfa4f5f16f664981b511e2e5abea0596fbe618cf0524d9ef75ff24a630d996
```

## 10.4 Elementos excluídos da chave

`requested_entity_id`; `requested_state_id`; nome humano; attempt ID; timestamps; paths temporários; warnings não determinísticos; contagens/propriedades resultantes da inspeção RDKit; `LigandPromotionPolicy.schema_version`/`source`.

## 10.5 Isolamento por `project_dir`

Sem alteração — `project_dir` não entra no payload; duas promoções em projetos diferentes nunca colidem fisicamente.

## 10.6 Retry e conflito

Sem alteração de conteúdo (tabela completa preservada do rascunho pré-spike). Destaque: **RAW diferente, conteúdo idêntico → duas promoções semanticamente independentes**, nunca deduplicação por checksum.

## 10.7 Token de revisão

Sem alteração.

---

# 11. Concorrência

**Esta seção incorpora integralmente as decisões de FS-018-02**, substituindo a formulação candidata/condicional do rascunho pré-spike por um mecanismo comprovado empiricamente em 8 cenários com processos reais.

## 11.1 Resultado do spike — resumo

FS-018-02 testou uma primitiva mínima baseada exclusivamente em biblioteca padrão (`os.mkdir` para criação exclusiva; `os.link` para publicação exclusiva do promotion record) em 8 cenários (S01-S08), com processos reais sincronizados por `multiprocessing.Barrier` (nunca `sleep` como prova de atomicidade), em NTFS local. **8/8 cenários PASS**, classificação final **`PASS`** (ver § 2.3 desta especificação para a verificação de identidade/manifesto/8-cenários recomputados). Duração total: 2,33 segundos.

## 11.2 Reserva semântica — decisão fechada

```text
scientific/promotion_reservations/<semantic_key>/
  reservation.yaml
```

**Mecanismo:** criação exclusiva de diretório via `os.mkdir(slot_dir)` — atômica no NTFS local, falha com `FileExistsError` se já existe, sem janela de "quase-livre". **Confirmado suficiente para exatamente um vencedor** sob 8 processos reais disputando a mesma chave simultaneamente (S01: um vencedor, sete perdedores determinísticos; S02: um vencedor, sete perdedores que **nunca chegam a tentar claim algum** porque falham na própria etapa da reserva semântica — nenhuma publicação parcial).

Após a criação exclusiva do diretório, `reservation.yaml`/`meta.json` é gravado via arquivo temporário + `os.replace` atômico dentro do mesmo diretório — nunca há uma janela em que o diretório existe com metadata parcialmente escrita visível a outro processo além do próprio criador.

## 11.3 Ownership

Cada tentativa gera:

- `attempt_id` — identificador de tentativa (UUID);
- `owner_token` — token imprevisível (gerado com uma fonte de aleatoriedade segura, por exemplo `secrets.token_hex`), nunca derivado de dados previsíveis (PID, timestamp);
- metadata da reserva contendo ambos, mais fase conhecida e timestamp de criação.

**O `owner_token` nunca é registrado em log público em texto puro.** Qualquer evidência, log ou relatório que precise referenciá-lo deve usar um hash do token (confirmado pela própria prática de evidência de FS-018-02: `owner_token_hash`, nunca o token em claro, em nenhum artefato).

## 11.4 Claims de entity/state — normalização por casefold, decisão fechada

```text
scientific/promotion_reservations/by-entity/<sha256(NFC(entity_id).casefold())>/
scientific/promotion_reservations/by-state/<sha256(NFC(state_id).casefold())>/
```

**Normalização obrigatória, nesta ordem, antes do hash:** Unicode NFC, depois `casefold()`, depois SHA-256. **Confirmado suficiente por FS-018-02** (S03: `Entity-A` vs. `entity-a`, semantic keys diferentes, colisão de claim corretamente forçada — somente um cria o claim, o outro falha determinìsticamente sem overwrite; S04: mesmo padrão para state claim com `State-A`/`state-a`).

## 11.5 Ordem de aquisição — decisão fechada

```text
semantic reservation → entity claim (se necessária) → state claim
```

Mecanicamente respeitada: **confirmado por S02 que um perdedor na etapa da reserva semântica nunca chega a tentar nenhum claim**, eliminando por construção qualquer possibilidade de publicação parcial a partir de IDs de um perdedor.

## 11.6 Semântica de ausência/metadata inválida — decisão fechada

**Ausência, metadata incompleta ou metadata inválida significa BUSY/INDETERMINATE — nunca "reserva livre".** A existência do diretório de reserva (produzida pela criação exclusiva) é, por si só, prova suficiente de posse; a legibilidade do `meta.json` é apenas informativa. Um leitor que encontre o diretório mas não consiga ler ou validar seu `meta.json` deve classificar o estado como `RESERVED_METADATA_MISSING_INDETERMINATE` ou `RESERVED_METADATA_CORRUPT_INDETERMINATE` — nunca como ausência de reserva. Confirmado pela própria construção do protótipo de FS-018-02 e exercitado nos cenários de crash (S06, S07).

## 11.7 TTL — decisão fechada

**TTL isolado nunca autoriza takeover, remoção ou reutilização de uma reserva.** Um relógio vencido não prova que outro processo morreu. FS-018-02 confirmou isto estruturalmente: o protótipo **não contém nenhum caminho de código que remova qualquer reserva por idade** — a idade (`age_seconds`) é calculada apenas para fins de inspeção/relatório administrativo, nunca comparada a um limite para autorizar remoção. Esta é uma propriedade estrutural (ausência de código), não uma negativa exaustivamente testada contra todo valor de idade possível — a natureza exata dessa evidência está registrada.

## 11.8 Release — decisão fechada

**Liberação exige correspondência exata de `attempt_id` **e** `owner_token`.** Qualquer divergência (ou metadata ilegível no momento do release) recusa a remoção sem tocar o recurso. **Non-owner nunca pode liberar reserva ou claim** — confirmado empiricamente por FS-018-02 (S08: tentativa de release com `owner_token` incorreto é sempre recusada com `OWNER_MISMATCH_REFUSE`, recursos permanecem intactos; release subsequente com `attempt_id`+`owner_token` corretos remove exatamente os recursos daquele owner).

## 11.9 Promotion record — commit marker, decisão fechada

```text
scientific/promotions/<semantic_key>.yaml
```

**Mecanismo de publicação:** o documento completo é escrito primeiro em um arquivo de staging privado (nome exclusivo por `attempt_id`+PID, nunca colidindo entre tentativas concorrentes); a publicação no destino final é feita por uma operação de criação exclusiva — **no Windows/NTFS local validado por este spike, um hardlink atômico/exclusivo (`os.link`) do arquivo de staging para o nome final** é a primitiva comprovada suficiente (falha com `FileExistsError` se o destino já existe, e o conteúdo já está completo antes do link, eliminando qualquer janela de conteúdo parcial visível sob o nome final).

**Se a primitiva de publicação exclusiva não estiver disponível na plataforma em execução, ou não puder provar exclusividade, a promoção deve falhar fechada** com um código de erro tipado (`promotion-primitive-unavailable`, § 17) — nunca publicar sem essa garantia.

**Recusa absoluta de overwrite:** confirmado por construção (S01, S02, S03, S04, S05: cada semantic key produz exatamente um promotion record) e explicitamente por S08 (tentativa de publicar novamente para uma semantic key já promovida é sempre recusada).

**O promotion record publicado é o commit marker autoritativo.** Um concorrente subsequente que encontre um promotion record válido para a semantic key que está tentando promover deve **reconhecer o sucesso existente e nunca publicar novamente** — confirmado por FS-018-02 S08 (`LOST_ALREADY_PROMOTED`, distinto de um simples `BUSY`).

## 11.10 Aquisição parcial e compensação — decisão fechada

**Se um concorrente adquirir semantic reservation → entity claim e depois perder o state claim, deve liberar somente os próprios recursos já adquiridos, em ordem inversa:**

```text
state claim, se adquirido → entity claim, se adquirido → semantic reservation
```

Nunca libera recurso de outro owner; nunca assume ter liberado algo que não confirmou.

**Se a liberação não puder ser confirmada** (por exemplo, metadata ilegível no momento da tentativa de release): registrar resíduos tipados (`residual_reservation_keys`, § 6.6); **nunca remover recurso de outro owner**; **nunca alegar compensação completa** quando ela não foi confirmada.

**Limitação registrada por este documento, herdada diretamente do escopo do spike:** FS-018-02 comprovou exclusividade, ownership e detecção de resíduos, mas o **protótipo do spike não implementou nem testou este rollback específico** (o cenário de casefold do spike, S03/S04, deixa deliberadamente a reserva semântica do perdedor como resíduo, sem executar a liberação em ordem inversa — ver relatório do spike, limitações). **A implementação de produção deve testar explicitamente a compensação inversa de aquisição parcial e o caso de falha de compensação produzindo resíduos** (§ 19.9, itens dedicados) antes de ser considerada completa — esta é uma lacuna de evidência explicitamente herdada do spike, não uma decisão de arquitetura em aberto.

## 11.11 Crash antes do promotion record — decisão fechada

**Se um crash ocorrer após adquirir a reserva semântica (e, eventualmente, claims), mas antes de publicar o promotion record:** os resíduos permanecem no filesystem; uma inspeção read-only os identifica (owner, fase conhecida, idade) sem qualquer mutação; um concorrente subsequente **nunca rouba automaticamente** a reserva (recebe `BUSY_OR_INDETERMINATE`); a reconciliação administrativa é uma responsabilidade futura, fora do caminho crítico de escrita — **este spike deliberadamente não implementa nem especifica compensação automática**. Confirmado empiricamente por FS-018-02 S06 (crash logo após a reserva semântica) e S07 (crash após ambos os claims, antes do promotion record).

## 11.12 Crash depois do promotion record, antes do release — decisão fechada

**O promotion record permanece o sucesso autoritativo.** Uma nova tentativa (de qualquer processo, incluindo um processo de reconciliação futuro) **reconhece o sucesso existente e não publica novamente**. As reservas residuais (semantic reservation, claims) que sobreviveram ao crash são objeto de reconciliação administrativa futura — **nunca removidas automaticamente por um concorrente**, e **nunca** o entity/state/promotion record já comprometidos são removidos ou re-publicados. Confirmado empiricamente por FS-018-02 S08.

## 11.13 Matriz de concorrência — atualizada com evidência de FS-018-02

| processo A | processo B | resultado obrigatório | confirmado por |
|---|---|---|---|
| mesma chave, mesmos IDs | mesma chave, mesmos IDs | um publica; outros retornam record vencedor | S01 (8 processos, 1 vencedor, 7 perdedores) |
| mesma chave, IDs diferentes | mesma chave, IDs diferentes | um publica; outros falham na reserva semântica, sem tentar claim | S02 |
| chaves diferentes, mesmo entity ID por casefold | qualquer | somente um claim de entity pode existir | S03 |
| chaves diferentes, mesmo state ID por casefold | qualquer | somente um claim de state pode existir | S04 |
| IDs e chaves totalmente distintos | idem | ambos progridem e podem vencer, sem bloqueio global indevido | S05 |
| vencedor cai após reserva, antes de claims | concorrente encontra reserva | concorrente recebe BUSY/INDETERMINATE; não rouba automaticamente; resíduo inspecionável | S06 |
| vencedor cai após claims, antes do promotion record | concorrente encontra reserva+claims | concorrente não duplica nem sobrescreve; reconciliação necessária, não automática | S07 |
| vencedor publica e cai antes do release | concorrente disputa a mesma chave | concorrente reconhece sucesso existente, não republica; release por non-owner falha; release pelo owner remove só seus recursos | S08 |

## 11.14 Reserva abandonada — reconciliação administrativa

Não usar TTL isolado como prova de abandono (§ 11.7). Operação candidata de reconciliação, Application API administrativa, não comando comum:

```python
inspect_promotion_reservation(project_dir, semantic_key) -> PromotionReservationInspection
```

Estritamente read-only — confirmado como padrão correto e suficiente pelo próprio mecanismo de inspeção de FS-018-02 (`inspect_slot`/`inspect_promotion`, nunca mutam). Remoção de reserva abandonada só pode ser autorizada por uma futura API administrativa separada, após confirmar que não há processo ativo e reconciliar artefatos — **não especificada por este documento, deliberadamente fora do escopo do Incremento 018** (§ 24).

## 11.15 Classificação final do spike

```text
FS-018-02 CLASSIFICATION: PASS
```

Ver § 2.3 desta especificação para a verificação completa de identidade/manifesto/8-cenários que sustenta esta classificação.

---

# 12. Fluxo algorítmico

## 12.1 Validação pré-attempt

Sem alteração: validar IDs/policy; rejeitar `entity_id == state_id` apenas se o domínio geral proibir; nenhuma I/O para entrada malformada.

## 12.2 Fase de resolução

6. criar `LigandPromotionAttempt(status="started")`;
7. activity `started` best effort;
8. carregar `LigandInput`;
9. exigir `raw_artifact.format.strip().lower() == "sdf"`;
10. validar path lexical e raiz esperada (§ 8.1);
11. validar contenção real via `is_relative_to()` e política de links (§ 8.2, § 8.4);
12. criar snapshot privado pela **Rota B endurecida** (§ 8.3), com verificação pós-leitura obrigatória (§ 8.3.2.1) e comportamento fail-closed (§ 8.7-8.8) quando a plataforma não é a validada;
13. calcular checksum e tamanho do snapshot exclusivamente a partir do descritor aberto (§ 8.3.3);
14. comparar com `RawArtifact.checksum` (§ 8.3.4);
15. resolver RDKit e sua versão;
16. inspecionar SDF do snapshot com a política final (`sanitize=True, remove_hs=False, strict_parsing=True`, § 9.2-9.3), com os três kwargs sempre explícitos;
17. construir `ResolvedLigandPromotionSnapshot` e provenance de aquisição (§ 9.7);
18. calcular semantic key pelo algoritmo da § 10.2, sobre o payload da § 10.1;
19. persistir attempt `resolved`.

Falha nos passos 8–18 produz `resolution_failed`; snapshot temporário é removido; RAW permanece.

## 12.3 Fase de execução

20. consultar promotion record pela semantic key;
21. se record consistente existir, validar IDs e finalizar attempt como sucesso reutilizado (§ 11.9, reconhecimento de commit marker existente);
22. se não existir, verificar se outro lineage do mesmo input exige `intentional_revision`;
23. **adquirir reserva exclusiva via `os.mkdir` (§ 11.2) e claims necessários, na ordem semantic → entity → state (§ 11.5)**;
24. reconsultar promotion record e IDs após a reserva;
25. carregar ou criar `ScientificEntity`;
26. registrar `MolecularState` usando o snapshot como `source_file`;
27. validar checksums e referências publicadas;
28. construir `ScientificInputPromotionRecord` completo;
29. **gravar o promotion record via staging + criação exclusiva (hardlink no Windows/NTFS local, § 11.9), recusando overwrite**;
30. marcar attempt `succeeded` com resultado;
31. **liberar claims/reserva em ordem inversa, com `attempt_id`+`owner_token` corretos (§ 11.8, § 11.10)**;
32. remover snapshot temporário;
33. activity `success` best effort;
34. retornar attempt concluído.

## 12.4 Interrupções

Sem alteração: `KeyboardInterrupt`/`SystemExit` após qualquer publicação executam compensação best effort; a interrupção original permanece primária; `GeneratorExit`/outros `BaseException` não são absorvidos como erro científico.

---

# 13. Atomicidade e compensação

## 13.1 Commit lógico

Sem alteração: a promoção só existe cientificamente quando `scientific/promotions/<semantic_key>.yaml` foi persistido (§ 11.9) e passou a validação.

## 13.2 Ownership

Sem alteração conceitual, com a precisão de FS-018-02: o attempt mantém flags locais (`entity_created_by_this_attempt`, `state_created_by_this_attempt`, `promotion_committed_by_this_attempt`, claims/reservation adquiridos por esta tentativa, identificados por `attempt_id`+`owner_token`, § 11.3). Nenhum objeto é removido apenas porque seu ID existe numa variável.

## 13.3 Ordem reversa

Em falha antes do commit marker, agora explicitamente incluindo a ordem de liberação de reserva/claims confirmada por FS-018-02 (§ 11.10):

1. remover state somente se criado pela tentativa, metadata corresponde e não há dependentes;
2. remover entity somente se criada pela tentativa, metadata corresponde e não há states/dependentes;
3. **liberar claims e reserva pertencentes ao attempt, em ordem inversa de aquisição (state claim → entity claim → semantic reservation), com `attempt_id`+`owner_token` corretos — nunca liberar recurso de outro owner, nunca alegar compensação completa sem confirmação (§ 11.10)**;
4. remover staging/snapshot;
5. persistir `execution_failed` com remoções não confirmadas;
6. activity `error` best effort.

O promotion record é escrito como documento completo, com publicação exclusiva e recusa de sobrescrita (§ 11.9). Depois que o record foi comprometido, nenhuma compensação remove record, state ou entity (§ 11.12); falha ao gravar status do attempt produz erro de persistência operacional.

## 13.4 Primitivas candidatas

Sem alteração:

```python
def remove_state_if_matches_and_unreferenced(
    project_dir: Path, *, expected: MolecularState
) -> bool: ...

def remove_entity_if_matches_and_unreferenced(
    project_dir: Path, *, expected: ScientificEntity
) -> bool: ...
```

`_remove_state_best_effort` não é reutilizada nem por wrapper.

## 13.5 Resíduos

Sem alteração de estrutura, agora confirmada por FS-018-02 como o padrão correto de tratamento de falha de liberação (§ 11.10):

| falha de remoção | campo |
|---|---|
| entity não confirmada removida | `residual_entity_ids` |
| state não confirmado removido | `residual_state_ids` |
| reservation/claim não confirmado removido | `residual_reservation_keys` |

Não existe `residual_promotion_ids`: o promotion record nunca é alvo de compensação (§ 11.9, § 11.12).

## 13.6 Falha de persistência terminal

Sem alteração.

---

# 14. Application Service

**Preservada sem alteração de conteúdo** — nenhum spike toca esta camada diretamente; ela apenas passa a invocar os mecanismos agora fechados de § 8 (Rota B endurecida) e § 11 (reserva por `os.mkdir`).

## 14.1 Módulo

`molecular/promotion_service.py`.

## 14.2 Assinatura pública

```python
def promote_ligand_input(
    project_dir: Path,
    *,
    input_id: str,
    entity_id: str,
    state_id: str,
    entity_name: str,
    policy: LigandPromotionPolicy,
    intentional_revision: str | None = None,
) -> LigandPromotionAttempt:
    ...
```

## 14.3 Resultado

Sem alteração: sempre retorna attempt `succeeded`; result informa reuso; falha pré-attempt mantém exceção original; falha após attempt usa wrappers determinísticos.

## 14.4 Exceções públicas

```python
class LigandPromotionAttemptFailedError(RuntimeError):
    attempt_id: str
    input_id: str
    status: Literal["resolution_failed", "execution_failed"]
    original_error: Exception

class LigandPromotionAttemptPersistenceError(RuntimeError):
    attempt_id: str
    input_id: str
    phase: PromotionPhase
    intended_status: Literal["resolution_failed", "execution_failed"]
    original_error: BaseException
    persistence_error: Exception
    residual_entity_ids: tuple[str, ...]
    residual_state_ids: tuple[str, ...]
    residual_reservation_keys: tuple[str, ...]
```

## 14.5 Activity

Sem alteração: um evento por outcome, sem path/URL/SMILES/mensagem arbitrária.

---

# 15. CLI

**Preservada sem alteração estrutural.**

## 15.1 Comando final

```text
molecular ligand promote <experiment> <input_id>
  --entity <entity_id>
  --state <state_id>
  --name <scientific-name>
  [--revision <intentional-revision>]
```

A policy é construída pela CLI com **exclusivamente** o perfil `sanitize=True, remove_hs=False, strict_parsing=True` — confirmado por RD-018-01. Não expor flags RDKit individuais.

## 15.2-15.3 Sucesso novo/idempotente

Sem alteração de conteúdo.

## 15.4 Erros

| banner | categorias | exit |
|---|---|---:|
| `INPUT ERROR` | IDs/policy inválidos, input inexistente, formato não SDF, conflito de IDs/revision | 1 |
| `CONFIGURATION ERROR` | YAML inválido, record inconsistente, policy/engine incompatível | 1 |
| `EXECUTION ERROR` | SDF inválido, fragmentos, record count, parsing/sanitização | 1 |
| `STORAGE ERROR` | path inseguro, checksum, snapshot, capability de no-follow ausente, identidade instável, `raw-permission-denied`/`raw-sharing-violation` (novo, FS-018-01), registry, reserva, `promotion-primitive-unavailable` (novo, FS-018-02), persistência | 1 |

## 15.5 Boundary

Sem alteração.

---

# 16. Provenance

**Preservada, com uma atualização textual**: a linha "rota usada (Rota A ou Rota B)" passa a "rota usada (Rota B endurecida, § 8.3 — única rota implementada no Incremento 018)".

## 16.1 Dados obrigatórios

| categoria | campos |
|---|---|
| aquisição | input ID, method, source name/identifier/URI, acquired_at |
| RAW | path relativo persistido, formato declarado, checksum persistido |
| verificação | snapshot checksum, tamanho, política de path/link, **Rota B endurecida (única rota)** |
| parser | engine, versão, flags solicitadas/efetivas (§ 9.7) |
| inspeção | record/fragment count, carga, atom/H counts, warnings |
| resultado | promotion/entity/state IDs e representation ref |
| operação | attempt ID, revision token, timestamps e outcome |

## 16.2-16.4

Sem alteração de conteúdo.

---

# 17. Taxonomia de erros

Tabela atualizada com os dois códigos novos confirmados pelos spikes (`raw-permission-denied`/`raw-sharing-violation` por FS-018-01; `promotion-primitive-unavailable` por FS-018-02):

| código | phase | tipo candidato | significado |
|---|---|---|---|
| `input-not-found` | resolution | `FileNotFoundError`/tipada | LigandInput ausente |
| `unsupported-format` | resolution | `UnsupportedPromotionFormatError` | formato declarado não SDF |
| `unsafe-raw-path` | resolution | `UnsafeRawArtifactPathError` | path lexical/real inseguro, incluindo falha de contenção via `is_relative_to()` (§ 8.2) |
| `raw-not-regular-file` | resolution | `RawArtifactTypeError` | ausente/não regular |
| `raw-checksum-mismatch` | resolution | `RawArtifactIntegrityError` | snapshot difere do registro (§ 8.3.2.1) |
| `raw-nofollow-unavailable` | resolution | `RawArtifactNoFollowUnavailableError` | plataforma não prova a Rota B endurecida para o arquivo final **ou para qualquer ancestral**, incluindo plataformas não validadas (§ 8.7) |
| `raw-identity-unstable` | resolution | `RawArtifactIdentityUnstableError` | identidade do arquivo final **ou de qualquer ancestral** divergiu entre validação, abertura, leitura ou verificação pós-leitura (§ 8.3.1/8.3.2/8.3.2.1) |
| **`raw-permission-denied`** (**confirmado por FS-018-01 §26**) | resolution | `RawArtifactSharingViolationError` | o sistema operacional bloqueou uma operação (ex.: rename com handle aberto) — observação empírica de plataforma, nunca tratada como garantia de segurança (§ 8.6) |
| `rdkit-unavailable` | resolution | `RDKitUnavailableError` | capability ausente |
| `invalid-sdf` | resolution | `InvalidPromotionSDFError` | bytes não interpretáveis, incluindo falha na construção do supplier (§ 9.4) |
| `record-count` | resolution | `PromotionRecordCountError` | zero/múltiplos/ilegível adicional |
| `disconnected-structure` | resolution | `DisconnectedStructureError` | mais de um fragmento |
| `revision-required` | execution | `PromotionRevisionRequiredError` | nova semântica sem token |
| `identity-conflict` | execution | `PromotionIdentityConflictError` | IDs divergem/colidem |
| `reservation-conflict` | execution | `PromotionReservationConflictError` | outra tentativa detém reserva/claim (`BUSY_OR_INDETERMINATE`, § 11.6) |
| **`promotion-primitive-unavailable`** (**confirmado por FS-018-02 § 11.9**) | execution | `PromotionPublicationUnavailableError` | plataforma não oferece primitiva de publicação exclusiva do promotion record, ou não pode provar exclusividade |
| `consistency-error` | execution | `PromotionConsistencyError` | lineage e filesystem divergem |
| `publication-failed` | execution | erro original tipado | entity/state/lineage não publicado |
| `promotion-persistence-failed` | resolution/execution | wrapper pública | terminal status não persistido |

---

# 18. Matrizes normativas

## 18.1 Segurança do path

| caso | antes de snapshot | resultado |
|---|---:|---|
| path canônico sob input | passa | continuar |
| POSIX absoluto / drive / UNC / drive-relative / `.`/`..`/backslash | falha | `unsafe-raw-path` |
| symlink/junction/reparse point em qualquer componente (final ou ancestral) | falha | `unsafe-raw-path` |
| resolve fora da raiz via `is_relative_to()` — nunca via `startswith()` (§ 8.2) | falha | `unsafe-raw-path` |
| diretório irmão com colisão textual de prefixo (`allowed_root_EVIL`) | falha (confirmado por FS-018-01) | `unsafe-raw-path` |
| arquivo ausente/não regular | falha | `raw-not-regular-file` |
| plataforma não prova a Rota B endurecida (arquivo final ou ancestral) | antes de abrir | `raw-nofollow-unavailable` |
| identidade diverge entre validação/abertura/leitura/pós-leitura, arquivo final ou ancestral | durante snapshot | `raw-identity-unstable` |
| sistema operacional bloqueia operação (rename com handle aberto) | durante ataque de terceiro | `raw-permission-denied` (observação, não garantia) |
| hash diferente do RAW persistido | após snapshot, na verificação pós-leitura | `raw-checksum-mismatch` |

## 18.2 SDF

Sem alteração:

| registros físicos | válidos | inválidos | resultado |
|---:|---:|---:|---|
| 0 | 0 | 0 | rejeitar |
| 1 | 1 | 0 | continuar |
| 1 | 0 | 1 | rejeitar |
| 2+ | qualquer | qualquer | rejeitar |
| 2 | 1 | 1 | rejeitar como dois registros |

## 18.3 Química mínima

Sem alteração.

## 18.4 Status/fase/campos

A matriz da § 6.9 é normativa (sem alteração).

## 18.5 Falhas e compensação

Sem alteração de estrutura; conteúdo de "liberar o que pertence à tentativa" agora precisado por § 11.10/13.3 (ordem inversa, credenciais exatas).

## 18.6 CLI

Sem alteração de estrutura; `STORAGE ERROR` agora cobre também `raw-permission-denied`/`promotion-primitive-unavailable` (§ 15.4).

## 18.7 Concorrência — nova matriz normativa (FS-018-02)

Ver § 11.13 (tabela completa, citando o cenário de FS-018-02 que sustenta cada linha).

---

# 19. Estratégia de testes

**Nota de método (reconciliação de contagens):** as listas abaixo são **linhas normativas de cenário**, não uma contagem de itens `pytest` coletados — uma única linha pode gerar múltiplos nós `pytest` via parametrização. Os três spikes são explorações externas ao repositório, não contribuem para a contagem. **Este documento recalcula mecanicamente a sequência inteira a partir de 1, sem lacunas nem duplicações, substituindo a contagem de 135 linhas do rascunho pré-spike.** A contagem total é **169 linhas normativas de cenário** (§ 19.1-19.9 abaixo), incluindo 19 itens novos dedicados a FS-018-02 (§ 19.9) e a expansão/atualização de § 19.3 (Rota B endurecida, contenção, verificação pós-leitura) e § 19.4 (achados RD-018-01). Reconciliação mecânica confirmada pela revisão final: `24+14+28+22+22+15+10+15+19 = 169`, sem lacunas nem duplicações.

## 19.1 Domínio — `tests/test_promotion.py` (itens 1-24, sem alteração de conteúdo)

1. policy válida e frozen;
2. extra proibido;
3. tipos (`bool`) dos flags RDKit permitem representar as oito linhas da matriz da § 9.3, sem violar validação;
4. resolved checksum válido/inválido;
5. contagens não negativas;
6. result reusado proíbe flags created;
7. error resolution proíbe resíduos;
8. resíduos validam IDs e unicidade;
9. cinco status válidos;
10. matriz completa status/campos;
11. promotion record exige `id == semantic_key`;
12. representation checksum igual ao snapshot;
13. intentional revision valida ID;
14. YAML round-trip dos modelos;
15. vetor de teste golden da § 10.3: payload fixo → JSON canônico esperado → digest esperado (`1bd810f669ad078fa744fc88b6248eeca8a5a2730d56493e518419dc316577f4`), hardcoded no teste;
16. independência da ordem de chaves no nível superior do payload;
17. independência da ordem de chaves em `policy`;
18. preservação da ordem de listas;
19. normalização NFC de strings Unicode equivalentes;
20. distinção entre valores semanticamente diferentes — digest diferente (`e3dfa4f5f16f664981b511e2e5abea0596fbe618cf0524d9ef75ff24a630d996`);
21. rejeição de `NaN`/`Infinity`/`-Infinity`;
22. estabilidade após serialização e leitura YAML/JSON;
23. ausência de IDs, timestamps e caminhos incidentais no payload;
24. `LigandPromotionPolicy` aceita, sem erro de validação, as oito combinações da matriz.

## 19.2 Registry — `tests/test_promotion_registry.py` (itens 25-38, sem alteração de conteúdo)

25. begin/load attempt;
26. transições permitidas;
27. transições proibidas/terminais;
28. atomic overwrite de attempt;
29. record de sucesso create-once (criação exclusiva, § 11.9);
30. conflito exato/casefold;
31. consultas por semantic key/input/state;
32. record inconsistente rejeitado;
33. YAML corrompido propaga validation/config error;
34. reservation create exclusive (`os.mkdir`, § 11.2);
35. reservation release somente por owner (`attempt_id`+`owner_token` exatos, § 11.8);
36. claims em ordem e cleanup parcial (ver detalhamento em § 19.9);
37. semantic key minúscula/64 hex;
38. attempt failure não cria promotion record.

## 19.3 Segurança do RAW — `tests/test_atomic.py` ou arquivo próprio (itens 39-66, atualizados para a Rota B endurecida)

39. path POSIX absoluto rejeitado;
40. drive Windows absoluto rejeitado;
41. UNC rejeitado;
42. drive-relative rejeitado;
43. `.`/`..`/backslash rejeitados;
44. prefixo diferente de `inputs/ligands/<input_id>/` rejeitado (lexical);
45. **contenção via `Path.is_relative_to()` — `startswith()`, mesmo pós-`resolve()`, é comprovadamente insuficiente e nunca deve ser usado (FS-018-01 § 11)**;
46. **prefix collision: diretório irmão cujo nome começa com o mesmo texto da raiz autorizada (`allowed_root_EVIL`) é corretamente rejeitado apesar de passar em `startswith()` ingênuo**;
47. escape por symlink no arquivo final rejeitado quando detectável;
48. escape por junction/reparse point no arquivo final rejeitado;
49. arquivo não regular rejeitado;
50. **cadeia completa de ancestrais capturada e reverificada nos três momentos normativos (§ 8.3.1)** — ver detalhamento por cenário em § 19.8;
51. ancestral trocado por symlink/junction/reparse point entre validação e abertura — rejeitado;
52. cadeia de ancestrais redirecionada para fora da raiz autorizada — rejeitada;
53. arquivo final trocado entre validação e abertura — `DETECTED`/`raw-identity-unstable`;
54. **arquivo final trocado (inclusive removido) durante a leitura — detectado pela verificação pós-leitura obrigatória (§ 8.3.2.1), fechando a assimetria que a Rota A não implementada teria**;
55. **verificação pós-leitura completa: arquivo final reidentificado, cadeia de ancestrais reverificada por inteiro, identidades e tamanho comparados, SHA-256 recalculado sobre os bytes usados, comparado ao checksum do RAW registrado — somente então o snapshot é aceito (§ 8.3.2.1)**;
56. **checksum e tamanho calculados exclusivamente a partir dos bytes efetivamente lidos do descritor aberto — nunca por releitura do path original (§ 8.3.3)**;
57. **mutação de conteúdo em vaga, mesmo tamanho, mesmo inode, durante a leitura — não detectável por identidade (limitação estrutural documentada, FS-018-01 § 22); deve ser capturada exclusivamente pela comparação de checksum externa, produzindo `raw-checksum-mismatch`**;
58. truncamento durante a leitura — mesma proteção exclusiva por checksum externo;
59. acréscimo durante a leitura — mesma proteção exclusiva por checksum externo;
60. **bloqueio de rename pelo SO enquanto um handle permanece aberto é documentado como observação empírica de plataforma — nunca exigido nem assumido como comportamento do contrato (§ 8.6)**;
61. **hardlink dentro da raiz autorizada, apontando para bytes originalmente fora de qualquer raiz autorizada, é permitido mas nunca tratado como prova de imutabilidade nem como identidade de bytes; o checksum é sempre recomputado e comparado (§ 8.5)**;
62. hardlink não é aceito como prova de escape de path;
63. plataforma sem identificador de arquivo estável para algum nível da cadeia — `raw-nofollow-unavailable`;
64. plataforma sem primitiva de abertura sem seguir link suficiente para a cadeia — falha fechada antes de tocar o RAW, `raw-nofollow-unavailable`;
65. **plataforma/filesystem não validado (POSIX, filesystem local diferente de NTFS, network share, filesystem montado em nuvem) falha fechado com `raw-nofollow-unavailable`, sem alegar suporte (§ 8.7)**;
66. mensagem de erro nunca expõe path absoluto; parsing recebe somente o snapshot, nunca o RAW original.

## 19.4 RDKit — `tests/test_rdkit_tautomer.py` (itens 67-88, expandidos com achados de RD-018-01)

67. base sem RDKit produz capability error;
68. versão real registrada;
69. matriz das oito combinações sanitize×removeHs×strictParsing é exercitada construindo `LigandPromotionPolicy` diretamente para cada uma das 8 linhas;
70. **os três kwargs (`sanitize`, `removeHs`, `strictParsing`) são sempre passados explicitamente à API, nunca omitidos — confirmado necessário porque os defaults nativos do RDKit (`True,True,True`) divergem da política final (RD-018-01 § 4)**;
71. vazio/não SDF;
72. **arquivo vazio falha na construção do supplier (não como registro `None` pós-construção); whitespace-only produz supplier construído com um registro `None` — os dois pontos de falha são distinguidos explicitamente no código (RD-018-01 § 20)**;
73. zero/um/múltiplos registros;
74. válido + inválido, em ambas as ordens (equivalente F13/F14);
75. fragmentos;
76. carga preservada;
77. stereo definida/indefinida;
78. H explícito preservado sob `remove_hs=False`;
79. **H isotópico preservado mesmo quando `remove_hs=True` remove H comum (RD-018-01 § 11)**;
80. propriedades SD preservadas/lidas;
81. nome/CID ausente/divergente vira warning;
82. nenhum `Mol` sai do adapter;
83. snapshot não é modificado;
84. **`sanitize=True, remove_hs=True` mascara um erro de valência real, produzindo silenciosamente uma molécula diferente da declarada — combinação nunca usada em produção (RD-018-01 § 10, § 9.3.1 deste documento)**;
85. **`Chem.MolToSmiles` bem-sucedido nunca é usado como prova de validade/elegibilidade — teste dedicado que gera SMILES válido a partir de um `Mol` não sanitizado quimicamente inválido e confirma que ele não é aceito como elegível (RD-018-01 § 15)**;
86. **algoritmo de "exatamente uma molécula" implementado acima do RDKit: supplier percorrido por inteiro, `total==1 and valid==1` exigido, nunca aceitar o único válido isoladamente quando há mais de um registro (RD-018-01 § 13)**;
87. **regra A/B/C de `strictParsing`: nenhuma diferença comportamental é exigida pelo teste; o parâmetro continua sendo passado explicitamente e registrado na proveniência/`semantic_key`; nenhuma equivalência universal entre `True`/`False` é declarada (§ 9.3.3 deste documento)**;
88. proveniência registra o valor solicitado (nunca um "efetivo" inferido) quando nenhum efeito é observável, para `remove_hs` sob `sanitize=False` e para `strict_parsing` sempre.

## 19.5 Application Service — `tests/test_promotion_service.py` (itens 89-110, sem alteração de conteúdo)

89. sucesso com entity nova;
90. sucesso com entity preexistente exatamente compatível;
91. entity preexistente incompatível e state preexistente sem promotion record são conflitos;
92. retry mesmos IDs retorna record;
93. retry IDs diferentes falha;
94. semantic key mudou sem revision falha;
95. revision explícita cria nova chave;
96. dois `input_id`s distintos com RAW de bytes/checksum idênticos produzem duas promoções independentes;
97. checksum divergente antes de escrita científica;
98. cada falha de resolução persiste status;
99. cada falha de execução compensa;
100. falha de terminal persistence usa wrapper;
101. KeyboardInterrupt/SystemExit em resolução;
102. KeyboardInterrupt/SystemExit após publicação;
103. entity criada/state falha;
104. state criado/lineage falha;
105. lineage committed/status falha não remove promoção;
106. resíduos locais de entity/state/reservation sobrevivem falha de persistência; promotion record nunca aparece como resíduo;
107. activity started/success/error e falha best effort;
108. RAW permanece em todas as falhas;
109. fluxo até load_state válido;
110. state resultante aceito por enumerate-tautomers com RDKit.

## 19.6 CLI — `tests/test_cli.py` (itens 111-125)

111. help e assinatura;
112. sucesso novo;
113. sucesso idempotente;
114. quatro banners e exit code;
115. attempt ID/status/phase;
116. unconfirmed removals;
117. ausência de traceback/path absoluto;
118. wrapper de persistência sem retry/compensação CLI;
119. KeyboardInterrupt/SystemExit atravessam;
120. Application Service chamado uma vez;
121. CLI não importa RDKit;
122. CLI não lista/diff attempts;
123. `--revision` válida/inválida;
124. conflito de IDs humano;
125. **banner `STORAGE ERROR` cobre `raw-permission-denied`/`raw-sharing-violation` e `promotion-primitive-unavailable` distintamente de outros erros de storage, sem expor traceback (§ 15.4, § 17)**.

## 19.7 Concorrência e integração geral (itens 126-135)

126. dois processos, mesma chave/mesmos IDs (nível de integração, complementar ao detalhamento com 8 processos de § 19.9);
127. mesma chave/IDs diferentes;
128. chaves diferentes/mesmo state (visão de integração; detalhamento em § 19.9);
129. casefold de entity **e** state em conjunto, em um único fluxo de integração (o detalhamento isolado de cada um está em § 19.9);
130. vencedor cai antes de publish (visão de integração; detalhamento em § 19.9);
131. vencedor cai após state antes de lineage (visão de integração; detalhamento em § 19.9);
132. pacote base sem RDKit importa CLI;
133. pacote `.[rdkit]` executa promoção;
134. PubChem já adquirido → promoção → tautomer CLI/API;
135. suíte completa preservada.

## 19.8 FS-018-01 — identidade da cadeia de ancestrais, Rota B endurecida (itens 136-150)

Itens normativos correspondentes ao checklist de 17 cenários de FS-018-01 (§ 23.2.1 do rascunho pré-spike, agora encerrado), reformulados para a Rota B endurecida (única rota implementada):

136. arquivo final substituído antes da abertura;
137. arquivo final substituído durante a leitura (fechado pela verificação pós-leitura obrigatória, § 8.3.2.1, item 55 de § 19.3);
138. diretório pai imediato substituído antes da abertura do arquivo final;
139. diretório pai imediato substituído após a validação e antes da leitura;
140. ancestral intermediário (nem pai imediato, nem raiz autorizada) substituído;
141. ancestral removido e recriado com o mesmo nome;
142. ancestral trocado por symlink entre a validação e a abertura;
143. ancestral trocado por junction entre a validação e a abertura;
144. ancestral trocado por reparse point genérico entre a validação e a abertura;
145. cadeia de ancestrais redirecionada para fora da raiz RAW autorizada após validação lexical inicial;
146. identidade do arquivo final preservada, mas identidade de um ancestral divergente — `raw-identity-unstable` mesmo com o arquivo final íntegro;
147. identidade de todos os ancestrais preservada, mas identidade do arquivo final divergente — `raw-identity-unstable`;
148. plataforma sem `st_ino`/identificador de arquivo confiável para algum nível da cadeia — `raw-nofollow-unavailable` antes de qualquer escrita científica;
149. plataforma sem primitiva de abertura sem seguir link suficiente para a cadeia de ancestrais — a Rota B endurecida deve ser provada suficiente, ou `raw-nofollow-unavailable`;
150. impossibilidade de obter reparse tag de um ancestral no Windows — degradação documentada para a garantia que a Rota B endurecida ainda puder prover, ou capability error se nem isso for suficiente.

## 19.9 FS-018-02 — reserva cross-process (itens 151-169)

Itens normativos correspondentes aos 8 cenários de FS-018-02, mais os invariantes estruturais confirmados pelo spike (ausência de TTL, ordem de aquisição, normalização de claims):

151. **8 processos reais disputam a mesma semantic key e os mesmos IDs simultaneamente — exatamente um vencedor, sete perdedores determinísticos, nenhum overwrite do promotion record nem de nenhum claim (FS-018-02 S01)**;
152. **8 processos reais disputam a mesma semantic key com IDs de entity/state diferentes por processo — exatamente um vencedor; os sete perdedores falham na própria etapa da reserva semântica e nunca chegam a tentar nenhum claim, eliminando qualquer publicação parcial a partir dos IDs de um perdedor (FS-018-02 S02)**;
153. **entity claim colide corretamente por casefold entre duas semantic keys distintas (`Entity-A` vs. `entity-a`) — somente um cria o claim, o outro falha determinìsticamente sem overwrite (FS-018-02 S03)**;
154. **state claim colide corretamente por casefold entre duas semantic keys distintas (`State-A` vs. `state-a`) — somente um cria o claim (FS-018-02 S04)**;
155. **duas transações com semantic key/entity/state totalmente distintos progridem e vencem de forma independente, sem bloqueio global indevido entre reservas não relacionadas (FS-018-02 S05)**;
156. **crash simulado imediatamente após adquirir a reserva semântica, antes de qualquer claim — um concorrente subsequente encontra o resíduo e recebe BUSY/INDETERMINATE, nunca trata como livre; inspeção read-only identifica o owner e a fase conhecida sem mutar nada (FS-018-02 S06)**;
157. **crash simulado após adquirir entity claim e state claim, antes do promotion record — reserva e claims preservados como resíduo; um concorrente não duplica nem sobrescreve; inspeção read-only sinaliza necessidade de reconciliação; nenhuma compensação automática é executada (FS-018-02 S07)**;
158. **crash simulado após publicar o promotion record, antes do release — o promotion record permanece como sucesso autoritativo; um concorrente subsequente reconhece o sucesso existente e não republica (FS-018-02 S08)**;
159. **tentativa de release com `owner_token` incorreto (mesmo com `attempt_id` correto) é sempre recusada sem tocar o recurso (FS-018-02 S08)**;
160. **release com `attempt_id`+`owner_token` corretos remove exatamente os recursos pertencentes àquele owner, nunca recursos de outro owner (FS-018-02 S08)**;
161. **uma reserva com metadata datada artificialmente no passado nunca é apropriada automaticamente por TTL — verificado estruturalmente pela ausência de qualquer caminho de código que remova por idade (§ 11.7)**;
162. **um concorrente que adquire semantic reservation + entity claim e perde o state claim libera, em ordem inversa, somente os recursos que ele mesmo já adquiriu (state se houver, entity, semantic) — compensação inversa de aquisição parcial (§ 11.10; limitação herdada: não exercitada diretamente pelo protótipo do spike, deve ser testada explicitamente na implementação)**;
163. **falha ao confirmar uma liberação (metadata ilegível/ausente no momento do release) produz um resíduo tipado, nunca remove recurso de outro owner, nunca declara compensação completa sem confirmação (§ 11.10)**;
164. **a publicação do promotion record recusa overwrite por construção (criação exclusiva via hardlink no Windows/NTFS local); uma segunda tentativa de publicar para a mesma semantic key nunca sobrescreve o record existente (FS-018-02 S01, S02, S08)**;
165. **um promotion record publicado é reconhecido como commit marker autoritativo por qualquer concorrente subsequente; nenhuma tentativa nova o trata como resíduo comum nem tenta removê-lo via release (FS-018-02 S08; § 11.9, § 11.12)**;
166. **ausência, metadata incompleta ou metadata inválida em qualquer reserva/claim é sempre interpretada como BUSY/INDETERMINATE, nunca como "livre para adquirir" (§ 11.6)**;
167. **normalização Unicode NFC + `casefold()` aplicada antes do SHA-256 de cada claim, garantindo que grafias/casos diferentes do mesmo ID resolvam ao mesmo claim (§ 11.4)**;
168. **ordem de aquisição respeitada mecanicamente: semantic reservation → entity claim (quando necessário) → state claim, nunca fora de ordem, e nunca com um claim adquirido sem a reserva semântica correspondente (§ 11.5)**;
169. **ambiente/primitiva de publicação exclusiva do promotion record indisponível, ou incapaz de provar exclusividade, produz falha fechada com `promotion-primitive-unavailable`, nunca publica sem essa garantia (§ 11.9, § 17)**.

---

# 20. Allowlist final

| arquivo | ação | justificativa |
|---|---|---|
| `src/molecular/promotion.py` | criar | modelos e invariantes do domínio |
| `src/molecular/promotion_registry.py` | criar | attempts, records, consultas e reserva/claims (§ 11) |
| `src/molecular/promotion_service.py` | criar | orquestração sem ampliar `application.py` |
| `src/molecular/rdkit_tautomer.py` | modificar | manter único boundary RDKit e adicionar inspeção neutra (§ 9) |
| `src/molecular/scientific_registry.py` | modificar | compensação estreita com match/dependents (§ 13.4) — nunca wrappers de `_remove_state_best_effort` |
| `src/molecular/atomic.py` | modificar | **primitiva de criação exclusiva/owner confirmada por FS-018-02 (`os.mkdir` para reserva/claims, staging+`os.link` para promotion record) e primitiva de abertura sem seguir link confirmada por FS-018-01 (Rota B endurecida, § 8.3) — ambas agora normativas** |
| `src/molecular/cli.py` | modificar | comando fino |
| `tests/test_promotion.py` | criar | domínio |
| `tests/test_promotion_registry.py` | criar | persistência/reserva |
| `tests/test_promotion_service.py` | criar | workflow/compensação |
| `tests/test_rdkit_tautomer.py` | modificar | inspeção SDF no boundary existente |
| `tests/test_scientific_registry.py` | modificar | primitivas de remoção segura |
| `tests/test_atomic.py` | modificar | exclusividade/concorrência/no-follow para arquivo final, ancestrais e reserva cross-process (§ 19.3, § 19.8, § 19.9) |
| `tests/test_cli.py` | modificar | CLI |

Não alterar `inputs.py`, `registry.py`, `scientific.py`, `execution.py`, `execution_registry.py`, `pubchem.py` ou `pyproject.toml` sem achado novo aprovado em revisão.

---

# 21. Migração e compatibilidade

**Preservada sem nenhuma alteração de conteúdo** — nenhum spike toca schemas existentes, inputs antigos, novos diretórios ou regras de versão futura.

## 21.1-21.4

Sem alteração: `LigandInput`/`AcquisitionRecord`/`RawArtifact`/`ScientificEntity`/`MolecularState`/`MolecularRepresentationRef`/`ExecutionAttempt` inalterados; input antigo promovível se validar/satisfizer o contrato seguro/existir/conferir checksum/passar na política; novos diretórios:

```text
scientific/promotion_attempts/<attempt_id>.yaml
scientific/promotions/<semantic_key>.yaml
scientific/promotion_reservations/<semantic_key>/reservation.yaml
scientific/promotion_reservations/by-entity/<digest>/reservation.yaml
scientific/promotion_reservations/by-state/<digest>/reservation.yaml
```

Versão futura (mudança de política, cardinalidade, sais, reserialização) exige novo schema/policy version.

---

# 22. Critérios de aceite

1. HEAD e baseline confirmados antes de implementar.
2. Somente arquivos do allowlist final são alterados.
3. `LigandInput` existente é a única origem aceita.
4. Nenhum HTTP é executado pela promoção.
5. IDs/policy inválidos falham antes de attempt/I/O.
6. Path absoluto POSIX/Windows, UNC, drive-relative, traversal e links não autorizados são rejeitados via `is_relative_to()` — nunca `startswith()` (§ 8.2, confirmado por FS-018-01).
7. O arquivo resolvido permanece dentro da raiz daquele input, inclusive contra colisão textual de prefixo (`allowed_root_EVIL`).
8. O snapshot é criado pela Rota B endurecida e seu checksum iguala o persistido, confirmado pela verificação pós-leitura obrigatória (§ 8.3.2.1).
9. Parsing e `register_state` consomem exatamente o snapshot, não o RAW original.
10. O RAW nunca é sobrescrito nem removido.
11. Somente SDF com exatamente um registro válido é aceito, com o algoritmo de contagem confirmado por RD-018-01 (§ 9.2).
12. Registro válido + inválido é rejeitado como multiplicidade, em qualquer ordem.
13. Estrutura desconectada é rejeitada sem dessalinização.
14. Carga e stereo não são normalizadas silenciosamente.
15. Flags RDKit solicitadas/efetivas e versão são persistidas, com os três kwargs sempre explícitos (§ 9.2, confirmado por RD-018-01).
16. Nenhum `Mol` entra no domínio.
17. Representação publicada é byte a byte igual ao snapshot para schema 1.0.
18. Promotion record é a aresta formal de lineage, publicado por criação exclusiva (hardlink no Windows/NTFS local), nunca sobrescrito (§ 11.9, confirmado por FS-018-02).
19. Promotion record somente existe após entity/state coerentes.
20. Semantic key exclui IDs desejados e inclui bytes/policy/engine efetivos.
21. Retry equivalente com mesmos IDs retorna o record existente — reconhecido como commit marker autoritativo (§ 11.9).
22. Retry equivalente com IDs diferentes falha sem publicar.
23. Nova promoção diferente exige `intentional_revision` explícita.
24. Reserva semântica é adquirida via `os.mkdir` exclusivo antes da primeira escrita científica (§ 11.2, confirmado por FS-018-02).
25. Dois (ou mais) processos não criam duas promoções para a mesma chave — confirmado com 8 processos reais (FS-018-02 S01/S02).
26. Claims protegem entity/state contra colisão exata e casefold (NFC+`casefold()`+SHA-256, confirmado por FS-018-02 S03/S04).
27. Objetos preexistentes nunca são removidos pela compensação.
28. Objetos criados só são removidos com ownership (`attempt_id`+`owner_token` exatos) e conteúdo confirmados (§ 11.8, confirmado por FS-018-02 S08).
29. Falha de compensação produz remoções não confirmadas estruturadas, nunca remove recurso de outro owner (§ 11.10).
30. Falha depois do commit marker não apaga promoção concluída; um concorrente reconhece o sucesso existente e não republica (§ 11.12, confirmado por FS-018-02 S08).
31. Exceções públicas preservam attempt ID, erro original e chaining.
32. Activity é best effort e não é source of truth.
33. CLI chama o Application Service exatamente uma vez.
34. CLI não importa RDKit nem executa química/compensação.
35. Saída CLI não contém traceback ou path absoluto.
36. Instalação base sem RDKit continua importando domínio/CLI.
37. Instalação com RDKit executa o fluxo ponta a ponta.
38. O state produzido pode alimentar `state enumerate-tautomers`.
39. Todos os testes novos e a suíte completa passam sem resultados forçados.
40. `git diff --check` fica limpo.
41. `increment-009-review.txt` permanece intocado e fora do diff.
42. A `semantic_key` é calculada pelo algoritmo determinístico da § 10.2; o vetor golden produz o digest hardcoded exato e permanece estável.
43. `LigandPromotionPolicy` representa, sem erro de validação, as oito combinações da matriz; a CLI de produção constrói exclusivamente o default confirmado.
44. Dois `input_id`s distintos com RAW de conteúdo idêntico produzem duas promoções independentes, sem merge ou deduplicação por checksum.
45. **A Rota B endurecida (única rota implementada, § 8.3) está definida com verificação pós-leitura obrigatória; quando a plataforma não é a validada (§ 8.7), a promoção falha fechado com `raw-nofollow-unavailable`, nunca degrada silenciosamente.**
46. A compensação da promoção nunca chama `_remove_state_best_effort` diretamente; as novas primitivas de `scientific_registry.py` não alteram o comportamento dos chamadores existentes dos Incrementos 016/017.
47. **A contagem de 169 linhas normativas de cenário (§ 19, incluindo § 19.8 e § 19.9) está correta e reconciliada; nenhuma seção deste documento cita as contagens antigas de 104, 120 ou 135 como vigentes.**
48. A reverificação de identidade das Rotas (agora exclusivamente a Rota B endurecida) cobre explicitamente toda a cadeia de ancestrais, nos três momentos normativos mais a verificação pós-leitura obrigatória (§ 8.3.1, § 8.3.2.1).
49. **A contenção de path usa exclusivamente `Path.is_relative_to()`; `startswith()`, mesmo pós-`resolve()`, está proibida em qualquer verificação de contenção do Incremento 018, incluindo o próprio harness de teste (§ 8.2, confirmado por FS-018-01).**
50. **Hardlink nunca é tratado como prova de escape de path nem como garantia de imutabilidade; o checksum é sempre recomputado sobre os bytes efetivamente lidos, mesmo para um arquivo final que seja hardlink (§ 8.5).**
51. **A reserva cross-process usa exclusivamente criação exclusiva de diretório (`os.mkdir`) para reserva/claims e criação exclusiva (hardlink no Windows/NTFS local) para o promotion record; nenhum mecanismo de TTL autoriza remoção automática de reserva em nenhuma circunstância (§ 11.2, § 11.7, § 11.9, confirmado por FS-018-02).**
52. **Release de reserva/claim exige correspondência exata de `attempt_id` e `owner_token`; non-owner nunca libera; compensação de aquisição parcial libera, em ordem inversa, somente os próprios recursos já confirmados (§ 11.8, § 11.10).**
53. **`strictParsing` é passado explicitamente e registrado na proveniência/`semantic_key` independentemente de qualquer efeito comportamental comprovado; nenhuma equivalência universal entre seus valores é declarada pela especificação ou pelos testes (§ 9.3.3, regra A/B/C).**

---

# 23. Spikes concluídos e questões fechadas

Os três spikes obrigatórios do rascunho pré-spike (§ 23 daquele documento) foram executados, revisados e/ou reconciliados, e a candidata resultante foi aprovada por revisão final sem blocker/major. Nenhuma nova família de spike é necessária.

## 23.1 `RD-018-01` — parsing RDKit — CONCLUÍDO

| item | resultado |
|---|---|
| execução | 144 células (8 combinações × 18 fixtures), 26,2s, 0 crashes não explicados |
| revisão adversarial | `APPROVE WITH NON-BLOCKING NOTES` (1 MAJOR sobre ferramenta de análise, 1 MINOR sobre duas tabelas-resumo, 3 NOTES de cobertura) |
| reconciliação | `RECONCILED PASS WITH LIMITATIONS` — 28/72 divergências brutas de stderr (artefato de timestamp), 0/72 após normalização; F13/F14 = 2/1/1 apenas em C5/C6, 2/2/0 nas demais 6 combinações |
| decisões incorporadas | § 7.1, § 9.2-9.8 deste documento |
| limitações remanescentes | caso "supplier vazio" (construído, zero registros) não demonstrado por nenhuma fixture; preservação RAW comprovada apenas indiretamente quanto às fixtures originais; defaults nativos não reinspecionados pelo revisor (RDKit ausente no ambiente de revisão) — nenhuma bloqueia o congelamento |

## 23.2 `FS-018-01` — path, links e snapshot — CONCLUÍDO

| item | resultado |
|---|---|
| execução | 44 cenários nomeados (50 entradas com sub-janelas), 20 repetições cada onde aplicável, 0 divergência entre repetições |
| revisão adversarial | reconciliação: 34 ataques genuinamente executados, 3 observações de capacidade reencaixadas, 7 cenários `UNSUPPORTED` (symlink sem privilégio) |
| classificação reconciliada | Rota A: `PASS WITH LIMITATIONS`; Rota B: `PASS`; FS-018-01: `PASS WITH LIMITATIONS` |
| decisão de produto | Rota B endurecida escolhida como único mecanismo normativo (§ 8.3); Rota A não implementada no Incremento 018 |
| decisões incorporadas | § 8 inteira deste documento |
| limitações remanescentes | POSIX não avaliado (nenhum ambiente disponível sem instalação); mutação em vaga do mesmo inode não detectável por identidade (mitigado por checksum externo, § 8.6) — nenhuma bloqueia o congelamento para a plataforma validada (Windows 11/NTFS local) |

## 23.3 `FS-018-02` — reserva cross-process — CONCLUÍDO

| item | resultado |
|---|---|
| execução | 8 cenários (S01-S08), processos reais, sincronização por `Barrier`, 2,33s total |
| classificação | `PASS` (§ 2.3 deste documento: identidade/manifesto/8-cenários recomputados e confirmados) |
| decisões incorporadas | § 11 inteira deste documento |
| limitações remanescentes | compensação inversa de aquisição parcial (perdedor que já adquiriu um recurso anterior) não exercitada diretamente pelo protótipo do spike — deve ser testada explicitamente na implementação (§ 11.10, § 19.9 item 162); rollback automático de tentativas abandonadas sem crash não especificado — nenhuma bloqueia o congelamento, ambas registradas como trabalho de implementação, não como decisão de arquitetura em aberto |

## 23.4 Revisão final — CONCLUÍDA

A candidata (revisão 4) foi submetida a uma revisão adversarial final curta e decisiva, que concluiu: **0 blockers, 0 majors, 1 minor evidencial (qualificação sobre corroboração do primeiro bug do harness de FS-018-02, aplicada em § 2.3), 4 notes (nenhuma exigindo mudança adicional), `VERDICT: APPROVE`, `READY FOR FREEZE: YES`**. Os 169 cenários normativos foram reconciliados mecanicamente pela revisão (`24+14+28+22+22+15+10+15+19 = 169`, sem lacunas nem duplicações). As três questões abertas da candidata (§ 31.4) foram avaliadas e classificadas como trabalho futuro não bloqueante, nunca como decisão de arquitetura pendente.

## 23.5 Nenhuma questão de arquitetura permanece aberta

Nenhuma limitação remanescente de qualquer spike, nem qualquer nota da revisão final, exige uma nova rodada de spike antes do congelamento. Todas estão refletidas explicitamente nos critérios de aceite (§ 22) e na matriz de testes (§ 19), e são tratadas como trabalho de implementação/teste, não como decisão de arquitetura em aberto.

---

# 24. Fora do escopo

**Preservada e expandida** com a lista explícita de padrões de proveniência/interoperabilidade que permanecem não normativos para este incremento.

## 24.1 Fora do escopo funcional (sem alteração)

- novo download PubChem;
- busca PubChem por nome;
- importação automática de PUG View;
- SID resolution;
- protonação ou microestados;
- pH/pKa operacional;
- `ExperimentalConditions`;
- escolha/ranking de tautômero;
- embedding ou otimização 3D;
- `Conformer` automático;
- receptor/RCSB;
- PDBFixer/OpenMM;
- PROPKA/PDB2PQR;
- Meeko/PDBQT;
- docking/redocking;
- Pose/RMSD/scoring;
- GUI nova;
- scheduler/jobs/database;
- promoção 1→N;
- dessalinização/neutralização;
- migração retroativa de inputs antigos;
- refatoração geral do adapter RDKit;
- reconciliação/remoção automática de reserva abandonada (§ 11.14 — permanece API administrativa futura, não deste incremento).

## 24.2 Fora do escopo de interoperabilidade/proveniência formal

Os seguintes padrões e formatos de proveniência/interoperabilidade científica **não são incorporados ao contrato normativo do Incremento 018**:

- W3C PROV / PROV-O;
- RO-Crate;
- FAIR Digital Objects;
- BCO (Bioinformatics Contribution Ontology / BioCompute Objects);
- SED-ML;
- COMBINE (arquivo/padrão);
- DataCite;
- SPDX;
- exportação JSON-LD/RDF de qualquer artefato deste incremento.

O modelo de proveniência interno deste incremento (§ 16, `AcquisitionProvenanceSnapshot`/`ScientificInputPromotionRecord`) permanece a única forma normativa de proveniência do Incremento 018. Qualquer estudo futuro sobre adoção de um ou mais desses padrões permanece **referência não normativa** — não é parte do contrato, e não deve ser antecipado por nenhuma implementação deste incremento.

---

# 25. Plano de implementação

Informativo, agora autorizado pelo congelamento (Gate 7-8, § 28).

1. ~~executar e revisar RD-018-01~~ — **concluído**;
2. ~~executar e revisar FS-018-01 e FS-018-02~~ — **concluído**;
3. ~~revisão final curta e decisiva da candidata~~ — **concluída** (`VERDICT: APPROVE`, 0 blockers, 0 majors);
4. ~~aplicar o minor evidencial indicado e congelar a especificação final~~ — **concluído, este documento**;
5. criar branch a partir do HEAD confirmado (§ 2);
6. implementar modelos e validators;
7. implementar registry de attempt/promotion/reserva (`os.mkdir` exclusivo, claims casefold, hardlink exclusivo para promotion record);
8. implementar Rota B endurecida no boundary de path/identidade (`atomic.py`), incluindo a verificação pós-leitura obrigatória;
9. implementar inspeção neutra no boundary RDKit (três kwargs sempre explícitos);
10. implementar compensação estreita no scientific registry (ordem inversa, ownership exato);
11. implementar Application Service;
12. implementar CLI fina;
13. executar testes por checkpoint (169 linhas normativas, § 19);
14. revisão adversarial de código;
15. correções, suíte completa, PR e merge normal.

Cada etapa produz commit/checkpoint independente depois de testes verdes. Este documento autoriza o início da etapa 5; não executa nenhuma das etapas 5-15.

---

# 26. Riscos

| risco | gravidade | mitigação | status |
|---|---:|---|---|
| escape do RAW/path alterado, incluindo por substituição de diretório ancestral | alta | Rota B endurecida, contrato de 12 pontos, verificação pós-leitura obrigatória, `is_relative_to()` (§ 8) | **mitigado, comprovado empiricamente (FS-018-01)** |
| parsing não corresponde às flags presumidas | alta | RD-018-01, parâmetros efetivos e literals fechados | **mitigado, comprovado empiricamente** |
| duplicação concorrente | alta | reserva/claims exclusivos por `os.mkdir`, processos reais em teste | **mitigado, comprovado empiricamente (FS-018-02)** |
| entity/state sem lineage | alta | commit marker exclusivo, compensação e reconciliação | mitigado por desenho |
| compensação remove preexistente | alta | flags locais + match + dependents + ownership exato (`attempt_id`+`owner_token`) | mitigado por desenho, parcialmente comprovado (FS-018-02 owner-only release) |
| ambiguidade de canonização produz duplicação silenciosa | alta | algoritmo determinístico fechado, vetor golden recomputado três vezes | mitigado |
| stale reservation bloqueia uso | média/alta | inspeção read-only; nenhum TTL automático (§ 11.7, § 11.14) | mitigado por desenho, remoção administrativa fora do escopo |
| `application.py`/CLI crescerem | média | serviço novo, CLI fina | mitigado por desenho |
| RDKit espalhado | média | único boundary existente | mitigado por desenho |
| propriedades SD virarem identidade | média | warnings somente; IDs explícitos | mitigado por desenho |
| state aceito não representar docking-ready | média | texto/CLI explícitos; 3D/preparo fora do escopo | mitigado por desenho |
| falha após commit do lineage | média | lineage permanece autoritativo; reconciliar attempt (§ 11.12) | mitigado, comprovado empiricamente (FS-018-02 S08) |
| RAW diferente com conteúdo idêntico causa deduplicação indevida | média | chave inclui `input_id`; duas promoções independentes | mitigado por desenho |
| mutação de conteúdo em vaga (mesmo inode) durante a leitura do RAW | média | não detectável por identidade (limitação estrutural, FS-018-01 § 22); único mecanismo de proteção é a comparação de checksum externa — tratada como camada obrigatória, não redundante | limitação residual reconhecida, mitigada apenas parcialmente |
| compensação inversa de aquisição parcial não exercitada empiricamente pelo protótipo de FS-018-02 | média | deve ser testada explicitamente na implementação (§ 11.10, § 19.9 item 162) | lacuna de evidência registrada, não bloqueou congelamento |
| POSIX e filesystems não-NTFS-local permanecem não validados | média | fail-closed explícito com código tipado (§ 8.7-8.8); nenhuma alegação de suporte | mitigado por desenho para o Incremento 018; POSIX permanece trabalho futuro |

---

# 27. Decisões

Decisões provisórias do rascunho pré-spike (D-018-DRAFT-01 a 16), com status final — nenhuma foi revertida:

| ID | decisão | status |
|---|---|---|
| D-018-DRAFT-01 | Opção B com lineage mínimo da A; C fora do escopo. | congelada |
| D-018-DRAFT-02 | Models/registry próprios; não estender `ExecutionAttempt`. | congelada |
| D-018-DRAFT-03 | SDF, exatamente um registro e um componente. | congelada, algoritmo confirmado por RD-018-01 |
| D-018-DRAFT-04 | Default `sanitize=True, removeHs=False, strictParsing=True`. | **congelada, confirmada por RD-018-01** (única combinação sem mascaramento) |
| D-018-DRAFT-05 | Publicar os mesmos bytes do snapshot. | congelada |
| D-018-DRAFT-06 | Promotion record de sucesso é commit marker. | **congelada, confirmada por FS-018-02** (criação exclusiva, nunca sobrescrito) |
| D-018-DRAFT-07 | Semantic key exclui IDs desejados, inclui bytes/policy/engine. | congelada |
| D-018-DRAFT-08 | Revisão semântica exige `intentional_revision`. | congelada |
| D-018-DRAFT-09 | Reserva/claims antecedem publication. | **congelada, confirmada por FS-018-02** (`os.mkdir` exclusivo, ordem semantic→entity→state) |
| D-018-DRAFT-10 | Compensação exige ownership; preexistentes nunca apagados. | **congelada, confirmada por FS-018-02** (owner-only release) |
| D-018-DRAFT-11 | Serviço dedicado `promotion_service.py`. | congelada |
| D-018-DRAFT-12 | Único boundary RDKit é `rdkit_tautomer.py`. | congelada |
| D-018-DRAFT-13 | Três flags RDKit tipados `bool`. | **congelada, confirmada por RD-018-01** (as 8 combinações foram construídas sem erro) |
| D-018-DRAFT-14 | Algoritmo de canonização da `semantic_key`. | congelada, inalterada |
| D-018-DRAFT-15 | Rota A/Rota B; fail-closed sem prova de identidade. | **resolvida por FS-018-01 — ver D-018-DRAFT-17** |
| D-018-DRAFT-16 | Reverificação de identidade cobre cadeia completa de ancestrais. | **congelada, confirmada por FS-018-01**, agora incluindo verificação pós-leitura obrigatória |

Decisões fechadas a partir da evidência dos spikes, agora congeladas:

| ID | decisão |
|---|---|
| **D-018-DRAFT-17** | A **Rota B endurecida** (§ 8.3) é o único mecanismo normativo de abertura sem seguir link para o Windows 11/NTFS local validado. A Rota A não é implementada no Incremento 018; permanece possibilidade futura condicionada a verificação pós-leitura, contrato integral de ancestrais, novo spike específico, e nenhuma degradação silenciosa (§ 8.3.0). Decidida por evidência direta de FS-018-01 (`os.supports_dir_fd=False` no Windows/CPython). |
| **D-018-DRAFT-18** | Contenção de path usa exclusivamente `Path.is_relative_to()`. `startswith()`, mesmo pós-`resolve()`, está proibida em qualquer verificação de contenção do Incremento 018 (§ 8.2). Decidida por evidência direta de FS-018-01 (caso `allowed_root_EVIL`). |
| **D-018-DRAFT-19** | Hardlink nunca é tratado como prova de escape de path nem como garantia de imutabilidade; identidade de arquivo nunca substitui identidade de bytes (§ 8.5). Decidida por análise de FS-018-01 (S40, hardlink apontando para fora da raiz). |
| **D-018-DRAFT-20** | Reserva semântica e claims usam criação exclusiva de diretório (`os.mkdir`); normalização de claims via Unicode NFC + `casefold()` + SHA-256; ordem semantic→entity→state; ownership por `attempt_id`+`owner_token` imprevisível; ausência/metadata inválida nunca significa "livre"; TTL isolado nunca autoriza remoção; release exige correspondência exata; non-owner nunca libera (§ 11.2-11.8). Decidida por evidência direta de FS-018-02 (8/8 cenários PASS). |
| **D-018-DRAFT-21** | Promotion record é publicado por staging privado + criação exclusiva (hardlink no Windows/NTFS local); recusa absoluta de overwrite; se a primitiva não estiver disponível, falha fechada (`promotion-primitive-unavailable`); é reconhecido como commit marker autoritativo por qualquer concorrente subsequente (§ 11.9). Decidida por evidência direta de FS-018-02 (S01, S02, S08). |
| **D-018-DRAFT-22** | Compensação de aquisição parcial libera, em ordem inversa, somente os recursos já confirmados pelo próprio attempt; falha de confirmação produz resíduo tipado, nunca remove recurso de outro owner (§ 11.10). Decisão de arquitetura fechada; **evidência empírica direta do spike é uma lacuna registrada** (§ 23.3), a ser fechada por teste de implementação, não por novo spike. |
| **D-018-DRAFT-23** | Os padrões de proveniência/interoperabilidade formal listados em § 24.2 (PROV/PROV-O, RO-Crate, FAIR DO, BCO, SED-ML, COMBINE, DataCite, SPDX, exportação JSON-LD/RDF) permanecem fora do contrato normativo do Incremento 018 — referência futura não normativa. |

**Todas as decisões acima estão congeladas a partir do Gate 7 (§ 28), concluído por este documento.**

---

# 28. Gates

## Gate 1 — revisão adversarial do rascunho original — **CONCLUÍDO**
## Gate 2 — correção documental (revisão 2) — **CONCLUÍDO**
## Gate 3 — nova revisão adversarial curta do rascunho revisado — **CONCLUÍDO**
## Gate 4 — correção documental pré-spike — **CONCLUÍDO**

## Gate 5 — execução controlada dos spikes técnicos — **CONCLUÍDO**

RD-018-01 (executado, revisado, reconciliado: `RECONCILED PASS WITH LIMITATIONS`), FS-018-01 (executado, revisado, reconciliado: `PASS WITH LIMITATIONS`) e FS-018-02 (executado: `PASS`) — todos fora do repositório, sem alterar código, com identidade e evidência recomputadas de forma independente em cada etapa.

## Gate 6 — especificação final candidata — **CONCLUÍDO**

Produziu `increments/018/09-final-specification/INCREMENT_018_FINAL_SPECIFICATION_CANDIDATE.md` (revisão 4), incorporando a evidência dos três spikes e reconciliando a contagem de testes (135 → 169).

## Gate 7 — congelamento — **CONCLUÍDO — ESTE DOCUMENTO**

A revisão final curta e decisiva (`increments/018/10-final-review/INCREMENT_018_FINAL_SPECIFICATION_CANDIDATE_SHORT_REVIEW.md`) concluiu com **0 blockers, 0 majors, 1 minor evidencial (corrigido em § 2.3 deste documento) e `VERDICT: APPROVE`**, `READY FOR FREEZE: YES`. Este documento aplica a única correção indicada e declara `FINAL SPECIFICATION FROZEN: YES`.

## Gate 8 — implementação — **AUTORIZADO A PARTIR DESTE DOCUMENTO**

O congelamento (Gate 7) está concluído. A implementação pode começar em um branch novo a partir do HEAD confirmado (§ 2), seguindo o plano informativo da § 25, após novo baseline local/`pytest` nesse branch.

---

# 29. Status final

Este documento é a **especificação final e congelada (revisão 5)** do Incremento 018. Ele incorpora integralmente as decisões sustentadas pelos três spikes obrigatórios (RD-018-01, FS-018-01, FS-018-02), por todas as suas revisões adversariais e reconciliações, e pela revisão final curta e decisiva da candidata (`VERDICT: APPROVE`, 0 blockers, 0 majors, 1 minor evidencial corrigido em § 2.3), mantém a seleção da Opção B com fundação mínima de lineage da Opção A, preserva integralmente o algoritmo de canonização da `semantic_key`, o payload canônico, o vetor golden, a matriz `LigandPromotionPolicy` e a separação das quatro identidades — e **autoriza implementação** a partir daqui.

```text
INCREMENT 018 FINAL SPECIFICATION COMPLETE: YES
REVISION NUMBER: 5
PRIOR ADVERSARIAL REVIEWS INCORPORATED: YES (4/4 documentais + 2 de spike + 1 reconciliação + 1 revisão final)
RD-018-01 INCORPORATED: YES (RECONCILED PASS WITH LIMITATIONS)
FS-018-01 INCORPORATED: YES (PASS WITH LIMITATIONS, RECONCILED)
FS-018-02 INCORPORATED: YES (PASS)
FINAL REVIEW RECONCILED: YES (0 BLOCKERS, 0 MAJORS, 1 MINOR EVIDENCIAL CORRIGIDO, VERDICT: APPROVE)
REQUIRED MINOR CORRECTED: YES
ROUTE B HARDENED SELECTED AS SOLE MECHANISM: YES
ROUTE A DEFERRED (NOT IMPLEMENTED IN INCREMENT 018): YES
STARTSWITH() FORBIDDEN FOR CONTAINMENT: YES
POST-READ VERIFICATION MANDATORY: YES
EXCLUSIVE-MKDIR RESERVATION ADOPTED: YES
CASEFOLD CLAIM NORMALIZATION ADOPTED: YES
TTL TAKEOVER PROHIBITED: YES
OWNER-ONLY RELEASE ADOPTED: YES
PROMOTION RECORD AS AUTHORITATIVE COMMIT MARKER: YES
NORMATIVE TEST COUNT RECONCILED: YES (135 -> 169; 24+14+28+22+22+15+10+15+19 = 169)
PROVENANCE STANDARDS (PROV/RO-CRATE/FAIR-DO/BCO/SED-ML/COMBINE/DATACITE/SPDX/JSON-LD/RDF) EXCLUDED FROM SCOPE: YES
OPTION B SELECTED: YES
MINIMAL LINEAGE FOUNDATION INCLUDED: YES
SEMANTIC KEY CANONICALIZATION PRESERVED UNCHANGED: YES
POLICY MODEL PRESERVED UNCHANGED: YES
GOLDEN VECTOR PRESERVED UNCHANGED: YES
TECHNICAL SPIKES REQUIRED: YES
TECHNICAL SPIKES EXECUTED: YES (3/3)
FINAL SHORT REVIEW COMPLETED: YES
READY FOR IMPLEMENTATION: YES
FINAL SPECIFICATION FROZEN: YES
IMPLEMENTATION PERFORMED: NO
REPOSITORY MODIFIED: NO
```

---

# 30. Checklist de reconciliação dos achados documentais (revisões 1-3 — histórico preservado)

| Achado | Descrição | Status |
|---|---|---|
| MAJOR-1 (revisão 2) | Canonização da `semantic_key` subespecificada | **RESOLVIDO** |
| MINOR-1 (revisão 2) | `LigandPromotionPolicy` tipava flags como `Literal` fixo | **RESOLVIDO**, confirmado necessário por RD-018-01 |
| MINOR-2 (revisão 2) | Cenário "RAW diferente, conteúdo idêntico" sem exemplo | **RESOLVIDO** |
| MINOR-3 (revisão 2) | Fallback indefinido sem abertura sem seguir link | **RESOLVIDO**, mecanismo exato fechado por FS-018-01 (§ 8) |
| MINOR-4 (revisão 2) | Citação de SHA desatualizada | **RESOLVIDO** |
| NOTE-1/2/3 (revisão 2) | Isolamento por `project_dir`; duas checagens de checksum distintas; compensação não usa `_remove_state_best_effort` | **INCORPORADAS** |
| MINOR-NOVO-1 (revisão 3) | Reverificação de identidade de ancestrais ausente com granularidade do arquivo final | **RESOLVIDO**, contrato de 12 pontos confirmado suficiente por FS-018-01 |
| NOTE-NOVA-1/2/3 (revisão 3) | Terminologia `fstat`; adiamento de especialização por rota; confirmação sem ação | **INCORPORADAS/FECHADAS** — a especialização por rota (NOTE-NOVA-2) está resolvida: apenas a Rota B endurecida existe |
| MINOR-1 (revisão final, esta revisão 5) | Claim histórico sobre o primeiro bug do harness de FS-018-02 não independentemente verificável a partir dos artefatos preservados | **RESOLVIDO**, qualificação evidencial aplicada em § 2.3 |

---

# 31. Reconciliação dos três spikes (núcleo desta especificação final)

## 31.1 RD-018-01 — síntese final

**Classificação:** `RECONCILED PASS WITH LIMITATIONS`. **Decisão adotada:** `sanitize=True, remove_hs=False, strict_parsing=True` como única política de produção, com os três kwargs sempre explícitos. **Achado mais importante:** `removeHs=True` mascara um erro de valência real (transforma um carbono pentavalente em metano silenciosamente); `removeHs=False` rejeita corretamente. **Limitações herdadas, não bloqueantes:** "supplier vazio" não demonstrado por fixture; `strictParsing` sem efeito observável no corpus testado (regra A/B/C adotada, § 9.3.3); preservação RAW e defaults nativos confirmados apenas com ressalvas de escopo do revisor.

## 31.2 FS-018-01 — síntese final

**Classificação reconciliada:** Rota A `PASS WITH LIMITATIONS`, Rota B `PASS`, FS-018-01 `PASS WITH LIMITATIONS`. **Decisão adotada:** Rota B endurecida como único mecanismo normativo, com verificação pós-leitura obrigatória adicionada para fechar a assimetria S27 (remoção durante a leitura). **Achado mais importante:** `startswith()`, mesmo pós-`resolve()`, é comprovadamente inseguro contra colisão de prefixo textual — banido em favor de `is_relative_to()`. **Limitações herdadas, não bloqueantes:** POSIX não avaliado; mutação em vaga do mesmo inode não detectável por identidade (mitigada por checksum externo, nunca redundante).

## 31.3 FS-018-02 — síntese final

**Classificação:** `PASS` (8/8 cenários, identidade/manifesto recomputados, § 2.3). **Decisão adotada:** reserva/claims por `os.mkdir` exclusivo, normalização NFC+casefold+SHA-256, ownership por `attempt_id`+`owner_token`, release exato owner-only, promotion record por staging+hardlink exclusivo, TTL nunca autoriza remoção, crash residues sempre detectáveis e nunca roubados automaticamente. **Limitação herdada, não bloqueante:** compensação inversa de aquisição parcial (perdedor que já adquiriu um recurso anterior) não foi exercitada diretamente pelos 8 cenários do spike — decisão de arquitetura já fechada (§ 11.10, D-018-DRAFT-22), mas deve ser testada explicitamente na implementação (§ 19.9, item 162).

## 31.4 Questões avaliadas pela revisão final — resolvidas como trabalho futuro não bloqueante

As três questões que a candidata deixara explicitamente para a revisão final foram avaliadas e classificadas por ela (§ 8 daquele documento) como trabalho futuro não bloqueante, nunca como decisão de arquitetura pendente:

1. **Regra A/B/C de `strictParsing` (§ 9.3.3):** aceita como está. Nenhuma decisão de arquitetura depende de um efeito comportamental ainda não observado; uma rodada adicional de fixtures é trabalho futuro de robustez de teste, não uma lacuna de especificação.
2. **Compensação inversa de aquisição parcial (§ 11.10, D-018-DRAFT-22):** tratada como item de teste de implementação obrigatório (§ 19.9, item 162), não como mini-spike adicional — a regra normativa já está completa e sem grau de liberdade de implementação.
3. **POSIX:** permanece trabalho de um incremento futuro (com um novo spike dedicado), nunca implementado por extrapolação da evidência Windows/NTFS deste incremento (§ 8.7, § 22 critério 45).

Nenhuma das três constituiu blocker, major, ou exigiu correção textual adicional além do minor evidencial já aplicado (§ 2.3).
