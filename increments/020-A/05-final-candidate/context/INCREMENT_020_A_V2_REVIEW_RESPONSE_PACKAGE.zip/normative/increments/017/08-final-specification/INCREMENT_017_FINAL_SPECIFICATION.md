# FINAL SPECIFICATION — INCREMENTO 017

## CLI fino para enumeração de tautômeros

**Projeto:** Turing Bohr Molecular Platform
**Natureza deste documento:** especificação final, autossuficiente e congelada. Contém integralmente todo o contrato técnico necessário para implementação — nenhuma seção depende da leitura de outro documento para ser compreendida ou implementada. Incorpora o BLOCKER-1, os três MAJOR e os quatro MINOR da revisão adversarial completa original; o MAJOR-A, os quatro MINOR (A-D) e a recomendação de parametrização de `KeyboardInterrupt`/`SystemExit` da revisão curta subsequente; e os dois MINOR (V2-1, V2-2) da revisão final curta subsequente a essa. A Seção 4 registra a proveniência histórica completa, apenas para rastreabilidade — nenhuma seção normativa (5 em diante) exige a leitura de qualquer documento anterior.
**Data:** 2026-09-24

---

## 1. Baseline

| Item | Valor confirmado nesta sessão |
|---|---|
| Repositório | `C:\Users\Pichau\molecular-platform` |
| Branch | `main` |
| HEAD local | `278383a50b37d5bf014082a0297e44b8806e614f` |
| `origin/main` | `278383a50b37d5bf014082a0297e44b8806e614f` (idêntico) |
| `git status --porcelain=v1` | apenas `?? increment-009-review.txt` |
| `git diff --check` | limpo (sem saída, exit 0) |
| `increment-009-review.txt` | 66.761 bytes, SHA-256 `6afb7d5fe5e796bc6f940c09984a0f8aa80cac36f34f15abdd526e9298e3ff87`, intocado antes e depois desta sessão |
| Suíte completa (última execução confirmada, sessão anterior) | 671 coletados, 669 passed, 2 skipped, 0 failed — não reexecutada nesta sessão por instrução explícita da tarefa |

**Documentos-fonte, métricas confirmadas nesta sessão:**

| Documento | Linhas | Bytes | SHA-256 |
|---|---:|---:|---|
| `06-corrected-draft/INCREMENT_017_TAUTOMER_CLI_DRAFT_REVISED_V2.md` (fonte principal) | 590 | 67.872 | `56fa99ccb86cfb53d2ea0e86752427dea2a9746efb7ddcbf34600a71eacf1e47` |
| `07-final-short-review/INCREMENT_017_TAUTOMER_CLI_DRAFT_REVISED_V2_FINAL_REVIEW.md` | 191 | 24.587 | `7658c39424f47ff27275bf4c4c064ecec2f9d6c3dd6a149b6a1e0643ea803e4b` |

Todas as métricas conferem exatamente com os valores esperados fornecidos nesta tarefa. Nenhuma divergência encontrada.

**Correção de entrega em relação à sessão anterior:** o artefato `08-final-specification-candidate/INCREMENT_017_TAUTOMER_CLI_FINAL_SPECIFICATION_CANDIDATE.md` foi criado no caminho e com o nome incorretos, e continha várias seções por referência em vez de conteúdo integral (violando o requisito de documento autossuficiente). Esse artefato foi **preservado intocado** como registro histórico superado — não foi apagado, movido ou sobrescrito. Este documento é a substituição correta, no caminho `08-final-specification/INCREMENT_017_FINAL_SPECIFICATION_CANDIDATE.md`, com todo o conteúdo técnico reproduzido integralmente.

Nenhuma alteração foi feita no repositório para produzir este documento. Nenhum spike foi executado. Nenhum teste foi reexecutado nesta sessão.

---

## 2. Escopo e exclusões

**Escopo do incremento:** um único comando CLI fino que chama `enumerate_state_tautomers` (Incremento 016, já congelado), formata sua saída, mais três mudanças de suporte: (a) uma correção isolada em `rdkit_tautomer.py` para suprimir o log nativo do RDKit em stderr; (b) uma extensão do contrato de exceções de `enumerate_state_tautomers`, com duas novas exceções tipadas em `application.py` para handoff determinístico de `attempt_id` e para tratamento explícito de falha de persistência do status terminal; (c) o tratamento explícito de `KeyboardInterrupt`/`SystemExit` em ambos os sub-casos (persistência bem-sucedida e persistência falha). Nenhuma nova química, nenhum novo campo de domínio, nenhuma nova persistência.

**Fora de escopo, confirmado sem nenhuma ocorrência nas Seções 5-17 deste documento:** automação PubChem→`ScientificEntity`→`MolecularState`; busca PubChem por nome/InChIKey; pH; pKa; `ExperimentalConditions`; protonação; microestados; padronização química adicional; geração 3D; confôrmeros; otimização de geometria; atribuição de cargas; receptor; RCSB/PDB; docking; redocking; RMSD; GUI; qualquer alteração no algoritmo científico do Incremento 016 (a lógica de enumeração/sanitização/dedup de `enumerate_tautomers_rdkit` permanece byte-a-byte idêntica); qualquer alteração da especificação congelada do Incremento 016 ou de schemas persistidos.

**Três notas técnicas registradas explicitamente pelas notas normativas incorporadas nesta candidata (não bloqueantes, detalhadas nas seções técnicas correspondentes):** (i) uma segunda interrupção (`KeyboardInterrupt`/`SystemExit`) ocorrendo durante a própria tentativa de persistir o status terminal é comportamento natural do Python (a segunda interrupção se torna a exceção primária, com a primeira disponível em `__context__` implícito), não uma regressão nem um risco novo — ver Seção 8.2; (ii) o pseudocódigo da Seção 8.3 representa dois blocos `except` fisicamente distintos (um por fase — resolução, execução), não uma única função compartilhada parametrizada — as variáveis `staged`/`state_created_flags`/`transformation_created_flags` só existem dentro do bloco de execução; (iii) não existe caminho realista em que `persistence_error` escape cru do tratamento de falha de persistência sem que o wrapper correspondente seja de fato levantado, porque o log de atividade nesse caminho é garantidamente best-effort (Fato 8, Seção 3).

---

## 3. Fatos confirmados no código

Lidos diretamente em sessões anteriores desta colaboração, com números de linha reais confirmados: `application.py` (linhas 18, 34-37, 79, 297-343 [em `cli.py`], 393-720), `execution.py` (linha 184), `execution_registry.py` (linhas 133-347), `cli.py` (linhas 42, 297-343), `rdkit_tautomer.py` (linha 33), `tests/test_execution_registry.py` (linhas 607-608).

1. **Ordem exata em `enumerate_state_tautomers`** (`application.py`, linhas 512-531): `validate_input_id(input_state_id)` na linha 512; `attempt = begin_execution_attempt(project_dir, ..., input_state_id=input_state_id)` na linha 514; `input_state = load_state(project_dir, input_state_id)` na linha 531, dentro do `try` da fase de resolução. `begin_execution_attempt` **sempre** roda antes de `load_state` e de qualquer outra chamada da fase de resolução/execução — todo `FileNotFoundError`/`ValueError`/`RDKitUnavailableError`/erro de execução ocorre **depois** que um `ExecutionAttempt` real já existe. A única exceção que ocorre **sem** attempt algum é o `ValueError` de `validate_input_id` na linha 512, antes de qualquer I/O.
2. **`except BaseException` confirmado em ambos os blocos** de `enumerate_state_tautomers` no código congelado do Incremento 016 (linha 555, fase de resolução; linha 695, fase de execução) — `KeyboardInterrupt`/`SystemExit` são de fato capturados por essa cláusula, o que aciona `mark_resolution_failed`/`mark_execution_failed` (e, na fase de execução, a compensação reversa completa) e o log de atividade `outcome="error"` — e **depois** o `raise` (sem argumento) relança exatamente a exceção capturada, nunca uma nova.
3. **`cli.py` importa hoje, de `transformation_registry`, somente `list_state_transformations`** (linha 42: `from molecular.transformation_registry import list_state_transformations`). `load_state_transformation` (singular, por id de transformação) **não está importada** — é import novo, necessário para a resolução `operation_ids → child_state_id` deste contrato.
4. **`rdBase` já é importado por `rdkit_tautomer.py`** (linha 33: `from rdkit import Chem, rdBase`), dentro do `try/except ImportError` que já isola RDKit do restante do projeto. `rdBase.BlockLogs`, `rdBase.DisableLog`, `rdBase.EnableLog` existem na versão instalada (`2026.3.6`), confirmado por introspecção real via spike técnico (Seção 11).
5. **`application.py` já define exceções de domínio próprias no mesmo módulo** (`InvalidPubChemCidError(ValueError)`, ao lado de `register_ligand_from_pubchem`, linha 79) — precedente direto para colocar as novas exceções de `enumerate_state_tautomers` no mesmo arquivo, não em `execution.py`/`rdkit_tautomer.py`.
6. **`state derive` não chama `_record_activity_safely` e `ligand fetch-pubchem` também não** — ambos delegam inteiramente o log de atividade à Application Service que já o faz internamente (`register_derived_state`/`register_ligand_from_pubchem`). `enumerate_state_tautomers` já grava `started`/`success`/`error` sob `command="enumerate-state-tautomers"` (`_ENUMERATE_TAUTOMERS_OPERATION`).
7. **`mark_resolution_failed`/`mark_execution_failed` não são best-effort** (`execution_registry.py`, linhas 267-346). Cada uma: (a) chama `load_execution_attempt(project_dir, attempt_id)` incondicionalmente como primeira ação (linhas 280, 321) — que por sua vez pode levantar `FileNotFoundError` (arquivo do attempt ausente) ou `pydantic.ValidationError` (`ExecutionAttempt.model_validate(data)`, dentro de `load_execution_attempt`, linha 223, se o YAML persistido estiver corrompido/inválido); (b) verifica a transição de status válida, levantando `ValueError` se violada (linhas 282-286, 323-327 — não relevante a este contrato, pois este incremento nunca viola a máquina de estados); (c) chama `_persist(project_dir, updated)` (linhas 303, 344) — que pode levantar `OSError` via `atomic_write_text` (linha 140). **Nenhuma dessas três etapas está envolvida em `try/except` dentro de `mark_resolution_failed`/`mark_execution_failed`.**
8. **Contraste confirmado com as duas etapas garantidamente best-effort do mesmo bloco `except BaseException`:** `_compensate_published_candidates` (linhas 430-466 de `application.py`) nunca propaga — `_remove_state_confirmed`/`_remove_transformation_confirmed` absorvem suas próprias falhas e retornam o id como residual em vez de levantar; `_record_enumerate_tautomers_activity_safely` (linha 373) já é nomeada e documentada como "safely" e captura `Exception` internamente. `mark_resolution_failed`/`mark_execution_failed` são a única etapa não best-effort dentro desse bloco.
9. **Ordem real dentro do bloco de execução** (`application.py`, linhas 695-719): `_compensate_published_candidates(...)` é chamada **antes** de `mark_execution_failed(...)`. Consequência: se `mark_execution_failed` falhar ao persistir, `residual_state_ids`/`residual_operation_ids` **já foram computados como variáveis locais** no momento da falha — a informação de resíduo não se perde, mesmo que nunca chegue a ser gravada dentro do campo `error` do attempt persistido.
10. **`_describe_error`** (`application.py`, linhas 393-399): `str(error) or repr(error)` — usado tanto para o erro científico original quanto para formatar `persistence_error` na exibição da CLI.
11. **`ExecutionAttemptError.phase`** (`execution.py`, linha 184): `Literal["resolution", "execution"]` — mesmo vocabulário adotado para o campo `phase` de `TautomerEnumerationAttemptPersistenceError` (Seção 7).
12. **`_call_or_exit`** (`cli.py`, linhas 297-343) já estabelece o precedente uniforme do projeto: traduzir toda falha realista em um banner CLI limpo, nunca deixando `OSError`/`yaml.YAMLError`/`pydantic.ValidationError` escapar como traceback não tratado — `OSError → STORAGE ERROR`, `FileNotFoundError → INPUT ERROR`, `ValidationError`/`yaml.YAMLError → CONFIGURATION ERROR`.
13. **Precedente real do `attempt_id` determinístico via monkeypatch de `uuid.uuid4`** (`tests/test_execution_registry.py`, linhas 607-608, dentro de `test_begin_rejects_a_colliding_generated_attempt_id`): `fixed_uuid = uuid.uuid4(); monkeypatch.setattr(uuid, "uuid4", lambda: fixed_uuid)`. `execution_registry.py` importa `uuid` no nível de módulo e chama `uuid.uuid4().hex` (linha 181) — `uuid` é o mesmo objeto de módulo em qualquer ponto do processo Python; `monkeypatch.setattr(uuid, "uuid4", ...)` (patchando o módulo global) e `monkeypatch.setattr(execution_registry.uuid, "uuid4", ...)` (via o nome qualificado do módulo importado) são equivalentes em efeito — ambos alteram o mesmo atributo do mesmo objeto de módulo. Esse precedente original patcheava `uuid.uuid4` apenas para uma única chamada relevante no teste; não estabelecia, por si só, o comportamento correto para testes com múltiplas chamadas subsequentes de `uuid.uuid4()` que não devem ser fixadas — ver Seção 13.5 para o mecanismo generalizado corretamente.
14. **`application.py` importa `mark_resolution_failed`/`mark_execution_failed` via `from molecular.execution_registry import (...)`** (`application.py`, linhas 34-37: `mark_execution_failed` na linha 36, `mark_resolution_failed` na linha 37). Uma vinculação `from ... import ...` cria um nome **próprio e independente** no namespace de `application.py` no momento do import — uma reatribuição posterior do atributo correspondente em `execution_registry` (`monkeypatch.setattr(execution_registry, "mark_resolution_failed", ...)`) **não** altera o que `enumerate_state_tautomers` efetivamente chama, porque essa função já resolveu o nome `mark_resolution_failed` para o objeto original no momento do import do módulo `application`, não a cada chamada. O alvo correto de monkeypatch é o nome já vinculado no próprio módulo `application` (`monkeypatch.setattr(molecular.application, "mark_resolution_failed", ...)`). Por contraste, `load_execution_attempt` (chamada internamente por `mark_resolution_failed`/`mark_execution_failed`) é definida e chamada dentro do **mesmo módulo** `execution_registry.py` (linha 212, definição; linhas 280/321, chamadas como nome do próprio módulo, não importado) — ali, `monkeypatch.setattr(execution_registry, "load_execution_attempt", ...)` funciona corretamente, porque a resolução desse nome acontece no namespace global do próprio módulo, em tempo de chamada.

---

## 4. Histórico resumido das revisões (proveniência, não requisito de leitura)

| Documento | Resultado |
|---|---|
| `INCREMENT_017_TAUTOMER_CLI_DRAFT_SPEC.md` (rascunho original) | preservado, histórico |
| `INCREMENT_017_TAUTOMER_CLI_DRAFT_ADVERSARIAL_REVIEW.md` (revisão adversarial completa) | BLOCKER-1, três MAJOR, quatro MINOR |
| `INCREMENT_017_TAUTOMER_CLI_DRAFT_REVISED.md` (rascunho revisado) | incorporou o BLOCKER-1 e os MAJOR/MINOR da revisão completa |
| `INCREMENT_017_TAUTOMER_CLI_REVISED_DRAFT_SHORT_REVIEW.md` (revisão curta) | 0 BLOCKERS; 1 MAJOR (MAJOR-A: falha de persistência do status terminal não tratada); 4 MINORS (A-D); 3 NOTES; APPROVE WITH CHANGES |
| `INCREMENT_017_TAUTOMER_CLI_DRAFT_REVISED_V2.md` (V2) | corrigiu o MAJOR-A, os quatro MINOR (A-D) e a recomendação de parametrização de interrupções da revisão curta |
| `INCREMENT_017_TAUTOMER_CLI_DRAFT_REVISED_V2_FINAL_REVIEW.md` (revisão final curta) | 0 BLOCKERS; 0 MAJORS; 2 MINORS (V2-1: colisão de UUID em mecanismo de teste; V2-2: alvo de monkeypatch ambíguo); 3 NOTES; APPROVE WITH CHANGES |
| `08-final-specification-candidate/...FINAL_SPECIFICATION_CANDIDATE.md` (entrega anterior, incorreta) | caminho/nome errados; várias seções por referência, não autossuficientes; preservada intocada como histórico superado |
| Este documento | candidata final autossuficiente, incorporando integralmente todo o histórico acima; corrige exclusivamente os dois MINOR (V2-1, V2-2) em relação ao conteúdo técnico da V2 |

Todo o conteúdo técnico necessário para implementar este incremento está reproduzido integralmente nas Seções 5-17 abaixo — esta tabela é apenas rastreabilidade histórica.

---

## 5. Contrato CLI

### 5.1 Posição na hierarquia

```
molecular state enumerate-tautomers <experiment> --input-state <input_state_id> [--max-states N]
```

`input_state_id` é a opção `--input-state`, não um argumento posicional. Esta decisão foi tomada por confronto explícito de dois precedentes reais do projeto:

- **Precedente "posicional"** (`state add <state_id>`, `state show <state_id>`): nesses comandos, o argumento posicional é o id do **próprio objeto que o comando cria ou exibe** — a identidade é o assunto direto do comando.
- **Precedente `--state`/`--parent-state`** (`conformer add --state`, `conformer list --state`, `provenance show --state`, e — o mais próximo funcionalmente de todos — `state derive --parent-state`): nesses comandos, o id referencia um objeto **já existente**, usado como **entrada** de uma operação cujo produto tem identidade própria, não escolhida na linha de comando.

`enumerate-tautomers` está estruturalmente no segundo grupo, não no primeiro: os novos `MolecularState`s produzidos recebem ids gerados internamente (`uuid.uuid4().hex`, nunca escolhidos pelo usuário) — exatamente como o `child_state` de `state derive` não é o argumento que identifica "o assunto" da chamada, e sim `--parent-state`, que é a referência de entrada. `state derive` é, dos dois precedentes, o mais próximo em função (ambos "transformam um estado existente"), e já usa `--parent-state`, não posicional. Por isso este contrato adota `--input-state` (nomeação paralela a `--parent-state`).

### 5.2 Argumentos e opções

| Nome | Forma | Tipo | Obrigatório | Origem |
|---|---|---|---|---|
| `experiment` | posicional | `str` | sim | idêntico a todo outro comando |
| `--input-state` | opção | `str` | sim (`typer.Option(...)`, sem default) | mapeia para `enumerate_state_tautomers(input_state_id=...)` |
| `--max-states` | opção | `Optional[int]` | não (default `None`) | mapeia para `TautomerEnumerationPolicy.max_states` |

Pré-validação de `--input-state`: `_validate_id_or_exit(input_state, project_dir=context.project_dir, command="state-enumerate-tautomers")`, idêntico ao padrão de `state show`/`entity show`/`conformer show`/`provenance show`. Malformação de id é rejeitada nesta etapa, antes de qualquer chamada à Application Service — a CLI já barra ids malformados antes de qualquer I/O (caso E, Seção 7.3).

### 5.3 Construção da política

```python
policy = TautomerEnumerationPolicy(
    schema_version="1.0",
    max_states=max_states,  # None se --max-states não foi passado
    source="scientist",
)
```

`--max-states 0`/negativo continuam rejeitados pelo `field_validator` já existente de `TautomerEnumerationPolicy` (Incremento 016, congelado), mapeado para `CONFIGURATION ERROR` (padrão idêntico a `entity_add`/`state_derive`) — rejeitado antes de qualquer chamada à Application Service.

---

## 6. `TautomerEnumerationAttemptFailedError`

**Módulo:** `src/molecular/application.py` (mesmo módulo de `enumerate_state_tautomers`, ao lado de `InvalidPubChemCidError` — precedente direto, Fato 5, Seção 3).

**Assinatura:**

```python
class TautomerEnumerationAttemptFailedError(RuntimeError):
    def __init__(
        self,
        *,
        attempt_id: str,
        input_state_id: str,
        status: Literal["resolution_failed", "execution_failed"],
        original_error: BaseException,
    ) -> None: ...
```

**Atributos:** `attempt_id: str`, `input_state_id: str`, `status: Literal["resolution_failed", "execution_failed"]`, `original_error: BaseException` (também acessível via `__cause__`, por `raise ... from original_error`).

**Semântica:** levantada **somente** depois que `begin_execution_attempt` já retornou um `ExecutionAttempt` real para esta chamada específica, depois que `mark_resolution_failed`/`mark_execution_failed` (e, na fase de execução, a compensação reversa) já rodaram **com sucesso** — isto é, quando a persistência do status terminal é confirmada (casos A e B, Seção 7.3; contraste com falha de persistência, casos C e D, Seção 7). Nunca é construída antes de um attempt existir — o caso "sem attempt" (`ValueError` de `validate_input_id`, Fato 1) continua propagando nu, sem wrapper.

**Exceções encapsuladas** (viram `TautomerEnumerationAttemptFailedError`, com `original_error` apontando para a causa real, quando a persistência terminal tem sucesso): `FileNotFoundError` (estado inexistente/arquivo ausente), `ValueError` genérico (formato≠sdf, checksum divergente), `RDKitUnavailableError`, `InvalidSDFError`, `MultipleMoleculesError`, `IncompleteEnumerationError`, `FileExistsError` (conflito de identidade no preflight), `OSError` (falha de registry/storage durante publicação) — qualquer `Exception` capturada pelo bloco `except Exception as error:` (Seção 8.3) cuja persistência do status terminal tenha sucesso.

**Exceções que continuam propagando diretamente, sem wrapper de nenhum tipo:**
- `ValueError` de `validate_input_id(input_state_id)` (linha 512) — nenhum attempt existe ainda.
- Qualquer exceção da própria chamada `begin_execution_attempt(...)` (linha 514) — ex. `ExecutionAttemptIdentityConflictError` em colisão de uuid4, astronomicamente rara — a criação do attempt em si falhou, não há attempt para referenciar.
- `KeyboardInterrupt`/`SystemExit` — **nunca** encapsuladas em nenhuma das duas exceções tipadas de attempt (ver Seção 8).

**Casos cobertos:**

- **A. Falha de resolução + persistência terminal bem-sucedida:** `status="resolution_failed"` confirmado como persistido; `original_error` é o erro científico real (`FileNotFoundError`, `ValueError` de formato/checksum, `RDKitUnavailableError`); `raise TautomerEnumerationAttemptFailedError(...) from original_error`.
- **B. Falha de execução + persistência terminal bem-sucedida:** `status="execution_failed"` confirmado como persistido; `original_error` é o erro científico real (`InvalidSDFError`, `MultipleMoleculesError`, `IncompleteEnumerationError`, `FileExistsError` de conflito de identidade, `OSError` de storage durante publicação); resíduos (se houver) **carregáveis** via `load_execution_attempt(project_dir, exc.attempt_id).error.residual_state_ids/residual_operation_ids` (Seção 10).

**Mudança de contrato público de `enumerate_state_tautomers`:** deliberada. Hoje (Incremento 016, congelado) a função relança a exceção original, sem alteração (mesma convenção de `register_derived_state`). Com este contrato, toda falha ocorrida **depois** da criação do attempt e **cuja persistência do status terminal tenha sucesso** passa a ser relançada como `TautomerEnumerationAttemptFailedError` (com a causa original preservada por atributo e por `__cause__`). Como `enumerate_state_tautomers` não tem hoje nenhum chamador real além de testes, o impacto de compatibilidade está inteiramente contido em `tests/test_application.py`.

**Exception chaining:** sempre `raise TautomerEnumerationAttemptFailedError(...) from error`, nunca `raise TautomerEnumerationAttemptFailedError(...)` bare.

**Caso não coberto por esta exceção (persistência do status terminal falhou):** ver Seção 7 — `TautomerEnumerationAttemptPersistenceError`, casos C e D.

**Caso sem attempt algum:** caso E, Seção 7.3 — nenhuma das duas exceções tipadas de attempt se aplica.

---

## 7. `TautomerEnumerationAttemptPersistenceError`

### 7.1 Módulo e assinatura

**Módulo:** `src/molecular/application.py` — mesmo arquivo de `TautomerEnumerationAttemptFailedError` e `InvalidPubChemCidError`, pelo mesmo precedente (Fato 5, Seção 3).

```python
class TautomerEnumerationAttemptPersistenceError(RuntimeError):
    def __init__(
        self,
        *,
        attempt_id: str,
        input_state_id: str,
        intended_status: Literal["resolution_failed", "execution_failed"],
        phase: Literal["resolution", "execution"],
        original_error: BaseException,
        persistence_error: Exception,
        residual_state_ids: tuple[str, ...] = (),
        residual_operation_ids: tuple[str, ...] = (),
    ) -> None: ...
```

**Por que o campo se chama `intended_status`, não `status` (diferente de `TautomerEnumerationAttemptFailedError`):** a diferença de nome é deliberada, não cosmética — `status` (na outra exceção) afirma um fato confirmado (a persistência terminou com sucesso, o attempt está de fato naquele status no disco). `intended_status` afirma apenas a **intenção** — o valor que `mark_resolution_failed`/`mark_execution_failed` **tentou** persistir e não confirmadamente conseguiu (item 3, Seção 7.2). Usar o mesmo nome `status` para os dois casos convidaria a CLI (ou qualquer consumidor futuro) a tratar os dois casos como equivalentes, quando não são.

### 7.2 Semântica obrigatória

1. **Só pode existir depois que `begin_execution_attempt` já criou um attempt real.** Nunca é construída no caminho pré-attempt (`validate_input_id`, ou a própria chamada a `begin_execution_attempt`) — esse caminho continua propagando a exceção original, nua (caso E, Seção 7.3).
2. **Representa falha ao persistir o status terminal do attempt** — não uma falha científica. `original_error` (o motivo pelo qual o attempt estava sendo finalizado) e `persistence_error` (o motivo pelo qual essa finalização não pôde ser gravada) são dois erros distintos, de duas etapas distintas, ambos preservados.
3. **Não pode afirmar que `intended_status` foi realmente persistido** — e, de fato, por construção, nunca é. O único caminho em que esta exceção é levantada é exatamente aquele em que a chamada a `mark_resolution_failed`/`mark_execution_failed` (a única responsável por persistir esse status) falhou antes de completar.
4. **Preserva:** `attempt_id`, `input_state_id`, `phase`, `intended_status`, `original_error` (erro científico), `persistence_error` (erro de persistência), e os resíduos conhecidos localmente após a compensação (`residual_state_ids`/`residual_operation_ids` — vazios por construção na fase de resolução, pois nada é staged antes da fase de execução; potencialmente não vazios na fase de execução, vindos da compensação local já executada — Fato 9, Seção 3).
5. **Levantada com `raise persistence_wrapper from persistence_error`** — nunca `from original_error`. A causa encadeada Python (`__cause__`) é o erro de **persistência**, não o erro científico, porque é a falha de persistência que interrompeu o fluxo normal (que teria, do contrário, levantado `TautomerEnumerationAttemptFailedError(...) from original_error`). `original_error` continua disponível, mas apenas como atributo estruturado — nunca via `__cause__` desta exceção.
6. **`original_error` disponível como atributo estruturado** — `exc.original_error`.
7. **`persistence_error` disponível como atributo estruturado** — `exc.persistence_error` (idêntico a `exc.__cause__` por construção, dado o item 5).
8. **A CLI captura esta exceção antes dos handlers genéricos** — ver Seção 7.4.
9. **Banner:** `STORAGE ERROR`.
10. **Exit code:** `1`.
11. **Saída explícita** — ver template, Seção 7.4.
12. **Resíduos conhecidos, se houver, exibidos como `Unconfirmed removals`** — mesmo rótulo e mesma semântica não-definitiva usados para o caso B (Seção 10); nunca "órfãos", nunca "removidos com sucesso".
13. **A CLI não tenta novamente a persistência nem a compensação.** Nenhum retry é introduzido em lugar algum do caminho de erro.
14. **A CLI não carrega o attempt para apresentar seu status atual como se fosse terminal.** Diferença deliberada em relação ao caminho de `TautomerEnumerationAttemptFailedError` (que **chama** `load_execution_attempt(project_dir, exc.attempt_id)` para buscar detalhes adicionais, Seção 10): aqui, essa chamada seria enganosa — o status real do attempt em disco, se carregável, ainda seria `"started"` ou `"resolved"` (o último valor gravado com sucesso antes da tentativa fracassada de finalização), nunca `intended_status`. Exibir esse valor correria o risco de ser lido como "o status real", contradizendo a garantia do item 3. Todos os campos exibidos vêm exclusivamente dos atributos já estruturados da própria exceção — nenhuma I/O adicional no caminho de erro.
15. **Nenhum schema persistido é alterado.** `ExecutionAttempt`/`ExecutionAttemptError` (schema 1.1, `execution.py`) permanecem byte-a-byte idênticos — esta exceção existe inteiramente em memória, no processo Python da CLI, nunca é serializada.

### 7.3 Casos A-E (definição normativa completa)

| Caso | Descrição | Exceção externa | `status`/`intended_status` | Status terminal confirmado? | Notas |
|---|---|---|---|---|---|
| **A** | falha de resolução + persistência terminal bem-sucedida | `TautomerEnumerationAttemptFailedError` | `status="resolution_failed"` | sim | `raise ... from` erro científico original |
| **B** | falha de execução + persistência terminal bem-sucedida | `TautomerEnumerationAttemptFailedError` | `status="execution_failed"` | sim | `raise ... from` erro científico original; resíduos carregáveis via `load_execution_attempt(exc.attempt_id)` |
| **C** | falha de resolução + `mark_resolution_failed` falha | `TautomerEnumerationAttemptPersistenceError` | `intended_status="resolution_failed"` | **não** | banner `STORAGE ERROR`; `residual_state_ids`/`residual_operation_ids` sempre `()` (nada staged na fase de resolução) |
| **D** | falha de execução + `mark_execution_failed` falha | `TautomerEnumerationAttemptPersistenceError` | `intended_status="execution_failed"` | **não** | banner `STORAGE ERROR`; resíduos transportados pelo wrapper a partir da compensação local (Fato 9, Seção 3) — nunca vazios por padrão, dependem do resultado real da compensação |
| **E** | falha anterior à criação do attempt (`validate_input_id` ou o próprio `begin_execution_attempt`) | exceção original, nua (`ValueError`/`ExecutionAttemptIdentityConflictError`) | não aplicável | não aplicável | nenhuma das duas exceções tipadas de attempt; tratamento direto pela CLI conforme a exceção real |

### 7.4 Contrato de captura na CLI

```
STORAGE ERROR

Attempt ID: <exc.attempt_id>
Input state: <exc.input_state_id>
Phase: <exc.phase>
Intended status: <exc.intended_status>
Terminal status persisted: no
Original error: <str(exc.original_error)>
Persistence error: <str(exc.persistence_error)>

<seção adicional, só se não vazia:>
Unconfirmed removals: <N> state(s), <M> transformation(s)
  State '<id>' [, para cada residual_state_id]
  Transformation '<id>' [, para cada residual_operation_id]
```

A CLI captura `TautomerEnumerationAttemptPersistenceError` em uma cláusula `except` própria, posicionada **antes** de qualquer handler genérico (`except TautomerEnumerationAttemptFailedError`, `except Exception`, ou qualquer bloco herdado do padrão de `_call_or_exit`, Fato 12) — nenhuma relação de herança é introduzida entre as duas exceções tipadas de attempt (ambas herdam diretamente de `RuntimeError`, são irmãs, não uma subclasse da outra), então a ordem entre elas no `except` não afeta corretude, mas a posição de `TautomerEnumerationAttemptPersistenceError` antes de qualquer captura mais ampla é obrigatória (item 8, Seção 7.2).

Nenhum `except OSError`/`except FileNotFoundError`/`except ValidationError` cru é adicionado à CLI para este caminho — a exceção crua nunca chega até lá: ela é sempre interceptada dentro de `enumerate_state_tautomers` (Seção 8.3) e reembrulhada antes de propagar.

---

## 8. Tratamento de `KeyboardInterrupt`/`SystemExit`

### 8.1 Princípio geral

`KeyboardInterrupt` e `SystemExit` permanecem, neste contrato, **fora das duas exceções tipadas de attempt** — nem `TautomerEnumerationAttemptFailedError`, nem `TautomerEnumerationAttemptPersistenceError` jamais as encapsulam.

### 8.2 Os dois sub-casos normativos

**1. Quando a persistência terminal funciona** (compensação, se fase de execução, mais `mark_resolution_failed`/`mark_execution_failed`, todas bem-sucedidas):

- a compensação ocorre (fase de execução);
- o status de falha é persistido com sucesso;
- o log de atividade best-effort ocorre (Seção 12);
- `KeyboardInterrupt`/`SystemExit` original é relançado **sem wrapper**, exatamente a mesma instância, via `raise` bare.

**2. Quando a persistência terminal também falha:**

- `KeyboardInterrupt`/`SystemExit` continua sendo a exceção primária — nunca é substituída por `TautomerEnumerationAttemptPersistenceError`, nunca por nenhuma outra exceção;
- `persistence_error` aparece como causa encadeada (`__cause__`) da própria interrupção — mecanismo: `raise interrupt from persistence_error`, onde `interrupt` é a variável que já contém a instância original de `KeyboardInterrupt`/`SystemExit` capturada (Python permite re-levantar uma exceção já capturada com uma nova causa encadeada sem construir uma exceção nova — a identidade do objeto `interrupt` é preservada, só `interrupt.__cause__` é atribuído);
- a CLI não captura a interrupção em lugar nenhum deste fluxo;
- nenhum `except BaseException` é introduzido na CLI.

**Nota sobre uma segunda interrupção durante a própria persistência:** se uma segunda `KeyboardInterrupt`/`SystemExit` ocorrer durante a tentativa de `mark_resolution_failed`/`mark_execution_failed` dentro do bloco de tratamento de interrupção (Seção 8.3), o `try/except Exception` interno que envolve essa chamada só captura `Exception`, não `BaseException` — a segunda interrupção propaga imediatamente, sem passar pelo log de atividade nem pelo `raise interrupt from persistence_error`/`raise` finais desse bloco. Este é o comportamento natural do Python diante de uma exceção levantada dentro de um bloco de tratamento de outra exceção (a segunda se torna a primária, com a primeira disponível em `__context__` por encadeamento implícito) — idêntico ao que qualquer bloco `except (KeyboardInterrupt, SystemExit):` de limpeza já teria, incluindo o código congelado do Incremento 016 com seu `except BaseException` único (Fato 2). Não é uma regressão, não exige contrato adicional.

### 8.3 Implementação normativa proposta (não executada nesta sessão)

O snippet abaixo representa **dois blocos `except` fisicamente distintos** em `enumerate_state_tautomers` — um após a fase de resolução (linha 555 do código congelado), outro após a fase de execução (linha 695) — não uma única função compartilhada e parametrizada. As variáveis `staged`/`state_created_flags`/`transformation_created_flags` (usadas na compensação) só existem dentro do bloco de execução (inicializadas nas linhas 575-579, depois que o bloco de resolução já terminou); no bloco de resolução, a ramificação `<fase de execução>` abaixo é sempre falsa e a chamada a `_compensate_published_candidates` nunca ocorre.

```python
except (KeyboardInterrupt, SystemExit) as interrupt:
    persistence_error: Exception | None = None
    try:
        if <fase de execução>:
            residual_state_ids, residual_operation_ids = _compensate_published_candidates(...)
            mark_execution_failed(
                project_dir, attempt.id,
                error=ExecutionAttemptError(
                    phase="execution", message=_describe_error(interrupt),
                    residual_state_ids=residual_state_ids,
                    residual_operation_ids=residual_operation_ids,
                ),
            )
        else:
            mark_resolution_failed(
                project_dir, attempt.id,
                error=ExecutionAttemptError(phase="resolution", message=_describe_error(interrupt)),
            )
    except Exception as error:
        persistence_error = error
    _record_enumerate_tautomers_activity_safely(project_dir, outcome="error", details=...)
    if persistence_error is not None:
        raise interrupt from persistence_error
    raise

except Exception as error:
    persistence_wrapper_residual_state_ids: tuple[str, ...] = ()
    persistence_wrapper_residual_operation_ids: tuple[str, ...] = ()
    try:
        if <fase de execução>:
            residual_state_ids, residual_operation_ids = _compensate_published_candidates(...)
            persistence_wrapper_residual_state_ids = residual_state_ids
            persistence_wrapper_residual_operation_ids = residual_operation_ids
            mark_execution_failed(
                project_dir, attempt.id,
                error=ExecutionAttemptError(
                    phase="execution", message=_describe_error(error),
                    residual_state_ids=residual_state_ids,
                    residual_operation_ids=residual_operation_ids,
                ),
            )
        else:
            mark_resolution_failed(
                project_dir, attempt.id,
                error=ExecutionAttemptError(phase="resolution", message=_describe_error(error)),
            )
    except Exception as persistence_error:
        _record_enumerate_tautomers_activity_safely(project_dir, outcome="error", details=...)
        raise TautomerEnumerationAttemptPersistenceError(
            attempt_id=attempt.id,
            input_state_id=input_state_id,
            intended_status=<"resolution_failed" | "execution_failed">,
            phase=<"resolution" | "execution">,
            original_error=error,
            persistence_error=persistence_error,
            residual_state_ids=persistence_wrapper_residual_state_ids,
            residual_operation_ids=persistence_wrapper_residual_operation_ids,
        ) from persistence_error
    _record_enumerate_tautomers_activity_safely(project_dir, outcome="error", details=...)
    raise TautomerEnumerationAttemptFailedError(
        attempt_id=attempt.id, input_state_id=input_state_id,
        status=<"resolution_failed" | "execution_failed">, original_error=error,
    ) from error
```

O log de atividade best-effort (`_record_enumerate_tautomers_activity_safely`) nunca propaga (Fato 8) — não existe caminho realista em que `persistence_error` escape cru desse bloco sem que `TautomerEnumerationAttemptPersistenceError` seja de fato levantada.

### 8.4 Caso E — falha anterior à criação do attempt

Nem `KeyboardInterrupt`/`SystemExit`, nem qualquer exceção científica, recebem tratamento especial antes de `begin_execution_attempt` retornar: `validate_input_id` (linha 512) e a própria chamada a `begin_execution_attempt` (linha 514) não estão dentro de nenhum dos blocos `try` acima — qualquer exceção levantada ali (incluindo uma `KeyboardInterrupt` do usuário nesse instante exato) propaga diretamente, sem wrapper, sem compensação (nada foi criado ainda), exatamente como hoje (Fato 1).

### 8.5 Testes parametrizados exigidos

Os testes reais de `KeyboardInterrupt`/`SystemExit` (Seção 13, itens `39b-KI`/`39b-SE`/`39c-KI`/`39c-SE`) são **parametrizados separadamente** sobre as duas classes de interrupção — nunca um teste cobrindo apenas `KeyboardInterrupt` com a alegação implícita de que `SystemExit` "funciona igual" sem prova. Mecanismo: `@pytest.mark.parametrize("interruption_cls", [KeyboardInterrupt, SystemExit])`, injetando `interruption_cls` como a exceção levantada pelo seam `_enumerate`/`_resolve_engine`, mesma técnica de injeção já usada por `test_enumerate_state_tautomers_engine_execution_failure`.

### 8.6 `GeneratorExit`

`GeneratorExit` **não é tratada como falha científica** neste contrato, por ausência de justificativa concreta (nota 6, Seção 11). `enumerate_state_tautomers` não é uma função geradora, não roda dentro de um generator/corrotina em nenhum caminho real da CLI proposta — `GeneratorExit` não é uma exceção que pode legitimamente atravessar esta função no fluxo síncrono da CLI. Ela deixa de ser capturada pela mudança da Seção 8.7 — comportamento correto: não há razão de domínio para tratá-la, e não há nenhum caminho real em que ela ocorra aqui.

### 8.7 Justificativa da mudança de `except BaseException` para cláusulas explícitas

**O código congelado do Incremento 016 usa `except BaseException`** (`application.py`, linhas 555 e 695) **deliberadamente, para garantir que `KeyboardInterrupt`/`SystemExit` também disparem compensação** — confirmado pelo docstring da função: *"The compensation/error-logging boundary from resolve onward is `except BaseException`, not `except Exception`... once a write has occurred, a `KeyboardInterrupt`/`SystemExit` must still trigger compensation and a best-effort error log."*

**Mudança proposta por este contrato:** substituir o único `except BaseException as error:` de cada bloco por duas cláusulas explícitas e ordenadas — `except (KeyboardInterrupt, SystemExit) as interrupt:` primeiro (Seção 8.3), depois `except Exception as error:` (não `BaseException`).

**Compatibilidade — o que se preserva e o que muda:**

- **Preservado integralmente:** a garantia original (compensação e log best-effort disparados por `KeyboardInterrupt`/`SystemExit`) continua válida — agora via a cláusula dedicada da Seção 8.3, que executa exatamente a mesma compensação/persistência/log que o `except BaseException` fazia, apenas com tratamento adicional para o caso em que essa persistência falha.
- **O que muda de fato:** qualquer subclasse de `BaseException` que **não** seja `Exception`, `KeyboardInterrupt`, nem `SystemExit` — na prática, isso significa `GeneratorExit` (e, dependendo da versão do Python, `asyncio.CancelledError`, que em Python 3.8+ é subclasse direta de `BaseException`) deixaria de disparar compensação/persistência de falha.
- **Por que essa mudança é seguramente compatível:** `enumerate_state_tautomers` é uma função síncrona, não geradora, não corrotina, chamada de um processo CLI síncrono por invocação (Seção 11, riscos de estado global — mesma premissa de ausência de concorrência/assincronia documentada para o `BlockLogs`). Nem `GeneratorExit` nem `CancelledError` podem realisticamente atravessar este código no fluxo real da CLI proposta — não há `yield` nesta função, não há `await`, não há execução dentro de uma tarefa `asyncio` cancelável. A mudança é, portanto, uma correção de precisão (capturar exatamente as duas interrupções de usuário que o docstring original tinha em mente), não uma redução de robustez real.

---

## 9. Matrizes completas

### 9.1 Matriz normativa principal (situação × attempt × persistência × exceção × banner × exit)

| Situação | Attempt existe | Persistência terminal | Exceção externa | Banner CLI | Exit |
|---|---:|---|---|---|---:|
| erro científico de resolução | sim | confirmada | `TautomerEnumerationAttemptFailedError` | INPUT/CONFIGURATION ERROR conforme causa | 1 |
| erro científico de execução | sim | confirmada | `TautomerEnumerationAttemptFailedError` | EXECUTION/INPUT/STORAGE ERROR conforme causa | 1 |
| `mark_resolution_failed` falha | sim | não confirmada | `TautomerEnumerationAttemptPersistenceError` | STORAGE ERROR | 1 |
| `mark_execution_failed` falha | sim | não confirmada | `TautomerEnumerationAttemptPersistenceError` | STORAGE ERROR | 1 |
| `begin_execution_attempt` falha | não | não aplicável | exceção original | banner direto correspondente | 1 |
| `KeyboardInterrupt`/`SystemExit` com persistência confirmada | sim | confirmada | interrupção original | nenhum banner próprio | não zero, tratamento Typer/Click |
| `KeyboardInterrupt`/`SystemExit` com persistência falha | sim | não confirmada | interrupção original com diagnóstico encadeado | nenhum banner próprio | não zero |

**Nenhum status final persistido é prometido nas duas linhas em que `mark_*` falhou** — exatamente o que `Terminal status persisted: no` (Seção 7.4) e a ausência de qualquer `load_execution_attempt` no caminho de erro (item 14, Seção 7.2) tornam explícito ao usuário.

### 9.2 Matriz detalhada por causa original

| Causa original | Attempt criado? | Persistência terminal | Exceção externa | Banner CLI | Exit | Caso (Seção 7.3) |
|---|---|---|---|---|---|---|
| `--input-state` malformado (CLI, pré-validação) | não | não aplicável | não chega a chamar `enumerate_state_tautomers` | `INPUT ERROR` | 1 | E |
| `ValueError` de `validate_input_id` interno (defesa redundante) | não | não aplicável | `ValueError` bruto | `INPUT ERROR` | 1 | E |
| Colisão de id em `begin_execution_attempt` | não | não aplicável | `ExecutionAttemptIdentityConflictError` bruto | `INPUT ERROR` (ver Seção 17, mapeamento e sua justificativa) | 1 | E |
| `FileNotFoundError` (estado inexistente), `mark_resolution_failed` OK | sim | confirmada | `TautomerEnumerationAttemptFailedError` | `INPUT ERROR` | 1 | A |
| `ValueError` genérico (formato/checksum), `mark_resolution_failed` OK | sim | confirmada | `TautomerEnumerationAttemptFailedError` | `INPUT ERROR` | 1 | A |
| `RDKitUnavailableError`, `mark_resolution_failed` OK | sim | confirmada | `TautomerEnumerationAttemptFailedError` | `CONFIGURATION ERROR` | 1 | A |
| **qualquer causa de resolução acima, mas `mark_resolution_failed` falha (`OSError`/`FileNotFoundError`/`ValidationError`)** | sim | **não confirmada** | `TautomerEnumerationAttemptPersistenceError` | `STORAGE ERROR` | 1 | **C** |
| `InvalidSDFError`/`MultipleMoleculesError`/`IncompleteEnumerationError`, `mark_execution_failed` OK | sim | confirmada | `TautomerEnumerationAttemptFailedError` | `EXECUTION ERROR` | 1 | B |
| `FileExistsError` (conflito de identidade, preflight), `mark_execution_failed` OK | sim | confirmada | `TautomerEnumerationAttemptFailedError` | `INPUT ERROR` | 1 | B |
| `OSError` (storage durante publicação), `mark_execution_failed` OK | sim | confirmada | `TautomerEnumerationAttemptFailedError` | `STORAGE ERROR` | 1 | B |
| **qualquer causa de execução acima, mas `mark_execution_failed` falha** | sim | **não confirmada** | `TautomerEnumerationAttemptPersistenceError` | `STORAGE ERROR` | 1 | **D** |
| `KeyboardInterrupt`/`SystemExit`, compensação+`mark_*` OK | sim | confirmada | interrupção original, bare | nenhum — Click/Typer | não-0 | — |
| `KeyboardInterrupt`/`SystemExit`, compensação+`mark_*` também falha | sim | **não confirmada** | interrupção original, `__cause__=persistence_error` | nenhum — Click/Typer | não-0 | — |

**Seleção de banner para `TautomerEnumerationAttemptFailedError` (casos A/B):** cadeia `isinstance(exc.original_error, ...)` ordenada — os tipos mais específicos (`InvalidSDFError`, `MultipleMoleculesError`) verificados **antes** do `ValueError` genérico (nunca `type(x) is ValueError`, sempre `isinstance` em sequência).

**Seleção de banner para `TautomerEnumerationAttemptPersistenceError` (casos C/D):** sempre `STORAGE ERROR`, incondicional — não depende do tipo de `original_error` nem de `persistence_error`. Justificativa: a informação relevante para o usuário neste ramo não é "qual foi o erro científico" (isso já está perdido de vista do ponto de persistência — o usuário precisa agir sobre o fato de que o storage do projeto está em estado potencialmente inconsistente), e sim que a própria camada de storage falhou ao registrar o desfecho.

---

## 10. Resíduos

Ao capturar `TautomerEnumerationAttemptFailedError` (casos A/B), a CLI:

1. Carrega o attempt **exclusivamente** por `load_execution_attempt(project_dir, exc.attempt_id)` — nunca por busca, ordenação ou diff de diretório.
2. Se o carregamento tiver sucesso e `attempt.error.residual_state_ids`/`residual_operation_ids` não estiverem vazios, imprime uma seção adicional com as contagens e os ids concretos, rotulada como **"Unconfirmed removals"** — nunca "órfãos", nunca "removidos com sucesso", nunca qualquer linguagem que implique um desfecho definitivo.
3. Se ambas as tuplas estiverem vazias, a seção é omitida por completo (não imprime "Unconfirmed removals: 0").
4. A CLI **nunca** tenta remover, corrigir ou compensar nada — apenas exibe o que `ExecutionAttemptError` já persistiu.
5. Se `load_execution_attempt` levantar (ex.: arquivo removido entre a criação do attempt e a leitura pela CLI), a CLI captura essa falha separadamente, exibe `exc.attempt_id`/`exc.status`/`str(exc.original_error)` (os únicos dados que já tinha, vindos da própria exceção, sem I/O adicional) e uma nota explícita de que detalhes adicionais não puderam ser carregados — nunca inventa valores.

**Regra para o caso D (persistência falhou):** a CLI **nunca** chama `load_execution_attempt` neste caminho (item 14, Seção 7.2) — os resíduos exibidos vêm exclusivamente de `exc.residual_state_ids`/`exc.residual_operation_ids`, atributos estruturados já preenchidos no momento em que `TautomerEnumerationAttemptPersistenceError` foi construída, a partir do retorno local de `_compensate_published_candidates` (Fato 9) — nunca de uma leitura do disco, porque a escrita que os teria persistido é exatamente a que falhou.

**Caso C (falha de resolução + persistência falha):** `exc.residual_state_ids`/`exc.residual_operation_ids` são sempre `()` — a fase de resolução nunca chega a popular `staged`/`state_created_flags`/`transformation_created_flags` (essas listas só existem dentro do bloco de execução); portanto não há nada para compensar nem para reportar como residual neste caso, por construção, não por omissão.

A seção "Unconfirmed removals" é omitida por completo quando ambas as tuplas estão vazias, em qualquer um dos dois templates (B, Seção 7.2 da V2 original; D, Seção 7.4) — nunca "Unconfirmed removals: 0" — regra idêntica em ambos os casos.

### 10.1 Templates de saída completos

**Sucesso:**
```
TAUTOMER ENUMERATION

Attempt ID: <attempt.id>
Input state: <input_state_id>
Status: succeeded
Engine: <resolved.engine_name> <resolved.engine_version>
New states published: <len(operation_ids)>

<uma linha por transformação publicada, omitida se zero:>
  State '<child_state_id>'  (transformation '<transformation_id>')
```
Resolução de `operation_ids → child_state_id` via `transformation_registry.load_state_transformation` (import novo — Fato 3).

**Falha (caso A/B) — attempt carregado com sucesso:**
```
TAUTOMER ENUMERATION FAILED

Attempt ID: <exc.attempt_id>
Input state: <exc.input_state_id>
Status: <exc.status>
Phase: <attempt.error.phase>
Error: <attempt.error.message>

<seção adicional, só se não vazia:>
Unconfirmed removals: <N> state(s), <M> transformation(s)
  State '<id>' [, para cada residual_state_id]
  Transformation '<id>' [, para cada residual_operation_id]
```

**Falha (caso A/B) — attempt não carregável:**
```
TAUTOMER ENUMERATION FAILED

Attempt ID: <exc.attempt_id>
Input state: <exc.input_state_id>
Status: <exc.status>
Error: <str(exc.original_error)>

(additional attempt details could not be loaded)
```

**Falha (caso C/D) — persistência falhou:** template completo já dado na Seção 7.4.

### 10.2 Testes de formatação exigidos

1. Sem resíduos — seção "Unconfirmed removals" ausente.
2. Somente `residual_state_ids` não vazio — seção mostra só estados.
3. Somente `residual_operation_ids` não vazio — seção mostra só transformações.
4. Ambos não vazios — seção mostra as duas listas e as contagens corretas.
5. Attempt não carregável (`load_execution_attempt` monkeypatchado para levantar) — template de fallback, nenhum campo inventado.
6. Ids exibidos pertencem exatamente ao attempt indicado por `exc.attempt_id` — verificado construindo um segundo `ExecutionAttempt` real (outro id, outro `input_state_id`) no mesmo `project_dir` antes de disparar a falha do teste, e confirmando que a saída nunca menciona o id/valores do segundo attempt.

---

## 11. stderr/BlockLogs

**Decisão comprovada por spike técnico** (executado inteiramente fora do repositório, diretório descartável, `src/molecular/rdkit_tautomer.py` não alterado durante o spike; resultado **PASS**). Achados empíricos centrais:

1. Em `rdkit==2026.3.6`, apenas os status `MaxTautomersReached` e `Canceled` produzem uma linha de log nativo em stderr (formato `[HH:MM:SS] Tautomer enumeration stopped at N tautomers: <motivo>`); `Completed` e `MaxTransformsReached` não produzem nenhuma linha, nem em stdout nem em stderr.
2. A mensagem pertence exclusivamente ao canal `rdApp.warning` (confirmado desabilitando cada canal individualmente em subprocessos isolados: `rdApp.error`, `rdApp.info`, `rdApp.debug` não afetam a mensagem; `rdApp.warning` e `rdApp.*` a suprimem igualmente).
3. `rdBase.BlockLogs()` é um gerenciador de contexto real (`__enter__`/`__exit__` em C++, docstring nativo: *"Temporarily block logs from outputting while this instance is in scope"*), confirmado por teste direto: suprime a mensagem durante seu escopo, restaura corretamente após saída normal, e **restaura corretamente mesmo após saída por exceção**.
4. Nenhum vazamento de supressão para fora do escopo do `with` foi observado.
5. Risco de estado global: o logger do RDKit é estado global do processo C++, não por thread; a CLI proposta é um processo síncrono por invocação (sem concorrência de threads), então este risco não se materializa neste incremento — mas fica documentado como limitação do mecanismo.

**Decisão adotada:** corrigir dentro deste mesmo incremento (não apenas documentar como pendência).

**Implementação normativa (não executada nesta sessão):**

```python
# dentro de enumerate_tautomers_rdkit, em rdkit_tautomer.py:
with rdBase.BlockLogs():
    result = enumerator.Enumerate(mol)
```

Escopo mínimo — só a chamada `Enumerate`, não a função inteira, não o nível do módulo. Nenhum import novo (`rdBase` já é importado, Fato 4). Restauração garantida pela semântica do `with` do Python, nunca por `try/finally` manual, nunca por desabilitar o canal permanentemente no import do módulo.

**Justificativa de `BlockLogs()` sobre `DisableLog`/`EnableLog` manual:** `BlockLogs()` é um gerenciador de contexto real — a restauração é garantida pela própria semântica do `with`, sem exigir `try/finally` escrito à mão nem conhecimento hardcoded do nome exato do canal. Um `DisableLog("rdApp.warning")`/`EnableLog("rdApp.warning")` manual funcionaria igualmente, mas depende de uma string de canal específica desta versão do RDKit — se uma versão futura mudar o canal usado para esta mensagem, a supressão manual pararia de funcionar silenciosamente, enquanto `BlockLogs()` continuaria funcionando por bloquear todos os canais indiscriminadamente.

**Notas normativas incorporadas:**

1. `rdBase.BlockLogs` tem estado global ao processo (não por thread, não por objeto Python).
2. O escopo permanece limitado exclusivamente a `Enumerate(mol)` — nunca a função inteira, nunca o nível do módulo.
3. Em uso multithread futuro, a estratégia deve ser reavaliada — não se materializa neste incremento.
4. Logs diagnósticos inesperados emitidos dentro do bloco podem ser suprimidos junto com a mensagem esperada — severidade baixa, porque as exceções tipadas do adapter (`IncompleteEnumerationError` etc.) já carregam o motivo estruturado sem depender do texto bruto de stderr.
5. Testes de stderr nativo devem usar `capfd` ou subprocesso — nunca `CliRunner().output` (que mistura stdout/stderr por padrão) como prova suficiente de ausência de vazamento.
6. `GeneratorExit` não deve ser tratada como falha científica sem justificativa concreta (ver Seção 8.6).

**Testes exigidos:** capturar stdout e stderr **separadamente** — nunca aceitar `CliRunner().output` como prova suficiente (ver Seção 13, itens 34, 35).

---

## 12. Activity logging

**Proibição explícita:** o novo comando **não deve, em nenhuma circunstância, chamar `_record_activity_safely`** diretamente. `enumerate_state_tautomers` já grava `outcome="started"`/`"success"`/`"error"` internamente, sob `command="enumerate-state-tautomers"` (Fato 6) — exatamente o mesmo padrão que `state derive` e `ligand fetch-pubchem` já seguem (nenhum dos dois chama `_record_activity_safely` a partir do comando). Uma chamada adicional no novo comando duplicaria/conflitaria eventos no log de atividade do experimento.

**Nos dois ramos de falha de persistência (casos C e D):** o log de atividade best-effort (`_record_enumerate_tautomers_activity_safely`, `outcome="error"`) **é tentado exatamente uma vez**, dentro do bloco `except Exception as persistence_error:` que constrói o wrapper (Seção 8.3), **antes** de `raise TautomerEnumerationAttemptPersistenceError(...) from persistence_error` — nunca depois (o `raise` termina o fluxo desta chamada). Isso preserva a garantia "uma única linha `started`, uma única linha `success`/`error` por invocação" (critério de aceite 38, Seção 15) mesmo quando a própria persistência do attempt falhou — o log de atividade é uma trilha independente do registro do attempt, best-effort por construção (nunca propaga, Fato 8), e portanto não é afetado pela falha de `mark_*`.

**Dependência opcional do RDKit:** `cli.py` não importa `rdkit` em nenhuma forma — os únicos símbolos importados de `rdkit_tautomer` são as classes de exceção tipadas (`RDKitUnavailableError`, `InvalidSDFError`, `MultipleMoleculesError`, `IncompleteEnumerationError`), definidas incondicionalmente fora do `try/except ImportError` do módulo. Instalação base sem o extra `rdkit` continua funcional; quando ausente, o caminho real é `resolve_rdkit_engine()` → `RDKitUnavailableError` → capturado dentro de `enumerate_state_tautomers` → envolvido em `TautomerEnumerationAttemptFailedError` com `status="resolution_failed"` (persistência confirmada) → CLI exibe `CONFIGURATION ERROR`, exit 1.

---

## 13. Matriz normativa de testes

### 13.1 Regra de contagem adotada

Uma **linha da matriz** é um cenário normativo com objetivo de asserção distinto. Uma linha mapeia, por padrão, para exatamente um teste pytest. Quando um pequeno grupo de atributos é verificado sobre **o mesmo objeto, no mesmo teste, pela mesma construção de cenário** (ex.: sete atributos estruturados da mesma exceção), as linhas correspondentes são combinadas em uma única linha/teste, com cada atributo listado explicitamente na coluna de asserções. As únicas linhas que não mapeiam para um teste pytest são três: validação em ambiente descartável sem RDKit, validação em ambiente descartável com RDKit, e aceitação final da suíte completa.

### 13.2 Itens 1-38, 40, 41

| # | Cenário | Objetivo | Mock ou RDKit real | `skipif` | Arquivo |
|---:|---|---|---|---|---|
| 1 | `--help` do comando | uso e opções documentados | — | não | `test_cli.py` |
| 2 | `--input-state` ausente | erro de uso do Typer | — | não | `test_cli.py` |
| 3 | `--max-states` ausente | `policy.max_states is None` | mock (`cli_module.enumerate_state_tautomers`) | não | `test_cli.py` |
| 4 | `--max-states 2` válido | `policy.max_states == 2` | mock | não | `test_cli.py` |
| 5 | `--max-states 0` inválido | rejeitado antes da chamada | mock (assert não chamado) | não | `test_cli.py` |
| 6 | `--max-states -1` inválido | idem | mock | não | `test_cli.py` |
| 7 | `--input-state` malformado | rejeitado antes da chamada | mock (assert não chamado) | não | `test_cli.py` |
| 8a | estado inexistente, RDKit ausente | `resolution_failed` via `FileNotFoundError` | real (sem RDKit) | `skipif` RDKit instalado | `test_cli.py` |
| 8b | estado inexistente, RDKit presente | idem, caminho não depende de RDKit | real | `skipif` RDKit ausente | `test_cli.py` |
| 9 | representação com formato ≠ sdf | `resolution_failed` | real | não | `test_cli.py` |
| 10 | checksum divergente | `resolution_failed` | real | não | `test_cli.py` |
| 11 | RDKit ausente | `resolution_failed`, `CONFIGURATION ERROR` | real, ausência genuína | `skipif` RDKit instalado | `test_cli.py` |
| 12 | sucesso, zero tautômeros | `operation_ids=()` é sucesso válido | mock | não | `test_cli.py` |
| 13 | sucesso, um tautômero | ponta a ponta real | real | `skipif` RDKit ausente | `test_cli.py` |
| 14 | sucesso, múltiplos tautômeros | idem, N | mock | não | `test_cli.py` |
| 15 | truncamento por `--max-states` | `operation_ids` truncado | mock | não | `test_cli.py` |
| 16 | ordem determinística da saída | preserva ordem de `operation_ids` | mock | não | `test_cli.py` |
| 17 | `InvalidSDFError` | `EXECUTION ERROR` | real (SDF vazio) | não | `test_cli.py` |
| 18 | `MultipleMoleculesError` | `EXECUTION ERROR` | real (SDF de 3 moléculas) | não | `test_cli.py` |
| 19 | `IncompleteEnumerationError` | `EXECUTION ERROR` | mock (`enumerate_state_tautomers` levanta o wrapper com essa causa) | não | `test_cli.py` |
| 20 | `ValueError` genérico | `INPUT ERROR`, nunca confundido com `InvalidSDFError`/`MultipleMoleculesError` | mock | não | `test_cli.py` |
| 21 | `FileExistsError` (conflito de identidade) | `INPUT ERROR` | mock | não | `test_cli.py` |
| 22 | `OSError` (storage) | `STORAGE ERROR` | mock | não | `test_cli.py` |
| 23 | wrapper com `attempt_id` correto (caso A/B) | CLI exibe exatamente o id do `exc.attempt_id` | mock | não | `test_cli.py` |
| 24 | preservação da causa original | `exc.original_error is <exceção original>`; `exc.__cause__ is exc.original_error` | unit, sem CLI | não | `test_application.py` |
| 25 | attempt exato carregado por id (caso A/B) | `load_execution_attempt` chamado com `exc.attempt_id`, nunca outro | mock | não | `test_cli.py` |
| 26 | duas execuções concorrentes, estados diferentes | cada uma reporta seu próprio `attempt_id`/`input_state_id`, sem cruzamento | real | não | `test_application.py` |
| 27 | duas execuções concorrentes, mesmo estado | dois attempts distintos com `input_state_id` igual mas `attempt_id` diferentes | real | não | `test_application.py` |
| 28 | ausência de diff/listagem global de `execution_attempts` | nenhuma leitura de diretório inteiro no caminho de erro (prova negativa) | estático + mock | não | `test_cli.py` |
| 29 | resíduos (caso B): sem resíduos | seção "Unconfirmed removals" ausente | mock | não | `test_cli.py` |
| 30 | resíduos (caso B): só `residual_state_ids` | idem | mock | não | `test_cli.py` |
| 31 | resíduos (caso B): só `residual_operation_ids` | idem | mock | não | `test_cli.py` |
| 32 | resíduos (caso B): ambos | idem | mock | não | `test_cli.py` |
| 33 | attempt não carregável (caso A/B) | template de fallback, nenhum campo inventado | mock (`load_execution_attempt` levanta) | não | `test_cli.py` |
| 34 | stdout/stderr separados — `MaxTautomersReached` | mensagem nativa não vaza para stdout | real, subprocesso (`subprocess.run`, não `CliRunner`) | `skipif` RDKit ausente | `test_cli.py` |
| 35 | supressão/restauração do logger | `BlockLogs()` suprime e restaura, mesmo sob exceção | real, subprocesso isolado | `skipif` RDKit ausente | `test_rdkit_tautomer.py` |
| 36 | instalação base sem RDKit | superfície pré-existente + novo comando continuam funcionais | real, venv descartável | — | ambiente descartável (não pytest) |
| 37 | integração real com RDKit | ponta a ponta com `.[rdkit]` | real, venv descartável | — | ambiente descartável (não pytest) |
| 38 | nenhuma duplicação de log de atividade | uma única linha `started`, uma única linha `success`/`error` por invocação | mock (conta linhas do log) | não | `test_cli.py` |
| 40 | comandos antigos permanecem inalterados | regressão | — | não | `test_cli.py` |
| 41 | suíte completa preservada | regressão final | — | não | repositório inteiro |

### 13.3 Itens 39-série — `KeyboardInterrupt`/`SystemExit`

| # | Cenário | Objetivo | Mecanismo | Arquivo |
|---:|---|---|---|---|
| 39a-KI | `KeyboardInterrupt` na fronteira da CLI | propaga sem wrapper; nenhum `except`/`except Exception` genérico na CLI a intercepta | mock (`enumerate_state_tautomers` levanta `KeyboardInterrupt` diretamente) | `test_cli.py` |
| 39a-SE | `SystemExit` na fronteira da CLI | idem, para `SystemExit` | mock | `test_cli.py` |
| 39b-KI | `KeyboardInterrupt` real, fase de execução, `mark_execution_failed` **funciona** | compensação e `mark_execution_failed` rodam; interrupção propaga sem wrapper (Seção 8.2, sub-caso 1); attempt carregado por id conhecido de antemão (Seção 13.5) mostra `status == "execution_failed"` | real (seam `_enumerate` levanta `KeyboardInterrupt`), `attempt_id` fixado via mecanismo de `uuid.uuid4` controlado (Seção 13.5) | `test_application.py` |
| 39b-SE | idem, para `SystemExit` | idem | real, mesmo mecanismo | `test_application.py` |
| 39c-KI | `KeyboardInterrupt` real, fase de execução, `mark_execution_failed` **falha** (`OSError` injetado) | interrupção continua sendo a exceção primária; `persistence_error` aparece como `__cause__`; nenhuma `TautomerEnumerationAttemptPersistenceError` é levantada (Seção 8.2, sub-caso 2) | real, `mark_execution_failed` monkeypatchado para levantar `OSError`, `attempt_id` conhecido de antemão | `test_application.py` |
| 39c-SE | idem, para `SystemExit` | idem | real, mesmo mecanismo | `test_application.py` |

### 13.4 Itens 42-49 — falha de persistência do status terminal

| # | Cenário | Objetivo | Mecanismo | Arquivo |
|---:|---|---|---|---|
| 42 | `mark_resolution_failed` levanta `OSError` | erro de persistência crua nunca escapa como traceback; vira `TautomerEnumerationAttemptPersistenceError` com `intended_status="resolution_failed"`, `phase="resolution"`, `residual_state_ids=residual_operation_ids=()` | real (falha científica genuína, ex. `FileNotFoundError` de estado); **`monkeypatch.setattr(molecular.application, "mark_resolution_failed", <fake que levanta OSError>)`** — o alvo é o nome importado em `application.py` (Fato 14), nunca `execution_registry.mark_resolution_failed` | `test_application.py` |
| 43 | `mark_execution_failed` levanta `OSError`, com resíduos | idem para `intended_status="execution_failed"`, `phase="execution"`; resíduos da compensação local (já computados antes da chamada, Fato 9) aparecem em `exc.residual_state_ids`/`exc.residual_operation_ids` mesmo sem terem sido persistidos | real (falha científica genuína após publicação parcial de um ou mais candidatos — se mais de um candidato for staged antes da falha induzida, o `attempt_id`, quando fixado, deve usar o mecanismo de primeira-chamada-apenas da Seção 13.5, nunca um `lambda` de uso único indiscriminado, sob risco de colisão de `state_id`/`transformation_id` entre candidatos); **`monkeypatch.setattr(molecular.application, "mark_execution_failed", <fake que levanta OSError>)`** — mesmo alvo do item 42 | `test_application.py` |
| 44 | `load_execution_attempt` interno a `mark_resolution_failed` levanta `FileNotFoundError` | mesmo wrapper, mesma garantia, quando a causa raiz da falha de persistência é a leitura interna, não a escrita | real, arquivo do attempt removido do disco entre `begin_execution_attempt` e a chamada a `mark_resolution_failed` (ou `monkeypatch.setattr(execution_registry, "load_execution_attempt", ...)` — alvo correto aqui é `execution_registry`, não `application`, porque `load_execution_attempt` é chamada dentro do próprio módulo `execution_registry.py`, não importada por `application.py`, Fato 14) | `test_application.py` |
| 45 | `load_execution_attempt` interno a `mark_execution_failed` levanta `FileNotFoundError` | idem, fase de execução | real, mesmo mecanismo do item 44 | `test_application.py` |
| 46 | attempt YAML corrompido durante `mark_*` produz `pydantic.ValidationError` | wrapper cobre também erro de validação, não só `OSError`/`FileNotFoundError`; parametrizado sobre `phase ∈ {resolution, execution}` | real, arquivo `.yaml` do attempt sobrescrito com conteúdo inválido antes da chamada a `mark_*_failed` | `test_application.py` |
| 47 | propriedades estruturadas do wrapper de persistência | `exc.attempt_id`, `exc.input_state_id`, `exc.phase`, `exc.intended_status`, `exc.original_error` (via `isinstance`), `exc.persistence_error`, `exc.__cause__ is exc.persistence_error` — as sete asserções, em um único cenário construído (falha científica real + persistência monkeypatchada) | real + mock; **`monkeypatch.setattr(molecular.application, "mark_execution_failed", <fake que levanta OSError>)`** — mesmo alvo e mesma justificativa dos itens 42/43 (Fato 14) | `test_application.py` |
| 48 | CLI mapeia o wrapper de persistência para `STORAGE ERROR` | banner `STORAGE ERROR`; linha `Terminal status persisted: no` presente; nenhum traceback Python na saída | mock (`cli_module.enumerate_state_tautomers` levanta `TautomerEnumerationAttemptPersistenceError` fabricada) | `test_cli.py` |
| 49 | CLI não tenta recarregar nem recompensar no caminho de persistência falha | `load_execution_attempt`, `mark_resolution_failed`, `mark_execution_failed`, `_compensate_published_candidates` — nenhum é chamado pela CLI depois de capturar o wrapper (spies via monkeypatch, contagem de chamadas == 0 para todos) | mock | `test_cli.py` |

**Regra geral aplicável a qualquer teste que precise interceptar `mark_resolution_failed`/`mark_execution_failed`/`load_execution_attempt` a partir de `enumerate_state_tautomers`:** o alvo do monkeypatch depende de **onde o nome é resolvido em tempo de chamada**, não de onde a função é **definida**. `mark_resolution_failed`/`mark_execution_failed` são resolvidos no namespace de `application.py` (importados via `from ... import`, Fato 14) — alvo: `molecular.application`. `load_execution_attempt`, quando chamada internamente por `mark_resolution_failed`/`mark_execution_failed` (itens 44/45), é resolvida no namespace de `execution_registry.py` (chamada como nome do próprio módulo) — alvo: `execution_registry`. Os dois alvos não são intercambiáveis.

### 13.5 Mecanismo de `attempt_id` determinístico

Para os itens `39b-KI`/`39b-SE`/`39c-KI`/`39c-SE` e qualquer outro teste real de `test_application.py` que precise de `attempt_id` conhecido antes de chamar `enumerate_state_tautomers` — inclusive cenários que staged mais de um candidato (item 43), o mecanismo é um `uuid.uuid4` **controlado**, que retorna o valor fixo **somente na primeira chamada** e delega todas as chamadas subsequentes à função real:

```python
import uuid

from molecular import execution_registry

fixed_uuid = uuid.UUID("00000000-0000-0000-0000-000000000017")
real_uuid4 = execution_registry.uuid.uuid4
calls = {"count": 0}

def controlled_uuid4():
    calls["count"] += 1
    if calls["count"] == 1:
        return fixed_uuid
    return real_uuid4()

monkeypatch.setattr(
    execution_registry.uuid,
    "uuid4",
    controlled_uuid4,
)
```

**Por que a primeira chamada é a única fixada:** `execution_registry.uuid` e `application.uuid` apontam para o mesmo objeto de módulo Python (`import uuid` em ambos — `execution_registry.py` e `application.py`). Um único `lambda: fixed_uuid` faria **todas** as chamadas posteriores de `application.py` para `uuid.uuid4()` — incluindo `state_id`/`transformation_id` de cada candidato publicado (`application.py`, linhas 606-607, dentro do list comprehension que constrói `staged`) — retornarem o mesmo valor. Em qualquer cenário que estagie mais de um candidato antes da falha induzida (ex.: uma variante do item 43 com múltiplos resíduos), o segundo `register_state`/`register_state_transformation` da mesma execução colidiria com o primeiro (`FileExistsError` genuína, por um motivo alheio ao que o teste pretende exercitar). Para exatamente um candidato staged não há colisão real (os três ids vivem em diretórios distintos — `execution_attempts/`, `states/`, `transformations/`), mas o mecanismo controlado é seguro em ambos os casos, sem exigir que o implementador raciocine sobre quantos candidatos cada cenário produz.

**Como o mecanismo funciona:**

1. Captura a função `uuid.uuid4` real (`real_uuid4 = execution_registry.uuid.uuid4`) **antes** do monkeypatch, preservando acesso a ela mesmo depois que o atributo `uuid4` do módulo for substituído.
2. `controlled_uuid4` retorna `fixed_uuid` **somente na primeira chamada** (`calls["count"] == 1`) — exatamente a chamada que `begin_execution_attempt` faz para gerar `attempt_id` (`execution_registry.py`, linha 181, a primeira chamada a `uuid.uuid4()` em qualquer execução de `enumerate_state_tautomers`).
3. **Todas as chamadas posteriores delegam à função real** (`return real_uuid4()`) — cada `state_id`/`transformation_id` gerado depois recebe um UUID genuinamente aleatório, distinto entre si e do `attempt_id` fixado.
4. `begin_execution_attempt` recebe o id determinístico normalmente — nenhuma mudança na ordem de chamadas de `enumerate_state_tautomers` é necessária.
5. Estados e transformações publicados posteriormente recebem ids distintos — nenhum risco de `FileExistsError` espúria, independentemente de quantos candidatos forem staged.
6. `monkeypatch.setattr` restaura `execution_registry.uuid.uuid4` ao valor original automaticamente ao fim do teste (garantia padrão do fixture `monkeypatch` do `pytest`) — nenhuma limpeza manual adicional é necessária; `calls`/`real_uuid4` são variáveis locais do escopo do teste, descartadas com ele.

**Resultado esperado:**
- `attempt_id == fixed_uuid.hex`;
- o teste carrega o attempt diretamente por esse id (`load_execution_attempt(tmp_path, fixed_uuid.hex)`), ou, mais frequentemente, obtém `attempt_id` diretamente de `exc.attempt_id`/`interrupt.__cause__` sem precisar do valor fixado antecipadamente;
- nenhum snapshot/diff de diretório;
- nenhuma noção de "attempt mais recente";
- nenhum uso de timestamp para correlação;
- nenhum lookup por `input_state_id`;
- nenhuma colisão de `state_id`/`transformation_id` entre candidatos diferentes, independentemente de quantos forem staged antes da falha induzida.

**Precedente citado, confirmado no código real** (`tests/test_execution_registry.py`, linhas 607-608, dentro de `test_begin_rejects_a_colliding_generated_attempt_id`): `fixed_uuid = uuid.uuid4(); monkeypatch.setattr(uuid, "uuid4", lambda: fixed_uuid)` (Fato 13). Esse precedente original cobre apenas o caso de uma única chamada relevante a `uuid.uuid4()` no teste (o segundo `attempt_id` daquele teste específico não precisa ser determinístico); o mecanismo desta seção generaliza o mesmo precedente para cenários com múltiplas chamadas subsequentes de `uuid.uuid4()` que não devem ser fixadas.

**Proibição de diff de diretório — escopo exato:** a proibição de técnica de snapshot/diff/listagem de `execution_attempts/` é **obrigatória no código de produção** e **obrigatória nos novos testes do contrato determinístico** (itens `39b-*`/`39c-*`/`42-49`) — estes devem usar `attempt_id` conhecido antecipadamente (mecanismo acima) ou `exc.attempt_id`/`interrupt.__cause__`-derivado, nunca diff. **Testes antigos já existentes**, isolados em `tmp_path` (sem concorrência real entre processos), **podem continuar usando seus helpers históricos** (`_new_attempt`/`_attempt_ids`, técnica de diff) sem necessidade de migração — essa técnica é tecnicamente segura dentro de um `tmp_path` de teste isolado, mesmo sendo proibida em produção. Apenas os testes **novos** do contrato determinístico é que devem adotar o mecanismo desta seção.

### 13.6 Contagem final

| Categoria | Contagem |
|---|---:|
| Total de linhas normativas (matriz completa: Seções 13.2 + 13.3 + 13.4) | **55** |
| Total de testes pytest novos (todas as linhas exceto as três de validação externa/suíte) | **52** |
| — dos quais, `tests/test_cli.py` | 38 |
| — dos quais, `tests/test_application.py` | 13 |
| — dos quais, `tests/test_rdkit_tautomer.py` | 1 |
| Total de validações em ambientes descartáveis (itens 36, 37) | **2** |
| Total de aceitações de suíte completa (item 41) | **1** |
| **Verificação:** 52 + 2 + 1 | **= 55** ✓ |

**Composição da contagem:** Seção 13.2 contribui 41 linhas (itens 1-7, `8a`/`8b`, 9-38, 40, 41, com `8a`/`8b` contando como duas); Seção 13.3 contribui 6 linhas (`39a-KI`, `39a-SE`, `39b-KI`, `39b-SE`, `39c-KI`, `39c-SE`); Seção 13.4 contribui 8 linhas (42-49). Total: 41 + 6 + 8 = 55. Nenhuma das 12 linhas das Seções 13.3/13.4 é validação externa ou aceitação de suíte — todas são testes pytest reais, então 38 (de 13.2, excluindo os itens 36/37/41 que não são pytest) + 6 + 8 = 52 testes pytest; 2 validações externas (36, 37) + 1 aceitação de suíte (41) completam os 55.

---

## 14. Allowlist

| Arquivo | Símbolo novo/alterado | Razão | Risco | Teste correspondente |
|---|---|---|---|---|
| `src/molecular/application.py` | `TautomerEnumerationAttemptFailedError` (nova classe); `TautomerEnumerationAttemptPersistenceError` (nova classe); os dois blocos de `enumerate_state_tautomers` ganham a estrutura de três cláusulas explícitas — `except (KeyboardInterrupt, SystemExit):`, depois `except Exception:` (substituindo `except BaseException:`); docstring atualizado | handoff determinístico de `attempt_id` e tratamento explícito de falha de persistência (Seções 6-8) | médio — muda o contrato público de exceções de uma função já congelada, mas sem consumidor real hoje além de testes | itens 24, 26, 27, `39b-*`, `39c-*`, 42-47 (`test_application.py`); todos os testes existentes de falha em `test_application.py` precisam de atualização (Seção 16, passo 2) |
| `src/molecular/rdkit_tautomer.py` | `with rdBase.BlockLogs():` ao redor de `enumerator.Enumerate(mol)`, dentro de `enumerate_tautomers_rdkit` | suprimir o log nativo do RDKit no stderr do processo (Seção 11) | baixo — mudança aditiva de escopo mínimo, usa símbolo já importado, não toca lógica de enumeração/sanitização/dedup | item 35 (`test_rdkit_tautomer.py`) |
| `src/molecular/cli.py` | novo comando `state_app.command("enumerate-tautomers")`; imports novos: `enumerate_state_tautomers`, `TautomerEnumerationAttemptFailedError`, `TautomerEnumerationAttemptPersistenceError` (de `application`); `TautomerEnumerationPolicy` (de `execution`); `load_execution_attempt` (de `execution_registry`); `RDKitUnavailableError`/`InvalidSDFError`/`MultipleMoleculesError`/`IncompleteEnumerationError` (de `rdkit_tautomer`); `load_state_transformation` (de `transformation_registry`, ao lado do já existente `list_state_transformations`); `except TautomerEnumerationAttemptPersistenceError:` antes de qualquer handler genérico | expor o comando (Seção 5); consumir o novo contrato de erro (Seção 7.4) | baixo — camada de apresentação, nenhuma lógica científica | itens 1-23, 25, 28-34, 38-40, `39a-KI`, `39a-SE`, 48, 49 (`test_cli.py`) |
| `tests/test_cli.py` | testes novos: itens 1-23 (incluindo `8a`/`8b`), 25, 28-34, 38-40, `39a-KI`, `39a-SE`, 48, 49 | cobertura do novo comando | — | é o próprio arquivo de teste |
| `tests/test_application.py` | atualização dos testes de falha existentes (Seção 16, passo 2) + itens 24, 26, 27, `39b-KI`, `39b-SE`, `39c-KI`, `39c-SE`, 42-47 | cobertura das duas novas exceções e do refinamento de `KeyboardInterrupt`/`SystemExit` (Seção 8) | — | é o próprio arquivo de teste |
| `tests/test_rdkit_tautomer.py` | item 35, estendendo `test_status_max_tautomers_reached` | cobertura da supressão de log | — | é o próprio arquivo de teste |

**A nova `TautomerEnumerationAttemptPersistenceError` permanece em `application.py`**, ao lado de `TautomerEnumerationAttemptFailedError` — nenhum motivo técnico concreto para outro módulo.

**Nenhum outro arquivo precisa mudar.** `execution.py`, `execution_registry.py` (incluindo `mark_resolution_failed`/`mark_execution_failed`/`load_execution_attempt`/`_persist`, todos deliberadamente não tornados best-effort — a falha de persistência é tratada no chamador, `application.py`, não no registry — preservando a visibilidade de falhas reais de storage), `transformation_registry.py`, `scientific_registry.py` permanecem inteiramente inalterados — todas as funções que a CLI e as novas exceções usam já são públicas e já existem. Nenhum schema persistido é alterado.

**Exclusões explícitas, confirmadas sem nenhuma ocorrência em nenhuma seção deste documento:** PubChem/promoção de ligante; `ExperimentalConditions`; pH/pKa; protonação; geração 3D; confôrmeros; receptor; docking/redocking; GUI; qualquer mudança em schemas científicos (`ScientificEntity`, `MolecularState`, `Conformer`, `StateTransformationRecord`, `TautomerEnumerationPolicy`, `ResolvedExecutionSnapshot`) além das duas novas classes de exceção em `application.py`.

---

## 15. Critérios de aceite objetivos

1. `molecular state enumerate-tautomers --help` funciona e documenta `--input-state`, `--max-states`.
2. Nenhuma linha nova em `cli.py` importa `rdkit` em qualquer forma.
3. `enumerate_state_tautomers` é chamada exatamente uma vez por invocação bem-sucedida, sempre com parâmetros reais.
4. Nenhuma lógica de enumeração, sanitização, dedup ou compensação é duplicada em `cli.py`.
5. Toda falha após a criação de um attempt, com persistência do status terminal confirmada, é reportada com o `attempt_id` correto, determinístico, nunca descoberto por busca/diff de diretório.
6. `residual_state_ids`/`residual_operation_ids`, quando não vazios, aparecem na saída de falha, rotulados como remoções não confirmadas — nunca como órfãos definitivos.
7. `KeyboardInterrupt`/`SystemExit` nunca são capturados por um `except BaseException` genérico na CLI, e nunca produzem um banner de erro de domínio.
8. Nenhuma mensagem de erro do comando contém stack trace, caminho absoluto sensível não sanitizado, ou saída bruta não controlada do motor RDKit em stdout **ou stderr**, para os status cobertos pela supressão (`MaxTautomersReached`, `Canceled`) — confirmado por teste que captura os dois canais separadamente.
9. `--max-states` inválido (`0`, negativo) é rejeitado antes de qualquer chamada à Application Service.
10. Sucesso com zero, um e múltiplos estados novos produzem saída correta e `exit 0`.
11. A suíte completa do repositório permanece 100% verde (0 failed) tanto com quanto sem o extra `rdkit` instalado.
12. Nenhum arquivo fora do allowlist da Seção 14 é modificado.
13. `increment-009-review.txt` permanece intocado.
14. A especificação congelada do Incremento 016 permanece intocada.
15. Nenhuma falha em `mark_resolution_failed`/`mark_execution_failed` (nem em `load_execution_attempt` interno a elas, nem em `_persist` interno a elas) produz um traceback Python não tratado em nenhum caminho da CLI — sempre `TautomerEnumerationAttemptPersistenceError` → banner `STORAGE ERROR` → exit 1.
16. A saída de `STORAGE ERROR` por falha de persistência sempre inclui, sem exceção: Attempt ID, Input state, Phase, Intended status, a linha literal `Terminal status persisted: no`, o erro científico original, e o erro de persistência.
17. A CLI nunca chama `load_execution_attempt` no caminho de `TautomerEnumerationAttemptPersistenceError` — nenhum status potencialmente enganoso (`started`/`resolved`, nunca `intended_status`) é apresentado como se fosse terminal.
18. A CLI nunca tenta novamente a persistência nem a compensação após capturar `TautomerEnumerationAttemptPersistenceError` — zero chamadas adicionais a `mark_*`/`_compensate_published_candidates`/`load_execution_attempt` neste caminho (verificado por spy, item 49).
19. `KeyboardInterrupt`/`SystemExit` nunca são substituídos por `TautomerEnumerationAttemptPersistenceError` nem por `TautomerEnumerationAttemptFailedError`, mesmo quando a persistência da compensação também falha — a interrupção original é sempre a exceção que atravessa a fronteira da CLI, com `persistence_error`, quando existir, apenas como `__cause__` encadeado.
20. Nenhum `except BaseException` é introduzido em `cli.py`.
21. `tests/test_application.py` cobre `KeyboardInterrupt` e `SystemExit` separadamente e explicitamente (nunca apenas um dos dois com a suposição de que o outro "funciona igual") em ambos os sub-casos: persistência bem-sucedida e persistência falha.
22. O mecanismo de `attempt_id` determinístico usado em qualquer teste novo desta especificação nunca fixa `uuid.uuid4()` para além da primeira chamada — nenhum teste produz `FileExistsError` espúria por colisão de `state_id`/`transformation_id` entre candidatos.
23. Todo monkeypatch de `mark_resolution_failed`/`mark_execution_failed` usado em testes desta especificação tem como alvo `molecular.application` (o nome importado), nunca `execution_registry` (o módulo de origem).

---

## 16. Plano de implementação (alto nível, não vinculante)

1. `application.py`: adicionar `TautomerEnumerationAttemptFailedError` e `TautomerEnumerationAttemptPersistenceError`; reestruturar os dois blocos de `enumerate_state_tautomers` conforme a Seção 8.3 (três cláusulas explícitas, substituindo os dois `except BaseException`); atualizar o docstring da função para declarar o novo contrato, incluindo a justificativa de compatibilidade da Seção 8.7.
2. `tests/test_application.py`: localizar programaticamente (busca objetiva no código-fonte de teste, não lista manual parcial) toda função de teste que chama `enumerate_state_tautomers` e hoje espera diretamente a exceção científica original; atualizar cada uma para esperar `TautomerEnumerationAttemptFailedError` e verificar `.original_error`/`.attempt_id`/`.status`/`__cause__`; testes de falha anterior a `begin_execution_attempt` continuam esperando a exceção original; testes de `KeyboardInterrupt`/`SystemExit` continuam esperando as interrupções originais; nenhuma alteração em testes de sucesso que não dependam da exceção; adicionar os itens `39b-KI`/`39b-SE`/`39c-KI`/`39c-SE`/42-47 (Seção 13.3, 13.4) — usando `monkeypatch.setattr(molecular.application, "mark_resolution_failed"/"mark_execution_failed", ...)` nos itens 42/43/47, e o mecanismo de `uuid.uuid4` de primeira-chamada-apenas (Seção 13.5) em qualquer cenário com múltiplos candidatos staged.
3. `rdkit_tautomer.py`: envolver a chamada `Enumerate(mol)` com `rdBase.BlockLogs()`.
4. `tests/test_rdkit_tautomer.py`: adicionar o item 35.
5. `cli.py`: implementar `state enumerate-tautomers` conforme Seções 5-12; adicionar `except TautomerEnumerationAttemptPersistenceError:` antes de qualquer handler genérico.
6. `tests/test_cli.py`: adicionar os itens 1-23, 25, 28-34, 38-40, `39a-KI`, `39a-SE`, 48, 49.
7. Rodar a suíte completa nos dois ambientes (com e sem `.[rdkit]`), confirmando 0 failed em ambos (itens 36, 37).
8. Confirmar via grep que nenhuma linha nova em `cli.py` importa `rdkit`.
9. Submeter esta candidata final para confirmação (o congelamento formal é uma decisão explícita, fora do escopo deste documento) antes de qualquer implementação real.

---

## 17. Riscos residuais

- **Quebra de contrato em `application.py`:** deliberada e de baixo risco real (sem consumidores fora de testes), mas exige atualizar todos os testes de falha existentes de `enumerate_state_tautomers` — trabalho mecânico, não conceitual. Estendida também à mudança de `except BaseException` para cláusulas explícitas (Seção 8.7) — mesma classe de risco.
- **Estado global do logger do RDKit:** documentado na Seção 11; não se materializa no uso single-thread da CLI, mas deve ser reavaliado se `enumerate_tautomers_rdkit` algum dia for chamada de um contexto multi-thread.
- **`FileExistsError` mapeado para `INPUT ERROR`** (preflight de execução e colisão em `begin_execution_attempt`): o mapeamento em si é mantido, mas a justificativa correta é apenas de **superfície**. `ligand_add`/`state_add` (via `_add_scientific_input`) e `state_derive` (`--child-state`) tratam `FileExistsError` sobre um **id digitado pelo usuário** — um erro de entrada genuíno. Em `enumerate_state_tautomers`, tanto `attempt_id` quanto `state_id`/`transformation_id` são gerados **inteiramente internamente** (`uuid.uuid4().hex`) — o usuário nunca os escolhe, nunca pode causar a colisão por erro seu. O precedente citado é real apenas de superfície — mesma classe de exceção, mesmo vocabulário de banner — não é um precedente estrutural (mesma causa raiz: entrada do usuário). A decisão de manter `INPUT ERROR` permanece aceitável (probabilidade astronomicamente baixa; escolha cosmética, não afeta exit code/compensação/corretude do attempt; nenhum banner existente descreve com exatidão "colisão interna de geração de identidade, causada pela plataforma"), mas a imprecisão semântica fica registrada como dívida, não resolvida.
- **Colisão de id em `begin_execution_attempt`:** astronomicamente rara; cobertura já existente em `test_execution_registry.py` (Fato 13); nenhum teste dedicado adicionado por este incremento.
- **Narrowing de `except BaseException` para `except (KeyboardInterrupt, SystemExit)` + `except Exception`:** `GeneratorExit`/`asyncio.CancelledError` deixam de disparar compensação/persistência de falha em `enumerate_state_tautomers`. Avaliado como seguro: a função é síncrona, não geradora, não corrotina, sem caminho real de `yield`/`await` na CLI proposta. Documentado como condição a reavaliar apenas se `enumerate_tautomers_rdkit`/`enumerate_state_tautomers` algum dia forem chamadas de um contexto assíncrono ou de dentro de um generator — não é o caso deste incremento.
- **`TautomerEnumerationAttemptPersistenceError` em si pode, em teoria, mascarar uma segunda falha de storage durante a própria tentativa de log de atividade best-effort:** não é um risco elevado — `_record_enumerate_tautomers_activity_safely` já é, e continua sendo, garantidamente best-effort (nunca propaga, Fato 8); se ela falhar silenciosamente ao mesmo tempo que `mark_*_failed`, o usuário ainda recebe o banner `STORAGE ERROR` correto — apenas o log de atividade do experimento fica sem a entrada `outcome="error"` correspondente, uma perda de auditoria secundária, não uma falha de correção reportada ao usuário.

---

## 18. Decisões aceitas/rejeitadas

**Aceitas integralmente, ao longo de todo o histórico deste incremento (Seção 4):** BLOCKER-1 (técnica de diff de diretório removida do caminho de produção, substituída por handoff determinístico via exceção tipada, Seção 13.5); MAJOR-1 original (resíduos na saída de falha, Seção 10); MAJOR-2 original (correção de stderr dentro deste incremento, não apenas documentada, Seção 11); MAJOR-3 original (testes de stdout/stderr separados, Seção 13.2, item 34); MAJOR-A (lacuna de tratamento na falha de persistir o status terminal — `TautomerEnumerationAttemptPersistenceError`, casos C/D, Seções 7-9); MINOR-1 original (correção da alegação de import de `load_state_transformation`, Fato 3); MINOR-2 original (ordenação de `isinstance`, não checagem de tipo exato, Seção 9.2); MINOR-4 original (proibição de `_record_activity_safely` duplicado, Seção 12); MINOR-A da revisão curta (justificativa do precedente de `INPUT ERROR` corrigida, Seção 17); MINOR-B da revisão curta (mecanismo de `attempt_id` determinístico especificado, Seção 13.5); MINOR-C da revisão curta (contagem recalculada de forma auditável, Seção 13.6); MINOR-D da revisão curta (regra verificável de busca objetiva, Seção 16, passo 2); recomendação de parametrização de `KeyboardInterrupt`/`SystemExit` (Seção 8.5, 13.3); **MINOR-V2-1** (mecanismo de `attempt_id` corrigido para delegar chamadas subsequentes de `uuid.uuid4()` à função real, Seção 13.5); **MINOR-V2-2** (itens 42, 43, 47 corrigidos para nomear explicitamente `molecular.application.mark_resolution_failed`/`mark_execution_failed` como alvo do monkeypatch, Seção 13.4, Fato 14).

**Aceita com resolução diferente da sugestão literal:** MINOR-3 original — a revisão pedia apenas "confrontar" os dois precedentes de posicional vs. opção; este contrato vai além e muda a decisão (de posicional para `--input-state`), por considerar `state derive --parent-state` o precedente funcionalmente mais próximo (Seção 5.1).

**Rejeitadas:** nenhuma, em nenhuma etapa do histórico. Todas as mudanças obrigatórias de todas as revisões foram incorporadas.

**Deliberadamente não incorporadas por não serem obrigatórias (notas, não MINOR/MAJOR/BLOCKER):** as três notas da revisão final curta (segunda interrupção durante a própria persistência — comportamento natural do Python, Seção 8.2; esclarecimento de que o pseudocódigo da Seção 8.3 representa dois blocos distintos — já esclarecido diretamente nesta candidata, Seção 8.3; confirmação de que `persistence_error` nunca escapa cru — já confirmado, Seção 8.3) foram tratadas como esclarecimentos incorporados diretamente na prosa técnica onde relevante, não como itens de correção separados, por não terem sido listadas como MINOR obrigatório em nenhuma revisão.

---

## 19. Estado final

Nenhum arquivo do repositório foi criado, modificado ou removido para produzir este documento. Nenhum branch ou commit foi criado. Nenhum push, merge ou PR foi realizado. `increment-009-review.txt` permanece intocado (hash confirmado idêntico nesta sessão, Seção 1). Todos os documentos anteriores do histórico (Seção 4) permanecem preservados, intocados, incluindo o artefato entregue no caminho incorreto na sessão anterior — nenhum foi lido em modo de escrita, nenhum foi apagado, movido ou sobrescrito. A suíte de testes não foi reexecutada nesta sessão, por instrução explícita da tarefa; a última execução confirmada (sessão anterior) permanece registrada na Seção 1. Nenhum spike foi executado. Nenhum código foi implementado. Nenhum teste foi alterado. Esta especificação **está congelada** após a micro-revisão final, com o único MINOR aritmético corrigido na Seção 13.6.

---

FINAL SPECIFICATION COMPLETE: YES
SELF-SUFFICIENT: YES
MINOR-V2-1 ADDRESSED: YES
MINOR-V2-2 ADDRESSED: YES
PREVIOUS INCORRECT ARTIFACT PRESERVED: YES
FINAL MICRO-REVIEW COMPLETE: YES
BLOCKERS: 0
MAJORS: 0
IMPLEMENTABLE MINORS PENDING: 0
READY FOR IMPLEMENTATION: YES
FINAL SPECIFICATION FROZEN: YES
REPOSITORY MODIFIED: NO
