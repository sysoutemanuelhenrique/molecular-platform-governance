# Fronteiras Legais e Éticas

## Natureza deste documento

Este documento estabelece fronteiras operacionais para o processo de investigação definido em `GOVERNANCE.md`. Ele **não é aconselhamento jurídico** e não substitui uma avaliação legal específica quando uma investigação envolver software proprietário, dados de terceiros, ou jurisdições com regras particulares sobre engenharia reversa, licenciamento e segredo comercial. Questões jurídicas concretas dependem da licença, do EULA, do contrato de acesso e da jurisdição aplicável a cada alvo específico, e devem ser avaliadas antes de qualquer investigação sensível — não depois.

Este documento também não afirma que engenharia reversa é universalmente permitida nem universalmente proibida. Essa afirmação seria falsa em ambos os sentidos: a permissibilidade depende da lei aplicável, da licença do software específico, e do propósito e método da investigação. Cada investigação precisa da sua própria checagem.

## O que é permitido, sujeito a licença e contexto

As atividades abaixo são compatíveis com o propósito desta governança quando conduzidas dentro de um contexto legítimo de acesso e com a licença do alvo verificada antes do início (ver `GOVERNANCE.md`, etapa *License / Authorization Check*):

- estudar comportamento observável de um software ou motor científico (black-box);
- comparar entradas e saídas (inputs/outputs) de um sistema;
- realizar benchmarking técnico e de desempenho;
- analisar formatos de arquivo;
- analisar protocolos de comunicação ou interoperabilidade;
- identificar e documentar as etapas de um workflow científico;
- estudar interoperabilidade entre sistemas;
- estudar software adquirido ou acessado legitimamente (licença comercial válida, acesso acadêmico autorizado, acesso público gratuito dentro dos termos de uso);
- estudar software open source, respeitando os termos da licença específica (que podem restringir uso, modificação ou redistribuição mesmo quando o código é publicamente legível);
- produzir especificações técnicas independentes a partir do entendimento obtido;
- analisar binários, quando a lei aplicável e a licença do software especificamente permitirem essa atividade;
- analisar chamadas de sistema, símbolos exportados, strings e comportamento em tempo de execução, dentro dos mesmos limites de licença e lei;
- utilizar os resultados dessas atividades para decisões arquiteturais independentes da Turing Bohr Molecular Platform.

A frase "sujeito à licença e contexto" não é uma formalidade — significa que cada uma destas atividades pode ser permitida para um alvo e proibida para outro, dependendo exclusivamente dos termos que governam aquele alvo específico.

## O que não é permitido dentro deste processo

As atividades abaixo são incompatíveis com esta governança, independentemente de benefício técnico percebido, e nenhuma investigação sob `competitive-technical-research/` pode incluí-las:

- copiar código proprietário;
- incorporar código decompilado proprietário ao código-fonte da Turing Bohr Molecular Platform, ou a qualquer especificação que alimente esse código-fonte;
- extrair ou reutilizar credenciais de acesso;
- contornar mecanismos de autenticação;
- remover ou neutralizar DRM (gerenciamento de direitos digitais);
- quebrar mecanismos de licenciamento de software;
- obter segredos comerciais por meio de acesso não autorizado;
- redistribuir código ou artefatos proprietários de terceiros;
- usar material obtido ilegalmente, por qualquer meio, como insumo de uma investigação;
- esconder, omitir ou misrepresentar a origem de qualquer evidência coletada.

Uma investigação que, em qualquer ponto, exigiria uma das atividades acima para continuar deve ser interrompida e movida para o estado `REJECTED` (ver `GOVERNANCE.md`) — não contornada, adaptada ou continuada por outro meio equivalente.

## Checagem antes de investigações sensíveis

Antes de iniciar uma investigação que envolva software proprietário, binários não documentados, ou qualquer alvo cuja licença não seja imediatamente clara, a etapa *License / Authorization Check* de `GOVERNANCE.md` deve produzir, no mínimo:

- identificação do instrumento legal aplicável (licença, EULA, contrato, termos de uso da API/serviço);
- identificação de restrições explícitas sobre engenharia reversa, decompilação ou análise de binário nesse instrumento;
- quando a legalidade permanecer genuinamente incerta após essa checagem, a investigação permanece em `PROPOSED` até que uma avaliação jurídica específica seja obtida — esta governança não resolve ambiguidade jurídica por si mesma.

## Relação com `CLEAN_ROOM_POLICY.md`

Mesmo quando uma atividade de pesquisa é legalmente permitida, a forma como sua evidência é usada ainda é restringida pela separação formal entre evidência, interpretação, especificação e implementação definida em `CLEAN_ROOM_POLICY.md`. Permissão legal para observar não é, por si só, permissão para copiar — essas são questões distintas, e esta governança trata ambas.
