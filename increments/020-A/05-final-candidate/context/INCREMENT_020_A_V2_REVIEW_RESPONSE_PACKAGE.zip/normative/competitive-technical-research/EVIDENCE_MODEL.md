# Modelo de Evidência

## Propósito

Toda conclusão técnica produzida sob `competitive-technical-research/` deve declarar explicitamente a classe de evidência que a sustenta. Isto existe para que um leitor futuro — revisor de arquitetura, implementador de um incremento candidato, ou auditor — possa distinguir, sem ambiguidade, o que foi efetivamente observado do que foi deduzido, suposto, ou permanece desconhecido. Uma afirmação técnica sem classe de evidência declarada não é uma conclusão válida sob esta governança.

## Taxonomia obrigatória

| Classe | Definição |
|---|---|
| `OBSERVED` | Evidência diretamente observada pelo investigador — uma saída real de um comando, uma resposta real de uma API, uma tela real de uma interface, capturada e registrada no momento da observação. |
| `DOCUMENTED` | Informação obtida de documentação oficial do alvo (manual, especificação publicada, release notes, documentação de API). Não verificada independentemente — apenas relatada pela fonte. |
| `SOURCE_VERIFIED` | Confirmada diretamente pela leitura de código-fonte legalmente disponível (open source, ou proprietário com acesso de leitura legitimamente concedido). A classe de evidência mais direta quando código-fonte está disponível. |
| `EXPERIMENTALLY_VERIFIED` | Confirmada por um experimento reproduzível, desenhado especificamente para testar a afirmação — não uma observação incidental, mas um teste deliberado com entrada e saída controladas. |
| `INFERRED` | Dedução lógica baseada em uma ou mais evidências de outra classe, mas não confirmada diretamente. A cadeia de inferência (quais evidências sustentam a dedução) deve ser citada. |
| `HYPOTHESIZED` | Hipótese formulada para explicar uma observação, mas ainda não submetida a verificação experimental ou de código-fonte. Permanece hipótese até ser promovida a uma classe mais forte ou refutada. |
| `UNKNOWN` | Explicitamente não determinado. Usar esta classe é preferível a omitir a questão ou a preencher o vazio com uma suposição não marcada como tal. |
| `CONFLICTING` | Duas ou mais evidências, de qualquer classe, apontam para conclusões incompatíveis sobre o mesmo fato. A natureza do conflito deve ser documentada, não resolvida por escolha arbitrária de um dos lados. |

## Regras de uso

1. **Toda afirmação técnica em um relatório de investigação (`templates/INVESTIGATION_REPORT_TEMPLATE.md`) deve ser anotada com exatamente uma destas classes.** Quando uma afirmação combina evidências de classes diferentes, ela deve ser decomposta em afirmações menores, cada uma com sua própria classe.
2. **A classe `SOURCE_VERIFIED` nunca se aplica a código-fonte obtido por decompilação de software proprietário sem licença que autorize essa leitura.** Código obtido dessa forma, quando sua origem for de outro modo legítima para fins de observação comportamental (ver `LEGAL_AND_ETHICAL_BOUNDARIES.md`), deve ser classificado como `OBSERVED` ou `INFERRED`, nunca `SOURCE_VERIFIED` — essa distinção existe precisamente para impedir que análise de binário seja apresentada com a mesma autoridade que leitura legítima de código-fonte.
3. **`INFERRED` e `HYPOTHESIZED` não são classes de evidência fraca a serem evitadas — são honestas.** Uma investigação que produz apenas `INFERRED`/`HYPOTHESIZED` sobre uma questão central deve dizer isso claramente, em vez de forçar uma classificação mais forte que a evidência não sustenta.
4. **`CONFLICTING` nunca deve ser silenciosamente resolvido.** Se duas fontes (por exemplo, documentação oficial e comportamento observado) discordam, ambas são registradas, o conflito é marcado como `CONFLICTING`, e a resolução — se houver — é uma conclusão separada e explicitamente justificada.
5. **Promoção de classe exige novo trabalho, não reinterpretação.** Uma hipótese (`HYPOTHESIZED`) só se torna `EXPERIMENTALLY_VERIFIED` depois de um experimento real ser desenhado e executado — nunca por decisão editorial de que a hipótese "parece correta".

## Uso no registro individual de evidência

Cada item de evidência coletado durante uma investigação é registrado individualmente usando `templates/EVIDENCE_RECORD_TEMPLATE.md`, que exige um campo `Classification` preenchido com uma das classes acima. O relatório final da investigação (`templates/INVESTIGATION_REPORT_TEMPLATE.md`) então agrupa e sintetiza os registros individuais por classe, nas suas próprias seções (`# Observed`, `# Documented`, `# Source Verified`, etc.), preservando a rastreabilidade entre a conclusão sintetizada e os registros individuais que a sustentam.

## Confiança não é uma classe de evidência

Um nível de confiança (ver também `ENGINE_RESEARCH_POLICY.md`, campo "nível de confiança") é uma avaliação subjetiva de quão bem uma conclusão se sustenta, dada a quantidade e a qualidade das evidências disponíveis. Ele é registrado separadamente da classe de evidência, nunca em seu lugar — duas conclusões podem ter a mesma classe de evidência (por exemplo, ambas `EXPERIMENTALLY_VERIFIED`) e níveis de confiança diferentes, dependendo de quantos experimentos independentes as sustentam e de quão consistentes foram seus resultados.
