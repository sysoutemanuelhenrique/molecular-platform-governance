# Política de Clean Room

## Princípio formal

A implementação da Turing Bohr Molecular Platform não deve depender de copiar a expressão específica de código proprietário de nenhum software de terceiros. Este documento formaliza a separação de processo que garante essa propriedade — não como uma intenção informal, mas como uma cadeia de responsabilidade com transferência de controle explícita entre pessoas e artefatos.

```
Evidence Team / Research
        ↓
Behavioral / Technical Specification
        ↓
Independent Design
        ↓
Implementation
```

Cada seta nesta cadeia representa uma fronteira de transferência: o que atravessa a fronteira é conhecimento *sobre* o comportamento de um sistema, nunca a expressão literal do código-fonte, binário ou documentação que produziu esse comportamento.

## Seis camadas distintas, frequentemente confundidas

A disciplina de clean room depende de manter estas seis camadas conceitualmente separadas em todo momento:

| Camada | O que é | Pode informar a implementação da Turing Bohr? |
|---|---|---|
| `behavior` | O que um sistema faz, observável de fora (entradas → saídas) | Sim — é exatamente o que a investigação deve capturar |
| `algorithmic concept` | A ideia geral de um método ou abordagem (ex.: "usar um algoritmo genético para busca conformacional") | Sim — conceitos algorítmicos genéricos não são, por si, propriedade de uma implementação específica |
| `scientific method` | Um método científico publicado, com fundamentação na literatura | Sim — método científico publicado é conhecimento público, independentemente de qual software o implementa primeiro |
| `interface/protocol` | A forma como dados são estruturados para troca (formato de arquivo, API, protocolo de rede) | Sim, para fins de interoperabilidade — entender um formato não é copiar a implementação de quem o lê/escreve |
| `implementation detail` | Decisões específicas de engenharia de uma implementação particular (estrutura de dados interna, otimizações específicas, organização de módulos) | Não diretamente — pode informar que uma decisão de design *existe a ser tomada*, mas a decisão da Turing Bohr deve ser própria |
| `source expression` | O texto literal do código-fonte ou binário | Nunca — esta é exatamente a camada que a cadeia de clean room existe para excluir |

A confusão mais comum, e a mais perigosa, é tratar `implementation detail` ou `source expression` como se fossem `algorithmic concept` ou `scientific method`. Esta política existe precisamente para impedir essa confusão.

## Por que esta separação importa

1. **Propriedade intelectual.** Direitos de autor protegem a expressão específica de código, não a ideia ou o método subjacente. Uma implementação independente que chega ao mesmo comportamento por desenho próprio não infringe direitos de autor sobre a expressão de outra implementação; uma implementação que transcreve ou parafraseia de perto a expressão de outra pode infringir, mesmo quando "reescrita com outras palavras".
2. **Arquitetura.** Uma implementação desenhada a partir de uma especificação comportamental independente tende a se integrar de forma mais limpa à arquitetura já existente da Turing Bohr do que uma implementação que tenta espelhar a estrutura interna de um sistema de terceiros, que foi desenhada para um contexto arquitetural diferente.
3. **Rastreabilidade.** Quando a cadeia evidência → especificação → implementação é preservada como artefatos distintos, qualquer questão futura ("de onde veio esta decisão de design?") tem uma resposta rastreável: a especificação independente, não um arquivo de terceiros.

## Como a separação é operacionalizada

- A pessoa (ou processo) responsável por **Evidence Team / Research** produz apenas evidência classificada (`EVIDENCE_MODEL.md`) e, no máximo, uma especificação comportamental/técnica (`Behavioral / Technical Specification`) descrevendo *o que foi observado que o sistema faz* — nunca uma proposta de como implementá-lo.
- A etapa de **Independent Design** parte apenas dessa especificação comportamental, nunca retorna à evidência bruta de `source expression` (código-fonte ou binário proprietário) para preencher lacunas. Se a especificação comportamental é insuficiente, a resposta é melhorar a investigação e a especificação — não consultar o artefato proprietário diretamente durante o design.
- A etapa de **Implementation** parte apenas do design independente, da mesma forma que qualquer outro incremento da Turing Bohr parte de uma especificação congelada — sem acesso direto a nenhum artefato da investigação original.

Esta separação de etapas não precisa necessariamente de pessoas fisicamente diferentes para ser válida, mas precisa de artefatos documentais diferentes e de uma transição deliberada entre eles — a disciplina está no processo e no registro, não apenas na intenção.

## Relação com `GOVERNANCE.md`

Esta política governa especificamente a transição de *Interpretation* para *Independent Specification* no processo definido em `GOVERNANCE.md`. Uma especificação candidata que não possa demonstrar essa separação — por exemplo, que cite trechos literais de código-fonte proprietário como justificativa de uma decisão de design, em vez de citar a especificação comportamental derivada dele — não deve avançar para `Architecture Review`.
