# Workflow Detalhado de Investigação

## Relação com `GOVERNANCE.md`

`GOVERNANCE.md` define a cadeia de processo e os estados formais de uma investigação. Este documento detalha tecnicamente as fases que ocorrem dentro dessa cadeia — principalmente entre *Investigation Plan* e *Evidence Collection* — e estabelece os **stop gates**: pontos em que a investigação deve explicitamente confirmar que pode prosseguir antes de avançar para a fase seguinte. Um stop gate não transposto mantém a investigação na fase atual, ou a move para `REJECTED` (ver `GOVERNANCE.md`).

## As fases

### Phase 0 — Question

A pergunta de pesquisa é articulada em linguagem clara e específica o suficiente para ser respondida ou refutada por evidência. Corresponde ao estado `PROPOSED` em `GOVERNANCE.md`.

**Stop gate 0 → 1**: a pergunta é específica (não um tópico genérico de exploração) e sua resposta teria consequência prática — científica, arquitetural, ou de produto — para a Turing Bohr Molecular Platform. Se a pergunta não passa este gate, ela é refinada ou a investigação não avança.

### Phase 1 — Authorization and Scope

O alvo é identificado precisamente (incluindo versão, quando aplicável), e a checagem de licença/autorização de `LEGAL_AND_ETHICAL_BOUNDARIES.md` é conduzida e documentada. O escopo e o fora-de-escopo são definidos (ver `templates/INVESTIGATION_PLAN_TEMPLATE.md`).

**Stop gate 1 → 2**: a checagem de autorização não identificou impedimento, ou identificou um impedimento que restringe — mas não elimina — o escopo possível, e o escopo foi ajustado de acordo. Corresponde à transição para o estado `APPROVED_FOR_RESEARCH`.

### Phase 2 — Documentation Research

Documentação oficial do alvo (manuais, especificações publicadas, release notes, documentação de API) é revisada. Produz evidência da classe `DOCUMENTED` (ver `EVIDENCE_MODEL.md`).

**Stop gate 2 → 3**: a documentação disponível foi suficientemente revisada para informar se análise de código-fonte é possível (fase 3) ou se a investigação deve seguir direto para experimentação comportamental (fase 4).

### Phase 3 — Source Research, when available

Quando o alvo é `OPEN_SOURCE_ENGINE`/`ACADEMIC_ENGINE` com licença que permite leitura, ou um `PROPRIETARY_ENGINE`/`COMMERCIAL_ENGINE` com acesso de leitura legitimamente concedido, o código-fonte é lido e analisado. Produz evidência da classe `SOURCE_VERIFIED`. Esta fase é condicional — não se aplica, e é explicitamente pulada com justificativa registrada, quando código-fonte não está disponível.

**Stop gate 3 → 4**: as questões que a análise de código-fonte pode responder foram respondidas, ou determinou-se que análise de código-fonte não pode responder a questão de pesquisa isoladamente (por exemplo, questões sobre desempenho em condições reais, que exigem execução).

### Phase 4 — Black-box Experimentation

Entradas e saídas do sistema são observadas e comparadas por meio de experimentos desenhados deliberadamente, não apenas uso incidental. Produz evidência das classes `OBSERVED` e `EXPERIMENTALLY_VERIFIED`.

**Stop gate 4 → 5**: a experimentação comportamental respondeu à questão de pesquisa com confiança suficiente, ou identificou uma lacuna que só análise de binário poderia potencialmente preencher.

### Phase 5 — Binary Investigation, when justified

Executada apenas quando a Phase 4 identificou uma lacuna real, e apenas quando `LEGAL_AND_ETHICAL_BOUNDARIES.md` e `TOOLING_POLICY.md` já autorizaram o método e a ferramenta específicos. Esta fase é condicional e, na maioria das investigações, não ocorrerá.

**Stop gate 5 → 6**: toda saída desta fase foi registrada como evidência classificada (tipicamente `OBSERVED` ou `INFERRED`, nunca `SOURCE_VERIFIED` — ver `EVIDENCE_MODEL.md`, regra 2), e a justificativa de necessidade e permissão permanece documentada junto ao registro.

### Phase 6 — Evidence Consolidation

Todos os registros individuais de evidência (`templates/EVIDENCE_RECORD_TEMPLATE.md`) produzidos nas fases anteriores são reunidos, revisados por completude, e organizados por classe (`EVIDENCE_MODEL.md`). Corresponde ao estado `EVIDENCE_COLLECTED`.

**Stop gate 6 → 7**: a evidência coletada, tomada como um todo, é suficiente para tentar responder à pergunta de pesquisa original — mesmo que a resposta seja "não determinável com a evidência disponível" (`UNKNOWN`).

### Phase 7 — Independent Interpretation

A evidência consolidada é traduzida em entendimento técnico e científico, com cada afirmação citando a classe de evidência que a sustenta. Corresponde ao estado `INTERPRETED`.

**Stop gate 7 → 8**: existe uma interpretação suficientemente madura para sustentar uma decisão arquitetural — se não existir, a investigação pode legitimamente encerrar em `CLOSED` sem avançar às fases seguintes.

### Phase 8 — Independent Specification

Quando a interpretação sustenta uma mudança ou decisão arquitetural, uma especificação candidata é redigida de forma independente, seguindo `CLEAN_ROOM_POLICY.md`. Corresponde ao estado `SPECIFICATION_CANDIDATE`.

**Stop gate 8 → 9**: a especificação candidata foi redigida sem referência direta a `source expression` ou `implementation detail` de terceiros (ver `CLEAN_ROOM_POLICY.md`) — apenas à especificação comportamental derivada da interpretação.

### Phase 9 — Architecture Review

A especificação candidata é revisada com o mesmo rigor adversarial já aplicado aos incrementos existentes da plataforma (ver os processos de revisão já estabelecidos em `increments/`).

**Stop gate 9 → 10**: a revisão aprova a especificação candidata como base viável para um incremento, rejeita-a, ou solicita correções antes de reavaliação.

### Phase 10 — Increment Candidate

A especificação aprovada se torna candidata a um incremento real da Turing Bohr Molecular Platform. Esta transição é uma decisão explícita e externa a `competitive-technical-research/` — a existência de uma especificação candidata aprovada não cria obrigação de implementação nem prazo para ela.

## Fases condicionais e investigações mais curtas

Não toda investigação percorre todas as onze fases. Uma investigação pode legitimamente encerrar em `CLOSED` após a Phase 2, 4 ou 7, quando a pergunta de pesquisa é respondida sem implicar nenhuma mudança arquitetural, ou quando a evidência disponível não sustenta avançar. Pular uma fase sem justificativa registrada, no entanto, não é uma opção — a justificativa (mesmo que seja apenas "não aplicável a este alvo") é parte do registro da investigação.
