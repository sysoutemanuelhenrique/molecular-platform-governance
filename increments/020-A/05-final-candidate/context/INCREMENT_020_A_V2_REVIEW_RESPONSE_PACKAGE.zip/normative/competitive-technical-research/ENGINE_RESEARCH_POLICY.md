# Política de Pesquisa de Motores Científicos

## Propósito

Este documento governa investigações cujo alvo é um motor científico — qualquer software ou serviço que execute um cálculo, simulação, ou operação científica que a Turing Bohr Molecular Platform já realiza ou pode vir a precisar realizar (por exemplo: preparação de ligantes e receptores, protonação, geração de confôrmeros, docking, scoring, otimização geométrica). O objetivo final de toda investigação sob esta política é sempre o mesmo: **identificar quais responsabilidades científicas pertencem ao motor externo e quais devem pertencer ao Domain/Application Core da própria Turing Bohr.**

## Classificação obrigatória de tipo de motor

Todo motor pesquisado deve ser classificado em exatamente uma das categorias abaixo antes do início da coleta de evidência, pois a categoria determina quais métodos de `TOOLING_POLICY.md` são aplicáveis:

| Categoria | Definição |
|---|---|
| `OPEN_SOURCE_ENGINE` | Código-fonte publicamente disponível sob uma licença que permite leitura e estudo. |
| `PROPRIETARY_ENGINE` | Código-fonte não disponível, ou disponível apenas sob licença que não permite leitura/estudo. |
| `ACADEMIC_ENGINE` | Originado e mantido primariamente em contexto de pesquisa acadêmica, independentemente de sua licença específica (que ainda deve ser verificada individualmente). |
| `COMMERCIAL_ENGINE` | Distribuído comercialmente, com licença de uso pago ou negociado, independentemente de código-fonte estar ou não disponível. |
| `REMOTE_SERVICE` | Acessado como serviço remoto (API, aplicação web, SaaS científico) sem distribuição de binário ou código-fonte local. |
| `UNKNOWN` | Categoria ainda não determinada — estado temporário, nunca um estado final de uma investigação concluída. |

Um motor pode pertencer a mais de uma categoria simultaneamente (por exemplo, `ACADEMIC_ENGINE` e `OPEN_SOURCE_ENGINE`); todas as categorias aplicáveis devem ser registradas.

## Campos obrigatórios de registro

Para cada motor pesquisado, a investigação deve registrar, no mínimo, os seguintes campos (ver também `templates/ENGINE_COMPARISON_TEMPLATE.md` quando mais de um motor for comparado):

- **nome**
- **versão**
- **fornecedor/projeto**
- **licença**
- **tipo** (uma ou mais categorias da tabela acima)
- **inputs**: formatos e estruturas de entrada aceitos
- **outputs**: formatos e estruturas de saída produzidos
- **parâmetros**: parâmetros científicos e técnicos expostos ao usuário/chamador
- **operações científicas**: quais operações científicas o motor efetivamente realiza
- **comportamento**: comportamento observado, incluindo casos de borda relevantes
- **dependências observadas**: outras bibliotecas, motores ou serviços dos quais o motor depende
- **formatos**: formatos de arquivo lidos/escritos
- **limitações**: limitações conhecidas (de precisão, escala, cobertura científica, licenciamento de uso)
- **evidências**: referências aos registros individuais de evidência (`templates/EVIDENCE_RECORD_TEMPLATE.md`) que sustentam cada campo acima
- **nível de confiança**: avaliação de quão bem as evidências disponíveis sustentam o registro como um todo (ver `EVIDENCE_MODEL.md`, seção "Confiança não é uma classe de evidência")

## Separação de responsabilidades: o objetivo final

A pergunta que toda investigação sob esta política existe para responder, direta ou indiretamente, é:

> Desta operação científica, o que é inerente ao método (e portanto deve ser decidido e documentado no Domain/Application Core da Turing Bohr, independentemente de qual motor a executa), e o que é um detalhe de implementação de um motor específico (e portanto pode e deve variar entre motores, sem vazar para o Domain/Application Core)?

Esta questão não tem resposta genérica — ela é respondida operação por operação, motor por motor, com base na evidência coletada. O resultado típico de uma investigação madura sob esta política é uma tabela ou especificação que atribui cada responsabilidade observada a um lado dessa fronteira, com a classe de evidência que sustenta cada atribuição.

## Não copiar comportamento como especificação automática

Documentar o comportamento observado de um motor não é o mesmo que adotá-lo como a especificação da Turing Bohr. Da mesma forma que `COMPETITOR_RESEARCH_POLICY.md` estabelece para software concorrente, toda decisão sobre como a Turing Bohr deve se comportar passa por avaliação científica e arquitetural independente (`CLEAN_ROOM_POLICY.md`) — o comportamento de um motor pesquisado é um insumo para essa avaliação, nunca um substituto para ela.

## Relação com outras políticas

- `TOOLING_POLICY.md` determina o método de investigação permitido dado o tipo de motor (prioridade a source analysis quando `OPEN_SOURCE_ENGINE`/`ACADEMIC_ENGINE` com licença aberta; black-box e, quando necessário e permitido, análise de binário para `PROPRIETARY_ENGINE`/`COMMERCIAL_ENGINE`).
- `LEGAL_AND_ETHICAL_BOUNDARIES.md` governa a checagem de licença antes de qualquer investigação de um `PROPRIETARY_ENGINE`, `COMMERCIAL_ENGINE` ou `REMOTE_SERVICE`.
- `CLEAN_ROOM_POLICY.md` governa a transição do registro de comportamento de um motor para qualquer especificação candidata da Turing Bohr.
