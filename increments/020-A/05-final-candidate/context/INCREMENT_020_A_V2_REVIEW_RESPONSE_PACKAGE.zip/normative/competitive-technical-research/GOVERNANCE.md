# Governança do Processo de Investigação

## Escopo deste documento

Este documento define o processo formal pelo qual uma investigação técnica nasce, é conduzida e é encerrada dentro de `competitive-technical-research/`. Ele não define *o que* pode ser investigado (ver `LEGAL_AND_ETHICAL_BOUNDARIES.md`, `ENGINE_RESEARCH_POLICY.md`, `COMPETITOR_RESEARCH_POLICY.md`) nem *como* cada fase é tecnicamente executada (ver `RESEARCH_WORKFLOW.md`). Ele define a estrutura de governança — quem decide o quê, em que ordem, e que registro cada decisão deixa.

## A cadeia de processo

Toda investigação, sem exceção, segue esta cadeia. Nenhuma etapa pode ser pulada; uma etapa pode concluir que a investigação deve parar (ver estados `REJECTED` e `CLOSED` abaixo).

```
Research Question
    ↓
Target Identification
    ↓
License / Authorization Check
    ↓
Investigation Plan
    ↓
Evidence Collection
    ↓
Evidence Classification
    ↓
Interpretation
    ↓
Independent Specification
    ↓
Architecture Review
    ↓
Possible Future Increment
```

- **Research Question**: a pergunta técnica ou científica concreta que motiva a investigação. Sem uma pergunta articulável, não há investigação — apenas exploração não governada, que esta estrutura não cobre.
- **Target Identification**: identificação explícita do software, motor, formato, protocolo ou artefato a ser estudado, incluindo versão quando aplicável.
- **License / Authorization Check**: verificação, antes de qualquer coleta de evidência, de que o alvo pode ser legitimamente acessado e estudado nos termos pretendidos (ver `LEGAL_AND_ETHICAL_BOUNDARIES.md`). Esta etapa pode encerrar a investigação antes que ela comece.
- **Investigation Plan**: documento formal (`templates/INVESTIGATION_PLAN_TEMPLATE.md`) descrevendo pergunta, escopo, método, ferramentas e condições de parada.
- **Evidence Collection**: execução do plano — observação, documentação, código-fonte quando disponível, experimentação, e, apenas quando justificado e permitido, análise de binário.
- **Evidence Classification**: cada item de evidência recebe uma classe formal (ver `EVIDENCE_MODEL.md`) antes de ser interpretado.
- **Interpretation**: tradução da evidência classificada em entendimento técnico/científico, sempre citando a classe de evidência que sustenta cada afirmação.
- **Independent Specification**: quando a interpretação sustenta uma decisão arquitetural, uma especificação candidata é redigida de forma independente — nunca por transcrição de código ou documentação de terceiros (ver `CLEAN_ROOM_POLICY.md`).
- **Architecture Review**: a especificação candidata é revisada com o mesmo rigor adversarial já aplicado aos incrementos existentes da plataforma.
- **Possible Future Increment**: se aprovada, a especificação candidata pode se tornar a base de um incremento real em `increments/`. Essa transição é uma decisão separada, tomada fora desta pasta.

## Estados de uma investigação

Toda investigação, do momento em que é proposta até seu encerramento, está em exatamente um dos seguintes estados. O estado atual de cada investigação deve ser visível no topo do seu diretório em `investigations/` (ver `templates/INVESTIGATION_PLAN_TEMPLATE.md` e `templates/INVESTIGATION_REPORT_TEMPLATE.md`).

| Estado | Significado |
|---|---|
| `PROPOSED` | A pergunta de pesquisa foi articulada, mas o alvo, escopo e autorização ainda não foram verificados. |
| `APPROVED_FOR_RESEARCH` | Target identification e a checagem de licença/autorização foram concluídas; a investigação pode prosseguir dentro do escopo aprovado. |
| `IN_PROGRESS` | Coleta de evidência em andamento, conforme o plano aprovado. |
| `EVIDENCE_COLLECTED` | A coleta de evidência planejada foi concluída; cada item aguarda ou já recebeu classificação. |
| `INTERPRETED` | A evidência classificada foi traduzida em entendimento técnico/científico documentado. |
| `SPECIFICATION_CANDIDATE` | Uma especificação independente foi redigida a partir da interpretação, pronta para revisão arquitetural. |
| `CLOSED` | A investigação foi concluída — com ou sem especificação candidata resultante — e não haverá mais trabalho sobre ela sob esta identidade. |
| `REJECTED` | A investigação foi interrompida antes da conclusão, por falha na checagem de autorização, por violação de uma fronteira de `LEGAL_AND_ETHICAL_BOUNDARIES.md`, ou por decisão explícita de descontinuar. |

### Regras de transição

- Uma investigação só avança de `PROPOSED` para `APPROVED_FOR_RESEARCH` depois que a checagem de licença/autorização é documentada — não apenas mencionada.
- `REJECTED` pode ser alcançado a partir de qualquer estado anterior a `CLOSED`. Uma investigação rejeitada permanece no histórico (nunca é apagada) com o motivo da rejeição registrado.
- `SPECIFICATION_CANDIDATE` é opcional — muitas investigações legitimamente terminam em `CLOSED` sem produzir uma especificação, porque a pergunta de pesquisa foi respondida sem implicar nenhuma mudança arquitetural.
- Nenhuma investigação transita automaticamente para um incremento real da plataforma. Essa decisão é sempre explícita e externa a esta pasta.

## Responsabilidade e rastreabilidade

Cada investigação deve registrar, desde o `INVESTIGATION_PLAN_TEMPLATE.md` inicial, quem a propôs e quem a conduz. Nenhuma investigação é anônima. Toda mudança de estado deve ser rastreável a uma data e, quando aplicável, a um motivo.

## Relação com os outros documentos desta área

- `LEGAL_AND_ETHICAL_BOUNDARIES.md` governa a etapa de *License / Authorization Check* e permanece aplicável durante toda a investigação.
- `EVIDENCE_MODEL.md` governa a etapa de *Evidence Classification*.
- `CLEAN_ROOM_POLICY.md` governa a transição de *Interpretation* para *Independent Specification*.
- `RESEARCH_WORKFLOW.md` detalha tecnicamente as fases entre *Investigation Plan* e *Evidence Consolidation*, com seus próprios stop gates.
- `TOOLING_POLICY.md`, `ENGINE_RESEARCH_POLICY.md` e `COMPETITOR_RESEARCH_POLICY.md` restringem o que pode ser feito dentro de *Evidence Collection*, conforme a natureza do alvo.
