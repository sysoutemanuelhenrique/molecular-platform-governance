# Política de Ferramentas

## Estado atual

Nenhuma ferramenta de engenharia reversa, análise de binário ou análise comportamental está, no momento da criação deste documento, instalada, configurada ou aprovada para uso. Este documento estabelece a política e o processo de aprovação — não uma aprovação em si. `tooling/README.md` é o registro onde cada ferramenta, quando avaliada, recebe seu próprio status formal.

## Categorias de ferramenta cobertas

Esta política se aplica, no mínimo, às seguintes categorias:

- **REA — Reverse Engineer Anything**: ferramenta de engenharia reversa de propósito geral.
- **Ghidra**: framework de engenharia reversa e análise de binário.
- **Hopper**: desmontador e depurador interativo.
- **`objdump`, `strings`** e utilitários equivalentes de inspeção de binário de baixo nível.
- **Debuggers**: ferramentas de depuração em tempo de execução.
- **Profilers**: ferramentas de análise de desempenho.
- **Network inspection tools**: ferramentas de captura e análise de tráfego de rede.
- **Source-code analysis tools**: ferramentas de análise estática ou navegação de código-fonte.
- **Black-box testing**: metodologias e ferramentas de teste comportamental sem acesso a código-fonte.
- **Scientific benchmarking**: ferramentas e metodologias de medição de desempenho e precisão científica.

Qualquer ferramenta não listada explicitamente, mas que sirva a um propósito equivalente a uma das categorias acima, está sujeita à mesma política.

## Ordem de prioridade de método

Esta é a regra central desta política, e governa a escolha de ferramenta para qualquer investigação:

1. **Se código-fonte estiver legalmente disponível para leitura**, a análise de código-fonte (source analysis) é o método prioritário. Produz evidência `SOURCE_VERIFIED` (ver `EVIDENCE_MODEL.md`), a classe mais direta e confiável disponível.
2. **Se código-fonte não estiver disponível**, a investigação considera análise comportamental (black-box) — observação de entradas e saídas, documentação, benchmarking — como o próximo método.
3. **Análise de binário é usada apenas quando necessária e permitida.** "Necessária" significa que a pergunta de pesquisa não pode ser respondida com confiança suficiente por análise comportamental isolada. "Permitida" significa que a checagem de `LEGAL_AND_ETHICAL_BOUNDARIES.md` já foi concluída e não identificou impedimento.

Esta ordem não é uma preferência estética — ela reflete diretamente o modelo de evidência (`EVIDENCE_MODEL.md`): métodos mais diretos produzem evidência mais forte com menor risco legal e menor custo de interpretação.

## REA e ferramentas equivalentes: papel e limite

**REA é uma ferramenta de investigação, não uma fonte de verdade.** O mesmo vale para Ghidra, Hopper e qualquer ferramenta de engenharia reversa de binário. A saída dessas ferramentas (desmontagem, decompilação heurística, grafos de chamada reconstruídos) é sempre tratada como evidência a ser classificada (tipicamente `OBSERVED` ou `INFERRED`, nunca `SOURCE_VERIFIED` — ver `EVIDENCE_MODEL.md`, regra 2), nunca como um substituto direto para código-fonte legítimo, e nunca como insumo direto de implementação (ver `CLEAN_ROOM_POLICY.md`).

## Processo de aprovação de uma ferramenta

Nenhuma ferramenta desta política pode ser instalada ou usada em uma investigação real antes de receber um registro em `tooling/README.md` contendo, no mínimo:

- versão;
- origem (distribuidor, projeto, fornecedor);
- licença;
- finalidade pretendida dentro desta governança;
- limitações conhecidas;
- riscos (legais, de segurança, ou de qualidade de evidência);
- ambiente suportado;
- status dentro da governança (proposta, em avaliação, aprovada para uso geral, aprovada apenas para um escopo específico, rejeitada).

A criação desta política, por si só, não aprova nenhuma ferramenta. A aprovação de cada ferramenta é uma decisão subsequente e específica.

## Relação com outras políticas

- A escolha de ferramenta para um motor científico específico segue também `ENGINE_RESEARCH_POLICY.md`.
- A escolha de ferramenta para um software concorrente segue também `COMPETITOR_RESEARCH_POLICY.md`.
- Toda saída de ferramenta, de qualquer categoria, é registrada como evidência individual via `templates/EVIDENCE_RECORD_TEMPLATE.md`, com o campo `Tool` preenchido e a `Classification` apropriada.
