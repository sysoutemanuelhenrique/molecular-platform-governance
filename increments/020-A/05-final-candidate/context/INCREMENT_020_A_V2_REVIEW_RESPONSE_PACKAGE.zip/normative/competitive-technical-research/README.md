# Competitive & Technical Research — Índice

## Propósito

Esta área estabelece a governança formal para investigações técnicas conduzidas em apoio ao desenvolvimento independente da Turing Bohr Molecular Platform. Ela existe porque a plataforma, ao crescer, inevitavelmente precisará entender:

- como motores científicos (open source, acadêmicos, comerciais ou proprietários) se comportam, quais entradas aceitam e quais saídas produzem;
- como formatos de arquivo e protocolos de interoperabilidade científica são estruturados;
- como softwares concorrentes organizam workflows, expõem parâmetros e dividem responsabilidades entre camadas;
- quais responsabilidades científicas pertencem a um motor externo e quais devem pertencer ao Domain/Application Core da própria plataforma.

Nenhuma investigação sob esta governança está, no momento da criação desta área, aprovada, em andamento, ou agendada. Esta é a estrutura que qualquer investigação futura deverá seguir — não um registro de investigações já realizadas.

## Relação com a Turing Bohr Molecular Platform

Esta área não é parte do runtime da aplicação. Nenhum código aqui produzido é importado, executado ou referenciado por `molecular-platform`. Ela é **governança de pesquisa**: um conjunto de processos, fronteiras e modelos de evidência que disciplinam como o conhecimento técnico externo é observado, classificado e eventualmente traduzido em decisões arquiteturais independentes.

A saída possível — nunca obrigatória — de uma investigação conduzida sob esta governança é uma **especificação independente**, do mesmo tipo e rigor que já existe em `increments/`. Essa especificação, se e quando produzida, segue o processo normal de incremento da plataforma (rascunho, revisão adversarial, congelamento, implementação em checkpoints) — ela não entra em produção automaticamente, e esta área de pesquisa não tem autoridade para autorizar implementação.

## Investigação científica, interoperabilidade e cópia — a distinção central

Esta governança distingue três atividades que são frequentemente confundidas:

1. **Investigação científica / técnica**: observar comportamento, comparar entradas e saídas, entender um método ou algoritmo científico publicado, medir desempenho, identificar como um formato é estruturado. Isto é sempre o objetivo desta área.
2. **Interoperabilidade**: entender um formato, protocolo ou convenção suficientemente para ler, escrever ou traduzir dados de forma compatível, sem reproduzir a implementação interna de quem originou o formato.
3. **Cópia**: reproduzir a expressão específica de código-fonte, binário ou documentação de terceiros. Isto nunca é o objetivo desta área, e `CLEAN_ROOM_POLICY.md` formaliza a separação de processo que impede que isso aconteça mesmo acidentalmente.

A cadeia de valor que esta governança protege é:

```
Observed Evidence
    ↓
Technical Interpretation
    ↓
Scientific / Architectural Understanding
    ↓
Independent Specification
    ↓
Independent Turing Bohr Implementation
```

E nunca:

```
Decompiled proprietary code
    ↓
Copy
    ↓
Turing Bohr source code
```

## Software open source vs. proprietário

A governança (`LEGAL_AND_ETHICAL_BOUNDARIES.md`, `TOOLING_POLICY.md`) trata esses dois casos de forma deliberadamente diferente:

- **Open source**: quando uma licença permite leitura e estudo do código-fonte, a análise de código-fonte é o método preferencial — é mais direta, mais confiável e produz evidência da classe mais forte (`SOURCE_VERIFIED`, ver `EVIDENCE_MODEL.md`).
- **Proprietário**: quando o código-fonte não está disponível ou a licença não permite sua leitura, a investigação se apoia em análise comportamental (black-box), documentação pública, e — apenas quando juridicamente permitido e tecnicamente necessário — análise de binário. Em nenhum caso o código-fonte proprietário decompilado alimenta diretamente a implementação da Turing Bohr; ele só pode alimentar uma camada de interpretação e especificação independente, nunca a escrita de código (ver `CLEAN_ROOM_POLICY.md`).

## Papel futuro de REA e ferramentas de engenharia reversa

Ferramentas como REA (Reverse Engineer Anything), Ghidra, Hopper e equivalentes **não estão instaladas, configuradas ou aprovadas para uso neste momento**. `TOOLING_POLICY.md` estabelece o registro formal que qualquer ferramenta dessa natureza precisará preencher antes de ser usada em uma investigação real, e `tooling/README.md` é o local onde esse registro, quando existir, será mantido. A existência desta governança não constitui autorização para instalar ou usar nenhuma dessas ferramentas — cada uso futuro exigirá uma decisão própria, documentada, com escopo e justificativa específicos.

## Relação com `MolecularGovernance`

Esta área é uma pasta de primeiro nível dentro de `MolecularGovernance`, no mesmo plano hierárquico que `increments/`, `strategy/` e `cross-session-audits/`. Ela não altera, substitui ou depende de nenhum documento já existente nessas pastas. Uma investigação que produza uma especificação candidata pode, no futuro, originar um novo incremento em `increments/` — mas essa ponte é uma decisão separada, tomada no momento em que uma especificação candidata realmente existir.

## Estrutura

```
competitive-technical-research/
├── README.md                              (este documento)
├── GOVERNANCE.md                           processo formal e estados de uma investigação
├── LEGAL_AND_ETHICAL_BOUNDARIES.md         o que é e o que não é permitido
├── EVIDENCE_MODEL.md                       taxonomia obrigatória de classes de evidência
├── RESEARCH_WORKFLOW.md                    fases detalhadas e stop gates
├── TOOLING_POLICY.md                       política de ferramentas, incluindo REA/Ghidra/Hopper
├── ENGINE_RESEARCH_POLICY.md               política específica para motores científicos
├── COMPETITOR_RESEARCH_POLICY.md           política específica para softwares concorrentes
├── CLEAN_ROOM_POLICY.md                    separação evidência → especificação → implementação
├── investigations/                         uma pasta por investigação real (nenhuma ainda existe)
│   └── README.md
├── templates/                              modelos obrigatórios para toda investigação
│   ├── INVESTIGATION_PLAN_TEMPLATE.md
│   ├── INVESTIGATION_REPORT_TEMPLATE.md
│   ├── ENGINE_COMPARISON_TEMPLATE.md
│   └── EVIDENCE_RECORD_TEMPLATE.md
└── tooling/                                registro de ferramentas (nenhuma aprovada ainda)
    └── README.md
```

## O que este documento não faz

Este documento, e a criação desta área como um todo, não autoriza nenhuma investigação específica, não aprova nenhuma ferramenta, não define nenhum alvo de pesquisa, e não cria nenhum compromisso de que qualquer investigação será de fato realizada. Ele estabelece apenas a estrutura que qualquer investigação futura deverá seguir.
