# Decisão de escopo — Conformer Generation e Geometry Optimization

**Projeto:** Turing Bohr Molecular Platform
**Natureza:** decisão arquitetural de roadmap. Não é pesquisa nova, não é especificação técnica, não altera o Incremento 018 nem sua candidata final.
**Data:** 2026-09-29
**Baseline no momento do registro:** `main` em `4aaeed12515ed14580b16240dd4d253a11c4d68e`

---

## 1. Decisão central

A Turing Bohr tratará como operações científicas independentes:

1. conformer generation;
2. geometry optimization;
3. seleção/clustering de conformeros.

Nenhuma delas deve ser escondida dentro de um comando genérico e opaco chamado apenas "optimize ligand".

## 2. Definições

### Conformer generation

Operação de amostragem que:

- recebe um `MolecularState`;
- produz uma ou mais geometrias tridimensionais candidatas;
- preserva a identidade química do `MolecularState`;
- não garante mínimo global;
- pode usar RDKit ETKDGv3 ou outros motores futuros.

Fluxo: `MolecularState` → `ConformerGenerationPolicy` → múltiplos `Conformer`s candidatos.

### Geometry optimization

Operação que:

- recebe um `Conformer` específico;
- ajusta suas coordenadas segundo um modelo energético declarado;
- produz um novo `Conformer` derivado;
- procura tipicamente um mínimo local;
- não garante mínimo global;
- nunca sobrescreve o conformero de entrada.

Fluxo: `Conformer` de entrada → `GeometryOptimizationPolicy` → novo `Conformer` otimizado.

### Seleção/clustering

Operação posterior que:

- compara conformeros metodologicamente compatíveis;
- pode aplicar RMSD, energia, diversidade ou outros critérios;
- determina quais conformeros seguem para docking;
- não pertence silenciosamente nem à geração nem à otimização.

## 3. Fronteira `MolecularState` × `Conformer`

Se mudar protonação, carga formal, tautomeria, conectividade, ordem de ligação ou configuração estereoquímica definida, o resultado pertence a outro `MolecularState`. Se mudar apenas a geometria tridimensional, preservando a identidade química, o resultado é outro `Conformer` do mesmo `MolecularState`. Uma engine de otimização não pode alterar silenciosamente a identidade química e continuar registrando o resultado como simples conformero.

## 4. Controle explícito do cientista

Durante a preparação do ligante, a plataforma deverá oferecer explicitamente: usar coordenadas existentes sem alteração; gerar novos conformeros; otimizar a geometria existente; gerar e otimizar; preservar a geometria original e gerar alternativas.

O cientista escolherá: método de geração; motor; número de conformeros; seed; pruning RMSD; método de otimização; número máximo de iterações; critério de convergência; restrições; modelo de solvente, quando aplicável; fallbacks autorizados; critérios posteriores de seleção.

## 5. Proibição de fallback silencioso

Exemplo proibido: MMFF94s falhou → plataforma utiliza UFF automaticamente.

A plataforma pode: interromper; recomendar alternativa; executar fallback previamente autorizado pelo cientista. `Requested`, `resolved`, `executed` e `observed` devem permanecer separados.

## 6. Presets

A plataforma poderá oferecer presets, desde que: todo parâmetro seja visível; o cientista confirme antes da execução; o preset tenha versão; alterações sejam registradas; nenhum preset seja tratado como decisão científica universal.

Exemplos futuros: preparação rápida; diversidade conformacional; molécula incomum; configuração personalizada.

## 7. Proveniência

`Conformer` permanece mínimo: `schema_version`, `id`, `state_id`, `representation`.

Não adicionar diretamente ao `Conformer`: energia, engine, seed, método, convergência, iterações, solvente, restrições. Essas informações pertencem a registros relacionados: `ConformerGenerationRecord`, `GeometryOptimizationRecord`, futuro `ConformerSelectionRecord`, `ExecutionAttempt` correspondente.

## 8. Energia

Energias só podem ser comparadas quando houver compatibilidade metodológica: mesmo `MolecularState`; mesmo método ou campo de força; mesma parametrização; mesmas unidades; mesmas condições ambientais; mesmas restrições; mesmo significado de energia.

A plataforma nunca deve declarar automaticamente "menor energia encontrada = mínimo global". Texto correto: "menor energia entre os conformeros avaliados sob este método, estes parâmetros e estas condições".

## 9. Falha e convergência

- conformero gerado não é automaticamente conformero otimizado;
- execução sem convergência não pode ser apresentada como sucesso de otimização;
- coordenadas não convergidas podem ser preservadas como artefato diagnóstico;
- falhas devem permanecer auditáveis;
- qualquer fallback usado deve ser explicitamente registrado.

## 10. Pipeline futuro

```text
MolecularState
  → conformer generation opcional
  → conformeros candidatos
  → geometry optimization opcional
  → conformeros otimizados
  → deduplicação/clustering
  → seleção explícita
  → docking
```

Cada etapa pode ser omitida por decisão explícita do cientista.

## 11. Roadmap revisado

- Incremento 018 — RAW/PubChem → Scientific Model;
- Incremento 019 — `ExperimentalConditions` declaradas pelo cientista;
- Incremento 020 — protonação e microestados;
- Incremento 021 — Conformer Generation Foundation;
- Incremento 022 — Geometry Optimization;
- Incremento 023 — aquisição de receptor/RCSB;
- Incremento 024 — preparação de receptor;
- Incremento 025 — binding site/grid;
- Incremento 026 — `DockingRunSpec`;
- Incremento 027 — primeiro motor de docking;
- Incremento 028 — `Pose`;
- Incremento 029 — RMSD/redocking/validação;
- Incremento 030+ — workflow integrado, GUI e expansões posteriores.

Essa numeração é roadmap provisório, não contrato congelado.

## 12. Princípio do projeto

A plataforma pode recomendar métodos e protocolos, mas o cientista determina explicitamente: se haverá geração conformacional; se haverá otimização geométrica; quais métodos serão utilizados; quais fallbacks são permitidos; quais conformeros serão selecionados.

Princípio: **automação supervisionada, nunca decisão científica silenciosa.**

---

## STATUS FINAL

```text
SCOPE DECISION RECORDED: YES
CONFORMER GENERATION SEPARATED: YES
GEOMETRY OPTIMIZATION SEPARATED: YES
SCIENTIST CONTROL PRESERVED: YES
SILENT FALLBACK PROHIBITED: YES
INCREMENT 018 MODIFIED: NO
REPOSITORY MODIFIED: NO
IMPLEMENTATION AUTHORIZED: NO
```
