# Incremento 020-A — Proposta arquitetural revisada

## Caracterização de MolecularState e representação 2D

Autor: Codex, arquiteto. Revisão documental: 20/10/2026 UTC. Versão: revisão arquitetural 2, posterior aos dois pareceres da proposta preliminar de 19/10/2026.

**Finalidade:** submeter decisões concretas a confronto independente. Este documento não é especificação final, não congela contratos, não autoriza implementação e não substitui os pareceres anteriores.

## 1. Decisão recomendada e resultado esperado

**DECISÃO PROPOSTA A-01:** caracterizar um `MolecularState` já registrado, por consulta sob demanda, retornando dez valores tipados, proveniência da observação e, se solicitado, SVG 2D estático. Não criar estado, entidade, conformero, transformação, registry, cache persistente ou attempt de tautomerização.

O ganho para a apresentação acadêmica será uma ficha compreensível da estrutura específica: composição, massas, carga, tamanho, HBD/HBA, flexibilidade topológica, TPSA e cLogP, com uma figura. Nenhum desses resultados será apresentado como medição experimental, protonação predominante, atividade, toxicidade ou preparação para docking.

A proposta escolhe a alternativa sem histórico interno e registra seu limite: **reprodutibilidade potencial do resultado capturado, sem registro durável automático da consulta na plataforma**. Um usuário pode guardar a saída; isso não se torna um registro científico da plataforma por renomeação.

## 2. Papéis, sequência e nomenclatura

O arquiteto lê o repositório, pesquisa APIs, propõe o modelo e reconcilia os pareceres. Revisores confrontam a proposta e evidências. Claude implementador somente implementa contrato aprovado ou executa uma investigação local delimitada quando necessária. O responsável pelo projeto decide a passagem dos gates.

**DECISÃO PROPOSTA A-02:** manter os nomes de trabalho pedidos pelo responsável: **020-A**, caracterização e figura; **020-B**, capacidades de esforço médio, a estudar separadamente; **020-C**, comandos guiados e apresentação. São novos recortes pós-020, não checkpoints retroativos nem alteração do contrato congelado do 020. A aceitação desta convenção deve constar da decisão que acompanhar a revisão.

[DOCUMENTED, confiança alta] O roadmap de 29/09 em `strategy/LIGAND_CONFORMER_GENERATION_AND_GEOMETRY_OPTIMIZATION_SCOPE_DECISION.md`, §11, declara a própria numeração provisória. O contrato final do 020, §§7/34, já reserva a interface da futura materialização de receptor ao **021**. Portanto não se deve deslocar o 021 por inferência de um roadmap antigo nem alegar que 020-A está implementado dentro do 020. Os originais são preservados.

## 3. Base factual, identidades e alcance da leitura

[OBSERVED, confiança alta] `main` remota e clone de referência em `08b797e0985e123ffd4d7ca7e5a5e8f040e63851`, reconfirmados nesta sessão por `git ls-remote`, `rev-parse`, working tree limpa e `git diff --check` sem saída. Nenhuma alteração no repositório de código foi feita.

[OBSERVED, confiança alta] O arquivo recebido `MolecularGovernance.zip` tem 1.826.687 bytes e SHA-256 `36885b10b6d26c3264e7999179b289e3690fa137d48a324cc76987313474d28b`: 258 entradas, 154 arquivos regulares. Foi inspecionado e extraído fora do clone sem alterar seus bytes. A especificação final 020 confere com a identidade anteriormente registrada: **1.975 linhas, 210.880 bytes, SHA-256 `cf6cb534f9267d51e718052c7b36a2293c522bc566c99cf3bb2ef5909385a0a6`**. O relatório CP4 confere: **365 linhas, 25.318 bytes, SHA-256 `69ece589ca25ddaa1e3286b33dd1a0e76e5245043cf8f633559383389e918785`**.

O pacote acompanhante contém cópias byte-idênticas dos contratos finais 016–020, CP4, parecer cumulativo 020 e políticas de pesquisa pertinentes. O manifesto traz as identidades calculadas de cada arquivo. Acesso ao documento integral e sua identidade não significam leitura integral de toda a coleção: foram lidas integralmente as políticas de pesquisa enumeradas na rastreabilidade, os dois pareceres 020-A e os relatórios CP4/cumulativo; nos cinco contratos finais, a leitura foi dirigida às seções relevantes também enumeradas ali. Não se alega auditoria cumulativa nova do 020.

[UNKNOWN, confiança alta quanto ao limite] O ZIP não contém todos os documentos centrais anteriores ao 016. Não se afirma conformidade com textos não recebidos nem se inventa uma proibição universal por sua ausência. O bloqueio anterior por não ter acesso aos originais pertinentes foi superado para esta proposta dentro do corpus recebido; qualquer exigência adicional deverá citar a norma e a cláusula aplicável. Isso não é aprovação normativa independente da nova solução.

## 4. Fatos do código que condicionam o desenho

Todas as referências abaixo são relativas ao SHA da §3. Classificação: **SOURCE_VERIFIED**, confiança alta. A rastreabilidade aponta os símbolos e testes; os testes foram lidos, não reexecutados nesta etapa.

| Fato | Evidência primária | Consequência proposta |
|---|---|---|
| MolecularState é mínimo, frozen, extra=forbid; representação declara path/format/checksum | `scientific.py`; `test_scientific.py` | Resultado separado, sem campos de descritores no estado |
| Registrar representação não equivale a validar elegibilidade química para qualquer operação | `scientific_registry.py::register_state`; testes de registro | Caracterização valida seu próprio perfil |
| Enumeração recebe SDF e publica estados filhos em SMILES, com newline final | `application.py::enumerate_state_tautomers`; testes de integração | Aceitar SDF e SMILES já existentes |
| ExecutionAttempt tem política de tautomerização e operation_type de transformação | `execution.py`; contrato 016 §§10–11 | Não usar esse schema para uma consulta |
| O adaptador permitido para imports RDKit é `rdkit_tautomer.py` | Docstring/imports do adaptador; contrato 016 §6 | Ampliação aditiva no mesmo módulo, sem renomeação |
| Snapshot RAW seguro é vinculado a LigandInput e `inputs/ligands/<input_id>` | `atomic.py::create_verified_raw_snapshot` | Não usar ID falso, não converter sua raiz em argumento genérico |
| `load_state` lê YAML por caminho; não implementa o protocolo completo de leitura verificada | `scientific_registry.py::load_state` | A nova operação precisa cuidar também do seu registro de entrada |
| Artefato de estado publicado fica em `scientific/artifacts/states/<state_id>/<filename>` | `scientific_registry.py::register_state` | Raiz autorizada específica e verificável |
| Experimento CLI é ID lógico, não caminho arbitrário | `context.py::resolve_experiment`; `test_context.py` | Usar `<experiment_id>` na CLI e na documentação |

[DOCUMENTED, confiança alta] O 020, §§24–27, persiste inspeções que são referências estáveis para seleção e resolução. O §26 não usa ExecutionAttempt para inspeção. O §32.1 distingue explicitamente sua leitura do RAW da solução do 018. Esses são contratos específicos, não prova de que todo cálculo futuro tenha de persistir ou usar o mesmo protocolo.

[INFERRED, confiança média-alta] Não foi identificada nas seções examinadas uma obrigação de persistir toda consulta derivada. A alternativa A é arquiteturalmente defensável, mas a sua autorização é uma decisão nova submetida ao revisor; ausência de uma regra encontrada não equivale a autorização já congelada.

## 5. Escopo e limite científico

**DECISÃO PROPOSTA A-03:** uma estrutura por chamada, format declarado normalizado por `strip().lower()` pertencente a `{sdf, smiles}`, exatamente uma molécula válida, não vazia, com um componente conectado. Rejeitar átomos dummy/query, ligações query e estruturas poliméricas/SGroups e estereogrupos enhanced (AND/OR) no perfil inicial; não interpretar uma unidade de repetição como molécula completamente definida. O conjunto molecular aceito não se confunde com todos os casos que RDKit consegue carregar.

Sais representados por componentes desconectados serão recusados, sem escolher o maior fragmento nem recomendar automaticamente substituir sal por base/ácido livre como se fossem o mesmo estado. Mensagem proposta: “This characterization profile requires one connected molecular component; no component was selected or removed.” O cientista decide qual representação estudar por operações autorizadas separadamente.

Condições experimentais não serão carregadas nem inferidas. O resultado declara `experimental_conditions_consumption="not-consumed"`. cLogP não usa o pH da declaração e não será rotulado logD. [DOCUMENTED] Essa separação atende ao princípio do 019 §21 sem alterar ExecutionAttempt ou criar um modelo universal de condições.

Exclusões: pKa, protonação, neutralização, fragment parent, dessalinização, geração 3D, MMFF/UFF, cargas parciais, docking, preparação de receptor, fingerprints, grupos funcionais, comparação de tautômeros, filtros farmacológicos, GUI, comandos interativos e alias `tbmp`.

## 6. Dez valores: perfil proposto

**DECISÃO PROPOSTA A-04:** perfil `molecular-characterization-v1`, ainda sujeito à revisão. `rdMolDescriptors` é o namespace completo de todas as funções `Calc*` desta tabela.

| Campo | Chamada explícita | Semântica e unidade |
|---|---|---|
| formula | `rdMolDescriptors.CalcMolFormula(mol, separateIsotopes=True, abbreviateHIsotopes=False)` | Fórmula calculada com distinção isotópica; H isotópico sem abreviação D/T |
| molar_mass_g_mol | `Descriptors.MolWt(mol)` | Massa molar calculada pelo RDKit; g/mol; respeita isótopos explicitamente marcados |
| exact_mass_da | `rdMolDescriptors.CalcExactMolWt(mol, onlyHeavy=False)` | Massa exata calculada da estrutura; Da; inclui H |
| formal_charge_e | `Chem.GetFormalCharge(mol)` | Soma das cargas formais, em unidades da carga elementar |
| heavy_atom_count | `mol.GetNumHeavyAtoms()` | Contagem de átomos não H |
| hbd_count | `rdMolDescriptors.CalcNumHBD(mol)` | Convenção HBD implementada no RDKit, também usada por Lipinski.NumHDonors no pin |
| hba_count | `rdMolDescriptors.CalcNumHBA(mol)` | Convenção HBA implementada no RDKit, também usada por Lipinski.NumHAcceptors no pin |
| rotatable_bond_count | `rdMolDescriptors.CalcNumRotatableBonds(mol, rdMolDescriptors.NumRotatableBondsOptions.Strict)` | Contagem sob Strict explícito, sem depender de Default |
| tpsa_a2 | `rdMolDescriptors.CalcTPSA(mol, force=True, includeSandP=False)` | Å²; sem contribuição adicional S/P |
| clogp_wildman_crippen | `rdMolDescriptors.CalcCrippenDescriptors(mol, includeHs=True, force=True)[0]` | Estimativa Wildman–Crippen, adimensional |

Os valores de máquina permanecem sem arredondamento de apresentação; números reais precisam ser finitos, contagens inteiras e não negativas. A apresentação text pode usar três casas para massas, duas para TPSA e quatro para cLogP, sem alterar JSON. cLogP negativo não é erro. Unidades são dados fixos do perfil.

Não confundir massa molar com massa exata, massa exata com m/z de íon/aduto experimental ou abundância isotópica experimental, carga formal com carga parcial, HBD/HBA com número de ligações N–H/O–H ou cLogP com solubilidade/logD. Descritores pertencem ao estado analisado e podem variar entre tautômeros/protômeros. A ficha não classifica moléculas como seguras, ativas ou biodisponíveis.

[EXPERIMENTALLY_VERIFIED, confiança alta no ambiente observado] `includeSandP=False` coincide com o default do binding instalado. `strictParsing=True` também coincide com o default; **removeHs=False** diverge do default True. Especificar valores continua sendo uma decisão de perfil mesmo quando coincide com o default. Não se afirma que Strict é um desvio do Default. Sondas S/P anteriores demonstram que a opção alternativa muda resultados e justificam teste discriminante.

[SOURCE_VERIFIED, confiança alta] No `Lipinski.py` instalado, `NumHDonors` chama `CalcNumHBD` e `NumHAcceptors` chama `CalcNumHBA`. [EXPERIMENTALLY_VERIFIED, confiança alta] Para metilamina, amônia e etilenodiamina, HBD foi 1, 1 e 2 em ambas as APIs; `NHOHCount` foi 2, 3 e 4. A recomendação do parecer R2 de documentar HBD como contagem de ligações é rejeitada por evidência contrária. O namespace correto do cálculo combinado Crippen é `rdMolDescriptors`, não uma função inexistente `Crippen.CalcCrippenDescriptors`.

## 7. Modelo e fronteiras propostos

**DECISÃO PROPOSTA A-05:** três DTOs imutáveis e estritos, sem objeto RDKit atravessando a fronteira do adaptador:

- `MolecularCharacterizationValues`: os dez campos fechados da §6.
- `MolecularCharacterizationProvenance`: state_id, entity_id declarados no registro validado, versão do schema do estado, SHA-256 observado dos bytes do registro YAML, referência relativa da representação, formato declarado e formato resolvido, SHA-256 esperado e observado da representação, tamanho observado, engine_name/version, versão da aplicação quando disponível, perfil de parsing/cálculo e opções efetivas, condições explicitamente não consumidas.
- `MolecularCharacterizationResult`: versão própria de resposta, values, provenance, avisos tipados, metadados de desenho e SVG opcional. Sem ID persistente e sem timestamp obrigatório que simule identidade química.

**DECISÃO PROPOSTA A-06:** serviço `characterize_state(project_dir, *, input_state_id, include_svg=False)` coordena uma leitura verificada e uma chamada de caracterização. Adaptador recebe os bytes e o formato explícito; retorna somente dados neutros. Engine version é observada no adaptador sem instanciar enumerador nem consumir parâmetros de tautomerização. O pin continua `rdkit==2026.3.6`, reportado pelo motor como `2026.03.6`.

Não copiar CID ou campos externos para atributos químicos do estado. Se a origem PubChem existir no lineage atual, continua nos seus registros próprios; não inferir origem por nome do arquivo. O hash do registro observado não é uma assinatura de autenticidade nem prova de todo o lineage.

O resultado declara todos os parâmetros fixos relevantes, em vez de guardar apenas um nome de preset cujo significado pudesse mudar. Se SVG for solicitado, inclui perfil de desenho, dimensões e identificação/hash da fonte tipográfica efetivamente usada. Saída SVG isolada contém vínculo controlado a state_id, checksum da representação, versão do motor e perfil em atributos `data-*` da raiz, sem caminho absoluto.

## 8. Leitura verificada: decisão concreta para M1

**DECISÃO PROPOSTA A-07:** acrescentar uma capacidade específica, aditiva e somente de leitura para esta operação. Não chamar `create_verified_raw_snapshot` com LigandInput falso; não mudar sua raiz autorizada; não transformar `resolve()+read_bytes()` numa alegação de resistência completa a substituição.

Duas entradas pequenas, com nomes de trabalho, em `atomic.py`, podem compartilhar seus próprios detalhes privados e os primitivos de identidade já existentes sem alterar o comportamento das funções atuais:

| Entrada específica | Arquivo permitido | Retorno neutro |
|---|---|---|
| `read_verified_state_metadata(project_dir, state_id=...)` | `scientific/states/<state_id>.yaml` | bytes imutáveis, SHA-256 observado, tamanho |
| `read_verified_state_representation(project_dir, state_id=..., relative_path=..., expected_checksum=...)` | `scientific/artifacts/states/<state_id>/<leaf>` | bytes imutáveis, SHA-256 observado, tamanho |

Não haverá parâmetro público para escolher outra raiz arbitrária. A primeira entrada existe porque apenas chamar `load_state()` e depois proteger o SDF deixaria sem essa garantia a leitura do YAML que determina o caminho e o checksum. O `load_state()` legado permanece inalterado; a nova operação faz `yaml.safe_load` e `MolecularState.model_validate` sobre o buffer verificado. Exige id carregado igual ao solicitado e valida entity_id segundo os validadores atuais. Não precisa abrir um registro de entidade só para duplicar seu nome na ficha.

Fluxo proposto, com garantias limitadas explicitamente:

1. Validar state_id antes de I/O. Verificar suporte Windows/volume local NTFS antes de abrir registro ou representação. Reutilizar a detecção existente quando adequada, sem alegar validação em plataforma diferente. O gate novo deve conferir também a versão Windows exigida; testar apenas sys.platform=win32 não satisfaz essa restrição.
2. Construir o caminho permitido por componentes. No path da representação exigir exatamente o prefixo do estado e um único nome final; rejeitar absoluto POSIX, drive, drive-relative, UNC, barras invertidas, segmentos vazios/`.`/`..`, NUL, ADS/dois-pontos e nomes inválidos/reservados do Windows. Comparar confinamento por componentes, não por prefixo textual. Não adivinhar arquivo pela extensão.
3. Inspecionar o projeto e a cadeia de diretórios/arquivo por `lstat`, rejeitando symlink, junction ou qualquer reparse point. Exigir diretórios nos ancestrais e arquivo regular no final. Ausência dos atributos necessários falha de forma fechada. Capturar identidade `st_dev/st_ino` e tamanho, conforme as limitações declaradas do protocolo existente.
4. Revalidar a cadeia imediatamente antes de abrir. Abrir um único handle por arquivo; conferir `fstat` contra a identidade capturada e revalidar ancestrais depois da abertura. Ler em blocos por esse handle, acumulando bytes e SHA-256; aplicar o limite durante a leitura, não apenas ao tamanho anunciado.
5. Após a leitura, conferir tamanho efetivo, identidade do arquivo e cadeia novamente. Para representação, exigir checksum hex64 válido e igualdade com o checksum declarado no registro capturado. Qualquer divergência encerra a chamada antes de RDKit.
6. Fechar o handle em `finally`/context manager. Usar somente os bytes desse buffer para parsing; não reabrir a representação no adaptador. Não criar snapshot em disco ou diretório temporário neste recorte.
7. Resolver o registro YAML por esse primeiro buffer e ler a representação autorizada por ele; registrar ambos os hashes observados. Uma consulta usa o registro capturado, não promete uma visão transacional de todos os arquivos no mesmo instante.

**Limite de garantia:** não há lock distribuído, proteção contra escritor com controle administrativo nem prova de ausência de toda corrida entre verificações por caminho. Uma troca transitória de ancestral ou modificação concorrente pode exceder o que verificações antes/depois detectam. Hard link não é automaticamente imutabilidade nem escape demonstrado; checksum é indispensável. Não chamar o protocolo de race-free. A confiança local e os riscos residuais devem ser registrados como na solução do 018, sem extrapolar a sua garantia.

**DECISÃO PROPOSTA A-08:** suportar inicialmente o serviço somente no mesmo perfil explicitamente validado de Windows 11/NTFS local; outros ambientes falham antes da leitura. Isso é uma escolha nova e conservadora do 020-A, não consequência universal imposta pelo 018 ou prova de que o serviço novo já foi validado. O adaptador puro pode ser testado em Linux. A matriz Windows terá de provar o comportamento dos dois leitores antes de aprovação de implementação.

Limites técnicos candidatos para tornar a leitura e a saída limitadas: YAML 1 MiB, representação 10 MiB, molécula com até 4.096 átomos totais e 8.192 ligações, SVG UTF-8 até 16 MiB. São limites operacionais propostos, não definição de molécula válida nem benchmark de segurança/tempo. Devem ter erros claros e testes nas fronteiras. A contagem de átomos ocorre após parsing; portanto o limite não promete limitar sozinho CPU ou alocação de parsing nativo. Se estes valores forem contestados, alterar explicitamente o perfil antes do rascunho, sem derivá-los falsamente dos cinco exemplos pequenos.

## 9. Parsing SDF e SMILES: decisão concreta para M3

**DECISÃO PROPOSTA A-09:** o checksum sempre cobre o arquivo integral observado. Validar a gramática sem reescrever seus bytes. Não tentar outro formato após uma falha e não trocar motor silenciosamente.

| Tema | Perfil SDF | Perfil SMILES |
|---|---|---|
| Codificação | UTF-8 estrito, sem BOM nem NUL; campos de dados Unicode podem existir, mas não viram legenda/proveniência química | ASCII estrito, sem BOM, NUL ou controles |
| Linhas | LF ou CRLF; exatamente um registro físico, V2000 ou V3000 | Exatamente um token, sem whitespace interno, inicial ou final |
| Fim | Exatamente uma linha `$$$$` como última linha física, com EOF, LF ou CRLF; nenhum conteúdo posterior | Sem terminador, ou exatamente um LF ou CRLF final; CR isolado e linhas extras rejeitados |
| Multirregistro | Rejeitar dois delimitadores, inclusive registro inválido mais válido; não filtrar None | Rejeitar múltiplas linhas, nomes, colunas e CXSMILES |
| API | `ForwardSDMolSupplier(BytesIO(bytes), sanitize=True, removeHs=False, strictParsing=True)` | `SmilesParserParams`: sanitize=True, removeHs=False, parseName=False, allowCXSMILES=False |
| Validação química | Exatamente um retorno não None, depois perfil da §5 | Mol não None, depois perfil da §5 |

Contar delimitadores por **linha exata**, nunca por ocorrência da substring `$$$$` em uma propriedade. `strictParsing=True` sozinho não prova a gramática externa; ambos os controles são necessários. Conteúdo após o terminador, inclusive espaços em uma nova linha, é recusado neste perfil para não depender da tolerância do supplier. Não apagar esse conteúdo e aceitar silenciosamente. Falta de terminador também é recusa explícita, mesmo que algum leitor legado tolere MOL/SDF incompleto.

[EXPERIMENTALLY_VERIFIED] As cinco entradas reais disponíveis atendem a esse perfil. Um ensaio inicial mostrou que o supplier pode produzir registro inválido diante de conteúdo whitespace extra; isso motivou a decisão explícita de recusar esse caso, em vez de documentar uma tolerância não comprovada. A política restritiva aplica-se à caracterização nova, não reescreve formatos antigos nem altera a aquisição/promoção existente.

Sanitização RDKit é percepção/interpretação química conforme perfil; não se afirma ausência de qualquer processamento interno da biblioteca. Não executar como pré-processamento separado Cleanup, Uncharger, Reionizer, normalização de tautômero, dessalinização, AddHs ou RemoveHs. O parâmetro includeHs do cálculo Crippen é parte do método do descritor, não autorização para publicar outro estado. Preservar bytes originais e estrutura de entrada do adaptador enquanto calcula/desenha sobre objetos de trabalho.

O teste de elegibilidade deve impedir que query/dummy/SGroup seja silenciosamente apresentado como molécula concreta. Isótopos, cargas e estereoquímica especificada são preservados; não atribuir um novo estereoisômero a centro indefinido. A interpretação estereoquímica pelo parser deve ser rastreada às opções e bytes fornecidos, não confundida com enumeração estereoquímica ou comprovação experimental.

## 10. SVG: decisão concreta para M4

**DECISÃO PROPOSTA A-10:** SVG estático, opcional, 600×400, produzido por RDKit no adaptador a partir de cópia. Não ler/importar SVG externo, não gerar HTML, não abrir browser e não criar PNG neste recorte.

Perfil `molecular-depiction-v1`, candidato:

- Coordenadas: `Compute2DCoords(canonOrient=True, clearConfs=True, nFlipsPerSample=0, nSample=0, sampleSeed=0, permuteDeg4Nodes=False, forceRDKit=True, useRingTemplates=False)` na cópia. Não consumir coordenadas 3D como geometria preparada.
- Preparação explícita: `PrepareMolForDrawing(kekulize=False, addChiralHs=False, wedgeBonds=True, forceCoords=False, wavyBonds=False)` na cópia com as coordenadas já geradas. `prepareMolsBeforeDrawing=False` no desenhador para evitar preparação adicional implícita. Mantém-se a representação gráfica de ligações aromáticas, sem exigir uma Kekulé nova.
- Não remover H explícitos; conservar H isotópicos e cargas. Nenhuma simplificação de H é proposta agora. Conferir ausência de mudança de conectividade, isótopos, carga e estereoquímica definida na cópia preparada, além da invariância do Mol de cálculo e dos arquivos. Coordenadas 2D e wedges são apresentação, não publicação de conformero ou novo estado.
- Legenda vazia; nenhum nome, título ou propriedade livre do SDF inserido. Omitir na cópia somente anotações de apresentação (`atomLabel`, `_displayLabel`, `_displayLabelW`, `molFileAlias`, `atomNote`, `bondNote`, `_MolFileRLabel`); não remover propriedades químicas, estereogrupos ou isótopos para fazer a figura passar. Estruturas fora do perfil da §5 falham explicitamente. Desligar includeMetadata e includeAtomTags; sem índices automáticos de átomos/ligações.
- Fonte `Telex-Regular.ttf` já distribuída no RDKit, explicitamente selecionada pelo caminho do pacote, sem fonte externa indicada pelo usuário. Registrar SHA-256 observado e falhar se não disponível; não usar fallback silencioso. [OBSERVED] No ambiente do ensaio seu hash é `eeaa2d17d105b6b46e5368ecd990f5b19c50131ff922dbf79bfb9bb45c249871`; a licença fornecida pelo pacote para Telex é SIL OFL 1.1. O desenho usa contornos, sem carregar fonte ou imagem remota.

**DECISÃO PROPOSTA A-11:** validar o SVG gerado antes de retorná-lo, por um perfil fechado deste produtor, sem pretensão de construir um sanitizador universal. Limitar tamanho e recusar DOCTYPE/ENTITY antes de parsing XML. Exigir raiz SVG e apenas elementos `svg`, `rect`, `path` no namespace SVG observado no ensaio. Rejeitar elemento/atributo inesperado em vez de removê-lo e declarar sucesso.

A allowlist candidata de atributos é a observada: `baseProfile`, `class`, `d`, `fill`, `height`, `style`, `version`, `viewBox`, `width`, `x`, `y`, `xml:space`, mais os quatro atributos próprios `data-state-id`, `data-representation-sha256`, `data-engine-version`, `data-profile`. Valores de identidade vêm de campos validados. `style`/`fill` aceitam somente literais de cor, propriedades estáticas de preenchimento/traço e números do desenho, sem CSS externo, `url(...)`, `@import` ou expressões. Vocabulário candidato fechado: fill/stroke como none ou cor hexadecimal de seis dígitos; opacity/stroke-opacity finitas entre 0 e 1; fill-rule evenodd/nonzero; stroke-width numérica não negativa com unidade px opcional; stroke-linecap butt/round/square; stroke-linejoin miter/round/bevel; stroke-dasharray none ou lista finita de números não negativos; stroke-miterlimit finito e pelo menos 1. Recusar declarações duplicadas, escapes, comentários e qualquer propriedade diferente, sem delegar a um interpretador CSS. Os atributos geométricos aceitam apenas o vocabulário numérico/comandos SVG correspondente, não strings arbitrárias. O rascunho deverá transformar esse perfil em gramática verificável e testes, sem aceitar style irrestrito.

Não permitir script, event handlers, href/xlink:href, image, foreignObject, use, animação ou recursos externos. As URIs de namespaces XML declaradas pelo RDKit não são, por si, acesso a rede: não banir cegamente toda ocorrência de `http` no XML. Os `data-*` fornecem vínculo de origem; não embutir nomes de pessoa, paths ou SD data em markup.

[EXPERIMENTALLY_VERIFIED] Os cinco desenhos e nove sondas estruturais do perfil usaram somente svg/rect/path. Isso fundamenta uma allowlist inicial, não prova cobertura de toda molécula futura. Uma saída legítima que requeira outro elemento deverá falhar de modo claro nesse perfil e motivar revisão explícita; não ampliar a allowlist automaticamente. O validador de produção ainda não existe e não foi testado pelo spike.

Se somente valores forem pedidos, não desenhar. Se figura for pedida e a geração/validação falhar, falhar toda a resposta pedida, sem sucesso parcial ou SVG truncado. Text/JSON sem SVG continuam independentes do desenhador.

## 11. Persistência, repetição, concorrência e falhas

**DECISÃO PROPOSTA A-12:** sem escrita em registries, artefatos, activity log ou diretórios do experimento neste recorte de consulta. Não chamar isso de “workflow persistido” ou de “execução idempotente com reuse”. Duas consultas recalculam; a repetição não cria duplicações porque não publica nada. Nenhuma função existente de logging será alterada.

Uma futura persistência poderá consumir o DTO e sua proveniência, mas precisará de incremento próprio com identidade, create-once, migração, cache/invalidação e publicação composta; esse desenho não é pré-implementado aqui. O resultado atual não garante disponibilidade futura da representação ou do motor: quem precisar reprodutibilidade durável deverá preservar também entradas/perfis/ambiente por mecanismo definido à época.

As leituras usam observações de metadados e bytes verificados; não prometem serialização contra alterações externas nem uma consulta transacional do experimento inteiro. Consultas em processos separados não disputam registro de saída. Não se promete execução paralela thread-safe do adaptador no mesmo processo; o fluxo CLI é síncrono, como o perfil existente, e a supressão de logs RDKit tem efeitos de processo. Não adicionar locks ou correção retroativa de concorrência dos registries do 020.

O leitor fecha recursos em todas as saídas. Não há arquivo de staging próprio para remover na solução escolhida. `try/finally` é apropriado; captura de `BaseException` pode existir exclusivamente para liberar recurso e relançar a mesma interrupção, jamais para traduzi-la em erro científico. CLI não captura BaseException, KeyboardInterrupt ou SystemExit como falha de negócio. Não compensar entidades, estados, transformações, promoções ou attempts existentes.

Preparar toda a resposta antes de escrevê-la. Isso evita sucesso parcial por cálculo/desenho; não promete rollback de um pipe de stdout que falhe durante a escrita. Logs RDKit devem ser suprimidos em escopo local ao parsing/cálculo/desenho quando necessários, com restauração após sucesso, exceção e interrupção; não modificar globalmente os demais comandos. Não criar retries silenciosos de parsing, leitura, engine ou desenho.

## 12. CLI técnica mínima, sem antecipar 020-C

**DECISÃO PROPOSTA A-13:** comando fino, consumindo o serviço exatamente uma vez:

```text
molecular state characterize <experiment_id> --input-state <state_id> --format text
molecular state characterize <experiment_id> --input-state <state_id> --format json
molecular state characterize <experiment_id> --input-state <state_id> --format svg
molecular state characterize <experiment_id> --input-state <state_id> --format json --include-svg
```

Default candidato: `--format text`. `--include-svg` só é aceito com JSON, validado antes do serviço; SVG isolado implica include_svg=True; text não solicita figura. stdout contém só a resposta solicitada: texto completo, um JSON ou um SVG. stderr recebe erros; sucesso 0, falha de negócio 1. Sem mensagens “salvo” ou “registrado”. Não selecionar output path, exportar multifile ou abrir navegador automaticamente.

Proposta de classificação, aproveitando o vocabulário existente sem alterar handlers atuais: argumento/ID inválido → INPUT ERROR; registro YAML/schema/formato/perfil/plataforma não suportado ou engine ausente/incompatível → CONFIGURATION ERROR; arquivo ausente/inacessível, checksum divergente ou substituição detectada → STORAGE ERROR; parsing químico inelegível, descritor ou desenho falho → EXECUTION ERROR. O rascunho deverá nomear exceções específicas e sua precedência. Não mostrar traceback, caminho absoluto ou mensagem arbitrária do motor; preservar state_id válido e razão útil por mensagens controladas da operação nova. Não reutilizar sanitizador de outra operação alterando a saída dos comandos existentes.

O resultado técnico será consumível por uma experiência guiada do 020-C, sem obrigar cientista leigo a decorar comandos internos. Esse futuro cliente não justifica incluir wizard, instalação assistida ou `tbmp init/create/show` agora.

## 13. Evidência independente produzida pelo arquiteto

Classificação desta seção: **EXPERIMENTALLY_VERIFIED**, confiança alta quanto aos casos realmente executados, sem generalização para Windows ou implementação futura.

Ambiente do ensaio: Python 3.12.14/Linux, RDKit 2026.03.6, isolado fora do clone. Não foram executados pytest, o serviço novo, a CLI nova ou leitores novos de produção, pois não existem. Não foram instaladas dependências na plataforma nem alterado o repositório. Os cinco arquivos RAW usados no ensaio do adaptador não foram promovidos pelo serviço da plataforma nesta pesquisa Linux.

| Ensaio | Evidência efetivamente observada | Limite |
|---|---|---|
| Spike preliminar preservado | Cinco SDFs identificados por hash: dez valores, SVG, invariância de arquivo/Mol e round-trip SMILES | Sem prova de acesso Windows ou serviço |
| Reconciliação de APIs | Defaults do supplier, wrappers Lipinski, namespace Crippen e casos discriminantes | Binding instalado, não revisão integral de C++ |
| Novo perfil de parsing | Cinco SDFs reais; 17 casos SMILES; 8 casos SDF sintéticos, incluindo V2000/V3000, multirregistro, inválido+válido e conteúdo extra | Script de pesquisa, não testes da plataforma |
| Novo perfil de desenho | Cinco figuras, nove sondas adicionais de isótopos/carga/estereoquímica/radical, invariância de assinatura estrutural; etiquetas hostis não reapareceram | Não prova validador SVG futuro nem todos os recursos químicos |
| Inspeção visual | Cinco SVGs rasterizados e examinados localmente; H explícitos tornam a figura mais carregada | Sem ensaio de browser Windows |

Valores observados no spike preliminar, não medições nem propriedades importadas do PubChem:

| Entrada | Fórmula | Massa molar g/mol | TPSA Å², S/P=False | cLogP |
|---|---|---:|---:|---:|
| Cafeína | C8H10N4O2 | 194,194 | 61,82 | −1,0293 |
| Ácido rosmarínico | C18H16O8 | 360,318 | 144,52 | 1,7613 |
| Imidacloprido | C9H10ClN5O2 | 255,665 | 83,66 | 0,6879 |
| Diclofenaco | C14H11Cl2NO2 | 296,153 | 49,33 | 4,3641 |
| Atrazina | C8H14ClN5 | 215,688 | 62,73 | 1,7771 |

A prova de preservação no novo desenho compara os átomos/isótopos/cargas e a representação canônica isomérica nos casos examinados; isso não substitui a matriz de testes de estereoquímica do rascunho. Não se deduz igualdade de bytes SVG entre SOs/builds de duas repetições locais iguais.

## 14. Reconciliação dos dois pareceres

Identidades integrais de R1/R2 no manifesto; ambos foram preservados sem edição. “Tratado na proposta” abaixo não significa que o próprio arquiteto encerrou um achado de revisão independente.

| Origem | Item | Encaminhamento desta revisão |
|---|---|---|
| R1 B1 | Ausência dos originais | Corpus pertinente recebido, identidades verificadas, leitura delimitada documentada, originais fornecidos no pacote (§3) |
| R1 M1 | Leitura segura indefinida | A-07/A-08: duas leituras específicas, roots fixas, handle único por arquivo, checks de identidade/checksum, perfil Windows e risco residual (§8) |
| R1 M2 | Sem histórico durável | A-01/A-12: opção A explicitamente escolhida como consulta, proveniência devolvida e nenhuma alegação de histórico (§§1/4/7/11) |
| R1 M3 | Gramática aberta | A-03/A-09 e ensaio delimitado (§§5/9/13) |
| R1 M4 | SVG/H/estereo/segurança | A-10/A-11, preparação explícita sem H quirais extra, fonte conhecida, perfil estático e inspeção (§10) |
| R1 N1 | Massas e m/z | Distinção explícita e unidades (§6) |
| R1 N2 | TPSA S/P | Aceitar default False como escolha documentada; parâmetro no resultado e sondas discriminantes (§6) |
| R1 N3 | Esforço | APIs simples; integração de segurança tem custo real, não prometer esforço total trivial (§16) |
| R2 MINOR-1 | Numeração | Convenção pós-020 proposta, sem deslocar 021; roadmap histórico provisório não prevalece sobre final020 (§2) |
| R2 MINOR-2 | Defaults | Clarificação incorporada; strictParsing=True também é default, contrariando parte factual do próprio parecer (§6) |
| R2 MINOR-3 | HBD por ligação | Correção sugerida rejeitada: wrappers e execução do pin demonstram a equivalência e distinguem NHOHCount (§6) |
| R2 MINOR-4 | BaseException/cleanup | finally ou captura restrita de limpeza com reraise permitidos; nenhuma tradução de interrupção (§11) |
| R2 NOTE-1 | Sais | Limite visível, sem substituição automática ou equivalência científica indevida (§5) |
| R2 NOTE-2 | “Rota B” | Qualificar historicamente Rota B de construção RDKit/016 e snapshot RAW/018; novos leitores recebem nomes próprios, sem renomear contratos antigos (§8) |
| R2 NOTE-3 | Versão | Pin 2026.3.6 e versão 2026.03.6 compatíveis, sem mudança de dependência (§7) |
| R2 NOTE-4 | Gate do leitor | Modelo agora proposto concretamente; prova Windows será requisito de implementação, não evidência já produzida (§§8/15) |
| R2 tabela factual | Crippen.CalcCrippenDescriptors | Namespace corrigido para rdMolDescriptors e ausência da API alegada registrada na evidência (§6) |

## 15. Matriz mínima a derivar no rascunho

Não fixar número artificial de testes nem transformar o spike em suíte de produção. O rascunho deve traduzir as decisões em cenários discriminantes e verificar:

1. Imutabilidade/validação dos DTOs; valores finitos/unidades; ausência de dependência RDKit em imports de domínio, serviço e CLI; --help sem extra.
2. Entradas reais SDF de promoção e SMILES de estado derivado. Leitor de metadata também verificado; state_id solicitado diverge do registro → recusa.
3. Paths absolutos/drive-relative/UNC, ADS, traversal, nomes reservados, reparse points em cada componente, identidade substituída, atributo ausente, tamanho anunciado/efetivo, arquivo regular, checksum inválido/divergente. Cenários de Windows reais para os dois leitores, não só mocks que impõem sucesso.
4. Parsing: gramática completa das §§5/9; inválido antes/depois do válido não escondido; formato extra sem fallback; desconectado/query/dummy/SGroup rejeitado. BOM, codificação, whitespace, CXSMILES e conteúdo extra exercitados no código real.
5. Isótopos, cargas, centros definidos e indefinidos, E/Z, massas média/exata, HBD/HBA versus NHOHCount, Strict discriminante e TPSA S/P. Casos de referência com expectativas justificadas além de chamar o mesmo cálculo duas vezes.
6. SVG: fonte/configuração observadas, sem adição/remoção de H, sem alteração de Mol de cálculo/RAW/representação; copiado label hostil omitido; conteúdo ativo/externo e atributos inesperados rejeitados, inclusive namespace e CSS. Mutação de SVG em testes do validador é fixture de teste, não importação de SVG pelo produto.
7. Erro de SVG não afeta consulta sem figura; figura solicitada falha sem sucesso parcial; JSON/text/SVG completos e stdout limpo; serviço chamado uma vez, sem retry, sem writes/logging/compensação.
8. KeyboardInterrupt e SystemExit separadamente, fechamento do handle e restauração de logs em sucesso/falha/interrupção. Não usar `pytest.raises(Exception)` genérico como prova.
9. Regressão dos contratos 016/017, promoção 018, condições 019 e receptor020; nenhuma escrita científica em uma consulta e nenhum handler existente alterado para acomodá-la.

A necessidade futura de execução Windows é concreta: plataforma/FS, atributos e substituição durante leituras; integração do parser do estado real; aparência do SVG e CLI. Não solicitar agora a Claude um estudo genérico ou implementação antecipada desses componentes.

## 16. Esforço, superfície candidata e checkpoints

**DECISÃO PROPOSTA A-14:** manter o recorte funcional pequeno, sem ampliar para registry de investigação ou framework universal. O aproveitamento das APIs é de baixo esforço relativo; o leitor seguro específico é a parte de integração com esforço moderado. Não prometer que tudo será uma ligação trivial de funções. A escolha dos limites de leitura e SVG é explícita e revisável antes do rascunho.

Superfície candidata, não allowlist congelada: novos DTOs/serviço de caracterização com testes; ampliação aditiva de `rdkit_tautomer.py`, `atomic.py`, `cli.py` e respectivos testes. Sem alteração de schemas persistidos, migração, rename do adaptador ou correção de registries legados fora deste caminho. Sem novo pacote externo; fonte já vem no RDKit existente.

Checkpoints candidatos: (1) perfil/DTOs/adaptador e parsing/desenho; (2) dois leitores específicos e serviço, com testes Windows; (3) CLI técnica, regressões, ensaio de apresentação e revisão cumulativa. Cada etapa só poderá ser implementada após especificação aprovada; esta lista não é um comando para Claude.

## 17. Fontes, proveniência e limites

As fontes primárias do projeto são as cópias originais normativas do pacote e o código fixado em:

`https://github.com/sysoutemanuelhenrique/molecular-platform/tree/08b797e0985e123ffd4d7ca7e5a5e8f040e63851`

A rastreabilidade acompanhante contém links por arquivo, seções consultadas, classes de evidência, identidades e limitações. Scripts/JSON de pesquisa são separados da proposta e da implementação. Não foi criado registro retrospectivo que finja aprovação prévia dos ensaios na governance original; nenhum registry de pesquisa do ZIP foi modificado.

Documentação oficial RDKit: [descritores](https://www.rdkit.org/docs/source/rdkit.Chem.rdMolDescriptors.html), [Lipinski](https://www.rdkit.org/docs/source/rdkit.Chem.Lipinski.html), [desenho](https://www.rdkit.org/docs/source/rdkit.Chem.Draw.rdMolDraw2D.html), [depiction](https://www.rdkit.org/docs/source/rdkit.Chem.rdDepictor.html). Consultada nesta linha de estudo; site identificado como 2026.09.1. Não usar essa versão web como prova automática do pin: existência, defaults e parâmetros efetivamente usados foram confrontados com o binding/source Python instalado 2026.03.6 e execução isolada.

O ensaio não é validação de precisão preditiva de cLogP/TPSA contra laboratório, auditoria integral de licenças, certificação de segurança nem validação cross-platform. A seleção do perfil é proposta de arquitetura informada por fontes, não fato científico universal.

## 18. Gate solicitado aos revisores

Confrontar esta revisão e as fontes primárias, classificar falha contratual separadamente de preferência e decidir se as decisões A-01–A-14 são suficientes para produzir um **rascunho**. Verificar especialmente A-07/A-08 (limite real do leitor), A-09 (gramática e compatibilidade) e A-10/A-11 (SVG e escopo das garantias). A formalização da gramática de atributos/style proposta na §10, nomes de exceções, precedência de erros e cenários de teste pertencem ao rascunho se a direção for aceita; não afirmar que esses pormenores já estão congelados.

Não aprovar implementação, não congelar contrato, não pedir hardening universal, não deslocar 021 nem reabrir 020 sem violação concreta. Se faltar norma decisiva, identificar documento/cláusula e impacto. Se uma API ou número contrariar o pacote, reproduzir no pin ou citar fonte primária correspondente.

ARCHITECTURAL PROPOSAL REVISED: YES
PROPOSAL STATUS: REVISED FOR INDEPENDENT REVIEW
HEAD STUDIED: 08b797e0985e123ffd4d7ca7e5a5e8f040e63851
RECEIVED GOVERNANCE INVENTORIED: YES
INCREMENT 020 SPECIFICATION IDENTITY VERIFIED: YES
CHECKPOINT 4 VALIDATION IDENTITY VERIFIED: YES
ALL HISTORICAL GOVERNANCE REVIEWED: NO
REVIEWER FINDINGS RECONCILED IN PROPOSAL: YES
INDEPENDENT REAPPROVAL OBTAINED: NO
RDKit RESEARCH PROBES EXECUTED: YES
PYTEST EXECUTED IN THIS REVISION: NO
WINDOWS READER VALIDATED: NO
READY FOR REVISED ARCHITECTURAL REVIEW: YES
READY FOR DRAFT SPECIFICATION: NO
READY FOR IMPLEMENTATION: NO
FINAL SPECIFICATION FROZEN: NO
ORIGINAL PROPOSAL AND REVIEWS PRESERVED: YES
CODE REPOSITORY MODIFIED: NO
