# Resposta ao parecer V2 — leia primeiro

Este pacote contém todos os 43 membros do pacote revisado anterior, byte-idênticos, mais a resposta e evidências desta rodada. A proposta V2 não foi substituída; os complementos candidatos C-01/C-02/C-03 estão em INCREMENT_020_A_V2_REVIEW_RESPONSE.md. O arquivo 00_START_HERE.md é a instrução histórica da primeira submissão V2. Para esta resposta delimitada, use o pedido abaixo.

Envie este ZIP completo ao Claude revisor. Encaminhe também ao outro revisor caso ele esteja avaliando a mesma rodada. Nenhum material deve ser enviado ao implementador como ordem de implementar.

## Pedido de fechamento curto

Atue como revisor independente e read-only da resposta ao seu parecer V2 do Incremento020-A. Leia INCREMENT_020_A_V2_REVIEW_RESPONSE.md, supplement/evidence/ e GOVERNANCE_EXCERPTS_FOR_NOTE1.md, confrontando os originais integrais de normative/ quando necessário. Verifique somente: MINOR-1/nSample e MINOR-2/TTF contra a evidência do pin2026.03.6; MINOR-3/C-01; NOTE-1/cláusulas de governança; C-02/algoritmo privado compartilhado; C-03/recusa de DTD e entidades no parser; posicionamento da validação dos leitores Windows no gate de implementação/checkpoint. Não exija implementar os leitores de produção antes de redigir a especificação que os autorizará. Se identificar dúvida de viabilidade realmente bloqueadora, descreva-a e o menor spike necessário. Preserve os pareceres anteriores e classifique qualquer achado novo com evidência. Informe se esta linha de revisão pode avançar para rascunho de especificação, mantendo READY FOR IMPLEMENTATION: NO e FINAL SPECIFICATION FROZEN: NO. Não repita revisão universal nem abra escopo futuro sem violação concreta.

O fechamento deste revisor não substitui o parecer do outro revisor. Devolva os pareceres ao arquiteto nesta conversa. A resposta do arquiteto ainda não é aprovação independente.

## Integridade e reprodução

MANIFEST.json é o manifesto original preservado. SUPPLEMENT_MANIFEST.json cobre os membros atuais, exceto ele próprio, e identifica o ZIP anterior. Scripts de pesquisa não são código de produto. O script novo requer ambiente já preparado, clone fixado e output fora do clone; não instala dependências e não usa rede. Leia o código antes de executá-lo. Não há fonte TTF, wheel, venv ou cópia do repositório neste ZIP.
